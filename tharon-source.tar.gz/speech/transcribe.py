"""Local speech processing. No runtime downloads or third-party audio transmission."""
import json
import os
import sys
from faster_whisper import WhisperModel

model = WhisperModel(os.environ['WHISPER_MODEL_DIR'], device='cpu', compute_type='int8', cpu_threads=2, local_files_only=True)
segments, info = model.transcribe(sys.argv[1], language='en', beam_size=3, vad_filter=True, condition_on_previous_text=False)
print(json.dumps({'text': ' '.join(s.text.strip() for s in segments).strip()}))

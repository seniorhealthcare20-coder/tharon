# Current shared-app implementation

The specification below describes the **original Tab demo**, including its mock REST routes. This build's live
UI uses authenticated `GET /api/state` and `POST /api/commands` with a session cookie and CSRF header.
Commands are allowlisted on the server, checked against lead ownership and record versions, and recorded
with unique idempotency keys. The browser cannot replace database state.

Production document transfer uses `POST /api/files` and authorized `GET /api/files/:id`; export uses
`GET /api/export`. The optional `GET /api/reporting/buildings` endpoint requires REPORTING_TOKEN and returns
aggregate counts only. No `/api/v1` integration or outgoing webhook delivery has been enabled in this release.

Keep the Command Center separate. It may consume aggregate reports later using the same 17 stable building IDs.

---

# Connecting Tharon Leads to your sales system

This explains how the sales system you built in Codex and the leads app exchange data. We don't know your
system's stack yet, so everything here is plain HTTPS and JSON that any stack can call: Node, Python,
Supabase, Firebase, Airtable, Google Sheets with Apps Script, or anything else.

**Sample data only in the demo.** The demo answers these same paths from the browser (Connect & API page, or
`TharonLeadsAPI.request('GET','/api/v1/leads')` in the browser console) so you can see the exact JSON. It has
no server, so nothing is stored outside the browser and no webhook is actually delivered. Real resident data
only flows once the production version runs on HIPAA-eligible hosting with a signed BAA (see CODEX-HANDOFF.md).

## 1. Three ways to connect

Pick one. They can be combined later.

1. **Your system pushes leads in.** Wherever a lead is captured today (your sales tool, a website form, a
   spreadsheet), call `POST /api/v1/leads`. The leads app takes it from there: rep, building, paperwork,
   reminders.
2. **The leads app tells your system what changed.** Register a webhook URL. When a lead is created, changes
   stage, gets assigned to a building, or is missing a document, your system receives an event and updates
   its own records (for example, it books the bed in the building's census when a lead reaches Move-in).
3. **Batch sync.** Export everything as one JSON file (`GET /api/v1/export`) and import it on the other side.
   Good for a nightly sync or a one-time migration.

## 2. Basics

- Base URL (production): `https://<your-host>/api/v1`
- Auth: `Authorization: Bearer <api_token>`. Use one token per connected system, scoped to what it needs.
  Your sales system gets a server-to-server token; staff never see it.
- Format: JSON, UTF-8. Dates are `YYYY-MM-DD`. Timestamps are ISO 8601.
- IDs are strings. When your system already has its own ID for a lead or building, send it as
  `external_id` and the leads app keeps it, so the two systems can match records.
- Errors: `{"error": "<code>", "message": "..."}` with 400, 401, 403, 404, 409 (duplicate), or 422 (validation).
- Every write is recorded in the audit log with who made it (user or API token) and what changed.

## 3. Resources

### Users

`GET /users` returns the staff who can own leads.

```json
{ "data": [ { "id": "u1", "name": "Maria Gonzalez", "role": "rep", "title": "Admissions · Riverside & Bakersfield", "email": "maria@example.com" } ] }
```

Roles: `admin` (sees and edits everything), `rep` (sees and edits own leads). Add `manager` (sees a set of
buildings) in production if you need it.

### Buildings

`GET /buildings`, `GET /buildings/:id`, `PATCH /buildings/:id` (census numbers).

```json
{ "id": "b4", "external_id": "HALLMARK-BAK", "name": "Hallmark of Bakersfield", "city": "Bakersfield, CA",
  "licensed_beds": 99, "occupied_beds": 88, "open_beds": 11, "pipeline_leads": 7, "license_number": "DEMO-1004" }
```

If your sales system is the source of truth for buildings and beds, it owns these records: create them with
your own `external_id`, and update `occupied_beds` from your census. The leads app only reads them and
links leads to them.

### Leads

`GET /leads?rep_id=&building_id=&stage=&updated_since=&q=` · `POST /leads` · `GET /leads/:id` · `PATCH /leads/:id`

```json
{
  "id": "L118",
  "external_id": "SALES-20419",
  "first_name": "Margaret", "last_name": "Silva", "age": 84,
  "contact": { "name": "Paul Silva", "relationship": "Son", "phone": "(555) 010-3118", "email": "paul.s@example.com" },
  "referral_source": "Hospital",
  "referral_detail": "Valley General discharge planner",
  "care_level": "Level 2 · moderate assist",
  "payer": "Private pay",
  "monthly_budget": 6600,
  "desired_move_in": "2026-11-14",
  "assigned_rep_id": "u1",
  "building_id": "b1",
  "stage": "paperwork",
  "lost_reason": null,
  "tour_at": "2026-10-30T10:00",
  "notes": "",
  "created_at": "2026-10-22T10:00", "updated_at": "2026-11-10T16:00", "last_contact_at": "2026-11-10T16:00",
  "paperwork": { "required": 11, "received": 9, "missing": ["lic602a", "agreement"] }
}
```

Field values:

| Field | Values |
|---|---|
| `stage` | `new`, `contacted`, `tour`, `toured`, `assessment`, `paperwork`, `movein`, `lost` |
| `referral_source` | `Hospital`, `SNF`, `Placement agency`, `Web`, `Referral`, `Other` |
| `payer` | `Private pay`, `ALW waiver`, `Long-term care insurance`, `VA Aid & Attendance`, `SSI/SSP`, `Other` |
| `temperature` | `hot`, `warm`, `cold` (open leads; new leads start `hot`) |
| `status` / `close_outcome` | `open`, `closed` / `won` (moved in), `lost` (with a reason) |
| `contact.relationship` | `Self`, `Daughter`, `Son`, `Wife`, `Husband`, ... (free text in production) |

To create a lead, send at least `first_name`, `last_name` and a contact phone or email. Anything else is
optional. The response is `201` with the full lead. A lead whose phone or name matches an open lead returns
`409` with `{"error":"duplicate","existing_id":"..."}` unless you send `"allow_duplicate": true`.

Actions (each writes one activity line and fires a webhook):

- `POST /leads/:id/stage` with `{ "stage": "lost", "lost_reason": "Chose another community" }`
- `PATCH /leads/:id` with `{ "temperature": "warm" }` (answers a check-in)
- `POST /leads/:id/close` with `{ "outcome": "won" }` or `{ "outcome": "lost", "reason": "Chose another facility" }`
  (a reason is required for lost; the lead leaves the active pipeline)
- `POST /leads/:id/reopen` (back to open, Hot, stage contacted or the stage it had before closing)
- `GET /leads?stale=true` lists open leads past their Hot / Warm / Cold inactivity window, with `last_activity_at`,
  `stale` and `checkins_unanswered` on each lead
- `POST /leads/:id/assign` with `{ "building_id": "b4", "assigned_rep_id": "u5" }` (either or both)
- `POST /leads/:id/activities` with `{ "type": "call" | "email" | "text" | "note", "text": "..." }`

`GET /leads/:id` also returns `activity`, newest first.

### Documents (admission paperwork)

`GET /leads/:id/documents` · `PATCH /leads/:id/documents/:key` with `{ "status": "received" | "missing" | "na", "due_date": "2026-11-12" }`

```json
{ "key": "lic602a", "form": "LIC 602A", "name": "Medical Assessment (physician's report)", "required": true,
  "status": "missing", "due_date": "2026-11-12", "requested_at": "2026-11-06", "received_at": null }
```

The checklist (keys): `lic602a` LIC 602A Medical Assessment · `tb` TB test result · `lic603a` LIC 603A Resident
Appraisal · `lic601` LIC 601 Identification and Emergency Information · `agreement` Admission Agreement
(built from LIC 604A) · `lic613c` LIC 613C-2 Personal Rights receipt · `lic627c` LIC 627C Consent for Emergency
Medical Treatment · `lic605a` LIC 605A Release of Medical Information · `lic625` LIC 625 Appraisal / Needs and
Services Plan · `payer` payer proof · `ids` photo ID and insurance cards · `polst` POLST/DNR if any (optional).
Confirm the final packet with your administrator. In production, `POST /leads/:id/documents/:key/file` uploads
the signed PDF to encrypted storage.

### Waiver / Medi-Cal checklist (ALW, CalAIM)

Leads whose payer is `ALW waiver` or `CalAIM Community Supports` get a second checklist. It comes back from the same
`GET /leads/:id/documents` call, each row with `"checklist": "waiver_medi_cal"` (the CDSS forms carry
`"checklist": "cdss_admission"`), plus `source_url` and `verify_with_cca`. Update it with the same
`PATCH /leads/:id/documents/:key`. Keys: `w_assess` Assessment done (CCA / RN assessment, tier) · `w_hcode` H code
(Medi-Cal aid code / eligibility confirmed) · `w_informing` Informing Notice · `w_isp` ISP packet · then the program
steps listed in `site/data.js` WDOCS, each with its DHCS source link. A lead also carries `payer_program`
(`alw` / `calaim` / null), `waiver_tier` (1–5) and `waiver_checklist` (required, received, missing). Missing items fire
`document.missing` with `"checklist": "waiver_medi_cal"`.

### Extraction (no-typing lead capture)

Production only (the demo runs this in the browser, in `site/capture.js`): `POST /extract` with
`{ "transcript": "New lead, ..." }` or `{ "file_id": "..." }` returns a draft lead, never a saved one:

```json
{ "fields": { "first_name": "Eleanor", "last_name": "Whitfield", "age": 86, "contact_name": "Robert Whitfield",
  "contact_relationship": "Son", "contact_phone": "(555) 214-8890", "referral_source": "Hospital",
  "care_level": "Level 2 · moderate assist", "payer": "Long-term care insurance", "desired_move_in": "2026-12-04",
  "building_id": "b2" },
  "confidence": { "first_name": "high", "desired_move_in": "high", "building_id": "low" },
  "detected_forms": [] }
```

`POST /leads/:id/attachments` with `{ "file_id": "...", "checklist_keys": ["lic602a","tb"] }` attaches a stored file
to a lead and marks those items received. The JSON schema is in CODEX-HANDOFF.md, Step 6b.

### Tasks (the Today list)

`GET /tasks?rep_id=u1&date=today` · `POST /tasks` · `PATCH /tasks/:id` with `{ "done": true }`

```json
{ "id": "doc_missing:L118", "type": "doc_missing", "text": "LIC 602A still missing for Margaret Silva: 5 days",
  "lead_id": "L118", "assigned_rep_id": "u1", "severity": "med", "channel": "email", "auto": true, "due_date": "2026-11-11" }
```

Auto tasks come from the reminder rules and disappear on their own when the cause is fixed (the document
arrives, the family is called). Manual tasks are created by people or by your system.

### Export and import

`GET /export` returns everything as one file:

```json
{ "format": "tharon-leads/v1", "exported_at": "2026-11-12T02:30:00Z",
  "users": [...], "buildings": [...], "leads": [ { ...lead, "documents": [...], "activity": [...] } ], "tasks": [...] }
```

`POST /import?mode=merge` takes the same file. `merge` updates leads with a matching `id` or `external_id` and
adds the rest. The demo's Upload page does the same with Import JSON / Export JSON.

## 4. Webhooks

Register one or more endpoints (Connect & API page in the demo, or `POST /webhooks` in production with
`{ "url": "...", "events": ["lead.created", ...] }`). Each event is an HTTPS POST:

```json
{ "id": "evt_1042", "type": "lead.stage_changed", "created_at": "2026-11-12T02:31:07Z",
  "data": { "lead_id": "L118", "from": "paperwork", "to": "movein", "lost_reason": null, "building_id": "b1", "assigned_rep_id": "u1" } }
```

| Event | When | `data` |
|---|---|---|
| `lead.created` | A lead is added by hand, by upload, by the API or from a JSON import | The full lead |
| `lead.stage_changed` | Any stage move | `lead_id`, `from`, `to`, `lost_reason`, `building_id`, `assigned_rep_id` |
| `lead.assigned` | Building or rep changes | `lead_id`, `building_id`, `assigned_rep_id` |
| `lead.temperature_changed` | Hot / Warm / Cold changes, by a person or by auto-cool | `lead_id`, `from`, `to`, `assigned_rep_id` |
| `lead.closed` | Closed as won or lost | `lead_id`, `outcome`, `reason`, `assigned_rep_id`, `building_id` |
| `lead.reopened`, `lead.needs_decision` | Production only (see CODEX-HANDOFF Step 4b): a closed lead reopened; a lead escalated to the admin after 2 unanswered check-ins | `lead_id`, `assigned_rep_id` |
| `document.missing` | A document is marked missing, or a reminder rule finds one still missing (once per day per lead) | `lead_id`, `document`, `form`, `due_date`, `days_missing`, `assigned_rep_id`, `building_id` |

Delivery rules for production:
- Header `X-Tharon-Signature: sha256=<hex>` is the HMAC-SHA256 of the raw body with the endpoint's secret.
  Verify it before trusting the event. `X-Tharon-Event-Id` repeats the event id.
- Answer `2xx` within 10 seconds. Anything else is retried with backoff for 24 hours.
- Events can arrive twice. Use the event `id` to ignore repeats.
- Keep the payload small. If your endpoint doesn't need resident details, subscribe to the IDs and call
  `GET /leads/:id` to fetch what you need. That keeps health information out of logs on both sides.

## 5. Mapping to your sales system

When Codex builds the production version, its first step is to read your project and fill in this table. Until
then, here is what to look for:

| Leads app | Likely in your sales system |
|---|---|
| `buildings` | Your list of facilities, communities or locations |
| `buildings.occupied_beds` | Census or occupancy per building |
| `users` | Your staff or sales team table |
| `leads` | Prospects, inquiries, deals or contacts |
| `leads.stage` | Deal stage or status |
| `leads.building_id` | The facility a deal belongs to |

If both systems already have leads, pick one owner. Usually: the sales system owns buildings and census,
the leads app owns leads, paperwork and tasks, and the two sync through the webhooks above.

## 6. Security notes

- Leads hold health information (care needs, payer, paperwork). Production needs HIPAA-eligible hosting and a
  signed BAA with every vendor that stores or sends it: host, database, file storage, the AI model API, and the
  texting service.
- Use HTTPS only. Never put a resident's name or care details in a URL query string.
- Tokens are per system, revocable, and never committed to code.

# Tharon Leads — separate marketers app

**Reliability repairs are local and not deployed.** Read [the audit and remaining checks](docs/reliability-audit.md) and [the prepared backup runbook](docs/backup-recovery.md) before release. A healthy service or passing unit suite is not staff-workflow acceptance.

A mobile web app for capturing prospective-resident leads, assigning them to one of Tharon's 19 buildings,
tracking activity and closings, and managing admission and ALW/CalAIM paperwork and follow-ups.

This is independent of **Tharon Sales Command Center**. Its original 17 building IDs/names were copied from the
Command Center roster. No census, resident records, financial data, or existing dashboard features were imported
or modified. Live census is not connected.

## Accounts

| Person | Email | Role |
|---|---|---|
| Steven Aron | steven@tharongroup.com | Administrator; all records and settings |
| Morgan Williams | mwilliams@tharongroup.com | Marketer; view all leads, edit own leads and assign any building |
| Olivia Fielder | ofielder@tharongroup.com | Marketer; view all leads, edit own leads and assign any building |
| Gaby Campos | gaby@thepointesummithills.com | Marketer; only assigned Hallmark, Carrington and Pointe buildings |

Accounts are allowlisted, never publicly self-registered. Existing staff sign in directly with work email and password. Steven can set an initial password or reset a staff password in Team; no staff activation link or setup code is needed. Password changes invalidate the staff user's existing sessions and pending invitations. Administrator bootstrap and authenticator verification remain protected. Existing valid token links remain compatible; visiting `/activate` without a token sends users to sign-in, and invalid links show sign-in with recovery instructions. Passwords use scrypt; sessions use HTTP-only cookies with a 30-minute inactivity limit. Permissions are checked on every server operation.

## Run

Requires Node 22.13+ (Node 24 recommended). `npm ci`, then `npm run dev`.
In sample mode, the root and `/login` open a **fictional, browser-local preview**. It has no shared database connection.
For the shared staging workspace, use `/login?staff=1`. The standalone preview can switch between the three user views; that switch is not authentication.

The real server runs with `npm start`. Configure `.env.example` values as environment variables; the app does
not load `.env` automatically. In production it requires PostgreSQL, HTTPS origin, and independent random secrets.
Use the included Dockerfile on Railway; deployment settings are configured on the Railway service. Deployment instructions are in DEPLOYMENT.md.

## Implemented

- Lead capture from typed or transcribed notes; PDF text and scanned PDF, photo OCR, Word, CSV and Excel.
- A review screen before saving; uncertain fields are flagged. Building aliases include Riverside and Bakersfield.
- Mobile voice recording and a local, offline transcription runtime packaged in the Railway Docker image.
- Lead profiles, activities, ownership, required assignments to one of the 19 buildings, a default By building view, prominent building labels, pipeline, hot/warm/cold, won/lost, reopening. New leads cannot be saved without a valid building. CSV imports require a building per row or an explicit batch fallback. Building transfers keep the same profile and activity history.
- Admission and program document checklists, deadlines, and in-app follow-ups.
- Authenticated uploads with AES-256-GCM encryption and authorized downloads of original documents.
- PostgreSQL persistence; SQLite is used only for development and automated integration tests.
- Ordered mutations, idempotency receipts, version-conflict checks and an explicit conflict-review screen.
- Shared-state refresh every 10 seconds and on focus. Unsaved/offline work is held in memory, with a warning before
  closing. **Offline work does not survive closing the page.** Real resident records are not stored in localStorage.
- A daily 7 AM Pacific-or-later reminder pass while the server is running; the Today list also derives follow-ups
  from the current lead data. Phone push reminders can be enabled by each signed-in user; messages contain no resident names. No family email or SMS service is connected.
- A server audit log for authentication, mutations, upload/download, exports and aggregate reporting.
- A read-only, token-protected building-summary endpoint for a future Command Center integration. It contains counts,
  not resident names. It is disabled without REPORTING_TOKEN. The existing Command Center has not been changed.

## Boundaries

`APP_MODE=sample` is the deployment default. `APP_MODE=live` requires `PHI_APPROVED=true` and a separate, empty
production database. A sample database cannot be promoted into a live database. Real-data activation additionally
requires the hosting/service agreements and operating procedures described in DEPLOYMENT.md.

The speech container was built and deployed successfully on Railway. An isolated PostgreSQL acceptance run passed account activation/isolation, atomic import, shared saving, PDF upload/download, service restart, encrypted backup recovery, and local transcription with public audio. Those checks do not substitute for tests on staff phones or inside the deployed Railway container.
Microphone behavior must be tested on the team's actual iPhones. Speech, OCR and rule-based field extraction can
misread names, dates and contact details: review is always required. HEIC depends on the browser's decoding support;
share as JPEG if unsupported. The assistant uses local matching rules, not an external AI model.

The original Tab demo's mock REST API and webhook console are not the production integration surface.
The shared app uses authenticated `/api/commands` and `/api/state`; see INTEGRATION.md for the implementation note.
No external email/SMS, QuickBooks sync or Command Center connection is enabled by this build.

## Validation

`npm test` runs the original parser/domain tests and added server and transport integration tests. Tests cover
role isolation, assignments, lost reasons, conflicts, activation/TOTP, CSRF, duplicate retry protection, encrypted
file access, aggregate reporting, rapid edits, and saved leads surviving a calendar-day change.
Browser QA verified capture/review/profile creation, PDF parsing, building alias matching, and the 17-building roster. Railway app and PostgreSQL are online. Actual staff-phone behavior and push delivery remain unverified. Railway scheduled backups are blocked by the current non-Pro workspace plan; isolated logical backup/restore passed.

The original product handoff is preserved in CODEX-HANDOFF.md as background specification.

## Reliable imports and recovery

Spreadsheet imports in the shared app use a single transaction, validate every row, preserve marketer permissions and reject duplicate retries. The preview remains device-local. The reviewed existing-lead packet is stored separately from source; real resident records must never be added to this repository or demo seed.

`node scripts/backup.mjs create PATH` creates an encrypted logical backup using DATABASE_URL, FILE_ENCRYPTION_KEY and an independent BACKUP_ENCRYPTION_KEY. `node scripts/backup.mjs restore PATH --empty-database` restores only into a separate empty database. Existing data is never overwritten; sessions and activation links are excluded. Store the archive and both recovery keys under company backup controls. This manual capability is not a configured backup schedule.

`node scripts/acceptance.mjs` runs synthetic end-to-end checks against separate empty, loopback-only TEST_DATABASE_URL and TEST_RESTORE_DATABASE_URL PostgreSQL databases. Optional WHISPER_PYTHON, WHISPER_MODEL_DIR and TEST_AUDIO_FILE enable local speech verification. Do not point acceptance tests at the deployed database.

Each lead now shows its current lead owner by full name on cards and profiles, plus original marketer and entry attribution. Reassigning from Morgan to Olivia preserves the original marketer. The server sets these fields at creation; clients cannot rewrite attribution. Administrators can filter by current owner or original marketer. Older records without origin evidence are labelled not recorded rather than guessed.

## Actionable follow-ups and paperwork

Today is a grouped list of leads needing attention, with the owner, building, specific blockers and due dates. One Open lead link takes staff to the existing status controls, paperwork checklist and a simple Next step / Follow up on form. No call or tour logging buttons are exposed. A planned next step appears on its due date; paperwork reminders reflect actual missing/received/N/A statuses. Existing dated tasks and activity history remain supported. The server enforces lead access and version conflicts for updates.

ALW and CalAIM profiles show a compact Assessment completed / Informing Notice / ISP packet / LIC 602A checklist and progress, with synchronized statuses, dates and activity. For CalAIM, Informing Notice and ISP are optional Tharon tracking items whose applicability must be confirmed; they are not presented as universal health-plan requirements.

Branding: the exact uploaded Tharon Group logo is used in desktop, mobile and sign-in headers. The original transparent PNG is copied without alteration.

Approved staff share visibility of all lead profiles and attached documents. Lead ownership and original marketer remain visible. Changes remain restricted to the owner or administrator; team invitations and reassignment remain administrator-only.

### Optional AI profile extraction

`server/extract.mjs` and authenticated `POST /api/extract-lead` support structured AI extraction for new voice and document captures. This connection is disabled by default: no transcript or document text is sent externally unless both `AI_EXTRACTION_ENABLED=true` and a server-only `OPENAI_API_KEY` are configured. The company operator must approve this text-processing service before enabling it; Railway hosting approval alone does not enable it. Add the key directly in the production app's Railway Variables tab, never in chat, browser code, Git or logs. Optional `AI_EXTRACTION_MODEL` defaults to `gpt-4.1-mini`. The client receives only an enabled boolean, never the key. Requests use structured outputs and `store:false`. Validate actual synthetic model output before enabling for staff. Provider failure keeps the transcript available and opens manual review instead of silently creating a profile. Missing or ambiguous fields remain blank; building IDs must come from the roster; assignment and duplicate checks still apply. Local regression tests use a mocked provider and do not prove real model accuracy.

### Marketer building access and lead progress

Building access is enforced on the server for reads, mutations, exports, imports, AI roster context and file downloads. Existing Morgan/Olivia access stays `all`; Gaby defaults to `pointe`, `carrington`, `hallmark`. Any newly configured marketer without an explicit grant defaults to no buildings. Admins edit grants in Team. Startup adds defaults once without overwriting later admin choices. A grant change does not reassign existing lead ownership; admins can reassign a lead if its owner no longer has access.

The profile uses one tour-completed checkbox, assessment status and ALW/CalAIM program controls. Legacy stage keys remain stored for history; the visible pipeline groups early stages under Active. The selected program opens its paperwork tab. The four core tracking items have Not received, Pending, Received/completed, Approved and N/A states. Pending items remain in follow-ups; received/approved items count complete. Program changes preserve each program's previous statuses and do not transfer approval automatically. Approval states are staff-entered tracking, not decisions made by the app. Browser preview QA used fictional data; server isolation tests used separate temporary databases.

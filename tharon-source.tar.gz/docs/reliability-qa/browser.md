# Browser acceptance evidence — local synthetic preview

Checked November 14, 2026 Pacific, continuing repair commit 33262aa4fe481364aba16d864605ba7c559c5f64. Final tested source commit is identified in the delivery. All records were fictional, browser-local sample data. No authenticated production session, database, email sending, configuration change or deployment was used.

| Check | Observation | Scope |
|---|---|---|
| Manual creation | Synthetic Manualcheck saved with Hallmark and private-pay budget 3500.25; profile displayed $3,500.25/month. Before repair, native form validation rejected fractional dollars. | Chrome sample mode |
| Edit and LA paperwork | Same record changed to Bella View / CalAIM and saved. Save-first hint appeared before save. Saved profile exposed Open and fill form, Download fillable PDF, Email signature request. Reopening profile preserved the card. | Chrome sample mode; does not establish production availability |
| Text PDF | Actual PDF.js read 7/7 pages. Taylor Textsample, present only on page 7, appeared in review fields. | Synthetic text.pdf |
| Scanned PDF | Actual Tesseract OCR read 3/3 scanned pages; Jordan Scanexample appeared in review fields. | Synthetic scanned.pdf |
| Mixed PDF | Text cover plus scanned second page processed 2/2. Jordan Scanexample extracted. Initially chose Pointe although document said Hallmark; fixed shared matcher and repeated: Hallmark selected. | Synthetic mixed.pdf |
| Review before saving | Intake opened review rather than saving. Explicit creation saved Jordan; profile editing changed age to 81 and building to Hallmark. Subsequent duplicate review identified Jordan and was dismissed without saving. | Browser-local creation, not server upload |
| Ask confirmation | “Can you move Synthetic Manualcheck to assessment?” showed Proposed and Apply proposed change / Cancel. Apply produced a saved-confirmation message; subsequent profile activity recorded the change. | Chrome sample mode; server checks separately automated |
| Spreadsheet | Sample CSV traversed real parseFile/mapping/preview path. Selected-sheet disclosure and consequential fields visible. Unknown/ambiguous building names correctly blocked import. Fixed stale sample names; reviewed blank-building fallback Hallmark. Imported 5 leads and skipped 1 duplicate. | Sample CSV; serialized multi-sheet XLSX selection tested automatically, not native file picker |
| Leads table | Repaired header/row alignment: 9 headers and 9 cells in first row. | Desktop Chrome |

The screenshot bella-view-paperwork.jpg shows the saved synthetic Bella View referral's paperwork card. No email was sent. Fillable PDF field/storage behavior is covered by existing automated tests; this browser pass verified controls, not a full PDF editing/email-app handoff.

## Reproduction

`node scripts/synthetic-preview.mjs --fixtures docs/reliability-qa/fixtures --host 127.0.0.1 --port 4173`

For managed Sites preview, temporarily point the dev command at that harness, start with `sites-preview start /workspace/sites/tharon-leads-app`, and restore package.json afterward. The harness serves only static sample mode, with fixture buttons calling the existing sample-file intake handler. Do not deploy it, use real files or point it at a database. The normal dev/start commands remain the authenticated server.

## Unverified acceptance

- Native browser/phone file chooser, clipboard and drag/drop: chooser automation stalled. Test fixture buttons supplied fetched File objects to the same intake path; this does not prove picker behavior.
- Authenticated browser reconnect/uncertain-save recovery. Server/transport injected-failure, lost-response, retry, permissions and conflict checks passed automatically on isolated databases.
- Actual iPhone/Safari Home Screen layout, microphone stop/transcription, external email handoff, push delivery, background suspension and overnight resume.
- Real model extraction accuracy; no external AI service or resident data was used here.
- Production source parity and deployment of these repairs.

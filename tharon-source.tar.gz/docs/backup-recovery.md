# Prepared backup and recovery setup — not activated

This is a proposal and tested local tooling, not a production backup schedule. No service, volume, billing, cron or notification configuration was changed.

## Proposed job

- Command: `node scripts/automatic-backup.mjs` from this source checkout.
- Frequency: once daily. For a Railway scheduled worker, proposed cron is `0 11 * * *` UTC (03:00 Pacific standard time / 04:00 daylight time). This requires an approved worker and persistent archive destination. Do not deploy it without approval.
- Environment: `DATABASE_URL` pointing to the intended private database, the existing `FILE_ENCRYPTION_KEY`, an independent `BACKUP_ENCRYPTION_KEY`, absolute `BACKUP_DIRECTORY`, and `BACKUP_RETENTION_DAYS=30`. Provision secrets outside source and chat.
- Archive includes state, users, audit/receipt tables, encrypted original attachments, notification secrets and access revocations. Sessions and invitations are excluded. New v2 archives verify attached-file references, decrypted sizes and SHA-256 hashes during restore. Legacy v1 archives remain readable; their missing revocation history requires private-link rotation before recovery is exposed.
- Archive names are unique, encrypted, mode 0600; incomplete temporary files do not count as successful backups. Retention deletes only expired archives matching this tool's own exact naming pattern after the new archive is written. Unrelated files and the latest successful archive are retained.
- A local volume alone is not disaster recovery. Choose and approve an independent durable copy destination, access controls, capacity, retention and monitoring. No off-host transfer integration was built or enabled.
- Daily backups imply up to 24 hours of data loss. Recovery duration has not been measured on production-sized data.

## Failure reporting

The job exits nonzero and writes `backup-status.json` with an explicit failed status on failure. Successful runs record completion time, archive name and retention result. Logs/status contain no resident data or secrets.

Configure the approved job supervisor to alert an operator on a nonzero exit, `ok:false`, or no completed backup for 36 hours. This external notification route is **not configured or verified**. `ops/tharon-backup.service`, `.timer` and `-failed.service` are optional Linux/systemd templates, not Railway instructions and not installed. Their failure unit writes a journal/syslog error; it does not send an email.

## Recovery drill / incident instructions

1. Select an intact archive and retrieve both recovery keys from approved secret storage. Keep keys separate from archives and never paste them into chat or a shell command history.
2. Provision an isolated, empty target database. Do not point restore at the live database. The restore command rejects occupied targets.
3. Supply the target `DATABASE_URL`, original `FILE_ENCRYPTION_KEY` and backup key through protected environment configuration.
4. Run `node scripts/backup.mjs restore /secure/path/archive.encrypted.json --empty-database`.
5. Verify restored lead counts and attachment counts, sign in again, download and compare original files, verify building access and conflict checks. No sessions or activation links are restored. Review legacy archive warnings before exposing the recovered application.
6. Keep the original production database intact. Approve any cutover separately, after verification and an operator decision. Never automatically overwrite the original database.
7. Repeat the isolated restore drill at least monthly and after changes to backup format, file encryption or schema; record results and timing.

## Evidence

`test/backup.test.mjs` restores an encrypted original and its lead attachment link into an empty SQLite database and rejects damaged archives, wrong keys and occupied targets. `test/reliability-backup-job.test.mjs` covers retention and failure reporting. `scripts/reliability-postgres-drill.sh` creates disposable loopback-only PostgreSQL source/restore databases and verifies the original PDF is downloadable after restore and sign-in.

## Owner decisions still needed

Approve the production job, independent destination, retention/capacity and any cost; provide protected secrets; assign a recovery owner; connect and test failure/staleness alerts; then authorize installation/scheduling and a deployment-environment restore drill. None has been activated by this repair.

# CalAIM county tracking

Process source: Steven's uploaded Tharon Group County Move In Roadmap (two pages), 2026-11-12. Rates and billing amounts are intentionally not implemented. This is an internal task tracker, not a clinical admission or payer eligibility decision system.

Operator clarifications on 2026-11-12:
- Orangewood is El Cajon, San Diego County.
- Ventura and Santa Barbara do not have CalAIM for this operation. Existing referrals are preserved and flagged for program review, not reassigned or deleted.
- Stanislaus follows MasterCare steps like Kern. Its health plan is not inferred to be Anthem.
- The separately supplied ALW Move-In Roadmap is now implemented for all counties except Ventura and Santa Barbara. ALW transition, waitlist, slot, assessment/ISP submission and Informing Notice states are separate from CalAIM authorization/LOA tasks. Estimated wait times are not individual deadlines or promises. Actual placement deadlines are entered from CCA confirmation.

County/location evidence is retained in county-roadmap.js GEO and each canonical building's countySource. Primary sources: community operator websites, CDSS licensing, DHCS's facility roster. Crenshaw matches the licensing report at 5140 Crenshaw Blvd with contact Leon Floyd; Pasadena building counties follow the existing operator-provided city roster. Oxnard's city implies Ventura County; source is a third-party facility address listing. County mappings do not establish payer participation or an individual's eligibility.

Orange's supplied sequence puts authorization steps after move-in. Building acceptance and a staff-confirmed individual CCA arrangement are tracked separately; no automatic permission to admit or bill is issued. Internal assessment/acceptance and document verification steps are Tharon workflow additions, not claims about county law. The unconfirmed agency name and cropped margin note are not encoded.

Migration is versioned and transactional. It adds workflows only to explicitly CalAIM- or ALW-coded leads, preserves old assessment/program status and next actions as legacy context, and never infers building acceptance or documentary approval. Existing saved dates and move-in stages are retained. Program/county transfers archive the prior county workflow and reset confirmation. Migration completion is logged as aggregate counts only.

ALW APS/Ombudsman referrals reveal a specific fast-track letter confirmation step. It is not shown for ordinary community/SNF transitions. Program unknown / Other is flagged for program selection; CCA alone never determines the payer. Pending actions follow the lead when transferred from the prior marketer, while original marketer credit stays unchanged.

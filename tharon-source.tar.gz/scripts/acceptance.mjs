// Synthetic acceptance only. Never point this script at an existing deployment.
import assert from 'node:assert/strict';
import {randomUUID} from 'node:crypto';
import {readFile} from 'node:fs/promises';
import {createApplication} from '../server/index.mjs';
import {openStore} from '../server/store.mjs';
import {createBackup,restoreBackup} from '../server/backup.mjs';
import {totpCode} from '../server/security.mjs';
const source=process.env.TEST_DATABASE_URL,target=process.env.TEST_RESTORE_DATABASE_URL;
for(const value of [source,target]){const url=new URL(value);assert.ok(['127.0.0.1','localhost'].includes(url.hostname),'Acceptance requires isolated local PostgreSQL.');}
assert.notEqual(source,target);
const env={NODE_ENV:'test',APP_MODE:'live',PHI_APPROVED:'true',DATABASE_URL:source,APP_ORIGIN:'',SESSION_SECRET:randomUUID(),FILE_ENCRYPTION_KEY:randomUUID(),ADMIN_SETUP_TOKEN:randomUUID(),TRANSCRIBE_LOCAL:process.env.WHISPER_PYTHON?'true':'false',WHISPER_PYTHON:process.env.WHISPER_PYTHON,WHISPER_MODEL_DIR:process.env.WHISPER_MODEL_DIR};
let app,origin;
const password=randomUUID();
async function start(database=source){app=await createApplication({env:{...env,DATABASE_URL:database},schedule:false});await new Promise(r=>app.server.listen(0,'127.0.0.1',r));origin='http://127.0.0.1:'+app.server.address().port;}
async function call(route,{method='GET',data,cookie,csrf,raw,headers={}}={}){const r=await fetch(origin+route,{method,redirect:'manual',headers:{Origin:origin,...(cookie?{Cookie:cookie}:{}),...(csrf?{'X-CSRF-Token':csrf}:{}),...(data?{'Content-Type':'application/json'}:{}),...headers},body:raw||(data?JSON.stringify(data):undefined)});const text=await r.text();let body;try{body=JSON.parse(text);}catch{body=text;}return {status:r.status,body,cookie:r.headers.get('set-cookie')?.split(';')[0]};}
async function login(email,code){const r=await call('/auth/login',{method:'POST',data:{email,password,code}});assert.equal(r.status,200);return {cookie:r.cookie,csrf:(await call('/api/state',{cookie:r.cookie})).body.csrf};}
try{
 const db=await openStore(source);try{for(const table of ['app_state','users','files'])assert.equal(Number((await db.query(`SELECT COUNT(*) AS n FROM ${table}`))[0].n),0,'Test database must be empty.');}finally{await db.close();}
 await start();
 const setup=await call('/auth/setup',{method:'POST',data:{token:env.ADMIN_SETUP_TOKEN}});assert.equal(setup.status,200);
 assert.equal((await call('/auth/activate',{method:'POST',data:{token:env.ADMIN_SETUP_TOKEN,password,code:totpCode(setup.body.totpSecret)}})).status,200);
 let admin=await login('steven@tharongroup.com',totpCode(setup.body.totpSecret));
 for(const userId of ['u1','u2']){const invite=await call('/api/users',{method:'POST',...admin,data:{userId}});assert.equal(invite.status,201);assert.equal((await call('/auth/activate',{method:'POST',data:{token:invite.body.url.split('#')[1],password}})).status,200);}
 const morgan=await login('mwilliams@tharongroup.com'),olivia=await login('ofielder@tharongroup.com');
 const batch={id:randomUUID(),skipDuplicates:true,records:[{first:'Fictional',last:'Acceptance',building:'sierra',rep:'u1',notes:'Synthetic QA record only.'},{first:'Fictional',last:'Second',building:'hallmark',rep:'u1'}]};
 let imported=await call('/api/import',{method:'POST',...admin,data:batch});assert.equal(imported.status,200);assert.equal(imported.body.imported,2);
 assert.equal((await call('/api/import',{method:'POST',...admin,data:batch})).body.state.leads.length,2);
 const lead=imported.body.state.leads.find(l=>l.last==='Acceptance'),id=lead.id;
 const pdf=await readFile(new URL('../site/samples/sample-hospital-referral.pdf',import.meta.url));
 const uploaded=await call('/api/files',{method:'POST',...morgan,raw:pdf,headers:{'Content-Type':'application/pdf','X-File-Name':'fictional.pdf'}});assert.equal(uploaded.status,201);
 let version=1;
 async function command(op,args,auth=morgan){const r=await call('/api/commands',{method:'POST',...auth,data:{id:randomUUID(),op,args,expectedVersion:version}});assert.equal(r.status,200,JSON.stringify(r.body));version++;return r;}
 await command('attachFile',[id,{...uploaded.body,forms:[]}]);await command('setDoc',[id,'lic602a',{status:'received'}]);await command('setStage',[id,'paperwork']);
 assert.equal((await call('/api/files/'+uploaded.body.id,{...olivia})).status,200);assert.equal((await call('/api/state',{...olivia})).body.state.leads.length,2);
 assert.equal((await call('/api/state',{...morgan})).body.state.leads.length,2);
 await app.close();await start();assert.equal((await call('/api/state',{...morgan})).body.state.leads.length,2,'second session sees persisted records after restart');
 const fileResponse=await fetch(origin+'/api/files/'+uploaded.body.id,{headers:{Cookie:morgan.cookie}});assert.deepEqual(Buffer.from(await fileResponse.arrayBuffer()),pdf);
 await command('closeLead',[id,'won']);await command('reopenLead',[id]);
 const stale=await call('/api/commands',{method:'POST',...admin,data:{id:randomUUID(),op:'updateLead',args:[id,{notes:'This stale edit must be rejected'}],expectedVersion:version-1}});assert.equal(stale.status,409,'second editor cannot overwrite a newer version');
 const health=await call('/health');assert.equal(health.body.launch_ready,false,'launch requires explicit operator acceptance even after accounts activate');
 if(new Date().getHours()>=7){assert.equal(await app.runReminderJob(),true);assert.equal(await app.runReminderJob(),false,'daily reminders do not repeat');}
 const archive=await createBackup(app.store,{backupKey:env.SESSION_SECRET,fileKey:env.FILE_ENCRYPTION_KEY});
 const restore=await openStore(target);try{assert.equal((await restoreBackup(restore,archive,{backupKey:env.SESSION_SECRET,fileKey:env.FILE_ENCRYPTION_KEY})).files,1);}finally{await restore.close();}
 await app.close();await start(target);assert.equal((await call('/api/state',{...morgan})).status,401,'recovered sessions require sign-in');
 admin=await login('steven@tharongroup.com',totpCode(setup.body.totpSecret));assert.equal((await call('/api/state',{...admin})).body.state.leads.length,2);
 const recoveredPDF=await fetch(origin+'/api/files/'+uploaded.body.id,{headers:{Cookie:admin.cookie}});assert.equal(recoveredPDF.status,200);assert.deepEqual(Buffer.from(await recoveredPDF.arrayBuffer()),pdf,'original attachment is downloadable after isolated restore');
 if(process.env.WHISPER_PYTHON){const audio=await readFile(process.env.TEST_AUDIO_FILE);const r=await call('/api/transcribe',{method:'POST',...admin,raw:audio,headers:{'Content-Type':'audio/flac'}});assert.equal(r.status,200,JSON.stringify(r.body));assert.match(r.body.text,/what your country can do for you/i);}
 console.log(JSON.stringify({postgres:true,shared_saving:true,atomic_import:true,shared_staff_visibility:true,pdf_upload_download:true,service_restart:true,encrypted_restore:true,voice:!!process.env.WHISPER_PYTHON,real_resident_data_used:false}));
}finally{if(app)await app.close();}

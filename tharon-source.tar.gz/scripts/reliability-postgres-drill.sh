#!/usr/bin/env bash
# Synthetic, loopback-only drill. Requires preinstalled PostgreSQL; never reads DATABASE_URL.
set -euo pipefail
: "${PG_BIN:?Set PG_BIN to the directory containing initdb and postgres}"
export PG_TEST_PORT="${PG_TEST_PORT:-55444}"
pgdir=$(mktemp -d /tmp/tharon-reliability-drill-XXXXXX)
"$PG_BIN/initdb" -D "$pgdir/cluster" -A trust -U reliability --no-locale > "$pgdir/init.log"
"$PG_BIN/postgres" -D "$pgdir/cluster" -h 127.0.0.1 -p "$PG_TEST_PORT" -c unix_socket_directories= > "$pgdir/server.log" 2>&1 &
pgprocess=$!
trap 'kill "$pgprocess" 2>/dev/null || true; wait "$pgprocess" 2>/dev/null || true; rm -rf "$pgdir"' EXIT
node --input-type=module - <<'JS'
import pg from 'pg';let client;for(let i=0;i<50;i++){try{client=new pg.Client({host:'127.0.0.1',port:Number(process.env.PG_TEST_PORT),user:'reliability',database:'postgres'});await client.connect();break;}catch{await new Promise(r=>setTimeout(r,100));}}for(const name of ['reliability_source','reliability_restore','reliability_faults'])await client.query('CREATE DATABASE '+name);await client.end();
JS
TEST_DATABASE_URL="postgresql://reliability@127.0.0.1:$PG_TEST_PORT/reliability_source" TEST_RESTORE_DATABASE_URL="postgresql://reliability@127.0.0.1:$PG_TEST_PORT/reliability_restore" node scripts/acceptance.mjs
RELIABILITY_TEST_PG="postgresql://reliability@127.0.0.1:$PG_TEST_PORT/reliability_faults" node --test test/reliability-save.test.mjs

import { cpSync,mkdirSync,rmSync,readFileSync,writeFileSync } from 'node:fs';
rmSync('dist',{recursive:true,force:true});mkdirSync('dist');cpSync('site','dist',{recursive:true});
// Hosted preview is deliberately static and cannot reach the Railway production database.
writeFileSync('dist/bootstrap.js','/* Standalone sample preview. No resident data connection. */\n');
const html=readFileSync('dist/index.html','utf8').replace('<strong>Demo</strong> — sample data only','<strong>Private preview</strong> — sample data only');writeFileSync('dist/index.html',html);
console.log('Built standalone sample preview.');

import {readFile,writeFile} from 'node:fs/promises';
import {openStore} from '../server/store.mjs';
import {createBackup,restoreBackup} from '../server/backup.mjs';
const [action,file,confirmation]=process.argv.slice(2);
if(!['create','restore'].includes(action)||!file)throw new Error('Usage: node scripts/backup.mjs create PATH | restore PATH --empty-database');
if(!process.env.DATABASE_URL)throw new Error('Set DATABASE_URL for the intended private database.');
if(action==='restore'&&confirmation!=='--empty-database')throw new Error('Restore only to a separate empty database; pass --empty-database.');
const store=await openStore(process.env.DATABASE_URL),keys={backupKey:process.env.BACKUP_ENCRYPTION_KEY,fileKey:process.env.FILE_ENCRYPTION_KEY};
try{
 if(action==='create'){const archive=await createBackup(store,keys);await writeFile(file,archive,{mode:0o600,flag:'wx'});console.log(JSON.stringify({backup_created:true}));}
 else console.log(JSON.stringify(await restoreBackup(store,await readFile(file,'utf8'),keys)));
}finally{await store.close();}

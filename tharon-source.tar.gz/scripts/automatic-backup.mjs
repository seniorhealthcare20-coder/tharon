// Prepared job only. Nothing schedules this script automatically.
import {mkdir,writeFile,rename,readdir,unlink} from 'node:fs/promises';
import path from 'node:path';import {fileURLToPath} from 'node:url';
import {openStore} from '../server/store.mjs';import {createBackup} from '../server/backup.mjs';
export async function automaticBackup(store,{directory,retentionDays=30,backupKey,fileKey,now=new Date()}){
 if(!path.isAbsolute(directory||'')||!Number.isInteger(retentionDays)||retentionDays<2||retentionDays>3650)throw Error('Set an absolute backup directory and retention between 2 and 3650 days.');
 await mkdir(directory,{recursive:true,mode:0o700});const report=path.join(directory,'backup-status.json'),filename='tharon-'+now.toISOString().replace(/[:.]/g,'-')+'.encrypted.json',destination=path.join(directory,filename),temporary=destination+'.pending';
 try{const archive=await createBackup(store,{backupKey,fileKey});await writeFile(temporary,archive,{flag:'wx',mode:0o600});await rename(temporary,destination);const cutoff=now.getTime()-retentionDays*86400000;let pruned=0;for(const name of await readdir(directory)){const m=/^tharon-(\d{4}-\d\d-\d\dT\d\d)-(\d\d)-(\d\d)-(\d{3})Z\.encrypted\.json$/.exec(name);if(!m)continue;const time=Date.parse(m[1]+':'+m[2]+':'+m[3]+'.'+m[4]+'Z');if(time<cutoff&&name!==filename){await unlink(path.join(directory,name));pruned++;}}
 const status={ok:true,completedAt:now.toISOString(),archive:filename,retentionDays,pruned};await writeFile(report,JSON.stringify(status),{mode:0o600});return status;
 }catch(error){await unlink(temporary).catch(()=>{});await writeFile(report,JSON.stringify({ok:false,failedAt:now.toISOString(),message:'Backup failed; inspect restricted job logs and preserve the previous archives.'}),{mode:0o600});throw Error('Automatic backup failed. No successful-backup status was recorded.');}
}
if(process.argv[1]===fileURLToPath(import.meta.url)){if(!process.env.DATABASE_URL)throw Error('DATABASE_URL is required.');const store=await openStore(process.env.DATABASE_URL);try{console.log(JSON.stringify(await automaticBackup(store,{directory:process.env.BACKUP_DIRECTORY,retentionDays:Number(process.env.BACKUP_RETENTION_DAYS||30),backupKey:process.env.BACKUP_ENCRYPTION_KEY,fileKey:process.env.FILE_ENCRYPTION_KEY})));}finally{await store.close();}}

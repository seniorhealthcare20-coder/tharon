import assert from 'node:assert/strict';
import { Pool } from 'pg';
import { transcribeLocal } from '../server/transcribe.mjs';
const pool=new Pool({connectionString:process.env.DATABASE_URL});
try {
 const state=JSON.parse((await pool.query("SELECT data FROM app_state WHERE id='main'")).rows[0].data);
 assert.equal(state.buildings.length,19);assert.equal(state.users.length,3);assert.equal(state.sample_data,true);
 assert.ok(state.leads.every(l=>state.buildings.some(b=>b.id===l.building)));
 const client=await pool.connect();try{await client.query('BEGIN');await client.query('CREATE TEMP TABLE tharon_runtime_probe (value TEXT) ON COMMIT DROP');await client.query('INSERT INTO tharon_runtime_probe (value) VALUES ($1)',['ok']);assert.equal((await client.query('SELECT value FROM tharon_runtime_probe')).rows[0].value,'ok');await client.query('ROLLBACK');}finally{client.release();}
 console.log(JSON.stringify({postgres:'passed',buildings:state.buildings.length,users:state.users.length,sample_data:state.sample_data,lead_count:state.leads.length}));
 const response=await fetch('https://raw.githubusercontent.com/openai/whisper/main/tests/jfk.flac');assert.ok(response.ok);
 const transcript=await transcribeLocal(Buffer.from(await response.arrayBuffer()),process.env);assert.match(transcript,/what your country can do for you/i);
 console.log(JSON.stringify({deployed_speech:'passed'}));
} finally {await pool.end();}

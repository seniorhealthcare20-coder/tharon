import webpush from 'web-push';
import { hash,seal,unseal,fail } from './security.mjs';
export function validateSubscription(s){
 let u;try{u=new URL(s?.endpoint);}catch{fail(422,'Invalid phone notification subscription.');}
 const vendor=u.hostname==='fcm.googleapis.com'||u.hostname==='updates.push.services.mozilla.com'||u.hostname.endsWith('.push.apple.com');
 if(u.protocol!=='https:'||u.port||u.username||u.password||u.hash||!vendor||s.endpoint.length>4096)fail(422,'This push provider is not supported.');
 if(!/^[\w-]{80,100}$/.test(s.keys?.p256dh||'')||!/^[\w-]{20,30}$/.test(s.keys?.auth||''))fail(422,'Invalid notification keys.');
 return {endpoint:s.endpoint,keys:{p256dh:s.keys.p256dh,auth:s.keys.auth},expirationTime:null};
}
export async function notifications(store,key,audit){
 const keys=await store.transaction(async q=>{const row=(await q('SELECT ciphertext FROM app_secrets WHERE id=$1',['vapid']))[0];if(row)return JSON.parse(unseal(row.ciphertext,key).toString());const k=webpush.generateVAPIDKeys();await q('INSERT INTO app_secrets (id,ciphertext) VALUES ($1,$2)',['vapid',seal(Buffer.from(JSON.stringify(k)),key)]);return k;});
 return {publicKey:keys.publicKey,
  subscribe:async(uid,sub)=>{const safe=validateSubscription(sub);await store.transaction(async q=>{await q('INSERT INTO push_subscriptions (id,user_id,ciphertext) VALUES ($1,$2,$3) ON CONFLICT (id) DO UPDATE SET user_id=excluded.user_id,ciphertext=excluded.ciphertext',[hash(safe.endpoint),uid,seal(Buffer.from(JSON.stringify(safe)),key)]);await audit(q,uid,'notifications.enabled');});},
  unsubscribe:async(uid,endpoint)=>{if(typeof endpoint!=='string')fail(422,'Invalid subscription.');await store.query('DELETE FROM push_subscriptions WHERE id=$1 AND user_id=$2',[hash(endpoint),uid]);},
  send:async summaries=>{for(const row of await store.query('SELECT * FROM push_subscriptions')){const summary=summaries.find(s=>s.user_id===row.user_id);if(!summary?.due)continue;
   try{await webpush.sendNotification(JSON.parse(unseal(row.ciphertext,key).toString()),JSON.stringify({body:'You have follow-ups waiting. Open Tharon Leads to review them.'}),{vapidDetails:{subject:'mailto:steven@tharongroup.com',publicKey:keys.publicKey,privateKey:keys.privateKey},TTL:3600,timeout:10000,topic:'tharon-followups'});await audit(store.query,row.user_id,'reminder.push.sent');}
   catch(e){if([404,410].includes(e.statusCode))await store.query('DELETE FROM push_subscriptions WHERE id=$1',[row.id]);await audit(store.query,row.user_id,'reminder.push.failed');}
  }}
 };
}

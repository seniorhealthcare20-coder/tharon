import {buildings} from './engine.mjs';
import {createHash} from 'node:crypto';
import {seal,unseal} from './security.mjs';

// Sessions and pending activation links are deliberately excluded from recovery.
const tables={
 app_state:['id','data'],users:['id','email','password_hash','totp_secret','activated_at'],
 audit_log:['id','user_id','action','record_id','field_names','created_at'],
 mutation_receipts:['id','user_id','created_at'],import_receipts:['id','user_id','fingerprint','result','created_at'],
 access_revocations:['token_hash','revoked_at'],app_secrets:['id','ciphertext'],push_subscriptions:['id','user_id','ciphertext'],
 files:['id','user_id','name','mime','size','sha256','ciphertext','created_at']
};
const archiveKey=s=>{if(typeof s!=='string'||s.length<32)throw new Error('Set BACKUP_ENCRYPTION_KEY to an independent secret of at least 32 characters.');return createHash('sha256').update(s).digest();};
const fileKeyId=s=>{if(typeof s!=='string'||s.length<32)throw new Error('Set the existing FILE_ENCRYPTION_KEY for this database.');return createHash('sha256').update(s).digest('hex');};
export async function createBackup(store,{backupKey,fileKey}){
 const key=archiveKey(backupKey),file_key_id=fileKeyId(fileKey);
 const data=await store.transaction(async q=>{const out={};for(const [table,columns] of Object.entries(tables))out[table]=await q(`SELECT ${columns.join(',')} FROM ${table}`);return out;});
 return JSON.stringify({format:'tharon-encrypted-backup/v2',ciphertext:seal(Buffer.from(JSON.stringify({created_at:new Date().toISOString(),file_key_id,tables:data})),key)});
}
export async function restoreBackup(store,archive,{backupKey,fileKey}){
 const key=archiveKey(backupKey),file_key_id=fileKeyId(fileKey),outer=JSON.parse(archive);
 if(!['tharon-encrypted-backup/v1','tharon-encrypted-backup/v2'].includes(outer.format))throw new Error('Unsupported backup format.');
 const data=JSON.parse(unseal(outer.ciphertext,key).toString());const legacy=outer.format==='tharon-encrypted-backup/v1';if(legacy&&data.tables&&!data.tables.access_revocations)data.tables.access_revocations=[];
 if(data.file_key_id!==file_key_id)throw new Error('The FILE_ENCRYPTION_KEY does not match this backup.');
 if(!data.tables||Object.keys(data.tables).sort().join()!==Object.keys(tables).sort().join())throw new Error('Incomplete backup.');
 if(data.tables.app_state.length!==1||data.tables.app_state[0].id!=='main')throw new Error('Invalid application state.');
 const state=JSON.parse(data.tables.app_state[0].data);
 if(!Array.isArray(state.buildings)||!state.buildings.length||state.buildings.some(b=>!buildings.some(known=>known.id===b.id))||new Set(state.buildings.map(b=>b.id)).size!==state.buildings.length||!Array.isArray(state.leads))throw new Error('Invalid application data.');
 for(const [table,columns] of Object.entries(tables)){
  if(!Array.isArray(data.tables[table]))throw new Error('Invalid backup table.');
  for(const row of data.tables[table])if(Object.keys(row).sort().join()!==[...columns].sort().join())throw new Error('Invalid backup columns.');
 }
 const decryptKey=createHash('sha256').update(fileKey).digest();
 for(const f of data.tables.files){const bytes=unseal(f.ciphertext,decryptKey);if(bytes.length!==Number(f.size)||createHash('sha256').update(bytes).digest('hex')!==f.sha256)throw new Error('Backup contains a damaged file.');}
 const fileIds=new Set(data.tables.files.map(f=>f.id));for(const l of state.leads)for(const f of l.files||[])if(!fileIds.has(f.id))throw new Error('Backup is missing an attached file.');

 return store.transaction(async q=>{
  for(const table of [...Object.keys(tables),'sessions','invitations'])if(Number((await q(`SELECT COUNT(*) AS n FROM ${table}`))[0].n)!==0)throw new Error('Restore requires a separate empty database. Existing data was not changed.');
  for(const [table,columns] of Object.entries(tables))for(const row of data.tables[table])await q(`INSERT INTO ${table} (${columns.join(',')}) VALUES (${columns.map((_,i)=>'$'+(i+1)).join(',')})`,columns.map(k=>row[k]));
  return {restored:true,leads:state.leads.length,files:data.tables.files.length,sessions_restored:0,warnings:legacy?['Legacy archive: revocations were not backed up. Revoke/rotate private access links before exposing the recovered app.']:[]};
 });
}

import { mkdirSync } from 'node:fs';
import { dirname } from 'node:path';

// Transactions serialize commands. No client is allowed to replace database state.
export async function openStore(url, sqlitePath = '.runtime/tharon.sqlite', {beforeCommit}={}) {
  let db, query, transaction;
  if (url) {
    const { Pool } = await import('pg');
    const pool = new Pool({ connectionString: url, max: 8 });
    query = async (sql, args=[]) => (await pool.query(sql,args)).rows;
    transaction = async fn => {
      const c=await pool.connect();
      try { await c.query('BEGIN'); await c.query("SELECT pg_advisory_xact_lock(880071)");
        const out=await fn(async (sql,args=[]) => (await c.query(sql,args)).rows);
        await beforeCommit?.();await c.query('COMMIT'); return out;
      } catch(e) { await c.query('ROLLBACK'); throw e; } finally { c.release(); }
    };
    db={close:()=>pool.end()};
  } else {
    mkdirSync(dirname(sqlitePath),{recursive:true});
    const { DatabaseSync }=await import('node:sqlite');
    const sqlite=new DatabaseSync(sqlitePath); sqlite.exec('PRAGMA journal_mode=WAL');
    query=async(sql,args=[])=> {
      const s=sqlite.prepare(sql.replace(/\$\d+/g,'?'));
      return s.columns().length?s.all(...args):(s.run(...args),[]);
    };
    let tail=Promise.resolve();
    transaction=fn=>{ const result=tail.then(async()=>{sqlite.exec('BEGIN IMMEDIATE');try{const r=await fn(query);await beforeCommit?.();sqlite.exec('COMMIT');return r;}catch(e){sqlite.exec('ROLLBACK');throw e;}});tail=result.catch(()=>{});return result;};
    db={close:()=>sqlite.close()};
  }
  for(const sql of [
    'CREATE TABLE IF NOT EXISTS app_state (id TEXT PRIMARY KEY, data TEXT NOT NULL)',
    'CREATE TABLE IF NOT EXISTS users (id TEXT PRIMARY KEY, email TEXT UNIQUE NOT NULL, password_hash TEXT, totp_secret TEXT, activated_at TEXT)',
    'CREATE TABLE IF NOT EXISTS sessions (token_hash TEXT PRIMARY KEY, user_id TEXT NOT NULL, expires_at BIGINT NOT NULL, csrf TEXT NOT NULL)',
    'CREATE TABLE IF NOT EXISTS invitations (token_hash TEXT PRIMARY KEY, user_id TEXT NOT NULL, expires_at BIGINT NOT NULL)',
    'CREATE TABLE IF NOT EXISTS audit_log (id TEXT PRIMARY KEY, user_id TEXT NOT NULL, action TEXT NOT NULL, record_id TEXT, field_names TEXT, created_at TEXT NOT NULL)',
    'CREATE TABLE IF NOT EXISTS mutation_receipts (id TEXT PRIMARY KEY, user_id TEXT NOT NULL, created_at TEXT NOT NULL)',
    'CREATE TABLE IF NOT EXISTS import_receipts (id TEXT PRIMARY KEY, user_id TEXT NOT NULL, fingerprint TEXT NOT NULL, result TEXT NOT NULL, created_at TEXT NOT NULL)',
    'CREATE TABLE IF NOT EXISTS app_secrets (id TEXT PRIMARY KEY, ciphertext TEXT NOT NULL)',
    'CREATE TABLE IF NOT EXISTS access_revocations (token_hash TEXT PRIMARY KEY, revoked_at TEXT NOT NULL)',
    'CREATE TABLE IF NOT EXISTS push_subscriptions (id TEXT PRIMARY KEY, user_id TEXT NOT NULL, ciphertext TEXT NOT NULL)',
    'CREATE TABLE IF NOT EXISTS files (id TEXT PRIMARY KEY, user_id TEXT NOT NULL, name TEXT NOT NULL, mime TEXT NOT NULL, size BIGINT NOT NULL, sha256 TEXT NOT NULL, ciphertext TEXT NOT NULL, created_at TEXT NOT NULL)',
  ]) await query(sql);
  return {query,transaction,close:db.close};
}

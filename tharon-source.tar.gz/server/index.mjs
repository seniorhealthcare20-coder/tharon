import http from 'node:http';
import {extractLead,extractionEnabled} from './extract.mjs';
import { readFileSync, statSync } from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { randomUUID, createHash, createHmac, timingSafeEqual } from 'node:crypto';
import {prepareLibertanaPDF} from './libertana-pdf.mjs';
import { notifications } from './notifications.mjs';
import { transcribeLocal } from './transcribe.mjs';
import { openStore } from './store.mjs';
import { token,hash,passwordHash,passwordOK,seal,unseal,totpSecret,totpOK,fail } from './security.mjs';
import { users,buildings,initialState,scoped,execute,engine,buildingAccess,migrateCountyRoadmaps,libertana } from './engine.mjs';
import { importLeads } from './import.mjs';
import {correctStaffPrograms} from './program-corrections.mjs';
import {applyConfirmedMoveIn} from './confirmed-movein.mjs';
import {readTeamActivity} from './team-activity.mjs';

const ROOT=path.resolve(path.dirname(fileURLToPath(import.meta.url)),'..');
export async function createApplication(options={}) {
 const env={...process.env,...options.env},production=env.NODE_ENV==='production';
 process.env.TZ='America/Los_Angeles';
 const mode=env.APP_MODE||'sample',live=mode==='live',sample=mode==='sample';
 if(!['sample','setup','live'].includes(mode))throw new Error('Choose sample, setup or live mode.');
 if(production&&(!env.DATABASE_URL||!env.APP_ORIGIN||!env.SESSION_SECRET||!env.FILE_ENCRYPTION_KEY))throw new Error('Production requires database, origin, session and encryption settings.');
 if(live&&env.PHI_APPROVED!=='true')throw new Error('Live mode requires the real-data approval setting.');
 if(production&&(env.SESSION_SECRET.length<32||env.FILE_ENCRYPTION_KEY.length<32))throw new Error('Use independent random secrets of at least 32 characters.');
 const sessionHash=t=>createHmac('sha256',env.SESSION_SECRET||'local-tests-only-session-key').update(t).digest('hex');
 const key=createHash('sha256').update(env.FILE_ENCRYPTION_KEY||'local-tests-only-encryption-key').digest();
 const store=options.store||await openStore(env.DATABASE_URL,env.SQLITE_PATH||path.join(ROOT,'.runtime/tharon.sqlite'));
 await store.transaction(async q=>{
  await q('INSERT INTO app_state (id,data) VALUES ($1,$2) ON CONFLICT (id) DO NOTHING',['main',JSON.stringify(initialState(sample))]);
  const existing=JSON.parse((await q('SELECT data FROM app_state WHERE id=$1',['main']))[0].data);if(!sample&&existing.sample_data!==false)throw new Error('Use an empty, separate production database. Sample data cannot be enabled as live data.');
  const knownBuildings=new Set((existing.buildings||[]).map(b=>b.id));
  const additions=buildings.filter(b=>!knownBuildings.has(b.id));
  existing.buildings=[...(existing.buildings||[]),...additions];
  const savedBella=existing.buildings.find(b=>b.id==='bellevue'),canonicalBella=buildings.find(b=>b.id==='bellevue');
  const renamed=savedBella&&canonicalBella&&(savedBella.name!==canonicalBella.name||savedBella.short!==canonicalBella.short||canonicalBella.aliases.some(a=>!savedBella.aliases?.includes(a)));
  if(renamed){savedBella.name=canonicalBella.name;savedBella.short=canonicalBella.short;savedBella.aliases=[...new Set([...(savedBella.aliases||[]),...canonicalBella.aliases])];}
  const knownUsers=new Set((existing.users||[]).map(u=>u.id)),newUsers=users.filter(u=>!knownUsers.has(u.id));
  existing.users=[...(existing.users||[]),...newUsers];
  const accessAdded=existing.users.some(u=>!Object.hasOwn(u,'buildingAccess'));for(const u of existing.users)if(!Object.hasOwn(u,'buildingAccess'))u.buildingAccess=users.find(x=>x.id===u.id)?.buildingAccess||[];
  const reminderBefore=JSON.stringify(existing.checkin);const geoBefore=JSON.stringify(existing.buildings),countyUpdated=migrateCountyRoadmaps(existing),geoUpdated=geoBefore!==JSON.stringify(existing.buildings);
  const staffPrograms=sample?null:correctStaffPrograms(existing);
  if(staffPrograms)await q('INSERT INTO audit_log (id,user_id,action,record_id,field_names,created_at) VALUES ($1,$2,$3,$4,$5,$6)',[randomUUID(),'u0','staff_programs.corrected','main',JSON.stringify(['payer','countyWorkflow','programCorrection','programCorrectionReview']),new Date().toISOString()]);
  const confirmedMoveIn=sample?null:applyConfirmedMoveIn(existing);
  if(confirmedMoveIn?.applied)await q('INSERT INTO audit_log (id,user_id,action,record_id,field_names,created_at) VALUES ($1,$2,$3,$4,$5,$6)',[randomUUID(),'u0','operator.movein_confirmed','main',JSON.stringify(['stage','closedAt','closeOutcome','moveInDateUnconfirmed']),new Date().toISOString()]);
  if(confirmedMoveIn?.applied||staffPrograms||additions.length||renamed||newUsers.length||accessAdded||countyUpdated||geoUpdated||reminderBefore!==JSON.stringify(existing.checkin)){existing.revision=(existing.revision||0)+1;await q('UPDATE app_state SET data=$1 WHERE id=$2',[JSON.stringify(existing),'main']);}
  if(countyUpdated)await q('INSERT INTO audit_log (id,user_id,action,record_id,field_names,created_at) VALUES ($1,$2,$3,$4,$5,$6)',[randomUUID(),'system','county_roadmap.migrated','main',JSON.stringify(['countyWorkflow']),new Date().toISOString()]);
  console.info(JSON.stringify({event:'county_roadmap_migration',version:1,programLeadsUpdated:countyUpdated,calAIMTotal:existing.leads.filter(l=>l.payer==='CalAIM Community Supports').length,alwTotal:existing.leads.filter(l=>l.payer==='ALW waiver').length}));
  if(confirmedMoveIn)console.info(JSON.stringify({event:'operator_confirmed_movein',...confirmedMoveIn}));
  if(staffPrograms)console.info(JSON.stringify({event:'staff_program_corrections',version:2,...staffPrograms}));
  for(const u of users)await q('INSERT INTO users (id,email) VALUES ($1,$2) ON CONFLICT (id) DO NOTHING',[u.id,u.email]);
 });
 const json=(res,status,body,extra={})=>{res.writeHead(status,{'Content-Type':'application/json; charset=utf-8',...extra});res.end(JSON.stringify(body));};
 const transactionJSON=async(res,status,fn,extra={})=>{const result=await store.transaction(fn);return json(res,status,result,extra);};
 const audit=async(q,uid,action,id='',fields=[])=>q('INSERT INTO audit_log (id,user_id,action,record_id,field_names,created_at) VALUES ($1,$2,$3,$4,$5,$6)',[randomUUID(),uid,action,id,JSON.stringify(fields),new Date().toISOString()]);
 const push=await notifications(store,key,audit);
 const readState=async q=>JSON.parse((await q('SELECT data FROM app_state WHERE id=$1',['main']))[0].data);
 const writeState=async(q,s)=>q('UPDATE app_state SET data=$1 WHERE id=$2',[JSON.stringify(s),'main']);
 async function body(req,max=1024*1024){let size=0,chunks=[];for await(const c of req){size+=c.length;if(size>max)fail(413,'That file or request is too large.');chunks.push(c);}return Buffer.concat(chunks);}
 async function payload(req){try{return JSON.parse((await body(req)).toString());}catch(e){if(e.status)throw e;fail(400,'Invalid request.');}}
 function sameOrigin(req){const expected=env.APP_ORIGIN||`http://${req.headers.host}`;if(req.headers.origin!==expected)fail(403,'Open the app and try again.');}
 const isAdmin=id=>users.find(u=>u.id===id)?.role==='admin';
 async function delegateAvailable(){return live&&/^[a-f0-9]{64}$/.test(env.DELEGATE_ACCESS_HASH||'')&&Number.isFinite(Date.parse(env.DELEGATE_ACCESS_EXPIRES_AT))&&Date.now()<Date.parse(env.DELEGATE_ACCESS_EXPIRES_AT)&&!(await store.query('SELECT token_hash FROM access_revocations WHERE token_hash=$1',[env.DELEGATE_ACCESS_HASH])).length;}
 async function session(req){const raw=(req.headers.cookie||'').split(';').map(x=>x.trim()).find(x=>x.startsWith('tl_session='))?.slice(11);if(!raw)return null;const s=(await store.query('SELECT * FROM sessions WHERE token_hash=$1',[sessionHash(raw)]))[0];if(!s||Number(s.expires_at)<Date.now())return null;if(s.user_id==='u4'&&(!await delegateAvailable()||!s.csrf.startsWith(env.DELEGATE_ACCESS_HASH+'.')))return null;return s;}
 async function signedIn(req){const s=await session(req);if(!s)fail(401,'Please sign in again.');if(req.method!=='GET'){sameOrigin(req);if(req.headers['x-csrf-token']!==s.csrf)fail(403,'Refresh the app and try again.');}if(req.method!=='GET')await store.query('UPDATE sessions SET expires_at=$1 WHERE token_hash=$2',[Date.now()+30*60000,s.token_hash]);return s;}
 const rates=new Map();
 function throttle(key){const now=Date.now(),v=rates.get(key)||{n:0,start:now};if(now-v.start>15*60000){v.n=0;v.start=now;}v.n++;rates.set(key,v);if(rates.size>5000)for(const[k,r]of rates)if(now-r.start>15*60000)rates.delete(k);if(v.n>15)fail(429,'Too many attempts. Wait 15 minutes before trying again.');}
 async function invitation(q,t){if(typeof t!=='string'||t.length<24)fail(403,'This setup link is invalid or expired.');if((!env.ADMIN_SETUP_EXPIRES_AT||Date.now()<Date.parse(env.ADMIN_SETUP_EXPIRES_AT))&&env.ADMIN_SETUP_TOKEN&&t.length===env.ADMIN_SETUP_TOKEN.length&&timingSafeEqual(Buffer.from(t),Buffer.from(env.ADMIN_SETUP_TOKEN))){const u=(await q('SELECT * FROM users WHERE id=$1',['u0']))[0];if(!u.password_hash)return u;}
 const i=(await q('SELECT * FROM invitations WHERE token_hash=$1',[hash(t)]))[0];if(!i||Number(i.expires_at)<Date.now())fail(403,'This setup link is invalid or expired.');const u=(await q('SELECT * FROM users WHERE id=$1',[i.user_id]))[0];if(u.password_hash)fail(403,'This account is already activated.');return u;}
 async function stateFor(s){return await store.transaction(async q=>{const state=await readState(q);return {state:scoped(state,s.user_id),csrf:s.csrf,mode,extractionEnabled:extractionEnabled(env),voiceEnabled:(env.TRANSCRIBE_LOCAL==='true'||env.TRANSCRIBE_URL)?'configured':'unconfigured'};});}
 const mime={'.html':'text/html; charset=utf-8','.js':'text/javascript; charset=utf-8','.css':'text/css; charset=utf-8','.png':'image/png','.jpg':'image/jpeg','.pdf':'application/pdf','.webmanifest':'application/manifest+json','.gz':'application/gzip','.wasm':'application/wasm','.docx':'application/vnd.openxmlformats-officedocument.wordprocessingml.document'};
 function staticFile(res,file){try{if(!statSync(file).isFile())fail(404,'Not found.');res.writeHead(200,{'Content-Type':mime[path.extname(file)]||'application/octet-stream'});res.end(readFileSync(file));}catch(e){if(e.status)throw e;fail(404,'Not found.');}}
 const server=http.createServer(async(req,res)=>{
  res.setHeader('Cache-Control','no-store');res.setHeader('X-Content-Type-Options','nosniff');res.setHeader('Referrer-Policy','no-referrer');res.setHeader('X-Frame-Options','DENY');res.setHeader('Permissions-Policy','camera=(self), microphone=(self), geolocation=()');
  res.setHeader('Content-Security-Policy',"default-src 'self'; script-src 'self' 'wasm-unsafe-eval'; style-src 'self' 'unsafe-inline'; img-src 'self' blob: data:; media-src 'self' blob:; worker-src 'self' blob:; connect-src 'self'; frame-ancestors 'none'; base-uri 'self'; form-action 'self'");
  if(production)res.setHeader('Strict-Transport-Security','max-age=31536000; includeSubDomains');
  try{
   const url=new URL(req.url,'http://localhost'),p=url.pathname;
   if(p==='/health'){
    const required=users.filter(u=>u.authType!=='private_link'),active=live?(await store.query('SELECT id FROM users WHERE password_hash IS NOT NULL')).filter(u=>required.some(r=>r.id===u.id)).length:0;
    return json(res,200,{ok:true,app:'tharon-leads',mode,launch_ready:live&&active===required.length&&env.LAUNCH_ACCEPTED==='true'});
   }
   if(p==='/brand/tharon-group.png')return staticFile(res,path.join(ROOT,'site/brand/tharon-group.png'));
   if(p==='/manifest.webmanifest'){
    const manifest=JSON.parse(readFileSync(path.join(ROOT,'site/manifest.webmanifest'),'utf8'));
    return json(res,200,{...manifest,id:'/',name:'Tharon Leads',description:'Tharon Group staff leads and follow-ups',start_url:'/',scope:'/'},{'Content-Type':'application/manifest+json'});
   }
   if(/^\/icons\/(?:favicon-64|apple-touch-icon|icon-192|icon-512|icon-maskable-512|tharon-symbol-192|tharon-symbol-512|tharon-symbol-maskable-512|tharon-symbol-apple|tharon-symbol-favicon|tharon-symbol-white-(?:192|512|maskable-512|apple|favicon))\.png$/.test(p))return staticFile(res,path.join(ROOT,'site',p.slice(1)));
   // Open the isolated, browser-only sample app without granting database access.
   if(sample&&(p==='/'||p==='/login')&&!await session(req)&&url.searchParams.get('staff')!=='1'){
    res.writeHead(302,{Location:'/preview/'});return res.end();
   }
   if(['/login','/activate','/login.js','/auth.css'].includes(p))return staticFile(res,path.join(ROOT,'site',p==='/login'||p==='/activate'?'login.html':p.slice(1)));
   if(p==='/access'||p==='/access.js')return staticFile(res,path.join(ROOT,'site',p==='/access'?'access.html':'access.js'));
   if(p.startsWith('/auth/')){
    if(req.method!=='POST')fail(405,'Use POST.');sameOrigin(req);const b=await payload(req);throttle(req.socket.remoteAddress+':auth');
    if(p==='/auth/access'){
     if(typeof b.token!=='string'||! /^[a-f0-9]{64}$/.test(b.token)||!await delegateAvailable()||!timingSafeEqual(Buffer.from(hash(b.token),'hex'),Buffer.from(env.DELEGATE_ACCESS_HASH,'hex')))fail(403,'This private access link is invalid, expired, or revoked. Ask Steven for a new link.');
     const t=token(),csrf=env.DELEGATE_ACCESS_HASH+'.'+token();await store.transaction(async q=>{await q('INSERT INTO sessions (token_hash,user_id,expires_at,csrf) VALUES ($1,$2,$3,$4)',[sessionHash(t),'u4',Math.min(Date.now()+30*60000,Date.parse(env.DELEGATE_ACCESS_EXPIRES_AT)),csrf]);await audit(q,'u4','login');});
     return json(res,200,{ok:true},{'Set-Cookie':`tl_session=${t}; Path=/; HttpOnly; SameSite=Strict${production?'; Secure':''}; Max-Age=28800`});
    }
    if(p==='/auth/setup')return await transactionJSON(res,200,async q=>{const u=await invitation(q,b.token),profile=users.find(x=>x.id===u.id);let secret;
     if(profile.role==='admin'){if(u.totp_secret)secret=unseal(u.totp_secret,key).toString();else{secret=totpSecret();await q('UPDATE users SET totp_secret=$1 WHERE id=$2',[seal(Buffer.from(secret),key),u.id]);}}
     return {name:profile.name,email:profile.email,role:profile.role,totpSecret:secret};});
    if(p==='/auth/activate')return await transactionJSON(res,200,async q=>{const u=await invitation(q,b.token);if(typeof b.password!=='string'||b.password.length<14||b.password.length>200)fail(422,'Choose a password of at least 14 characters.');
     if(u.id==='u0'&&(!u.totp_secret||!totpOK(unseal(u.totp_secret,key).toString(),b.code)))fail(422,'Enter the current code from your authenticator.');
     await q('UPDATE users SET password_hash=$1,activated_at=$2 WHERE id=$3',[passwordHash(b.password),new Date().toISOString(),u.id]);await q('DELETE FROM invitations WHERE user_id=$1',[u.id]);await audit(q,u.id,'account.activated');return {ok:true};});
    if(p==='/auth/login'){
     if(typeof b.email!=='string'||typeof b.password!=='string'||b.password.length>200)fail(401,'Email, password, or verification code is incorrect.');
     throttle('login:'+hash(b.email.toLowerCase()));const u=(await store.query('SELECT * FROM users WHERE email=$1',[b.email.toLowerCase().trim()]))[0];
     if(!u||!passwordOK(b.password,u.password_hash)||(u.id==='u0'&&(!u.totp_secret||!totpOK(unseal(u.totp_secret,key).toString(),b.code))))fail(401,'Email, password, or verification code is incorrect.');
     const t=token(),csrf=token();await store.transaction(async q=>{await q('INSERT INTO sessions (token_hash,user_id,expires_at,csrf) VALUES ($1,$2,$3,$4)',[sessionHash(t),u.id,Date.now()+30*60000,csrf]);await audit(q,u.id,'login');});
     return json(res,200,{ok:true},{'Set-Cookie':`tl_session=${t}; Path=/; HttpOnly; SameSite=Strict${production?'; Secure':''}; Max-Age=28800`});
    } fail(404,'Not found.');
   }
   // The preview uses only fictional leads and cannot talk to the live API.
   if(sample&&(p==='/preview'||p.startsWith('/preview/'))){if(p==='/preview'){res.writeHead(302,{Location:'/preview/'});return res.end();}const relative=p==='/preview/'?'index.html':p.slice(9);if(relative==='bootstrap.js'){res.writeHead(200,{'Content-Type':'text/javascript'});return res.end('');}const file=path.resolve(ROOT,'site',relative);if(!file.startsWith(path.join(ROOT,'site')+path.sep))fail(404,'Not found.');return staticFile(res,file);}
   if(mode==='setup'&&['/api/commands','/api/import','/api/files','/api/transcribe','/api/extract-lead'].includes(p))fail(403,'Staff setup is open. Lead capture will open after the live launch checks are complete.');
   if(p==='/api/reporting/buildings'){
    if(!env.REPORTING_TOKEN||req.headers.authorization!==`Bearer ${env.REPORTING_TOKEN}`)fail(401,'Unauthorized.');
    return await transactionJSON(res,200,async q=>{const s=await readState(q),tl=engine(s,'u0');const data=buildings.map(b=>{const ls=s.leads.filter(l=>l.building===b.id),stats=tl.pipelineStats(ls);return {id:b.id,name:b.name,open:stats.open,stale:stats.stale,won_this_month:stats.wonMonth,lost_this_month:stats.lostMonth,by_stage:Object.fromEntries(tl.STAGES.map(([k])=>[k,ls.filter(l=>l.stage===k).length]))};});await audit(q,'command-center','reporting.read');return {generated_at:new Date().toISOString(),sample_data:!live,buildings:data};});
   }
   const s=await session(req);
   if(!s&&p==='/'&&!production&&env.NODE_ENV!=='test'&&!env.ADMIN_SETUP_TOKEN){res.writeHead(302,{Location:'/preview/'});return res.end();}
   if(!s){if(p.startsWith('/api/')||p==='/bootstrap.js')fail(401,'Please sign in.');res.writeHead(302,{Location:p==='/voice-test'||p==='/voice-test.html'?'/login?next=%2Fvoice-test':'/login'});return res.end();}
   if(p==='/bootstrap.js'){const result=await stateFor(s);res.writeHead(200,{'Content-Type':'text/javascript'});return res.end('window.TL_BOOT='+JSON.stringify(result).replace(/</g,'\\u003c')+';');}
   if(p==='/api/admin/activity'){const a=await signedIn(req);if(req.method!=='GET')fail(405,'Use GET.');if(users.find(u=>u.id===a.user_id)?.role!=='admin')fail(403,'Administrator only.');return await transactionJSON(res,200,async q=>await readTeamActivity(q,await readState(q)),{'Cache-Control':'no-store'});}
   if(p==='/api/admin/delegate-access'){const a=await signedIn(req);if(!isAdmin(a.user_id))fail(403,'Administrator only.');if(req.method==='GET')return json(res,200,{active:!!await delegateAvailable(),email:'efrain@tharongroup.com',expiresAt:env.DELEGATE_ACCESS_EXPIRES_AT||null});if(req.method!=='DELETE')fail(405,'Use GET or DELETE.');if(env.DELEGATE_ACCESS_HASH)await store.transaction(async q=>{await q('INSERT INTO access_revocations (token_hash,revoked_at) VALUES ($1,$2) ON CONFLICT (token_hash) DO NOTHING',[env.DELEGATE_ACCESS_HASH,new Date().toISOString()]);await q('DELETE FROM sessions WHERE user_id=$1',['u4']);await audit(q,a.user_id,'access.revoked','u4');});return json(res,200,{ok:true});}
   if(p==='/api/state'){const a=await signedIn(req);if(req.method!=='GET')fail(405,'Use GET.');return json(res,200,await stateFor(a));}
   const packetMatch=/^\/api\/leads\/([^/]+)\/libertana\/packet\.pdf$/.exec(p);
   if(packetMatch){
    const a=await signedIn(req);if(req.method!=='GET')fail(405,'Use GET.');
    const state=await store.transaction(readState),visible=scoped(state,a.user_id),lead=visible.leads.find(l=>l.id===decodeURIComponent(packetMatch[1]));
    if(!lead||!libertana.applicable(lead,visible.buildings.find(b=>b.id===lead.building)))fail(404,'Packet not found.');
    const bytes=await prepareLibertanaPDF(libertana.values(lead),lead.libertana?.pdfFields||{}),name=('Libertana_'+lead.first+'_'+lead.last+'_for_signature.pdf').replace(/[^a-zA-Z0-9_.-]/g,'_');
    await audit(store.query,a.user_id,'libertana.packet_viewed',lead.id);
    res.writeHead(200,{'Content-Type':'application/pdf','Content-Disposition':`inline; filename="${name}"`});return res.end(bytes);
   }
   if(p==='/api/push/key'){await signedIn(req);if(req.method!=='GET')fail(405,'Use GET.');return json(res,200,{publicKey:push.publicKey});}
   if(p==='/api/push/subscribe'){const a=await signedIn(req);if(req.method!=='POST')fail(405,'Use POST.');await push.subscribe(a.user_id,await payload(req));return json(res,200,{ok:true});}
   if(p==='/api/push/unsubscribe'){const a=await signedIn(req);if(req.method!=='POST')fail(405,'Use POST.');await push.unsubscribe(a.user_id,(await payload(req)).endpoint);return json(res,200,{ok:true});}
   if(p==='/api/activity'){await signedIn(req);if(req.method!=='POST')fail(405,'Use POST.');return json(res,200,{ok:true});}
   if(p==='/api/logout'){const a=await signedIn(req);if(req.method!=='POST')fail(405,'Use POST.');await store.query('DELETE FROM sessions WHERE token_hash=$1',[a.token_hash]);return json(res,200,{ok:true},{'Set-Cookie':'tl_session=; Path=/; HttpOnly; SameSite=Strict; Max-Age=0'});}
   if(p==='/api/commands'){
    const a=await signedIn(req);if(req.method!=='POST')fail(405,'Use POST.');const b=await payload(req);if(typeof b.id!=='string'||!/^[\w-]{8,80}$/.test(b.id))fail(422,'Invalid action ID.');
    return await transactionJSON(res,200,async q=>{const old=await readState(q),receipt=(await q('SELECT user_id FROM mutation_receipts WHERE id=$1',[b.id]))[0];if(receipt){if(receipt.user_id!==a.user_id)fail(409,'Action ID already used.');return {state:scoped(old,a.user_id)};}
     if(b.op==='attachFile'){const file=b.args?.[1];if(!file?.id)fail(422,'Upload the file before attaching it.');const stored=(await q('SELECT * FROM files WHERE id=$1',[file.id]))[0];if(!stored||(!isAdmin(a.user_id)&&stored.user_id!==a.user_id&&!old.leads.find(l=>l.id===b.args?.[0])?.files?.some(f=>f.id===file.id)))fail(404,'File not found.');b.args[1]={id:stored.id,name:stored.name,type:stored.mime,size:Number(stored.size),forms:file.forms||[]};}
     const next=execute(old,a.user_id,b);if(b.op==='updateLead'&&b.args?.[1]?.libertana?.pdfFields&&Object.keys(b.args[1].libertana.pdfFields).length){const candidate=next.leads.find(l=>l.id===b.args[0]);try{await prepareLibertanaPDF(libertana.values(candidate),candidate.libertana.pdfFields);}catch{fail(422,'One of the PDF fields is invalid. Review the entries and try saving again.');}}await writeState(q,next);await q('INSERT INTO mutation_receipts (id,user_id,created_at) VALUES ($1,$2,$3)',[b.id,a.user_id,new Date().toISOString()]);await audit(q,a.user_id,b.op,b.createdId||String(b.args?.[0]?.id||b.args?.[0]||''),b.op==='updateLead'?Object.keys(b.args[1]):[]);return {state:scoped(next,a.user_id)};
    });
   }
   if(p==='/api/import'){
    const a=await signedIn(req);if(req.method!=='POST')fail(405,'Use POST.');const b=await payload(req);
    if(typeof b.id!=='string'||!/^[\w-]{8,80}$/.test(b.id))fail(422,'Invalid import ID.');
    const fingerprint=hash(JSON.stringify({records:b.records,skipDuplicates:b.skipDuplicates!==false}));
    return await transactionJSON(res,200,async q=>{
     const receipt=(await q('SELECT * FROM import_receipts WHERE id=$1',[b.id]))[0],state=await readState(q);
     if(receipt){if(receipt.user_id!==a.user_id||receipt.fingerprint!==fingerprint)fail(409,'This import ID was already used for a different file.');return {state:scoped(state,a.user_id),...JSON.parse(receipt.result)};}
     const result=importLeads(state,a.user_id,b.records,{skipDuplicates:b.skipDuplicates!==false});
     await writeState(q,result.state);await q('INSERT INTO import_receipts (id,user_id,fingerprint,result,created_at) VALUES ($1,$2,$3,$4,$5)',[b.id,a.user_id,fingerprint,JSON.stringify({imported:result.imported,skipped:result.skipped}),new Date().toISOString()]);
     await audit(q,a.user_id,'leads.imported',b.id);return {state:scoped(result.state,a.user_id),imported:result.imported,skipped:result.skipped};
    });
   }
   if(p==='/api/export'){const a=await signedIn(req);if(req.method!=='GET')fail(405,'Use GET.');return await transactionJSON(res,200,async q=>{const state=scoped(await readState(q),a.user_id),tl=engine(state,a.user_id);await audit(q,a.user_id,'leads.exported');return tl.exportJson();},{'Content-Disposition':'attachment; filename=tharon-leads-export.json'});}
   if(p==='/api/users/password'){
    const a=await signedIn(req);if(!isAdmin(a.user_id))fail(403,'Administrator only.');if(req.method!=='POST')fail(405,'Use POST.');
    const b=await payload(req),u=users.find(u=>u.id===b.userId&&u.role==='rep');if(!u)fail(422,'Choose a marketer.');
    if(typeof b.password!=='string'||b.password.length<14||b.password.length>200)fail(422,'Choose a password of at least 14 characters.');
    throttle('password:'+a.user_id);
    return await transactionJSON(res,200,async q=>{
     await q('UPDATE users SET password_hash=$1,activated_at=$2 WHERE id=$3',[passwordHash(b.password),new Date().toISOString(),u.id]);
     await q('DELETE FROM invitations WHERE user_id=$1',[u.id]);await q('DELETE FROM sessions WHERE user_id=$1',[u.id]);
     await audit(q,a.user_id,'staff.password_set',u.id);return {ok:true};
    });
   }
   if(p==='/api/users'){
    const a=await signedIn(req);if(!isAdmin(a.user_id))fail(403,'Administrator only.');
    if(req.method==='GET'){const rows=await store.query('SELECT id,activated_at FROM users'),state=await store.transaction(readState),delegateActive=!!await delegateAvailable();return json(res,200,{users:users.map(u=>({...u,buildingAccess:buildingAccess(state,u.id),active:u.authType==='private_link'?delegateActive:!!rows.find(r=>r.id===u.id)?.activated_at})),delegateExpiresAt:env.DELEGATE_ACCESS_EXPIRES_AT||null});}
    if(req.method==='POST'){const b=await payload(req),u=users.find(u=>u.id===b.userId);if(!u||u.role==='admin')fail(422,'Choose a marketer.');const t=token();return await transactionJSON(res,201,async q=>{const row=(await q('SELECT * FROM users WHERE id=$1',[u.id]))[0];if(row.password_hash)fail(409,'This account is already active.');await q('DELETE FROM invitations WHERE user_id=$1',[u.id]);await q('INSERT INTO invitations (token_hash,user_id,expires_at) VALUES ($1,$2,$3)',[hash(t),u.id,Date.now()+24*3600000]);await audit(q,a.user_id,'invitation.created',u.id);return {url:(env.APP_ORIGIN||`http://${req.headers.host}`)+'/activate#'+t,expires_hours:24};});}
   }
   if(p==='/api/files'&&req.method==='POST'){
    const a=await signedIn(req),bytes=await body(req,20*1024*1024);let name;try{name=decodeURIComponent(req.headers['x-file-name']||'document');}catch{fail(422,'Invalid file name.');}name=path.basename(name).replace(/[\x00-\x1f]/g,'').slice(0,180);const ext=path.extname(name).toLowerCase();
    if(!['.pdf','.jpg','.jpeg','.png','.webp','.heic','.heif','.docx','.txt','.csv','.xlsx','.xls','.webm','.m4a','.mp4','.ogg','.wav'].includes(ext)||!bytes.length)fail(422,'Unsupported or empty file.');
    const supplied=req.headers['x-upload-id'];if(supplied&&!/^file_[\w-]{8,80}$/.test(supplied))fail(422,'Invalid upload ID.');const id=supplied||'file_'+randomUUID(),mimeType=String(req.headers['content-type']||'application/octet-stream').slice(0,150);await store.transaction(async q=>{const prior=(await q('SELECT * FROM files WHERE id=$1',[id]))[0];if(prior){if(prior.user_id!==a.user_id||prior.sha256!==hash(bytes)||prior.name!==name||prior.mime!==mimeType)fail(409,'Upload ID already used for another file.');return;}await q('INSERT INTO files (id,user_id,name,mime,size,sha256,ciphertext,created_at) VALUES ($1,$2,$3,$4,$5,$6,$7,$8)',[id,a.user_id,name,mimeType,bytes.length,hash(bytes),seal(bytes,key),new Date().toISOString()]);await audit(q,a.user_id,'file.uploaded',id);});return json(res,201,{id,name,type:mimeType,size:bytes.length});
   }
   if(p.startsWith('/api/files/')&&req.method==='GET'){
    const a=await signedIn(req),id=p.slice(11);const downloaded=await store.transaction(async q=>{const state=scoped(await readState(q),a.user_id),lead=state.leads.find(l=>(l.files||[]).some(f=>f.id===id));if(!lead)fail(404,'File not found.');const f=(await q('SELECT * FROM files WHERE id=$1',[id]))[0];if(!f)fail(404,'File not found.');await audit(q,a.user_id,'file.viewed',id);const ext=path.extname(f.name).toLowerCase(),safeMime={'.pdf':'application/pdf','.png':'image/png','.jpg':'image/jpeg','.jpeg':'image/jpeg','.webp':'image/webp','.txt':'text/plain'}[ext];return {bytes:unseal(f.ciphertext,key),headers:{'Content-Type':safeMime||'application/octet-stream','Content-Disposition':`${safeMime?'inline':'attachment'}; filename*=UTF-8''${encodeURIComponent(f.name)}`}};});res.writeHead(200,downloaded.headers);return res.end(downloaded.bytes);
   }
   if(p==='/api/extract-lead'&&req.method==='POST'){
    const a=await signedIn(req);throttle('extract:'+a.user_id);const b=await payload(req);
    const permitted=scoped(await store.transaction(readState),a.user_id).buildings;const result=await extractLead(b.text,{env,buildings:permitted,kind:b.kind==='doc'?'doc':'voice',today:new Date().toLocaleDateString('en-CA',{timeZone:'America/Los_Angeles'})});
    await audit(store.query,a.user_id,'lead.extracted');return json(res,200,result);
   }
   if((p==='/api/transcribe'||p==='/api/voice-test')&&req.method==='POST'){
    const a=await signedIn(req);if(env.TRANSCRIBE_LOCAL==='true'){const bytes=await body(req,20*1024*1024);let text;try{text=await transcribeLocal(bytes,env);}catch(e){fail(e.status||502,e.status?e.message:'The recording could not be transcribed. Please try a shorter, clearer voice note.');}await audit(store.query,a.user_id,'voice.transcribed');return json(res,200,{text});}
    if(!env.TRANSCRIBE_URL||!env.TRANSCRIBE_TOKEN)fail(503,'Voice recording is available, but transcription is not connected yet. Type the note or attach the recording.');
    const bytes=await body(req,20*1024*1024),r=await fetch(env.TRANSCRIBE_URL,{method:'POST',headers:{Authorization:`Bearer ${env.TRANSCRIBE_TOKEN}`,'Content-Type':req.headers['content-type']||'audio/webm'},body:bytes,signal:AbortSignal.timeout(90000)});if(!r.ok)fail(502,'The transcription service could not process this recording. Try again.');const out=await r.json();if(typeof out.text!=='string')fail(502,'No transcript was returned.');await audit(store.query,a.user_id,'voice.transcribed');return json(res,200,{text:out.text});
   }
   if(p.startsWith('/api/'))fail(404,'Not found.');
   if(req.method!=='GET')fail(405,'Use GET.');
   const relative=decodeURIComponent(p==='/'?'/index.html':p==='/voice-test'?'/voice-test.html':p);const file=path.resolve(ROOT,'site','.'+relative);if(!file.startsWith(path.join(ROOT,'site')+path.sep))fail(404,'Not found.');return staticFile(res,file);
  }catch(e){if(res.headersSent){res.end();return;}json(res,e.status||500,{error:e.status?e.message:'The request could not be completed. Please try again.'});}
 });
 async function runReminderJob(){const result=await store.transaction(async q=>{const state=await readState(q),tl=engine(state,'u0'),day=tl.T;if(new Date().getHours()<7||state.reminderRun===day)return false;tl.sweep();const next=JSON.parse(JSON.stringify(tl.S));for(const lead of next.leads){const before=state.leads.find(l=>l.id===lead.id);if(JSON.stringify(lead)!==JSON.stringify(before))lead.version=(before?.version||0)+1;}next.reminderRun=day;next.revision=(state.revision||0)+1;next.notifications=users.map(u=>({user_id:u.id,date:day,due:engine(scoped(next,u.id),u.id).allReminders(u.role==='admin'?'all':u.id).length}));await writeState(q,next);await audit(q,'system','reminders.generated');return next.notifications;});if(result)await push.send(result);return !!result;}
 const scheduler=options.schedule===false?null:setInterval(()=>runReminderJob().catch(()=>{}),60000);scheduler?.unref();
 return {server,store,runReminderJob,close:async()=>{if(scheduler)clearInterval(scheduler);await new Promise(r=>server.listening?server.close(r):r());await store.close();}};
}
if(process.argv[1]===fileURLToPath(import.meta.url)){
 const app=await createApplication();const portIndex=process.argv.indexOf('--port');const port=Number(process.env.PORT||(portIndex>=0?process.argv[portIndex+1]:3000));app.server.listen(port,'0.0.0.0',()=>console.log('Tharon Leads server ready.'));
 for(const sig of ['SIGINT','SIGTERM'])process.on(sig,async()=>{await app.close();process.exit(0);});
}

import { readFileSync } from 'node:fs';
import { randomUUID } from 'node:crypto';
import vm from 'node:vm';
import { fail } from './security.mjs';
const read=p=>readFileSync(new URL('../'+p,import.meta.url),'utf8');
export const users=JSON.parse(read('config/users.json'));
export const buildings=JSON.parse(read('config/buildings.json'));
const dataCode=read('site/data.js'),apiCode=read('site/api.js'),referralCode=read('site/referral-progress.js'),countyCode=read('site/county-roadmap.js'),libertanaCode=read('site/libertana.js');
const countyContext={window:{},Date};vm.createContext(countyContext);vm.runInContext(libertanaCode,countyContext);vm.runInContext(countyCode,countyContext);
export const countyRoadmap=countyContext.window.TLRoadmap;
export const libertana=countyContext.window.TLLibertana;
export function migrateCountyRoadmaps(state,today=new Date().toLocaleDateString('en-CA',{timeZone:'America/Los_Angeles'})){return countyRoadmap.migrate(state,today);}
export function engine(state,userId,ids={}) {
  const ctx={Date,JSON,Math,URLSearchParams,console,TL_BOOT:state?{state}:null,
    TL_ID_FACTORY:p=>ids[p]||(p+'_'+randomUUID()), localStorage:{getItem:()=>null,setItem:()=>{}}};
  ctx.window=ctx; vm.createContext(ctx);vm.runInContext(dataCode,ctx);vm.runInContext(libertanaCode,ctx);vm.runInContext(countyCode,ctx);vm.runInContext(referralCode,ctx);vm.runInContext(apiCode,ctx);
  ctx.TL.S.me=userId;return ctx.TL;
}
export function initialState(sample=false) {
  const tl=engine(null,'u0'),s=JSON.parse(JSON.stringify(tl.S));
  s.users=users;s.buildings=buildings;s.me='u0';s.revision=0;s.sample_data=sample;s.rules.forEach(r=>r.channel='none');
  s.tasks=[];s.chat=[];s.events=[];s.outbox=[];s.done={};s.snooze={};s.emitted={};s.leads=sample?s.leads:[];
  const map={b1:'riverside',b2:'sierra',b3:'crescendo',b4:'hallmark'};
  for(const [i,l] of s.leads.entries()) { l.building=map[l.building]||'shadowridge';l.rep=i%2?'u1':'u2';l.originRep=l.rep;l.createdBy=l.rep;l.activity.forEach(a=>{a.by=l.rep;});l.version=0; }
  return s;
}
export function buildingAccess(state,userId){
 const configured=users.find(u=>u.id===userId),saved=state.users.find(u=>u.id===userId);
 if(configured?.role==='admin')return 'all';
 const access=saved&&Object.hasOwn(saved,'buildingAccess')?saved.buildingAccess:configured?.buildingAccess;
 return access==='all'?'all':Array.isArray(access)?access.filter(id=>buildings.some(b=>b.id===id)):[];
}
export function canAccessBuilding(state,userId,buildingId){const a=buildingAccess(state,userId);return a==='all'||a.includes(buildingId);}
export function scoped(state,userId) {
 const s=JSON.parse(JSON.stringify(state));s.me=userId;const access=buildingAccess(state,userId);
 s.accessSignature=JSON.stringify(access);
 s.users=s.users.map(u=>({...u,buildingAccess:buildingAccess(state,u.id)}));
 if(users.find(u=>u.id===userId)?.role!=='admin') {
  s.buildings=s.buildings.filter(b=>canAccessBuilding(state,userId,b.id));
  s.leads=s.leads.filter(l=>canAccessBuilding(state,userId,l.building));
  const ids=new Set(s.leads.map(l=>l.id));
  s.tasks=s.tasks.filter(t=>t.rep===userId&&(!t.leadId||ids.has(t.leadId)));
  const visibleKeys=[...ids,...s.tasks.map(t=>t.id)];
  s.events=[];s.outbox=[];s.chat=[];s.notifications=[];
  s.done=Object.fromEntries(Object.entries(s.done).filter(([k])=>visibleKeys.some(id=>k.includes(id))));
  s.snooze=Object.fromEntries(Object.entries(s.snooze).filter(([k])=>visibleKeys.some(id=>k.includes(id))));
 } return s;
}
const leadOps=new Set(['updateLead','setStage','assign','setDoc','addActivity','attachFile','setTemp','closeLead','reopenLead','setCountyStep','setReferralProgress','saveReferral']);
const allowedOps=new Set([...leadOps,'createLead','addTask','completeReminder','snoozeReminder','settings','resolveTask','setBuildingAccess','addReferrer','addFollowupContact']);
const leadFields=new Set(['first','last','age','caller','source','sourceDetail','cca','care','payer','budget','moveIn','rep','building','tourAt','touredAt','notes','tier','assessmentStatus','programStatus','nextAction','nextFollowUp','libertana','followupContactId']);
function checkRecord(d,admin,userId,state) {
  if(!d||typeof d!=='object'||Array.isArray(d))fail(422,'Invalid lead fields.');
  for(const k of Object.keys(d))if(!leadFields.has(k))fail(422,'Unsupported lead field.');
  if(d.building!==undefined&&(!d.building||!buildings.some(b=>b.id===d.building)))fail(422,'Choose an existing building.');
  if(d.building!==undefined&&!canAccessBuilding(state,userId,d.building))fail(403,'This building is not assigned to your account.');
  if(d.rep&&!users.some(u=>u.id===d.rep))fail(422,'Choose an existing marketer.');
  if(!admin&&d.rep!==undefined&&d.rep!==userId)fail(403,'Only the administrator can reassign a marketer.');
  for(const k of ['first','last','sourceDetail','cca','notes'])if(d[k]!==undefined&&(typeof d[k]!=='string'||d[k].length>12000))fail(422,'Invalid text field.');
  if(d.followupContactId!==undefined&&d.followupContactId!==null&&(typeof d.followupContactId!=='string'||d.followupContactId!==''&&!state.followupContacts?.some(c=>c.id===d.followupContactId)))fail(422,'Choose a saved follow-up contact.');
  if(d.caller){if(typeof d.caller!=='object'||Array.isArray(d.caller)||Object.keys(d.caller).some(k=>!['name','rel','phone','email'].includes(k))||Object.values(d.caller).some(v=>typeof v!=='string'||v.length>500))fail(422,'Invalid contact details.');}
  if(Object.hasOwn(d,'nextAction')||Object.hasOwn(d,'nextFollowUp')){if(typeof d.nextAction!=='string'||!d.nextAction.trim()||d.nextAction.length>2000||typeof d.nextFollowUp!=='string'||!/^\d{4}-\d{2}-\d{2}$/.test(d.nextFollowUp)||!Number.isFinite(Date.parse(d.nextFollowUp))||new Date(d.nextFollowUp+'T12:00').toISOString().slice(0,10)!==d.nextFollowUp)fail(422,'Enter a next step and a valid follow-up date.');}
  if(d.assessmentStatus!==undefined&&!['not_started','pending','completed'].includes(d.assessmentStatus))fail(422,'Choose a valid assessment status.');
  if(d.programStatus!==undefined&&!['not_started','pending','approved'].includes(d.programStatus))fail(422,'Choose a valid program status.');
  if(d.age!=null&&(!Number.isInteger(d.age)||d.age<0||d.age>125))fail(422,'Check the age.');
  if(d.budget!=null&&(!Number.isFinite(d.budget)||d.budget<0))fail(422,'Check the budget.');
  if(d.tier!=null&&![1,2,3,4,5].includes(d.tier))fail(422,'Choose a waiver tier from 1 to 5.');
}
export function execute(state,userId,command) {
  const {op,args=[]}=command; if(!allowedOps.has(op)||!Array.isArray(args))fail(422,'Unsupported action.');
  const admin=users.find(u=>u.id===userId)?.role==='admin';const tl=engine(state,userId,command.createdId?{L:command.createdId,task_:command.createdId,ref_:command.createdId,contact_:command.createdId}:{});
  let target=null;
  if(leadOps.has(op)) {
    target=tl.Lead(args[0]);const actionOwner=op==='setCountyStep'&&target?.countyWorkflow?.steps?.[args[1]]?.owner;
    if(!target||!canAccessBuilding(state,userId,target.building)||(!admin&&target.rep!==userId&&actionOwner!==userId))fail(404,'Lead not found.');
    if(command.expectedVersion!==(target.version||0))fail(409,'This lead changed on another device. Refresh and review it before saving again.');
  }
  if(op==='resolveTask'){
    const task=tl.allReminders(admin?'all':userId).find(t=>t.id===args[0]);if(!task)fail(404,'Task not found or no longer due.');
    target=task.leadId?tl.Lead(task.leadId):null;if(target&&(!canAccessBuilding(state,userId,target.building)||(!admin&&target.rep!==userId)))fail(404,'Task not found.');
    if(target&&command.expectedVersion!==(target.version||0))fail(409,'This lead changed on another device. Refresh before recording the follow-up.');
  }
  if(op==='createLead') {
    checkRecord(args[0],admin,userId,state);if(Object.hasOwn(args[0],'libertana'))try{countyContext.window.TLLibertana.validate(args[0].libertana,{files:[]});}catch(e){fail(422,e.message);}if(!args[0].building)fail(422,'Choose a building before saving this lead.');
    if(!args[0].first?.trim()||!args[0].last?.trim())fail(422,'Enter the first and last name.');
    if(state.leads.some(l=>l.id===command.createdId))fail(409,'This record ID is already in use.');
    if(!command.createdId||!/^[\w-]{8,80}$/.test(command.createdId))fail(422,'Invalid new record ID.');
    const d=args[0],phone=(d.caller?.phone||'').replace(/\D/g,'');
    if(state.leads.some(l=>tl.isOpen(l)&&((l.first.toLowerCase()===d.first.toLowerCase()&&l.last.toLowerCase()===d.last.toLowerCase())||(phone.length>=10&&l.caller.phone.replace(/\D/g,'')===phone))))fail(409,'A matching open lead already exists. Ask the administrator to check before creating a duplicate.');
  }
  if(['updateLead','saveReferral','assign'].includes(op)&&args[1]&&Object.hasOwn(args[1],'rep')&&!args[1].rep)fail(422,'Choose a lead owner.');
  if(['updateLead','saveReferral'].includes(op)){checkRecord(args[1],admin,userId,state);if(Object.hasOwn(args[1],'libertana'))try{countyContext.window.TLLibertana.validate(args[1].libertana,target);}catch(e){fail(422,e.message);}}
  if(op==='assign'){if(!args[1]||Object.keys(args[1]).some(k=>!['building','rep'].includes(k)))fail(422,'Invalid assignment.');checkRecord(args[1],admin,userId,state);}
  if(['createLead','updateLead','saveReferral','assign'].includes(op)){
   const candidate=op==='createLead'?args[0]:{...target,...args[1]};
   if(candidate.rep&&candidate.building&&!canAccessBuilding(state,candidate.rep,candidate.building))fail(422,'The selected marketer does not have access to that building.');
  }
  if(op==='addReferrer'&&(typeof args[0]!=='string'||typeof args[1]!=='string'||args[1].length>200))fail(422,'Choose a source and enter a referrer name up to 200 characters.');
  if(op==='setBuildingAccess'){
   if(!admin)fail(403,'Administrator only.');
   const [id,access]=args;if(!users.some(u=>u.id===id&&u.role==='rep')||!(access==='all'||(Array.isArray(access)&&access.every(b=>buildings.some(x=>x.id===b)))))fail(422,'Choose a marketer and valid buildings.');
  }
  if(op==='setDoc') {const p=args[2];if(!tl.docDef(args[1])||!p||Object.keys(p).some(k=>!['status','due','requested'].includes(k))||(p.status&&!['missing','pending','received','approved','na'].includes(p.status)))fail(422,'Invalid document update.');}
  if(op==='setCountyStep'){
   if(!countyRoadmap.isTracked(target))fail(422,'Program tracking applies to CalAIM and ALW referrals.');
   const owner=args[2]?.owner;if(owner&&!canAccessBuilding(state,owner,target.building))fail(422,'The responsible staff member needs access to this building.');
  }
  if(op==='addActivity'&&(!['call','note','email','text'].includes(args[1])||typeof args[2]!=='string'||args[2].length>12000))fail(422,'Invalid activity.');
  if(op==='setTemp'&&!['hot','warm','cold'].includes(args[1]))fail(422,'Invalid temperature.');
  if(op==='closeLead'&&!['won','lost'].includes(args[1]))fail(422,'Choose won or lost.');
  if(op==='setStage'&&args[1]==='lost'&&!args[2]?.trim())fail(422,'A reason is required to close a lead as lost.');
  if(op==='addTask') { const t=args[0];if(!t||typeof t.text!=='string'||!t.text.trim()||t.text.length>2000)fail(422,'Enter a task.');if(t.leadId){const l=tl.Lead(t.leadId);if(!l||(!admin&&l.rep!==userId))fail(404,'Lead not found.');}if(!admin)t.rep=userId; }
  if(['completeReminder','snoozeReminder'].includes(op)&&!tl.allReminders(admin?'all':userId).some(t=>t.id===args[0]))fail(404,'Reminder not found.');
  if(op==='settings') {
    if(!admin)fail(403,'Only the administrator can change reminder rules.');
    const p=args[0];if(!p||Object.keys(p).some(k=>!['rules','checkin'].includes(k)))fail(422,'Invalid settings.');
    if(p.checkin){const d=p.checkin.days;if(!d||!['hot','warm','cold'].every(k=>Number.isInteger(d[k])&&d[k]>=1&&d[k]<=365)||!Number.isInteger(p.checkin.escalateAfter)||p.checkin.escalateAfter<1||p.checkin.escalateAfter>30)fail(422,'Check the reminder windows.');tl.S.checkin=p.checkin;}
    if(p.rules){if(!Array.isArray(p.rules)||p.rules.length!==tl.S.rules.length||p.rules.some(r=>!tl.S.rules.some(o=>o.id===r.id)||!Number.isInteger(r.days)||r.days<0||r.days>365))fail(422,'Invalid reminder rule.');tl.S.rules=p.rules.map(r=>({...r,channel:'none'}));}
  } else {try{tl[op](...args);}catch(e){if(['resolveTask','setCountyStep','setReferralProgress','saveReferral','createLead','addReferrer','addFollowupContact'].includes(op)&&!e.status)fail(422,e.message);throw e;}}
  const s=JSON.parse(JSON.stringify(tl.S));s.revision=(state.revision||0)+1;
  if(target){const l=s.leads.find(l=>l.id===target.id);l.version=(l.version||0)+1;}
  if(op==='createLead'){const created=s.leads.find(l=>l.id===command.createdId);created.version=1;created.rep=args[0].rep||userId;created.originRep=created.rep;created.createdBy=userId;}
  return s;
}

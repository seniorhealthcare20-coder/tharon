import {readFileSync} from 'node:fs';
import {createRequire} from 'node:module';
import vm from 'node:vm';
const require=createRequire(import.meta.url),lib=require('../site/vendor/pdf-lib.min.js'),fontkit=require('../site/vendor/fontkit.min.js');
const context={window:{}};vm.createContext(context);
vm.runInContext(readFileSync(new URL('../site/libertana-pdf.js',import.meta.url),'utf8'),context);
const template=readFileSync(new URL('../site/forms/libertana-assisted-living.pdf',import.meta.url));
const typography={fontkit,fontBytes:readFileSync(new URL('../site/vendor/DejaVuSans.ttf',import.meta.url))};
export async function prepareLibertanaPDF(values,edits={}){return Buffer.from(await context.window.TLLibertanaPDF.fillPDF(template,values,lib,typography,edits));}

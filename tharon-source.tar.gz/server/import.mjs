import {randomUUID} from 'node:crypto';
import {execute,users} from './engine.mjs';
import {fail} from './security.mjs';

// Build the entire batch before committing: one bad row cannot partially import a file.
export function importLeads(state,userId,records,{skipDuplicates=true}={}) {
 if(!Array.isArray(records)||!records.length||records.length>500)fail(422,'Choose between 1 and 500 leads per import.');
 let next=structuredClone(state),imported=0,skipped=0;
 for(const [index,record] of records.entries()){
  try{
   if(!record||typeof record!=='object'||Array.isArray(record))fail(422,'Invalid lead fields.');
   const d=structuredClone(record);
   if(users.find(u=>u.id===userId)?.role!=='admin')d.rep=userId;
   const name=s=>String(s||'').trim().toLowerCase(),phone=String(d.caller?.phone||'').replace(/\D/g,'');
   const duplicate=next.leads.some(l=>!['movein','lost'].includes(l.stage)&&((name(l.first)===name(d.first)&&name(l.last)===name(d.last))||(phone.length>=10&&String(l.caller?.phone||'').replace(/\D/g,'')===phone)));
   if(duplicate&&skipDuplicates){skipped++;continue;}
   next=execute(next,userId,{op:'createLead',createdId:'L_'+randomUUID(),args:[d,'Imported from a reviewed spreadsheet.']});imported++;
  }catch(e){if(e.status)fail(e.status,`Row ${index+1}: ${e.message} No leads from this batch were saved.`);throw e;}
 }
 return {state:next,imported,skipped};
}

// One-time operator-requested correction of existing staff referrals, not an eligibility decision.
import {execute} from './engine.mjs';
const CAL='CalAIM Community Supports',ALW='ALW waiver';
export function requestedProgram(l){
 const text=[l.notes,l.sourceDetail].filter(Boolean).join('\n').replace(/\balw\s*(?:\/|or)\s*cal\s*aim\s+(?:not provided|not specified|unknown)\b/ig,'program not specified');
 const alw=/\balw\b/i.test(text)&&!/(?:\bnot\s+(?:an?\s+)?|\bnon[- ]?)alw\b/i.test(text);
 const cal=/\bcal\s*aim\b/i.test(text);
 if(l.rep==='u2')return {payer:alw?ALW:CAL,reason:alw?'Uploaded notes identify ALW':'Steven: Olivia defaults to CalAIM unless uploaded notes identify ALW'};
 if(l.rep!=='u3')return null;
 if(!['pointe','carrington','hallmark'].includes(l.building))return {review:'Gaby referral is outside her three Kern County buildings; confirm program.'};
 const provider=String(l.cca||'').trim()||text.match(/\b(?:cca|program provider)\s*[:=-]\s*([^\n;,]+)/i)?.[1]?.trim()||(/\bmaster\s*care\b/i.test(text)?'MasterCare':/\bbeta\b/i.test(text)?'Beta':/\blibertana\b/i.test(text)?'Libertana':'');
 const usable=provider&&!/^(?:n\/?a|none|unknown|other|not recorded|pending)$/i.test(provider);
 const master=/\bmaster[\s-]*care\b/i.test(provider);
 if(alw&&cal||alw&&master||cal&&provider&&!master)return {review:'Uploaded program notes and CCA conflict; confirm with Steven.'};
 if(/\b(?:aps|ombudsman)\s+letter\b/i.test(text))return {payer:ALW,reason:'Uploaded notes identify an APS / Ombudsman letter, matching Steven’s ALW roadmap'};
 if(alw)return {payer:ALW,reason:'Uploaded notes identify ALW'};
 if(cal)return {payer:CAL,reason:'Uploaded notes identify CalAIM'};
 if(/\bprivate[ -]*pay\b/i.test(text))return {payer:'Private pay',reason:'Uploaded notes explicitly identify private pay'};
 if(usable)return {payer:master?CAL:ALW,reason:master?'Steven: MasterCare referrals are CalAIM':'Steven: other CCAs for Gaby’s Kern buildings use ALW'};
 return {review:'No explicit program or CCA was found in the uploaded notes; confirm with Steven.'};
}
export function correctStaffPrograms(state){
 if(state.staffProgramCorrections?.version===2)return null;
 const result={reviewed:0,changed:0,oliviaChanged:0,gabyChanged:0,unchanged:0,needsReview:0,oliviaNeedsReview:0,gabyNeedsReview:0,oliviaCalAIM:0,oliviaALW:0,gabyCalAIM:0,gabyALW:0,gabyPrivatePay:0};
 const ids=state.leads.filter(l=>['u2','u3'].includes(l.rep)).map(l=>l.id);
 for(const id of ids){let lead=state.leads.find(l=>l.id===id),decision=requestedProgram(lead);result.reviewed++;
  if(lead.building==='crenshaw'&&decision.payer===ALW)decision={review:'Uploaded notes identify ALW, but Crenshaw is CalAIM-only. Confirm the building or program with Steven.'};
  if(decision.review){lead.programCorrectionReview=decision.review;lead.version=(lead.version||0)+1;result.needsReview++;result[lead.rep==='u2'?'oliviaNeedsReview':'gabyNeedsReview']++;continue;}
  if(lead.payer!==decision.payer){const previous=lead.payer;Object.assign(state,execute(state,'u0',{op:'updateLead',expectedVersion:lead.version||0,args:[id,{payer:decision.payer}]}));lead=state.leads.find(l=>l.id===id);lead.programCorrection={version:2,previous,reason:decision.reason,at:new Date().toISOString()};lead.activity.unshift({at:new Date().toISOString(),by:'u0',type:'edit',text:'Program corrected under Steven’s staff referral instructions. '+decision.reason+'.'});result.changed++;result[lead.rep==='u2'?'oliviaChanged':'gabyChanged']++;}else result.unchanged++;
  delete lead.programCorrectionReview;
  const prefix=lead.rep==='u2'?'olivia':'gaby';if(lead.payer===CAL)result[prefix+'CalAIM']++;else if(lead.payer===ALW)result[prefix+'ALW']++;else if(lead.payer==='Private pay')result.gabyPrivatePay++;
 }
 state.staffProgramCorrections={version:2,completedAt:new Date().toISOString(),...result};return result;
}

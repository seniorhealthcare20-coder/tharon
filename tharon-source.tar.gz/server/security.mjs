import { randomBytes, createHash, scryptSync, timingSafeEqual, createCipheriv, createDecipheriv, createHmac } from 'node:crypto';
export const token=()=>randomBytes(32).toString('base64url');
export const hash=s=>createHash('sha256').update(s).digest('hex');
export function passwordHash(p) { const salt=randomBytes(16).toString('hex'); return salt+':'+scryptSync(p,salt,64).toString('hex'); }
export function passwordOK(p,stored) { if(!stored)return false;const [s,h]=stored.split(':'); const v=scryptSync(p,s,64);return h?.length===128&&timingSafeEqual(v,Buffer.from(h,'hex')); }
export function seal(bytes,key) { const iv=randomBytes(12),c=createCipheriv('aes-256-gcm',key,iv);return Buffer.concat([iv,c.update(bytes),c.final(),c.getAuthTag()]).toString('base64'); }
export function unseal(value,key) { const b=Buffer.from(value,'base64'),c=createDecipheriv('aes-256-gcm',key,b.subarray(0,12));c.setAuthTag(b.subarray(-16));return Buffer.concat([c.update(b.subarray(12,-16)),c.final()]); }
const ALPHABET='ABCDEFGHIJKLMNOPQRSTUVWXYZ234567';
export function totpSecret(){const b=randomBytes(20);let bits='';for(const n of b)bits+=n.toString(2).padStart(8,'0');return bits.match(/.{1,5}/g).map(x=>ALPHABET[parseInt(x.padEnd(5,'0'),2)]).join('');}
function decodeBase32(s){let b='';for(const c of s)b+=ALPHABET.indexOf(c).toString(2).padStart(5,'0');return Buffer.from((b.match(/.{8}/g)||[]).map(x=>parseInt(x,2)));}
export function totpCode(s,at=Date.now()){const b=Buffer.alloc(8);b.writeBigUInt64BE(BigInt(Math.floor(at/30000)));const h=createHmac('sha1',decodeBase32(s)).update(b).digest(),o=h[19]&15;return String((h.readUInt32BE(o)&0x7fffffff)%1000000).padStart(6,'0');}
export function totpOK(secret,code){return /^\d{6}$/.test(String(code))&&[-1,0,1].some(d=>timingSafeEqual(Buffer.from(totpCode(secret,Date.now()+d*30000)),Buffer.from(String(code))));}
export function fail(status,message){throw Object.assign(new Error(message),{status});}

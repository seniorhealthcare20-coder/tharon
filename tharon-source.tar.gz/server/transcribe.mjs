import { mkdtemp,writeFile,rm } from 'node:fs/promises';
import { tmpdir } from 'node:os';
import path from 'node:path';
import { execFile } from 'node:child_process';
import { promisify } from 'node:util';
const run=promisify(execFile);
let busy=false;
export async function transcribeLocal(bytes,env){
 if(busy)throw Object.assign(new Error('Another recording is being processed. Please try again shortly.'),{status:503});
 busy=true;let dir;
 try{dir=await mkdtemp(path.join(tmpdir(),'tharon-audio-'));const file=path.join(dir,'recording');await writeFile(file,bytes,{mode:0o600});
  const {stdout}=await run(env.WHISPER_PYTHON||'/opt/speech/bin/python',[new URL('../speech/transcribe.py',import.meta.url).pathname,file],{env:{...process.env,...env,HF_HUB_OFFLINE:'1',TRANSFORMERS_OFFLINE:'1'},timeout:120000,maxBuffer:1024*1024});
  const result=JSON.parse(stdout.trim().split('\n').at(-1));if(typeof result.text!=='string'||!result.text.trim())throw new Error('No speech found.');return result.text;
 }finally{if(dir)await rm(dir,{recursive:true,force:true});busy=false;}
}

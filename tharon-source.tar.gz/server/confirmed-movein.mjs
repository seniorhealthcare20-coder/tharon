// Scoped, idempotent operator-confirmed move-in. Resident names are not embedded in source.
import {createHash} from 'node:crypto';
import {execute} from './engine.mjs';
const JOB='operator_movein_20261112_01';
const SELECTOR='7cf815f095a3433e27246c885ae8fe540c86cc1c7af4cbf2f64bf86a687a0b21';
export function applyConfirmedMoveIn(state){
 if(state.completedOperatorActions?.[JOB])return null;
 const matches=state.leads.filter(l=>l.rep==='u3'&&l.building==='hallmark'&&createHash('sha256').update([l.first,l.last].join(' ').trim().replace(/\s+/g,' ').toLowerCase()).digest('hex')===SELECTOR);
 if(matches.length!==1)return {matched:matches.length,archived:0,applied:false};
 const lead=matches[0],priorDate=lead.moveIn||null,alreadyMovedIn=lead.stage==='movein';
 if(!alreadyMovedIn){Object.assign(state,execute(state,'u0',{op:'closeLead',args:[lead.id,'won'],expectedVersion:lead.version||0}));const saved=state.leads.find(l=>l.id===lead.id);saved.moveIn=priorDate;saved.moveInDateUnconfirmed=!priorDate;saved.activity.unshift({at:new Date().toISOString(),by:'u0',type:'note',text:'Steven confirmed the resident has already moved in and requested removal from active referrals. Original notes are retained. The exact move-in date has not been inferred.'});}
 state.completedOperatorActions={...(state.completedOperatorActions||{}),[JOB]:{recordId:lead.id,at:new Date().toISOString(),outcome:'movein'}};
 return {matched:1,archived:alreadyMovedIn?0:1,alreadyMovedIn,applied:true};
}

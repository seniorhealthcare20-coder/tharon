# Codex handoff: build the production Tharon Leads module

## Part 1. For Steven, in plain English

**What this is.** The demo shows how the leads app should work. This file is the instruction sheet for
Codex to build the real version inside your existing sales project, with real logins, a real database,
and real reminders.

**One thing Codex can't do for you.** Codex writes the code. To go live with real residents' information,
the app also needs a place to run (a "host") that will sign a BAA (Business Associate Agreement) with
Tharon Group. That's the contract HIPAA requires from any company that stores or sends health information
for you. The same goes for the texting service and the AI model. Until those BAAs are signed, use the app
with sample data only. Plan on an hour or two of signups and paperwork with the vendors. Codex can't sign
them for you.

**New: adding a lead without typing.** The demo now lets a rep say a lead out loud or drop in a file (a hospital
referral PDF, a photo of an intake sheet, a Word file) and get the lead form filled in to check before saving.
In the demo, voice uses the phone's built-in speech recognition and files are read inside the browser. In the
real app, voice and files go to Tharon's own server and then to a speech-to-text service and an AI extraction
step. Both of those vendors must sign a BAA too, because a referral or a voice note about a resident is health
information. The prompt below tells Codex exactly how (Step 6b).

**New: the ALW / CalAIM checklist.** Leads paid through the Assisted Living Waiver or CalAIM Community Supports
get a second checklist: assessment and tier, H code, Informing Notice, ISP packet, and the program steps from the
DHCS pages. Items marked "verify with your CCA" weren't confirmed on an official page, so check them before
relying on them.

**New: Hot / Warm / Cold and closing out old leads.** Every open lead is Hot, Warm or Cold (new leads start Hot).
If a lead sits with no activity past its window (Hot 3 days, Warm 7, Cold 14, editable), the rep's Today list asks
"Any update on ...?" with one-tap answers: still hot, move to warm, move to cold, close as won (moved in), or close as
lost (a reason is required). After 2 unanswered check-ins the lead goes to you as "needs a decision". An optional
switch cools a stale lead one step (Hot to Warm to Cold) but never closes it on its own. Closed leads leave the active
pipeline and sit under Closed, where they stay searchable and can be reopened. The prompt covers it in Step 4b.

**How to give this to Codex.** Your Codex project isn't connected to GitHub, so pick one:

*Option 1: quick (2 minutes)*
1. Unzip `tharon-leads-demo-source.zip`.
2. Open the Codex app and open your existing sales project.
3. Drag the unzipped `tharon-leads-demo` folder into the project, so it sits next to your code.
4. Copy everything in Part 2 below (from "You are working inside..." to the end) and paste it into Codex as one message.
5. Let it work. It will tell you what it found in your project first, then build step by step. Answer its questions as they come.

*Option 2: recommended (about 5 minutes)*
Connect GitHub first, so every change Codex makes is backed up and you can undo anything.
1. Make a free account at github.com if you don't have one.
2. In Codex, open Settings and find GitHub (it may be under Connectors or Integrations). Click Connect and sign in to GitHub.
3. When GitHub asks which repositories Codex can use, allow access (all repositories is simplest).
4. Ask Codex: "Create a private GitHub repository for this project and push all the code to it."
5. Then do Option 1, steps 1–5. From now on, ask Codex to commit and push after each step.
The button names may look slightly different in your version of Codex. The idea is the same.

**Phone app.** The demo already installs on a phone from the browser (Add to Home Screen). If you later want
a real App Store app, Step 9 in the prompt covers it. For 5–6 staff, TestFlight is the easy route.

---

## Part 2. The prompt to paste into Codex

You are working inside Tharon Group's existing sales project. Tharon Group operates several California
assisted living buildings (licensed RCFEs). Add a **leads module** to THIS codebase. Do not create a separate
app or a second backend. Reuse what is already here: its framework, database, auth, styling and deploy setup.

The folder `tharon-leads-demo/` is a working demo of the module with sample data. Treat it as the product
spec: `site/` shows the screens and behavior, `site/api.js` shows the data layer, reminder rules and API
shapes, `site/assistant.js` shows the assistant and its tool list, and `INTEGRATION.md` is the API and webhook
contract. Match its behavior. You may rewrite its code in this project's stack.

Hard rules for the whole job:
- Leads are prospective residents. Their names, care needs, payer and paperwork are health information (PHI).
  Never put real PHI in seed data, logs, analytics, error trackers, URLs or test fixtures. Seed data is fictional.
- Never describe the app as "HIPAA compliant" in code, UI or docs. Say it is built to run on HIPAA-eligible
  services under signed BAAs.
- Keep the demo banner idea: any non-production environment shows "Sample data only".
- Ask me before adding a paid service or changing the existing sales features.
- Work in small steps. After each step, run the tests, tell me what you changed in plain English, and commit
  (and push, if GitHub is connected).

### Step 0. Read this project first and report back

Before writing code, inspect the repository and tell me:
1. The stack: language, framework, frontend, backend, database/ORM, auth, hosting/deploy config, and how tests run.
2. How buildings (facilities) are stored now: table or collection name, fields, IDs, and where bed counts or census live.
3. How leads, prospects or deals are stored now, if at all, and which screens create them.
4. How users and roles work now.
5. Where the app is hosted, and whether that host can sign a BAA.

Then propose a short plan that maps the demo's `users`, `buildings`, `leads`, `documents`, `tasks` and
`events` onto what exists. Reuse the existing buildings and users tables and add only what's missing.
Fill in the mapping table in section 5 of `tharon-leads-demo/INTEGRATION.md` and save it. Wait for my OK
before Step 1.

### Step 1. Data model and migrations

Add (or map onto existing tables) with migrations:
- `leads`: id, external_id, first_name, last_name, age, contact_name, contact_relationship, contact_phone,
  contact_email, referral_source, referral_detail, care_level, payer, monthly_budget, desired_move_in,
  assigned_rep_id → users, building_id → buildings, stage (new, contacted, tour, toured, assessment,
  paperwork, movein, lost), lost_reason, tour_at, toured_at, last_contact_at, notes, created_at, updated_at, deleted_at.
- `lead_activities`: lead_id, user_id or api_token_id, type (call, email, text, note, stage, assign, docs, created), text, created_at.
- `lead_documents`: lead_id, key, status (missing, received, na), due_date, requested_at, received_at, file_id.
  Seed the checklist from `site/data.js` DOCS: LIC 602A, TB test, LIC 603A, LIC 601, admission agreement
  (LIC 604A), LIC 613C-2, LIC 627C, LIC 605A, LIC 625, payer proof, IDs, POLST (optional).
- `leads` also gets: `payer_program` (private_pay, alw, calaim, other; derived from payer), `waiver_tier` (1–5, from the
  CCA / RN assessment).
- `lead_waiver_items`: lead_id, key, program (alw, calaim), status (missing, received, na), due_date, requested_at,
  received_at, file_id, note. Seed the item list from `site/data.js` WDOCS. Each item there carries `src` (the DHCS or
  CCA page it comes from) and `verify` (true = not confirmed on an official page; show "verify with your CCA" until
  Tharon's administrator confirms it). The first four are Steven's own items and keep his wording as the label:
  Assessment (with tier), H code, Informing Notice, ISP packet. The checklist opens when payer_program is alw or
  calaim. Missing items feed the `waiver_missing` reminder rule the same way admission documents feed `doc_missing`,
  and fire `document.missing` with `checklist: "waiver_medi_cal"`.
- `leads` also gets: `temperature` (hot, warm, cold; default hot), `status` (open, closed), `close_outcome` (won, lost),
  `closed_at`, `closed_by`, `last_activity_at` (denormalized, updated on every activity), `checkins_unanswered`,
  `needs_decision` (bool). Lost reasons are a fixed list: chose another facility, passed away, too expensive,
  not eligible, no response, other (with text).
- `lead_status_history`: lead_id, field (temperature, status, stage), from, to, changed_by (user, or `system` for the
  scheduled job), reason, created_at. Append-only; every temperature change, close and reopen writes a row.
- `lead_checkins`: lead_id, rep_id, asked_at, answered_at, answer (still_hot, warm, cold, won, lost), escalated_at.
- `checkin_settings`: days per temperature (3 / 7 / 14), escalate_after (2), auto_cool (false), enabled. Admin-editable.
- `lead_attachments`: lead_id, file_id, detected_forms (checklist keys), extraction_id, attached_by, attached_at.
- `extractions`: id, kind (voice, file), file_id, transcript_id, model, schema_version, output_json (the draft
  lead), field_confidence_json, reviewed_by, accepted_at, discarded_at. A draft is never a lead until a person taps Save.
- `files`: encrypted object storage key, sha256, uploaded_by, created_at. Uploads go to private storage with
  short-lived signed URLs.
- `tasks`: manual tasks (text, due, lead_id, assigned_rep_id, done_at). Auto reminders are computed, see Step 4.
- `reminder_rules`: the eight rules in `site/data.js` (enabled, days, channel, wording), editable by admins.
- `webhook_endpoints` (url, secret, events) and `webhook_deliveries` (event, attempts, status).
- `audit_log`: who (user or token), what (table, record id, action), before/after (field names, not full PHI
  values, unless your counsel wants values), ip, user agent, timestamp. Append-only. Write it for every
  create, update, delete, view of a lead's documents, export and login.
Soft-delete leads; never hard-delete activity or documents.

### Step 2. Auth and permissions

Use the project's existing auth if it has one; otherwise add real accounts with email + password or magic
link, plus required 2-factor for admins. Roles: `admin` (everything), `rep` (own leads; can view others only
if an admin allows), optional `manager` (a set of buildings). Enforce permissions on the server for every
endpoint and every assistant tool call, not only in the UI. Sessions time out after 30 minutes of
inactivity. Add Steven as the first admin.

### Step 3. API

Implement the REST API in INTEGRATION.md under `/api/v1`: users, buildings, leads (list with filters,
create with duplicate check, read, update), stage, assign, activities, documents (read, update, file upload),
tasks, export and import (merge mode). Server-to-server API tokens for the sales system, hashed at rest,
revocable. Validation errors return 422 with field messages. Write API tests for each route, including
permission tests (a rep cannot read another rep's lead).

### Step 4. Reminders engine

Port `remindersFor()` and `allReminders()` from `site/api.js`. Rules: first call on a new lead, confirm an
upcoming tour, call back after a tour, no contact for N days, paperwork still missing after N days (one task
per lead listing the forms), document past due, move-in soon with the admission agreement unsigned. Compute
the Today list on request, and run a scheduled job every morning at 7:00 AM Pacific that builds each rep's
list and sends a digest. Done and snoozed state is stored per task per day. Fire `document.missing` once per
day per lead from the job.

### Step 4b. Temperature, stale-lead check-ins and closing

Port `checkinState()`, `checkinItems()`, `setTemp()`, `closeLead()`, `reopenLead()`, `sweep()` and `pipelineStats()`
from `site/api.js`.
- **Scheduled job.** Every morning at 7:00 AM Pacific (same job as Step 4, or its own cron), for each open lead compute
  days since `last_activity_at`. Past the window for its temperature, open a `lead_checkins` row (one open check-in per
  lead at a time) and put "Any update on <name>? Open N days, no activity for M" on the rep's Today list. A check-in
  left unanswered by the next run counts as unanswered. At `escalate_after` unanswered check-ins set `needs_decision`
  and put the lead on the admin's Today list. If `auto_cool` is on, cool one step per window (hot to warm to cold) and
  log it as `system`. The job never closes a lead.
- **Answers.** Still hot / warm / cold sets the temperature and counts as activity. Close as won moves the stage to
  move-in; close as lost requires a reason from the list. Both set `status=closed` and fire `lead.closed`. Reopen sets
  status open, temperature hot, stage contacted (or the stage before closing) and fires `lead.reopened`.
- **Notification rules.** In-app first. The rep's morning digest may say "3 leads need an update" with no names (PHI-free,
  see Step 5); an escalation to the admin is an in-app item plus an optional PHI-free email. Never text a family about
  a check-in.
- **Views.** The pipeline, lists and the board show open leads only, with a temperature chip and filter. A Closed view
  lists won and lost leads with reason and date, searchable, with Reopen. Dashboard stats: open leads, average age in
  days, percent stale, closed this month (won vs lost).
- **Assistant.** Add the `stale_leads`, `set_temperature` and `close_lead` tools (already in `site/assistant.js`).
  "Which leads are stale" and "close the Cohen lead as lost, chose another facility" must work; closing asks to confirm.
- **Webhooks.** `lead.temperature_changed`, `lead.closed`, `lead.reopened`, `lead.needs_decision`.
- **Tests.** Window boundaries per temperature, escalation after 2, auto-cool never closes, lost without a reason is
  rejected, reopen restores the lead, history rows are written, a rep cannot close another rep's lead.

### Step 5. Texts and emails

Texts through Twilio Programmable Messaging, sent only after Tharon has a signed Twilio BAA (Twilio offers one
on its eligible editions) and only to contacts who agreed to receive texts. Store consent and honor STOP.
Email: Twilio SendGrid is NOT a HIPAA-eligible service and will not sign a BAA, so do one of these:
(a) send only PHI-free emails through SendGrid, such as "You have 4 follow-ups today in Tharon Leads" with a
login link and no names or care details; or (b) use a provider that signs a BAA (for example Amazon SES under
an AWS BAA, or Paubox) for any email that names a resident. Default to (a) for staff digests and (b) for
family or physician requests. Never put PHI in a text either unless the Twilio BAA is in place; keep family
texts short ("Hi Tom, this is Maria from Tharon Group, confirming your tour tomorrow at 2:00 PM"). Every send
is logged on the lead. Add a SEND_MODE env var (off, log-only, live) defaulting to log-only outside production.

### Step 6. Assistant with function calling

Build `POST /api/assistant`. The server receives the question and recent chat history, adds the signed-in user
from the session, and calls an LLM with function calling. Use the OpenAI API under a signed BAA with Tharon (OpenAI's help article "Getting a Business Associate
Agreement for the OpenAI API" explains how to request one), with zero data retention if available, or another
model provider that signs a BAA. The key lives in a server environment variable, never in the browser.

Tools (one per API call, each run with the user's permissions): `search_leads`, `get_lead`,
`missing_paperwork`, `todays_tasks`, `assign_lead`, `change_stage`, `update_document`, `log_activity`,
`create_task`, `extract_lead`, `attach_document`, `building_census`. Their names, descriptions and parameters are in `site/assistant.js` TOOLS.
Tools that change data return a confirmation card the user must tap before it runs. Log every tool call in the
audit log. System prompt: answer briefly, only from tool results, say when something isn't in the data, and
never give medical advice. Keep the demo's local answers as a fallback when the model is unavailable.

### Step 6b. Add a lead without typing: voice and documents

The demo's version lives in `site/capture.js` (a rule-based parser) and the "Add a lead" screen in `site/app.js`.
In the demo, voice uses the browser's own `SpeechRecognition` (Safari sends the audio to Apple's speech service,
Chrome to Google's) and files are read in the browser with pdf.js, Tesseract OCR and mammoth. Neither of those is
acceptable for real resident data: there is no BAA with the browser makers' consumer speech services, and a
browser-only parser can't be audited. Build the production version like this:

1. **Voice.** Record in the browser with `MediaRecorder` (hold-to-talk or tap to start / stop, max 2 minutes), upload
   the audio over TLS to `POST /api/v1/transcribe`, and call a speech-to-text API from a vendor that signs a BAA with
   Tharon and lists that service as covered (for example Amazon Transcribe under the AWS BAA, Google Cloud
   Speech-to-Text under the Google Cloud BAA, or Azure AI Speech under Microsoft's BAA; check the vendor's current
   list of covered services before you pick). Don't store the audio after transcription unless Tharon's policy says
   so; store the transcript on the extraction record.
2. **Files.** `POST /api/v1/files` puts the upload straight into encrypted private storage (S3 with SSE-KMS, GCS with
   CMEK, or Azure Blob with customer-managed keys), linked to the lead or to a pending extraction, with the sha256,
   uploader and time. Then the server reads it: the text layer for PDFs and DOCX, and OCR or a vision model for photos
   and scanned PDFs (Amazon Textract, Google Document AI or Azure AI Document Intelligence, again only under a BAA).
   Accept PDF, JPG, PNG, HEIC (convert to JPEG on the server), DOCX, and keep CSV / Excel on the existing importer.
3. **Extraction.** `POST /api/v1/extract` takes `{transcript}` or `{file_id}` and calls an LLM with structured output
   (strict JSON schema, temperature 0) under a BAA, with zero data retention where the vendor offers it. The schema:

```json
{
  "type": "object", "additionalProperties": false,
  "required": ["fields", "confidence", "detected_forms"],
  "properties": {
    "fields": { "type": "object", "additionalProperties": false, "properties": {
      "first_name": {"type": ["string","null"]}, "last_name": {"type": ["string","null"]},
      "age": {"type": ["integer","null"]}, "date_of_birth": {"type": ["string","null"], "format": "date"},
      "contact_name": {"type": ["string","null"]},
      "contact_relationship": {"enum": ["Self","Daughter","Son","Wife","Husband","Niece","Nephew","Granddaughter","Grandson","Friend","Case manager","Other",null]},
      "contact_phone": {"type": ["string","null"]}, "contact_email": {"type": ["string","null"]},
      "referral_source": {"enum": ["Hospital","SNF","Placement agency","Web","Referral","Other",null]},
      "referral_detail": {"type": ["string","null"]},
      "care_level": {"enum": ["Independent with reminders","Level 1 · light assist","Level 2 · moderate assist","Level 3 · high assist","Level 4 · hospice","Memory care",null]},
      "payer": {"enum": ["Private pay","ALW waiver","CalAIM Community Supports","Long-term care insurance","VA Aid & Attendance","SSI/SSP","Other",null]},
      "waiver_tier": {"type": ["integer","null"], "minimum": 1, "maximum": 5},
      "monthly_budget": {"type": ["integer","null"]}, "desired_move_in": {"type": ["string","null"], "format": "date"},
      "building_id": {"type": ["string","null"], "description": "one of the building ids passed in the prompt"},
      "notes": {"type": ["string","null"]}
    }},
    "confidence": { "type": "object", "description": "per field: high | low", "additionalProperties": {"enum": ["high","low"]} },
    "evidence": { "type": "object", "description": "per field: the exact words it came from", "additionalProperties": {"type": "string"} },
    "detected_forms": { "type": "array", "items": {"enum": ["lic602a","tb","lic603a","lic601","agreement","lic613c","lic627c","lic605a","lic625","polst","w_assess","w_hcode","w_informing","w_isp","w_medical","w_waitlist","w_cca","w_mcp","w_soc"]} },
    "resident_match_hint": { "type": ["string","null"] }
  }
}
```

   Pass today's date, the building list and the checklist keys in the prompt. Tell the model to leave a field null
   rather than guess, and to mark anything inferred as `low`. Validate the output on the server (phone format, real
   dates, building id exists) and downgrade to `low` anything that fails.
4. **Review before saving.** Always show the review screen: fields filled from the extraction highlighted, `low`
   fields flagged, the evidence on tap, a duplicate check by name and phone. Nothing becomes a lead until the rep taps
   Save. If `detected_forms` is not empty, offer "Attach to an existing lead" (pre-select the matching lead) and
   tick those checklist items, as the demo does.
5. **Audit log.** Write a row for: file uploaded, file viewed or downloaded, transcription run, extraction run (model,
   schema version, no PHI values in the log line), draft accepted or discarded, document attached, checklist item
   ticked by an extraction. Files keep their link to the lead and are never deleted when a lead is soft-deleted.
6. **Assistant tools.** Add `extract_lead` (calls `/api/v1/extract`, returns the draft, never saves) and
   `attach_document` (attaches a file to a lead and marks checklist keys received; needs a confirmation tap) to the
   assistant's tool list in Step 6. Saying "new lead, ..." in the chat should call `extract_lead` and open the review screen.
7. **Tests.** Keep `site/capture.js` and its tests as the fallback and as fixtures: the sample files in
   `site/samples/` (all fictional) should produce the same fields through the production pipeline.

### Step 7. Screens

Rebuild the demo screens in this project's UI framework and styling, phone first: Today, Leads (board with
drag and drop plus a list with filters by rep, building, stage and search), Add a lead (big mic button, file drop and camera, review before saving), Lead detail (stage stepper,
building and rep dropdowns, contact, paperwork checklist with upload, the ALW / CalAIM waiver checklist with tier,
documents on file, activity, tasks), Buildings (open beds
against pipeline per building), Upload (CSV/Excel with column matching and duplicate check, using SheetJS),
Ask, Reminder rules, Connect & API (webhooks, tokens, export/import). Keep bottom tab navigation on phones and
keep it installable (manifest, icons, service worker that never caches API responses or PHI).

### Step 8. Connect to the sales system and go live

Wire the leads module to the existing sales features using what Step 0 found: link `leads.building_id` to the
existing buildings, read census from where it already lives, and fire the webhooks in INTEGRATION.md.
Write `DEPLOY.md` with: the host and whether its BAA is signed; the database with encryption at rest and
daily backups; file storage encryption; TLS everywhere; environment variables; how to rotate keys; and the
vendor BAA checklist (host, database, file storage, model API, Twilio, email provider). Production stays
behind a "sample data only" flag until I confirm every BAA is signed.

Suggested hosts that sign a BAA, if the current host can't: AWS (Amplify, App Runner or ECS with RDS,
under the AWS BAA), Google Cloud (Cloud Run with Cloud SQL, under the Google Cloud BAA), Azure (App Service
with Azure SQL), or Supabase on a plan with its HIPAA add-on and BAA. Confirm the current terms with the vendor.

### Step 9. Optional: a native phone app

Only if I ask for it. Build it with React Native and Expo in a separate `mobile/` folder, using the same
`/api/v1` and the same login. Screens: Today, Leads, Lead detail, Ask, with push notifications for the morning
digest (no PHI in the notification text). Store tokens in the device's secure storage and require Face ID or
a passcode to open. Notes for me:
- The App Store needs an Apple Developer account (paid yearly) and Apple's review.
- For 5–6 staff, TestFlight (Apple's beta app) or Apple's private/custom app distribution avoids a public listing.
  Android can use an internal testing track on Google Play or a direct install.
- The installable web app from Step 7 may be enough. Try it with the team first.

When you finish each step, tell me in two or three plain sentences what works now and what's next.

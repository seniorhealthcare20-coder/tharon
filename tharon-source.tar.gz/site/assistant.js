/* Tharon Leads demo — the assistant.
   DEMO: answers come from the local rules below, reading the same data the app shows. No AI model is called.
   PRODUCTION: replace askLocal() with askModel(), which posts the question to your own serverless endpoint.
   That endpoint calls an LLM with function calling, using the TOOLS listed here, and runs each tool call
   against your real API with the signed-in user's permissions. Your model API key stays on the server. */
(function(){
'use strict';
const TL=window.TL;

/* Tool functions the production model gets. Each maps to one REST call in INTEGRATION.md. */
const TOOLS=[
  {name:'search_leads',description:'Find leads by name, rep, building, stage, referral source or date range.',params:'query?, rep_id?, building_id?, stage?, created_after?, created_before?',api:'GET /api/v1/leads'},
  {name:'get_lead',description:'One lead with contact, stage, building, paperwork and activity.',params:'lead_id',api:'GET /api/v1/leads/:id'},
  {name:'missing_paperwork',description:'Required admission documents not yet received, per lead.',params:'rep_id?, building_id?',api:'GET /api/v1/leads/:id/documents'},
  {name:'todays_tasks',description:'The auto-generated reminders and manual tasks due today.',params:'rep_id?',api:'GET /api/v1/tasks?date=today'},
  {name:'assign_lead',description:'Assign a lead to a building and/or a rep.',params:'lead_id, building_id?, rep_id?',api:'POST /api/v1/leads/:id/assign',confirm:true},
  {name:'change_stage',description:'Move a lead to another pipeline stage.',params:'lead_id, stage, lost_reason?',api:'POST /api/v1/leads/:id/stage',confirm:true},
  {name:'update_document',description:'Mark a document received, missing or not needed, or set its due date.',params:'lead_id, document_key, status?, due_date?',api:'PATCH /api/v1/leads/:id/documents/:key',confirm:true},
  {name:'log_activity',description:'Add a call, email, text or note to a lead.',params:'lead_id, type, text',api:'POST /api/v1/leads/:id/activities'},
  {name:'create_task',description:'Create a reminder for a rep.',params:'text, due_date, lead_id?, rep_id?',api:'POST /api/v1/tasks'},
  {name:'extract_lead',description:'Pull lead fields out of a voice transcript or an uploaded document (PDF, photo, Word) into the lead JSON schema, with a confidence per field. Returns a draft for the rep to review. Never saves on its own.',params:'transcript? | document_id?, kind',api:'POST /api/v1/extract'},
  {name:'attach_document',description:'Attach an uploaded document to a lead and mark the matching checklist items received (CDSS forms or the ALW / CalAIM waiver checklist).',params:'lead_id, document_id, checklist_keys[]',api:'POST /api/v1/leads/:id/attachments',confirm:true},
  {name:'stale_leads',description:'Open leads past their Hot / Warm / Cold inactivity window, with days idle and unanswered check-ins.',params:'rep_id?, temperature?',api:'GET /api/v1/leads?stale=true'},
  {name:'set_temperature',description:'Mark a lead Hot, Warm or Cold (answers a check-in).',params:'lead_id, temperature',api:'PATCH /api/v1/leads/:id',confirm:true},
  {name:'close_lead',description:'Close a lead as won (moved in) or lost with a reason. It leaves the active pipeline; it can be reopened.',params:'lead_id, outcome, reason?',api:'POST /api/v1/leads/:id/close',confirm:true},
  {name:'building_census',description:'Licensed, occupied and open beds, and leads in the pipeline, per building.',params:'building_id?',api:'GET /api/v1/buildings'}
];

async function askModel(question,history){
  // PRODUCTION ONLY. Not called in this demo.
  // const res = await fetch('/api/assistant', {method:'POST', headers:{'Content-Type':'application/json'},
  //   body: JSON.stringify({question, history})});   // the server adds the user's identity from their session
  // return (await res.json()).answer;
  throw new Error('No model in the demo');
}

/* ---------- local matching helpers ---------- */
const norm=s=>String(s||'').toLowerCase().replace(/[\u2019']/g,'').replace(/[^a-z0-9 ]/g,' ').replace(/\s+/g,' ').trim();
function findBuilding(q){
  const t=norm(q); let best=null;
  TL.S.buildings.forEach(b=>{const keys=[b.name,b.short,b.city.split(',')[0],b.name.replace(/^the /i,'').split(' of ').pop()].filter(Boolean).map(norm);
    keys.forEach(k=>{if(k&&k.length>2&&t.includes(k)&&(!best||k.length>best.k.length)) best={b,k};});});
  return best&&best.b;
}
function findRep(q){
  const t=' '+norm(q)+' ';
  return TL.S.users.find(u=>t.includes(' '+norm(u.name)+' '))||TL.S.users.find(u=>t.includes(' '+norm(u.name.split(' ')[0])+' '));
}
function findLeads(q){
  const t=' '+norm(q)+' ';
  const full=TL.S.leads.filter(l=>t.includes(' '+norm(l.first+' '+l.last)+' '));
  if(full.length) return full;
  const last=TL.S.leads.filter(l=>t.includes(' '+norm(l.last)+' '));
  if(last.length) return last;
  return TL.S.leads.filter(l=>t.includes(' '+norm(l.first)+' ')&&!TL.S.users.some(u=>norm(u.name.split(' ')[0])===norm(l.first)));
}
const STAGE_WORDS=[['lost','lost'],['move in','movein'],['moved in','movein'],['movein','movein'],['paperwork','paperwork'],['assessment','assessment'],['toured','toured'],['tour scheduled','tour'],['tour','tour'],['contacted','contacted'],['new','new']];
const link=l=>`<a href="#/lead/${l.id}">${esc(TL.leadName(l))}</a>`;
const esc=s=>String(s==null?'':s).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const scopeLeads=rep=>{const all=TL.S.leads; if(rep) return all.filter(l=>l.rep===rep.id); return all;};
const scopeName=rep=>rep?rep.name.split(' ')[0]:(TL.isAdmin()?'the team':'you');

function paperwork(l){return TL.docStats(l);}
function propose(op,args,description){const l=TL.Lead(args[0]);if(!TL.isAdmin()&&l.rep!==TL.S.me)return {html:'Only the lead owner or administrator can change this referral.'};return {html:'Proposed: '+esc(description),proposal:{op,args,description,baseline:JSON.stringify(l)}};}
/* ---------- intents ---------- */
function askLocal(qRaw){
  const q=norm(qRaw); const rep=findRep(qRaw); const bld=findBuilding(qRaw); const leads=findLeads(qRaw);
  const has=(...w)=>w.some(x=>q.includes(x));


  // close a lead: "close the Cohen lead as lost, chose another facility" / "close Ruth Cohen as won"
  if(has('close')&&!has('closed this month','closest')&&leads.length){
    if(leads.length>1) return {html:`Which one: ${leads.map(link).join(', ')}?`};
    const l=leads[0]; if(!TL.isOpen(l)) return {html:`${link(l)} is already closed. Open it to reopen.`};
    if(has('won','win','moved in','move in','movein')){return propose('closeLead',[l.id,'won'],'Close '+TL.leadName(l)+' as moved in.');}
    const after=String(qRaw).split(/\blost\b/i)[1]||''; const t=norm(after);
    const map=[[['another','other facility','other community','elsewhere','competitor','closer to'],'Chose another facility'],[['passed','died','death'],'Passed away'],[['expensive','afford','budget','cost','price'],'Too expensive'],[['eligible','eligibility','denied'],'Not eligible'],[['no response','not responding','never called','ghost','no answer','unresponsive'],'No response']];
    let reason=(map.find(([ws])=>ws.some(w=>t.includes(w)))||[])[1];
    const detail=after.replace(/^[\s,.:;\-\u2013]+/,'').trim();
    if(!reason&&detail) reason='Other';
    if(!reason) return {html:`Why is ${link(l)} lost? Say it like \u201cclose the ${esc(l.last)} lead as lost, chose another facility\u201d. Reasons: ${TL.LOST_REASONS.map(esc).join(', ')}.`};
    return propose('closeLead',[l.id,'lost',reason+(detail&&norm(detail)!==norm(reason)?': '+detail:'')],'Close '+TL.leadName(l)+' as lost: '+reason+(detail&&norm(detail)!==norm(reason)?': '+detail:'')+'.');
  }
  // temperature: "mark Cohen as warm", "Ruth Cohen is cold"
  const tw=['hot','warm','cold'].find(w=>has(' '+w)||q.startsWith(w));
  if(tw&&leads.length===1&&has('mark','set','make','move',' is ','change')&&!has('which','how many','list')){return {html:'Temperature changes are no longer supported in Ask. Open the referral to update its progress.'};}
  // stale leads / check-ins
  if(has('stale','check in','checkin','check-in','lingering','no update','no activity','gone quiet','needs a decision','need a decision')||(has('hot','warm','cold')&&has('which','how many','list','show'))){
    const ls=scopeLeads(rep).filter(TL.isOpen);
    const tq=['hot','warm','cold'].find(w=>has(w));
    if(tq&&!has('stale','check')){const rows=ls.filter(l=>(l.temp||'hot')===tq); return {html:`${rows.length} ${esc(tq)} lead${rows.length===1?'':'s'}${rep?' for '+esc(rep.name):''}:<ul>${rows.map(l=>`<li>${link(l)} \u00b7 ${esc(TL.stageLabel(l.stage))}</li>`).join('')}</ul>`};}
    const rows=ls.map(l=>({l,s:TL.checkinState(l)})).filter(x=>x.s&&x.s.stale).sort((a,b)=>b.s.idle-a.s.idle);
    if(!TL.S.checkin?.enabled||!['hot','warm','cold'].every(k=>Number.isFinite(TL.S.checkin?.days?.[k])&&TL.S.checkin.days[k]>0))return {html:'Legacy inactivity checks are disabled. This does not mean every lead is recent.<ul>'+ls.map(l=>'<li>'+link(l)+' · '+TL.daysSince(TL.lastActivity(l))+' days since recorded activity</li>').join('')+'</ul>Use Today for dated follow-ups.'};
    if(!rows.length) return {html:`No stale leads ${rep?'for '+esc(rep.name)+' ':''}right now. Every open lead has had activity inside its window (Hot ${TL.S.checkin.days.hot}, Warm ${TL.S.checkin.days.warm}, Cold ${TL.S.checkin.days.cold} days).`};
    return {html:`${rows.length} stale lead${rows.length>1?'s':''}${rep?' for '+esc(rep.name):''}:<ul>${rows.map(x=>`<li>${link(x.l)} \u00b7 ${esc(TL.tempLabel(x.s.temp))} \u00b7 no activity for ${x.s.idle} days${x.s.escalated?' \u00b7 <b>needs a decision</b>':''}${TL.U(x.l.rep)?' \u00b7 '+esc(TL.U(x.l.rep).name.split(' ')[0]):''}</li>`).join('')}</ul>Answer the check-ins on the Today list, or tell me, e.g. \u201cclose the ${esc(rows[0].l.last)} lead as lost, no response\u201d.`};
  }
  // assign X to building / rep
  if(has('assign','move','put','give')&&(bld||rep)&&leads.length&&!STAGE_WORDS.some(([w])=>has(' to '+w))){
    if(leads.length>1) return {html:`I found ${leads.length} leads by that name: ${leads.map(link).join(', ')}. Which one?`};
    const l=leads[0]; const ch=[],patch={};
    if(bld){patch.building=bld.id; ch.push(`building ${bld.name}`);}
    if(rep&&rep.role==='rep'&&has(' to '+norm(rep.name.split(' ')[0]))){patch.rep=rep.id; ch.push(`owner ${rep.name}`);}
    if(!ch.length) return {html:`Who or where should ${link(l)} go?`};
    return propose('assign',[l.id,patch],TL.leadName(l)+' → '+ch.join(' and ')+'.');
  }
  // move X to stage
  const st=STAGE_WORDS.find(([w])=>has(' to '+w)||has('mark '+w)||has('as '+w));
  if(has('move','mark','change','set')&&st&&leads.length){
    if(leads.length>1) return {html:`Which one: ${leads.map(link).join(', ')}?`};
    const l=leads[0]; return propose('setStage',[l.id,st[1],st[1]==='lost'?'Marked lost from the assistant':null],TL.leadName(l)+' → '+TL.stageLabel(st[1])+'.');
  }
  // waiver / Medi-Cal checklist (ALW, CalAIM)
  const WMAP=[['individual service plan','w_isp'],['isp','w_isp'],['h code','w_hcode'],['hcode','w_hcode'],['aid code','w_hcode'],['eligibility','w_hcode'],['informing notice','w_informing'],['informing','w_informing'],['tier','w_assess'],['rn assessment','w_assess'],['assessment','w_assess'],['waitlist','w_waitlist'],['wait list','w_waitlist'],['slot','w_waitlist'],['care coordination','w_cca'],['cca','w_cca'],['authorization','w_mcp'],['mcp','w_mcp'],['health plan','w_mcp'],['share of cost','w_soc'],['soc','w_soc'],['freedom of choice','w_foc'],['amenity','w_amenity'],['patients rights','w_rights'],['individualized service plan','w_isp'],['active medi cal','w_medical'],['medi cal','w_medical']];
  const wctx=has('alw','calaim','cal aim','waiver','medi cal','medical checklist')||has(' isp','isp ','h code','hcode','informing notice','share of cost');
  if(wctx){
    const prog=has('alw','assisted living waiver')?'alw':has('calaim','cal aim','community supports')?'calaim':null;
    const qq=' '+q+' '; let keys=[];
    for(const [w,k] of WMAP){if(w==='medi cal') continue; if((qq.includes(' '+w+' ')||qq.includes(' '+w+'s '))&&!keys.includes(k)) keys.push(k);}
    if(has('active medi cal','full scope')&&!keys.includes('w_medical')) keys.push('w_medical');
    const pool=scopeLeads(rep).filter(l=>TL.isOpen(l)&&TL.program(l)&&(!prog||TL.program(l)===prog)&&(!bld||l.building===bld.id));
    pool.forEach(l=>TL.ensureWDocs(l));
    const pname=prog?TL.programLabel(prog):'ALW / CalAIM';
    if(leads.length===1&&TL.program(leads[0])){const l=leads[0]; const ws=TL.wdocStats(l);
      return {html:`${link(l)} (${esc(TL.programLabel(ws.program))}${l.tier?', tier '+l.tier:''}) has ${ws.got} of ${ws.req} waiver items. Missing: ${ws.missing.map(k=>'<b>'+esc(TL.docDef(k).form)+'</b>').join(', ')||'nothing'}.`};}
    if(!pool.length) return {html:`No open ${esc(pname)} leads ${rep?'for '+esc(rep.name)+' ':''}right now.`};
    if(keys.length){
      const rows=pool.filter(l=>keys.some(k=>TL.wdocsFor(l).some(d=>d.key===k)&&l.wdocs&&l.wdocs[k]&&!['received','approved','na'].includes(l.wdocs[k].status)));
      const names=keys.map(k=>TL.docDef(k).form).join(' or ');
      if(!rows.length) return {html:`Every open ${esc(pname)} lead ${rep?'for '+esc(rep.name)+' ':''}has the <b>${esc(names)}</b>.`};
      return {html:`${rows.length} ${esc(pname)} lead${rows.length>1?'s are':' is'} missing the <b>${esc(names)}</b>:<ul>${rows.map(l=>{const x=l.wdocs[keys.find(k=>l.wdocs[k]&&!['received','approved','na'].includes(l.wdocs[k].status))]||{}; return `<li>${link(l)} \u00b7 ${esc(TL.programLabel(TL.program(l)))} \u00b7 ${esc(TL.stageLabel(l.stage))}${x.requested?' \u00b7 requested '+esc(TL.fmtShort(x.requested)):' \u00b7 not requested yet'}</li>`;}).join('')}</ul>`};
    }
    const rows=pool.map(l=>({l,s:TL.wdocStats(l)}));
    return {html:`${rows.length} open ${esc(pname)} lead${rows.length>1?'s':''}:<ul>${rows.map(x=>`<li>${link(x.l)} \u00b7 ${esc(TL.programLabel(x.s.program))} \u00b7 ${x.s.got}/${x.s.req} done${x.s.missing.length?' \u00b7 missing '+x.s.missing.slice(0,3).map(k=>esc(TL.docDef(k).form)).join(', ')+(x.s.missing.length>3?' +'+(x.s.missing.length-3):''):''}</li>`).join('')}</ul>`};
  }
  // missing paperwork
  if(has('missing','paperwork','documents','docs','forms','602')){
    let ls=scopeLeads(rep).filter(TL.isOpen); if(bld) ls=ls.filter(l=>l.building===bld.id);
    if(leads.length===1){const l=leads[0]; const s=paperwork(l);
      return {html:`${link(l)} has ${s.got} of ${s.req} documents. Missing: ${s.missing.map(k=>'<b>'+esc(TL.docDef(k).form)+'</b>').join(', ')||'nothing'}.`};}
    const rows=ls.map(l=>({l,s:paperwork(l)})).filter(x=>x.s.missing.length);
    if(!rows.length) return {html:`No open leads ${rep?'for '+esc(rep.name)+' ':''}are missing paperwork.`};
    return {html:`${rows.length} lead${rows.length>1?'s are':' is'} missing paperwork${rep?' for '+esc(rep.name):''}${bld?' at '+esc(bld.short):''}:<ul>${rows.map(x=>`<li>${link(x.l)} \u00b7 ${esc(TL.B(x.l.building)?TL.B(x.l.building).short:'no building')}: ${x.s.missing.map(k=>esc(TL.docDef(k).form)).join(', ')}</li>`).join('')}</ul>`};
  }
  // today / due
  if(has('today','due','to do','todo','my day','reminders','follow up','follow ups','what should')){
    const who=rep||(TL.isAdmin()?null:TL.me());
    const list=TL.allReminders(who?who.id:'all');
    if(!list.length) return {html:`Nothing due today for ${esc(who?who.name:'the team')}.`};
    return {html:`${esc(who?who.name.split(' ')[0]:'The team')} has <b>${list.length}</b> thing${list.length>1?'s':''} due today:<ul>${list.slice(0,8).map(x=>`<li>${x.sev==='high'?'<b class="tbad">!</b> ':''}${esc(x.text)}${!who?` <span class="muted">(${esc(TL.U(x.rep)?TL.U(x.rep).name.split(' ')[0]:'unassigned')})</span>`:''}</li>`).join('')}</ul>${list.length>8?`<a href="#/today">See all ${list.length}</a>`:''}`};
  }
  // beds / census
  if(has('bed','vacanc','census','occupancy','room')){
    const bs=bld?[bld]:TL.S.buildings;
    return {html:bs.map(b=>{const p=TL.S.leads.filter(l=>l.building===b.id&&TL.isOpen(l)).length;return `<b>${esc(b.short)}</b>: census not connected, ${p} lead${p===1?'':'s'} in the pipeline`;}).join('<br>')};
  }
  // counts
  if(has('how many','count','number of','total')){
    let ls=scopeLeads(rep); if(bld) ls=ls.filter(l=>l.building===bld.id);
    let period='';
    if(has('this month')){const m=TL.T.slice(0,7); ls=ls.filter(l=>String(l.created).slice(0,7)===m); period=' this month';}
    else if(has('this week')){ls=ls.filter(l=>TL.daysSince(l.created)<7); period=' in the last 7 days';}
    else if(has('today')){ls=ls.filter(l=>TL.daysSince(l.created)===0); period=' today';}
    const st2=STAGE_WORDS.find(([w])=>has(w+' ')||q.endsWith(w)); if(st2&&!has('new lead')) ls=ls.filter(l=>l.stage===st2[1]);
    const by={}; ls.forEach(l=>{by[l.stage]=(by[l.stage]||0)+1;});
    return {html:`<b>${ls.length}</b> lead${ls.length===1?'':'s'}${bld?' for '+esc(bld.name):''}${rep?' for '+esc(rep.name):''}${period}.${ls.length?' By stage: '+TL.STAGES.filter(s=>by[s[0]]).map(s=>esc(s[1])+' '+by[s[0]]).join(', ')+'.':''}`};
  }
  // tours
  if(has('tour')){
    const ls=scopeLeads(rep).filter(l=>l.stage==='tour'&&l.tourAt).sort((a,b)=>a.tourAt.localeCompare(b.tourAt));
    return {html:ls.length?`Upcoming tours:<ul>${ls.map(l=>`<li>${link(l)} \u00b7 ${esc(TL.B(l.building)?TL.B(l.building).short:'no building')} \u00b7 ${esc(TL.fmtWhen(l.tourAt))}</li>`).join('')}</ul>`:'No tours scheduled.'};
  }
  // unassigned
  if(has('unassigned','no building','without a building')){
    const ls=scopeLeads(rep).filter(l=>TL.isOpen(l)&&(!l.building||!l.rep));
    return {html:ls.length?`${ls.length} open lead${ls.length>1?'s need':' needs'} a building or rep:<ul>${ls.map(l=>`<li>${link(l)}${!l.building?' \u00b7 no building':''}${!l.rep?' \u00b7 no rep':''}</li>`).join('')}</ul>`:'Every open lead has a building and a rep.'};
  }
  // lead summary
  if(leads.length===1||(leads.length>1&&has('about','status','who is','tell me','where'))){
    if(leads.length>1) return {html:`Which one: ${leads.map(link).join(', ')}?`};
    const l=leads[0]; const s=paperwork(l); const b=TL.B(l.building); const r=TL.U(l.rep); const rem=TL.remindersFor(l);
    return {html:`${link(l)}, ${l.age||'age not given'} \u00b7 <b>${esc(TL.stageLabel(l.stage))}</b><br>${esc(l.caller.rel==='Self'?'Calling for themself':l.caller.name+' ('+l.caller.rel+')')} \u00b7 ${esc(l.source)} \u00b7 ${esc(l.care)} \u00b7 ${esc(l.payer)}<br>${b?esc(b.name):'No building yet'} \u00b7 rep ${r?esc(r.name):'unassigned'}${l.moveIn?' \u00b7 move-in '+esc(TL.fmtShort(l.moveIn)):''}${s.started?`<br>Paperwork ${s.got}/${s.req}`:''}${rem.length?`<br>Next: ${esc(rem[0].text)}`:''}`};
  }
  if(has('pipeline','summary','overview','how are we','how is')){
    const ls=scopeLeads(rep); const by={}; ls.forEach(l=>{by[l.stage]=(by[l.stage]||0)+1;});
    return {html:`Pipeline for ${esc(scopeName(rep))}: ${TL.STAGES.map(s=>esc(s[1])+' <b>'+(by[s[0]]||0)+'</b>').join(' \u00b7 ')}`};
  }
  return {html:'This keyword-based helper supports the listed lead, document and follow-up questions. I cannot reliably answer that request. Open the referral to review or change it.',help:true};
}

window.TLAssistant={askLocal,askModel,TOOLS,proposalCurrent:p=>JSON.stringify(TL.Lead(p.args[0]))===p.baseline,
  suggestions:()=>{const m=TL.me(); const first=m.role==='admin'?'Maria':m.name.split(' ')[0];
    return ['Which leads are missing paperwork?','Which ALW leads are missing the ISP?','Which leads are stale?',`What's due today for ${first}?`,'How many leads for Riverside this month?','Assign the Cohen lead to Bakersfield','Open beds by building','Tours coming up','Tell me about Margaret Silva','Move Dorothy Hayes to assessment'];}};
})();

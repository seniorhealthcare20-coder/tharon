/* Compact referral tracking. County requirements remain separate and authoritative. */
(function(){
'use strict';
const statuses=[['assessment','Assessment not done'],['approval','Waiting on CCA / program'],['paperwork','Approval paperwork missing'],['county','Program follow-up needed'],['movein','Move-in date not set'],['scheduled','Move-in date set'],['moved','Moved in']];
const date=v=>/^\d{4}-\d{2}-\d{2}$/.test(v||'')&&Number.isFinite(Date.parse(v))&&new Date(v+'T12:00:00Z').toISOString().slice(0,10)===v;
const key=l=>[l.payer,l.building].join('|');
function waitingOptions(l,building,today){const f=window.TLRoadmap?.summary(l,building,today);if(l.payer==='Private pay')return [['payment','Payment arrangements'],['agreement','Signed agreement']];if(l.payer==='ALW waiver')return [['aps_letter','APS / Ombudsman letter'],['waitlist','Waitlist / slot release'],['cca_assessment','CCA assessment'],['isp','Signed ISP / DHCS submission'],['decision','DHCS approval'],['notice','Informing Notice']];return [['provider','CCA / health plan confirmation'],...(f?.steps||[]).filter(s=>['libertana_packet','libertana_submission','assessment_submission','authorization_request','loa_request','loa_ready','authorization','cca_submission'].includes(s.key)).map(s=>[s.key,s.key==='libertana_packet'?'Signed Libertana packet':s.label])];}
function summary(l,building,today){
 const flow=window.TLRoadmap?.summary(l,building,today),saved=l.referralProgress?.programKey===key(l)?l.referralProgress:null,steps=l.countyWorkflow?.steps||{},privatePay=l.payer==='Private pay';
 const approvalKey=flow?.steps.some(s=>s.key==='informing_notice')?'informing_notice':flow?.steps.some(s=>s.key==='authorization')?'authorization':flow?.steps.some(s=>s.key==='loa_ready')?'loa_ready':null;
 const assessment=saved?.assessment||(steps.building_fit?.status==='done'?'accepted':!flow&&l.assessmentStatus==='completed'?'accepted':'pending');
 const approval=saved?.approval||(approvalKey&&steps[approvalKey]?.status==='done'?'received':l.programStatus==='approved'||l.countyWorkflow?.legacy?.programApproval==='approved'?'missing':'waiting');
 const moveStatus=l.stage==='movein'?'moved':saved?.moveStatus||(l.moveIn?'scheduled':'none');
 const provider=(l.cca||flow?.config.partner||'').trim(),waiting=!privatePay&&approval!=='received'&&l.stage!=='lost';
 const savedWaiting=saved?.waitingOn===provider?saved:null;
 const prior=approvalKey?steps[approvalKey]:null;
 const waitingSince=waiting?(savedWaiting?.waitingSince||(['pending','blocked'].includes(prior?.status)?prior.updatedAt?.slice(0,10):null)):null;
 const waitingBasis=savedWaiting?.waitingBasis||(waitingSince?'recorded':null),waitingDays=waitingSince?Math.max(0,Math.round((Date.parse(today+'T12:00:00Z')-Date.parse(waitingSince+'T12:00:00Z'))/86400000)):null;
 const before=flow?.config.beforeMove||[],requirement=flow?.steps.find(s=>before.includes(s.key)&&s.status!=='done'&&!['building_fit',approvalKey].includes(s.key));
 const document=privatePay?'signed agreement':l.payer==='ALW waiver'?'Informing Notice':approvalKey==='loa_ready'?'LOA confirmation':'approval letter';
 let stage=moveStatus==='moved'?'moved':assessment!=='accepted'?'assessment':approval==='waiting'?'approval':approval==='missing'?'paperwork':requirement?'county':moveStatus==='scheduled'?'scheduled':'movein';
 let next=stage==='assessment'?'Complete the assessment and confirm building acceptance.':stage==='approval'?(privatePay?'Confirm the resident’s payment arrangements.':'Follow up with '+(provider||'the program provider')+' for program approval.'):stage==='paperwork'?(privatePay?'Get the signed agreement and upload it here.':'Get the '+document+' from '+(provider||'the program provider')+' and upload it here.'):stage==='county'?requirement.label:stage==='scheduled'?'Confirm arrangements for the scheduled move-in.':stage==='movein'?'Schedule the move-in.':approval!=='received'?'Follow up on outstanding '+document+'.':flow?.next?.afterMove?flow.next.label:'Move-in recorded. Review any outstanding paperwork.';
 if(l.programReviewRequired){stage='county';next='Confirm this referral’s program and county process.';}
 if(flow?.config.unavailable||flow&&!flow.config.supported){stage='county';next=flow.config.unavailable?'Review the available program for this building with Steven.':'Confirm the county process with Steven.';}
 const due=saved?.due||l.nextFollowUp||flow?.due||today;
 const note=saved?.note||'',noteAt=saved?.noteUpdatedAt||null;
 const reason=saved?.reason||'',reasonLabel=waitingOptions(l,building,today).find(x=>x[0]===reason)?.[1]||'';
 if(approval==='waiting'&&assessment==='accepted'&&reasonLabel){const actions={aps_letter:'Obtain the APS / Ombudsman letter.',waitlist:'Follow up with '+(provider||'the CCA')+' on waitlist / slot release.',cca_assessment:'Arrange or follow up on the CCA assessment.',isp:'Obtain the signed ISP and confirm submission to DHCS.',decision:'Follow up with '+(provider||'the CCA')+' on the DHCS decision.',notice:'Request the Informing Notice from '+(provider||'the CCA')+'.',payment:'Confirm payment arrangements.',agreement:'Get the signed agreement.'};next=actions[reason]||'Follow up with '+(provider||'the program provider')+': '+reasonLabel+'.';}
 return {assessment,approval,moveStatus,stage,label:stage==='county'?(requirement?.label||'Confirm program details'):statuses.find(x=>x[0]===stage)?.[1]||'Review referral',next,due,provider,waiting,waitingSince,waitingBasis,waitingDays,note,noteAt,reason,reasonLabel,document,approvalKey,flow,requirement,privatePay};
}
function apply(l,building,patch,userId,today){
 if(!patch||Object.keys(patch).some(k=>!['assessment','approval','moveStatus','moveDate','due','note','reason'].includes(k)))throw Error('Invalid referral progress fields.');
 if(patch.reason&&!waitingOptions(l,building,today).some(x=>x[0]===patch.reason))throw Error('Choose a waiting reason for this program and county.');
 if(!['accepted','pending'].includes(patch.assessment)||!['waiting','missing','received'].includes(patch.approval)||!['none','scheduled','moved'].includes(patch.moveStatus))throw Error('Choose valid referral progress options.');
 if(!date(patch.due)||typeof patch.note!=='string'||patch.note.length>2000)throw Error('Set a follow-up date and keep the update within 2,000 characters.');
 if(patch.moveStatus!=='none'&&!date(patch.moveDate)&&!(l.stage==='movein'&&patch.moveStatus==='moved'&&!patch.moveDate&&!l.moveIn))throw Error('Enter the move-in date.');
 const before=summary(l,building,today),now=new Date().toISOString();
 const old=l.referralProgress?.programKey===key(l)?l.referralProgress:null;if(before.moveStatus==='moved'&&patch.moveStatus!=='moved')throw Error('Use Reopen before changing a recorded move-in.');
 const approvalChanged=patch.approval!==before.approval,assessmentChanged=patch.assessment!==before.assessment;
 const steps=l.countyWorkflow?.steps;
 function confirmed(k,done){if(!steps?.[k])return;steps[k]={...steps[k],status:done?'done':'pending',owner:steps[k].owner||l.rep||userId,due:done?null:patch.due,note:patch.note.trim()||('Confirmed by staff in referral progress: '+(done?'complete':'pending')+'.'),updatedAt:now,updatedBy:userId};}
 if(assessmentChanged)confirmed('building_fit',patch.assessment==='accepted');
 if(approvalChanged&&before.approvalKey)confirmed(before.approvalKey,patch.approval==='received');
 const next={...old,programKey:key(l),assessment:patch.assessment,approval:patch.approval,reason:patch.approval==='waiting'?(patch.reason||''):'',moveStatus:patch.moveStatus,due:patch.due,note:patch.note.trim(),updatedAt:now,updatedBy:userId};
 if(next.note!==before.note){next.noteUpdatedAt=now;next.noteBy=userId;}
 const waiting=patch.approval!=='received'&&!before.privatePay;
 if(waiting&&old?.waitingSince&&old.waitingOn!==before.provider)next.waitHistory=[...(old.waitHistory||[]),{on:old.waitingOn,since:old.waitingSince,until:today}];
 if(waiting){next.waitingOn=before.provider;next.waitingSince=before.waitingSince||today;next.waitingBasis=before.waitingSince?before.waitingBasis:'tracking';}else{if(old?.waitingSince)next.waitHistory=[...(old.waitHistory||[]),{on:old.waitingOn,since:old.waitingSince,until:today}];next.waitingSince=null;next.waitingOn='';}
 l.referralProgress=next;
 const after=summary(l,building,today);
 if(patch.moveStatus!==before.moveStatus&&patch.moveStatus!=='none'){
  if(patch.assessment!=='accepted')throw Error('Confirm the assessment and building acceptance before scheduling move-in.');
  if(before.flow){const current=window.TLRoadmap.summary(l,building,today);if(!current.ready)throw Error('Review Program details: '+(after.requirement?.label||'confirm county requirements before move-in')+'.');}
  else if(patch.approval!=='received')throw Error('Confirm payment arrangements and paperwork before scheduling move-in.');
 }
 if(patch.moveStatus!=='none'){if(patch.moveDate)l.moveIn=patch.moveDate;if(patch.moveStatus!==before.moveStatus){if(patch.moveStatus==='moved'){l.stage='movein';l.closedAt=l.closedAt||now;confirmed('moved_in',true);}confirmed('schedule_movein',true);}}
 else if(before.moveStatus==='scheduled'){l.moveIn=null;confirmed('schedule_movein',false);}
 l.assessmentStatus=patch.assessment==='accepted'?'completed':'pending';l.programStatus=patch.approval==='waiting'?'pending':'approved';
 return {before,after:summary(l,building,today),noteChanged:next.note!==before.note};
}
window.TLReferral={summary,apply,statuses,date,waitingOptions};
})();

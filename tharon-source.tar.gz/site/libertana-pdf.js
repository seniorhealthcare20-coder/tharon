/* Shared PDF preparation: same template and field mapping in browser and server. */
(function(){
'use strict';
async function fillPDF(bytes,v,lib,typography,edits={}){
 const pdf=await lib.PDFDocument.load(bytes),form=pdf.getForm();if(typography)pdf.registerFontkit(typography.fontkit);const font=await pdf.embedFont(typography?typography.fontBytes:lib.StandardFonts.Helvetica,typography?{subset:false}:undefined);
 const fmt=d=>/^\d{4}-\d{2}-\d{2}$/.test(d||'')?d.slice(5,7)+'/'+d.slice(8,10)+'/'+d.slice(0,4):d||'';
 function text(name,value){if(!value)return;try{const f=form.getTextField(name);f.setText(value);f.setFontSize(10);}catch(e){throw Error('Could not fill PDF field: '+name);}}
 for(const [k,n] of Object.entries({name:'Members Name',phone:'Home Phone Number',cin:'9-Digit MediCal Number',address:'Address',city:'City',zip:'Zip Code',currentCounty:'County in which the applicant currently resides',repName:'Name of authorized representative',residenceOther:'Other (Please Specify)'}))text(n,v[k]);
 text('Date of Birth',fmt(v.dob));text('Care Coordination Agency CCA Name','Libertana');
 function radio(name,value){if(value)form.getRadioGroup(name).select(value);}
 radio('Gender',v.gender);radio('Married',v.married);
 const residence={'Acute Hospital':'acute hospital','At Home':'At Home',Homeless:'Homeless',RCFE:'R C F E','Skilled Nursing':'Skilled Nursing Facility',Other:'Other (Please Specify)'};
 radio('Where is the applicant currently residing',residence[v.residence]);radio("Who has the legal authority to make the applican'ts health care decisions?",v.authority==='Representative'?'Other':v.authority);
 if(v.priorWaitlist==='Yes')form.getCheckBox('Check Box1').check();if(v.priorWaitlist==='No')form.getCheckBox('Check Box2').check();
 radio('Was the legal representative notified of this request for the ALW waitlist',v.priorEnrollment);
 function field(page,name,value,x,top,width){const f=form.createTextField(name);f.addToPage(pdf.getPage(page),{x,y:792-top-14,width,height:14,borderWidth:0,font,textColor:lib.rgb(0,0,0)});f.setFontSize(10);if(value)f.setText(value);}
 field(1,'Tharon_page2_name',v.name,115,90,190);field(1,'Tharon_page2_dob',fmt(v.dob),370,90,137);
 field(2,'Tharon_page3_authorizing_name',v.name,93,154,160);
 field(4,'Tharon_page5_name',v.name,126,85,230);field(4,'Tharon_page5_dob',fmt(v.dob),434,85,102);
 // All remaining writing areas are real, editable AcroForm fields.
 function choice(page,name,options,value){const g=form.createRadioGroup(name);for(const [label,x,top]of options)g.addOptionToPage(label,pdf.getPage(page),{x,y:792-top-9,width:9,height:9,borderWidth:.6,borderColor:lib.rgb(.45,.45,.45),backgroundColor:lib.rgb(1,1,1)});if(value)g.select(value);}
 choice(1,'Tharon_service_program',[['ALWP',76,195],['CCT',76,206],['ICMS',76,218]],v.program);
 choice(1,'Tharon_advance_directive',[['Yes',88,566],['No',139,566]],v.directive);
 choice(1,'Tharon_directive_type',[['Durable Power of Attorney',88,583],['Living Will',315,583],['Other',396,583]],v.directive==='Yes'?v.directiveType:undefined);
 choice(1,'Tharon_directive_copy',[['Provided',350,600],['Not Provided',438,600]],v.directive==='Yes'?v.directiveCopy:undefined);
 field(1,'Tharon_directive_other','',431,578,99);
 const scopes=[['demographics',79,193],['diversity',300,193],['religion',79,213],['financial',302,213],['medical',79,232],['criminal',303,232],['social_security',79,252],['family_friends',303,252],['other',79,277]];
 const recipients=[['family',79,333],['caregivers',79,365],['spiritual_advisors',79,397],['facilities',79,429],['transport',79,461],['financial_institutions',79,493],['other',79,525]];
 const purposes=[['health_care',79,557],['housing',303,557],['financial_status',79,579],['personal_needs',304,579],['other',79,605]];
 for(const [prefix,items]of [['scope',scopes],['recipient',recipients],['purpose',purposes]])for(const [key,x,top]of items){const c=form.createCheckBox('Tharon_release_'+prefix+'_'+key);c.addToPage(pdf.getPage(2),{x,y:792-top-8,width:8,height:8,borderWidth:.6,borderColor:lib.rgb(.4,.4,.4),backgroundColor:lib.rgb(1,1,1)});}
 field(2,'Tharon_release_exclusions','',184,272,353);
 for(const [key,x,top]of [['family',175,328],['caregivers',151,360],['spiritual_advisors',233,392],['facilities',272,424],['transport',206,456],['financial_institutions',193,488],['other',171,520]])field(2,'Tharon_release_names_'+key,'',x,top,537-x);
 field(2,'Tharon_release_purpose_other_details','',130,599,407);
 function signingRow(page,prefix,top,relationship){
  field(page,prefix+'_printed_name','',74,top,142);
  field(page,prefix+'_signature','',220,top,128);
  if(relationship)field(page,prefix+'_relationship_or_title','',352,top,90);
  field(page,prefix+'_date','',relationship?448:452,top,82);
 }
 signingRow(1,'Tharon_services_patient',684,true);signingRow(1,'Tharon_services_agency',730,true);
 signingRow(3,'Tharon_release_client',32,false);signingRow(3,'Tharon_release_witness',81,false);
 signingRow(4,'Tharon_waitlist_patient',587,true);signingRow(4,'Tharon_waitlist_agency',636,true);
 // Leave every signature, date, disclosure scope and recipient choice blank until the person completes it.
 for(const f of form.getFields())if(!(f instanceof lib.PDFSignature))f.disableReadOnly();
 // Apply the team's explicitly saved in-app edits after prefilling.
 for(const [name,value]of Object.entries(edits)){
  const f=form.getFieldMaybe(name);if(!f||f instanceof lib.PDFSignature)throw Error('This PDF field cannot be edited: '+name);
  if(f instanceof lib.PDFTextField){if(typeof value!=='string')throw Error('Invalid text field.');f.setText(value);}
  else if(f instanceof lib.PDFCheckBox){if(typeof value!=='boolean')throw Error('Invalid checkbox.');value?f.check():f.uncheck();}
  else if(f instanceof lib.PDFRadioGroup){if(value==='')f.clear();else if(typeof value==='string'&&f.getOptions().includes(value))f.select(value);else throw Error('Invalid selection.');}
 }
 // Transparent writing fields must not cover the original form's printed labels.
 for(const f of form.getFields())if(f instanceof lib.PDFTextField)for(const w of f.acroField.getWidgets())w.getAppearanceCharacteristics()?.dict.delete(lib.PDFName.of('BG'));
 // Signatures, signature dates, disclosure scope and recipients are never inferred or signed by the app.
 form.updateFieldAppearances(font);
 // Keep editable field resources consistent with their regenerated appearances.
 const dr=form.acroForm.dict.lookup(lib.PDFName.of('DR'),lib.PDFDict),fonts=dr.lookup(lib.PDFName.of('Font'),lib.PDFDict);fonts.set(lib.PDFName.of(font.name),font.ref);
 for(const f of form.getFields())if(f instanceof lib.PDFTextField)f.acroField.dict.delete(lib.PDFName.of('DR'));
 // The source has an empty, malformed optional-content dictionary and no groups.
 const oc=pdf.catalog.lookupMaybe(lib.PDFName.of('OCProperties'),lib.PDFDict);if(oc&&!oc.has(lib.PDFName.of('OCGs')))pdf.catalog.delete(lib.PDFName.of('OCProperties'));
 return pdf.save();
}
window.TLLibertanaPDF={fillPDF,radioOptions:{Tharon_service_program:['ALWP','CCT','ICMS'],Tharon_advance_directive:['Yes','No'],Tharon_directive_type:['Durable Power of Attorney','Living Will','Other'],Tharon_directive_copy:['Provided','Not Provided']}};
})();

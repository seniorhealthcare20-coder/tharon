/* Original documents stay inside the app, with a permanent way back to the lead. */
(function(){
'use strict';
let active=null,pdfLoader;
function pdfLibrary(){
 if(window.pdfjsLib)return Promise.resolve(window.pdfjsLib);
 if(!pdfLoader)pdfLoader=new Promise((resolve,reject)=>{
  const script=document.createElement('script');script.src='vendor/pdfjs/pdf.min.js';
  script.onload=()=>resolve(window.pdfjsLib);script.onerror=()=>{pdfLoader=null;script.remove();reject(Error('The PDF reader could not load. Close this window and try again.'));};
  document.head.appendChild(script);
 });
 return pdfLoader;
}
function finish(view){
 if(active!==view)return;
 active=null;view.controller.abort();view.renderTask?.cancel();view.loadingTask?.destroy();
 if(view.objectUrl)URL.revokeObjectURL(view.objectUrl);
 view.dialog.close();view.dialog.remove();
 document.documentElement.style.overflow=view.overflow;
 window.scrollTo(0,view.scrollY);
 if(view.opener?.isConnected)view.opener.focus({preventScroll:true});view.onClose?.();
}
function close(){
 const view=active;if(!view)return;if(view.dirty&&!window.confirm('Discard unsaved form changes? Choose Cancel to keep editing and save.'))return;
 finish(view);
 if(history.state?.tharonDocument===view.key)history.back();
}
window.addEventListener('popstate',()=>{if(active?.dirty&&!window.confirm('Discard unsaved form changes?')){history.pushState({...history.state,tharonDocument:active.key},'',active.href);return;}if(active)finish(active);});
window.addEventListener('hashchange',()=>{if(active?.dirty&&!window.confirm('Discard unsaved form changes?')){history.replaceState({...history.state,tharonDocument:active.key},'',active.href);return;}if(active)finish(active);});
window.addEventListener('beforeunload',e=>{if(active?.dirty){e.preventDefault();e.returnValue='';}});
async function open({url,name,opener,onSave=null,onClose=null,bytes=null}){
 if(active)return;
 const endpoint=new URL(url,location.href);
 if(endpoint.origin!==location.origin||!(endpoint.pathname.startsWith('/api/files/')||/^\/api\/leads\/[^/]+\/libertana\/packet\.pdf$/.test(endpoint.pathname)))throw Error('This document is not available in the app.');
 const dialog=document.createElement('dialog');dialog.className='document-viewer';
 dialog.setAttribute('aria-labelledby','documentViewerTitle');
 dialog.innerHTML='<header class="document-viewer-header"><div><small>Document</small><h2 id="documentViewerTitle"></h2></div><button type="button" class="btn ghost document-close" aria-label="Close document and return to lead">× <span>Back to lead</span></button></header><div class="document-viewer-content" aria-busy="true"><p role="status">Opening document…</p></div><footer class="document-viewer-footer" hidden><button type="button" class="btn ghost document-previous">Previous page</button><span role="status" class="document-page-count"></span><button type="button" class="btn ghost document-next">Next page</button></footer>';
 dialog.querySelector('h2').textContent=name||'Uploaded document';
 const view={dialog,opener,onSave,onClose,href:location.href,edits:{},dirty:false,scrollY:window.scrollY,overflow:document.documentElement.style.overflow,controller:new AbortController(),key:Date.now()+':'+Math.random(),page:1,renderVersion:0};
 active=view;document.body.appendChild(dialog);
 document.documentElement.style.overflow='hidden';
 history.pushState({...history.state,tharonDocument:view.key},'',location.href);
 const closeButton=dialog.querySelector('.document-close');closeButton.onclick=close;
 dialog.addEventListener('cancel',event=>{event.preventDefault();close();});
 dialog.showModal();closeButton.focus({preventScroll:true});
 const content=dialog.querySelector('.document-viewer-content'),footer=dialog.querySelector('footer');
 const current=()=>active===view;
 try{
  let blob;
  if(bytes)blob=new Blob([bytes],{type:'application/pdf'});
  else{const response=await fetch(endpoint.href,{credentials:'same-origin',signal:view.controller.signal});
   if(!response.ok)throw Error(response.status===401?'Your sign-in expired. Close this document and sign in again.':response.status===403?'You do not have access to this document.':'This document could not be opened. Close it and try again.');
   blob=await response.blob();}
  if(!current())return;
  if(onSave){
   const tools=document.createElement('div');tools.className='document-fillable-tools';const save=document.createElement('button');save.type='button';save.className='btn small primary';save.textContent='Save form';save.disabled=true;
   const state=document.createElement('p');state.className='small';state.setAttribute('role','status');state.textContent='Tap a highlighted field to edit. Changes are saved to this lead when you select Save form.';const zoomIn=document.createElement('button'),zoomOut=document.createElement('button');zoomIn.type=zoomOut.type='button';zoomIn.className=zoomOut.className='btn small ghost';zoomIn.textContent='Zoom +';zoomOut.textContent='Zoom −';zoomIn.onclick=()=>{view.zoom=Math.min(3,(view.zoom||1)+.5);view.refresh?.();};zoomOut.onclick=()=>{view.zoom=Math.max(1,(view.zoom||1)-.5);view.refresh?.();};tools.append(save,zoomOut,zoomIn,state);dialog.querySelector('header').after(tools);
   view.changed=()=>{view.dirty=true;save.disabled=false;state.textContent='Unsaved changes — select Save form to keep them.';};
   save.onclick=async()=>{save.disabled=true;const batch={...view.edits};try{const accepted=await onSave(batch);if(!current())return;view.saved={...(view.saved||{}),...(accepted||batch)};for(const [k,v]of Object.entries(batch))if(view.edits[k]===v)delete view.edits[k];view.dirty=Object.keys(view.edits).length>0;state.textContent=view.dirty?'New unsaved changes — save again.':'Saved to this lead. Signature verification remains separate.';}catch(error){state.textContent='Not saved: '+error.message;}finally{save.disabled=!view.dirty;}};
  }
  if(blob.type.includes('pdf')||/\.pdf$/i.test(name||'')){
   const library=await pdfLibrary();if(!current())return;
   library.GlobalWorkerOptions.workerSrc=new URL('vendor/pdfjs/pdf.worker.min.js',document.baseURI).href;
   const data=new Uint8Array(await blob.arrayBuffer());if(!current())return;
   view.loadingTask=library.getDocument({data,isEvalSupported:false});
   const pdf=await view.loadingTask.promise;if(!current())return;
   const previous=dialog.querySelector('.document-previous'),next=dialog.querySelector('.document-next');
   async function renderPage(number){
    const version=++view.renderVersion;view.renderTask?.cancel();view.page=number;
    previous.disabled=number===1;next.disabled=number===pdf.numPages;
    dialog.querySelector('.document-page-count').textContent='Page '+number+' of '+pdf.numPages;
    content.setAttribute('aria-busy','true');
    try{
     const page=await pdf.getPage(number);if(!current()||version!==view.renderVersion)return;
     const base=page.getViewport({scale:1}),width=Math.max(240,content.clientWidth-24);
     const scale=Math.min(width/base.width,2)*(view.zoom||1),viewport=page.getViewport({scale});
     const ratio=Math.min(window.devicePixelRatio||1,2),canvas=document.createElement('canvas');
     canvas.width=Math.ceil(viewport.width*ratio);canvas.height=Math.ceil(viewport.height*ratio);
     canvas.style.width=viewport.width+'px';canvas.style.height=viewport.height+'px';
     canvas.setAttribute('aria-label','Page '+number+' of '+pdf.numPages);
     const sheet=onSave?document.createElement('div'):null;if(sheet){sheet.className='document-editable-page';sheet.style.width=viewport.width+'px';sheet.style.height=viewport.height+'px';sheet.append(canvas);content.replaceChildren(sheet);}else content.replaceChildren(canvas);content.scrollTop=0;
     view.renderTask=page.render({...(onSave?{annotationMode:library.AnnotationMode?.DISABLE??0}:{}),canvasContext:canvas.getContext('2d'),viewport,transform:ratio===1?null:[ratio,0,0,ratio,0,0]});
     await view.renderTask.promise;
     if(onSave&&current()&&version===view.renderVersion){const annotations=await page.getAnnotations({intent:'display'});if(!current()||version!==view.renderVersion)return;for(const a of annotations){
      if(a.subtype!=='Widget'||a.fieldType==='Sig'||a.readOnly||!a.fieldName)continue;
      if(!['Tx','Btn'].includes(a.fieldType))continue;
      const radioOptions=window.TLLibertanaPDF?.radioOptions?.[a.fieldName],choiceValue=radioOptions?.[Number(a.buttonValue)]??a.buttonValue;
      const input=document.createElement('input'),rect=viewport.convertToViewportRectangle(a.rect),isRadio=a.radioButton,isCheck=a.checkBox;
      input.type=isRadio?'radio':isCheck?'checkbox':'text';input.setAttribute('aria-label',(a.alternativeText||a.fieldName.replace(/Tharon_/g,'').replace(/_/g,' '))+(a.radioButton?': '+choiceValue:''));input.dataset.pdfField=a.fieldName;input.style.left=Math.min(rect[0],rect[2])+'px';input.style.top=Math.min(rect[1],rect[3])+'px';input.style.width=Math.max(9,Math.abs(rect[2]-rect[0]))+'px';input.style.height=Math.max(9,Math.abs(rect[3]-rect[1]))+'px';input.style.fontSize=Math.max(9,(a.defaultAppearanceData?.fontSize||10)*scale)+'px';
      const value=Object.hasOwn(view.edits,a.fieldName)?view.edits[a.fieldName]:Object.hasOwn(view.saved||{},a.fieldName)?view.saved[a.fieldName]:radioOptions&&/^\d+$/.test(String(a.fieldValue))?radioOptions[Number(a.fieldValue)]:a.fieldValue;
      if(isRadio){input.name='pdf-'+a.fieldName;input.value=choiceValue;input.checked=value===choiceValue;}else if(isCheck)input.checked=typeof value==='boolean'?value:!!value&&value!=='Off';else{input.value=value||'';input.maxLength=a.maxLen||2000;}
      input.addEventListener(isRadio||isCheck?'change':'input',()=>{view.edits[a.fieldName]=isRadio?input.value:isCheck?input.checked:input.value;view.changed();});sheet.append(input);
     }}
     if(current()&&version===view.renderVersion)content.setAttribute('aria-busy','false');
    }catch(error){if(current()&&version===view.renderVersion&&error.name!=='RenderingCancelledException')showError(error);}
   }
   view.refresh=()=>renderPage(view.page);
   previous.onclick=()=>renderPage(Math.max(1,view.page-1));
   next.onclick=()=>renderPage(Math.min(pdf.numPages,view.page+1));
   footer.hidden=false;await renderPage(1);
  }else if(blob.type.startsWith('image/')){
   view.objectUrl=URL.createObjectURL(blob);const image=document.createElement('img');image.src=view.objectUrl;image.alt=name||'Uploaded document';content.replaceChildren(image);content.setAttribute('aria-busy','false');
  }else if(blob.type.startsWith('text/')){
   const text=await blob.text();if(!current())return;const pre=document.createElement('pre');pre.textContent=text;content.replaceChildren(pre);content.setAttribute('aria-busy','false');
  }else{
   const message=document.createElement('p');message.textContent='This file type needs to be downloaded to review it.';
   view.objectUrl=URL.createObjectURL(blob);const link=document.createElement('a');link.href=view.objectUrl;link.download=name||'document';link.className='btn primary';link.textContent='Download document';content.replaceChildren(message,link);content.setAttribute('aria-busy','false');
  }
 }catch(error){if(current()&&error.name!=='AbortError')showError(error);}
 function showError(error){content.setAttribute('aria-busy','false');const message=document.createElement('p');message.setAttribute('role','alert');message.textContent=error.message||'This document could not be opened.';content.replaceChildren(message);footer.hidden=true;}
}
window.TLDocumentViewer={open,close,isOpen:()=>!!active};
})();

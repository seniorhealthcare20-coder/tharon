/* Tharon's operator-supplied CalAIM process. Not an eligibility or clinical decision engine. */
(function(){
'use strict';
const VERSION=1;
const GEO={
 shadowridge:['San Diego','Oceanside','https://shadowridgeatmelrose.com/'],
 sierra:['San Bernardino','Victorville','https://www.sierravistaseniorliving.com/'],
 pointe:['Kern','Bakersfield','https://www.thepointesummithills.com/'],
 oxnard:['Ventura','Oxnard','https://www.assistedlivingcenter.com/facilities/ca/oxnard/the-vistas-at-oxnard-senior-living-93036/'],
 lakes:['Riverside','Banning','https://www.thelakesatbanning.com/'],
 sunlit:['San Bernardino','Alta Loma','https://www.ccld.dss.ca.gov/transparencyapi/api/FacilityReports?facNum=365530159&inx=6'],
 valley:['San Bernardino','Apple Valley','https://www.dhcs.ca.gov/services/long-term-care-alternatives-home-and-community-based-service-options/assisted-living-waiver-program-participating-facilities/'],
 lompoc:['Santa Barbara','Lompoc','https://www.ccld.dss.ca.gov/transparencyapi/api/FacilityReports?facNum=425850365&inx=10'],
 crescendo:['Orange','Placentia','https://www.crescendoseniorliving.com/'],
 hallmark:['Kern','Bakersfield','https://hallmarkofbakersfield.com/'],
 carrington:['Kern','Shafter','https://www.carringtonofshafter.com/'],
 riverside:['Riverside','Riverside','https://www.dhcs.ca.gov/services/long-term-care-alternatives-home-and-community-based-service-options/assisted-living-waiver-program-participating-facilities/'],
 crenshaw:['Los Angeles','Los Angeles','https://www.ccld.dss.ca.gov/transparencyapi/api/facilityreports?facnum=198601776&inx=5'],
 orangewood:['San Diego','El Cajon','Steven confirmed El Cajon, 2026-11-12'],
 modesto:['Stanislaus','Modesto','https://www.gardensofmodesto.com/'],
 plaza:['Los Angeles','Los Angeles','https://www.theplazawestwood.com/contact/'],
 bellevue:['Los Angeles','Pasadena','Existing operator-supplied Pasadena roster'],
 lincoln:['Los Angeles','Pasadena','Existing operator-supplied Pasadena roster'],
 carrolls:['San Diego','El Cajon','https://www.ccld.dss.ca.gov/transparencyapi/api/FacilityReports?facNum=374604690&inx=7']
};
const step=(key,label,party,phase,extra={})=>({key,label,party,phase,...extra});
const referral=step('referral','Referral received','Assigned marketer',1);
const fit=step('building_fit','Complete assessment and confirm building acceptance','Building assessment team',2,{evidence:true});
const schedule=step('schedule_movein','Schedule the move-in','Facility / family / referring team',4);
const moved=step('moved_in','Confirm resident moved in','Facility',4);
function baseConfig(county,program='calaim'){
 if(program==='alw')return alwConfig(county);
 const start=[referral,fit];
 const confirm=(plan,partner)=>step('confirm_pathway','Confirm '+plan+' pathway and '+partner+' contact','Assigned marketer',3,{evidence:true});
 const authorization=(plan)=>step('authorization','Receive and verify '+plan+' approval paperwork',plan,3,{evidence:true});
 if(['Ventura','Santa Barbara'].includes(county))return {county,supported:false,unavailable:true,plan:'Not available',partner:'',steps:[referral,step('review_program','CalAIM unavailable here — review program / building with Steven','Steven Aron',1)],note:'Steven confirmed CalAIM is not available for this county. Preserve the referral and review its program; do not change the payer automatically.'};
 if(county==='Orange')return {county,supported:true,plan:'CalOptima',partner:'CCA',beforeMove:['building_fit','confirm_pathway','movein_arrangement'],steps:[...start,confirm('CalOptima','CCA'),step('movein_arrangement','Confirm the move-in arrangement with the CCA','Facility + CCA',3,{evidence:true}),schedule,moved,step('notify_cca','Notify CCA the same day and send required documents','Facility',4,{afterMove:true,sameDay:true}),step('cca_submission','Confirm CCA submitted request to CalOptima','CCA',4,{afterMove:true}),{...authorization('CalOptima'),phase:4,afterMove:true}],note:'Your Orange County roadmap places CCA submission and the authorization letter after move-in. Confirm the individual arrangement; this tracker does not authorize admission. The 5–10 day letter timing in the notes is an estimate.'};
 if(['Riverside','San Bernardino'].includes(county))return {county,supported:true,plan:'IEHP',partner:'IEHP',beforeMove:['building_fit','confirm_pathway','loa_request','loa_ready'],steps:[...start,confirm('IEHP','IEHP'),step('loa_request','Submit referral to IEHP for an LOA','Internal team',3),step('loa_ready','Confirm LOA is drafted before move-in','Internal team + IEHP',3,{evidence:true}),schedule,moved],note:'Your roadmap requires the LOA to be drafted before move-in. Record the actual LOA arrangement and confirmation here.'};
 if(county==='San Diego')return {county,supported:true,plan:'CHG',partner:'CHG',beforeMove:['building_fit','confirm_pathway','authorization'],steps:[...start,confirm('CHG','CHG'),step('authorization_request','Request authorization from CHG','SNF or internal team',3),authorization('CHG'),schedule,moved],note:'SNF referral → request CHG authorization. Verification and building acceptance are Tharon tracking steps added to your roadmap.'};
 if(['Kern','Stanislaus'].includes(county)){const plan=county==='Kern'?'Anthem':'health plan (confirm with MasterCare)';return {county,supported:true,plan,partner:'MasterCare',beforeMove:['building_fit','confirm_pathway','assessment_submission','authorization'],steps:[...start,confirm(plan,'MasterCare'),step('assessment_submission','Send assessment to '+plan+' for approval','Assessment team / MasterCare',3),authorization(plan),schedule,moved],note:county==='Kern'?'MasterCare referral → assessment submitted to Anthem → approval.':'Steven requested the MasterCare sequence for Stanislaus. Confirm the actual health plan; Anthem is not assumed.'};}
 if(county==='Los Angeles')return {county,supported:true,plan:'L.A. Care',partner:'Libertana',beforeMove:['building_fit','confirm_pathway','libertana_submission','authorization'],steps:[...start,confirm('L.A. Care','Libertana'),step('libertana_submission','Submit referral to Libertana for L.A. Care authorization','Internal team → Libertana',3),authorization('L.A. Care'),schedule,moved],note:'SNF referral → internal team submits to Libertana for L.A. Care authorization. Confirm the actual plan and partner for this referral.'};
 return {county:county||'Not confirmed',supported:false,plan:'Needs confirmation',partner:'',steps:[referral,fit,step('confirm_county','Confirm building county and CalAIM process with Steven','Steven Aron',3)],note:'County or process not confirmed. No other county workflow has been substituted.'};
}
function config(county,program='calaim'){
 const cfg=baseConfig(county,program);if(program==='alw'||!cfg.supported)return cfg;
 const billing={Orange:['CCA','Confirm contracted billing handoff to the CCA'],Riverside:['IEHP / facility','Confirm back office IEHP billing and facility SSI collection handoff'],'San Bernardino':['IEHP / facility','Confirm back office IEHP billing and facility SSI collection handoff'],'San Diego':['CHG','Confirm CHG billing and applicable bed-hold arrangements'],Kern:['MasterCare','Confirm approval and contracted billing handoff to MasterCare'],Stanislaus:['MasterCare','Confirm actual plan approval and billing arrangement with MasterCare'],'Los Angeles':['Libertana','Confirm contracted billing handoff to Libertana']}[county];
 if(billing)cfg.steps.push(step('billing_handoff',billing[1],'Back office / '+billing[0],4,{afterMove:true,evidence:true}));return cfg;
}
function alwConfig(county){
 if(['Ventura','Santa Barbara'].includes(county))return {county,supported:false,unavailable:true,program:'ALW',plan:'ALW not available',partner:'CCA',steps:[referral,step('review_program','ALW unavailable here — review program / building with Steven','Steven Aron',1)],note:'Steven confirmed this ALW process excludes Ventura and Santa Barbara. Do not change the resident’s program or building automatically.'};
 if(!county)return {county:'Not confirmed',supported:false,plan:'ALW',partner:'CCA',steps:[referral,step('confirm_county','Confirm building county with Steven','Steven Aron',1)],note:'Confirm the building county before choosing this ALW process.'};
 return {county,supported:true,program:'ALW',plan:'ALW / DHCS',partner:'CCA',beforeMove:['transition','fast_track_letter','cca_verification','slot_release','building_fit'],steps:[referral,
 step('transition','Identify transition: community, SNF, APS or Ombudsman','Assigned marketer',1,{evidence:true}),
 step('fast_track_letter','Obtain and verify APS / Ombudsman fast-track letter','Assigned marketer → APS / Ombudsman',3,{evidence:true,whenFastTrack:true}),
 step('cca_verification','Verify waitlist date, submission type and current status with CCA','Assigned marketer → CCA',3,{evidence:true}),
 step('slot_release','Confirm waitlist release / slot and placement deadline with CCA','CCA',3,{evidence:true}),fit,
 step('dhcs_submission','Confirm assessment and signed ISP sent to DHCS','CCA',3,{evidence:true}),
 step('informing_notice','Receive and verify the Informing Notice','CCA',3,{evidence:true}),schedule,moved,
 step('billing_review','Confirm billing authorization with CCA / back office','Back office + CCA',4,{evidence:true})],
 note:'Your notes: community waitlist 3+ years; SNF 60+ days with an approximately 11-month waitlist; APS / Ombudsman fast-track 1–2 months. Pended means released, awaiting RCFE acceptance; placement 30–60 days. Enrolled in the notes means assessment / ISP sent to DHCS, not verified DHCS approval. Informing Notice estimated 5–10 days later. Confirm actual dates and billing authorization with the CCA.'};
}
const PAYMENTS=[['calaim','CalAIM','CalAIM Community Supports'],['alw','ALW','ALW waiver'],['private','Private pay','Private pay']];
function paymentOptions(id){return PAYMENTS.filter(([key])=>id==='crenshaw'?key==='calaim':['bellevue','lincoln'].includes(id)?key!=='private':true);}
function applyBuildingPolicy(l){
 const allowed=paymentOptions(l.building);if(allowed.some(x=>x[2]===l.payer))return false;
 if(l.building!=='crenshaw'&&(!l.payer||l.payer==='Other'))return false;
 if(l.building!=='crenshaw'&&!['bellevue','lincoln'].includes(l.building))return false;
 l.paymentHistory=[...(l.paymentHistory||[]),{payer:l.payer||'',programStatus:l.programStatus||'',at:new Date().toISOString(),reason:'Building program policy confirmed by Steven'}];
 l.payer=l.building==='crenshaw'?'CalAIM Community Supports':'Other';l.programStatus='not_started';return true;
}
const isCalAIM=l=>l?.payer==='CalAIM Community Supports';
const programOf=l=>isCalAIM(l)?'calaim':l?.payer==='ALW waiver'?'alw':null;
const isTracked=l=>!!programOf(l);
const date=d=>/^\d{4}-\d{2}-\d{2}$/.test(d||'')&&Number.isFinite(Date.parse(d))&&new Date(d+'T12:00:00Z').toISOString().slice(0,10)===d;
function businessDays(today,n){const d=new Date(today+'T12:00:00Z');while(n>0){d.setUTCDate(d.getUTCDate()+1);if(![0,6].includes(d.getUTCDay()))n--;}return d.toISOString().slice(0,10);}
function syncBuildings(state){let count=0;for(const b of state.buildings||[]){const geo=GEO[b.id];if(!geo)continue;if(b.county!==geo[0]||!b.countySource){b.county=geo[0];b.countySource=geo[2];if(!b.city)b.city=geo[1];count++;}}return count;}
function leadConfig(l,building){
 const cfg=config(building?.county||GEO[l.building]?.[0]||'',programOf(l));
 if(window.TLLibertana?.applicable(l,building)){cfg.steps.unshift(step('libertana_packet','Complete Libertana packet and receive signed copy','Assigned marketer / current care team / Libertana',1,{evidence:true}));cfg.beforeMove=['libertana_packet',...(cfg.beforeMove||[])];}
 return cfg;
}
function ensure(l,building,today){
 const policyChanged=applyBuildingPolicy(l),referenceChanged=window.TLLibertana?.syncReference(l,building)||false;
 if(!isTracked(l)){let changed=false;if(l.countyWorkflow&&l.countyWorkflow.active!==false){l.countyWorkflow.active=false;changed=true;}if(l.payer&&l.payer!=='Other'&&l.programReviewRequired){l.programReviewRequired=false;changed=true;}if((!l.payer||l.payer==='Other')&&!l.programReviewRequired){l.programReviewRequired=true;l.programReviewDue=today;changed=true;}return changed||policyChanged||referenceChanged;}
 if(l.programReviewRequired)l.programReviewRequired=false;
 const county=building?.county||GEO[l.building]?.[0]||'',cfg=leadConfig(l,building);
 if(l.countyWorkflow?.version===VERSION&&l.countyWorkflow.county===county&&l.countyWorkflow.program===programOf(l)&&l.countyWorkflow.active!==false){let added=false;for(const def of cfg.steps)if(!l.countyWorkflow.steps[def.key]){l.countyWorkflow.steps[def.key]={status:'not_started',owner:null,waitingOn:'',due:null,note:'',updatedAt:null,updatedBy:null};added=true;}return policyChanged||added||referenceChanged;}
 const old=l.countyWorkflow;const steps={};
 for(const def of cfg.steps){const value={status:'not_started',owner:null,waitingOn:'',due:null,note:'',updatedAt:null,updatedBy:null};
  if(def.key==='referral')value.status='done';
  if(def.key==='moved_in'&&l.stage==='movein'){value.status='done';value.note='Move-in already recorded in this profile.';}
  if(def.key==='schedule_movein'&&l.moveIn){value.status='done';value.note='Existing move-in date: '+l.moveIn;}
  steps[def.key]=value;
 }
 l.countyWorkflow={version:VERSION,county,program:programOf(l),reviewed:false,reviewDue:today,createdAt:today,steps,plan:'',legacy:{assessment:l.assessmentStatus||'',programApproval:l.programStatus||'',nextAction:l.nextAction||'',nextFollowUp:l.nextFollowUp||''},...(old?{previous:[...(old.previous||[]),{...old,previous:undefined}].slice(-3)}:{})};
 return true;
}
function migrate(state,today){syncBuildings(state);if(state.checkin){state.checkin.enabled=false;state.checkin.autoCool=false;}let count=0;for(const l of state.leads||[]){let changed=ensure(l,state.buildings.find(b=>b.id===l.building),today);if(changed){l.version=(l.version||0)+1;count++;}}return count;}
function summary(l,building,today){
 if(!isTracked(l))return null;
 const cfg=leadConfig(l,building);const flow=l.countyWorkflow;
 const applicable=cfg.steps.filter(d=>!d.whenFastTrack||['aps','ombudsman'].includes(flow?.transition));
 const steps=applicable.map(d=>({...d,...(d.key==='libertana_packet'?{label:window.TLLibertana.nextAction(l)}:{}),...(flow?.steps?.[d.key]||{status:d.key==='referral'?'done':'not_started'}),owner:flow?.steps?.[d.key]?.owner||l.rep||null,...(d.key==='libertana_packet'&&flow?.steps?.[d.key]?.status==='done'&&!window.TLLibertana.complete(l)?{status:'pending'}:{})}));
 const next=l.stage==='lost'?null:steps.find(s=>s.status!=='done'&&(!s.afterMove||l.stage==='movein'||flow?.steps?.moved_in?.status==='done'));
 const ready=cfg.supported&&(cfg.beforeMove||[]).filter(key=>applicable.some(s=>s.key===key)).every(key=>steps.find(s=>s.key===key)?.status==='done');
 const baseDue=next?.due||flow?.reviewDue||today,deadline=flow?.placementDeadline;
 return {config:cfg,steps,next,ready,reviewed:flow?.reviewed===true,due:deadline&&date(deadline)&&deadline<baseDue?deadline:baseDue,complete:!next,plan:flow?.plan||cfg.plan};
}
function update(l,building,key,patch,userId,today,users){
 ensure(l,building,today);const cfg=leadConfig(l,building),def=cfg.steps.find(d=>d.key===key);
 if(!def)throw Error('This step does not belong to the current county process.');
 if(!patch||Object.keys(patch).some(k=>!['status','owner','waitingOn','due','note','plan','moveIn','transition','waitlistDate','slotStatus','placementDeadline'].includes(k)))throw Error('Invalid county step update.');
 if(!['not_started','pending','blocked','done'].includes(patch.status))throw Error('Choose a step status.');
 if(!users.some(u=>u.id===patch.owner))throw Error('Choose the staff member responsible for this step.');
 for(const k of ['waitingOn','note','plan'])if(patch[k]!==undefined&&(typeof patch[k]!=='string'||patch[k].length>2000))throw Error('Check the step details.');
 if(patch.status!=='done'&&!date(patch.due))throw Error('Set a follow-up date for this unfinished step.');
 if(patch.due&&!date(patch.due))throw Error('Check the follow-up date.');
 if(key==='libertana_packet'&&patch.status==='done'&&!window.TLLibertana.complete(l))throw Error('Upload the signed PDF, verify every required signature and review the returned packet first.');
 if(patch.status==='done'&&def.evidence&&!patch.note?.trim())throw Error('Record who confirmed this step and the supporting details.');
 if(key==='confirm_pathway'&&patch.status==='done'&&!patch.plan?.trim())throw Error('Confirm the actual health plan for this referral.');
 if(patch.transition!==undefined&&!['community','snf','aps','ombudsman'].includes(patch.transition))throw Error('Choose the transition type.');
 if(patch.slotStatus!==undefined&&!['unknown','waitlist','coming_off','pended','submitted','notice_received'].includes(patch.slotStatus))throw Error('Choose the CCA status.');
 for(const k of ['waitlistDate','placementDeadline'])if(patch[k]&&!date(patch[k]))throw Error('Check the CCA dates.');
 if(key==='transition'&&patch.status==='done'&&!patch.transition)throw Error('Choose the transition type.');
 const current=summary(l,building,today);
 if(['schedule_movein','moved_in'].includes(key)&&patch.status==='done'&&!current.ready)throw Error('Confirm building acceptance and the county prerequisites before recording this step.');
 if(['schedule_movein','moved_in'].includes(key)&&patch.status==='done'&&!date(patch.moveIn))throw Error('Enter the scheduled move-in date.');
 if(def.afterMove&&patch.status==='done'&&l.stage!=='movein'&&l.countyWorkflow.steps.moved_in?.status!=='done')throw Error('This is a post-move-in step. Confirm the move-in first.');
 if(key==='confirm_pathway'&&patch.plan!==undefined)l.countyWorkflow.plan=patch.plan.trim();
 for(const key of ['transition','waitlistDate','slotStatus','placementDeadline'])if(patch[key]!==undefined)l.countyWorkflow[key]=patch[key];
 const saved={status:patch.status,owner:patch.owner,waitingOn:patch.waitingOn?.trim()||'',due:patch.status==='done'?null:patch.due,note:patch.note?.trim()||'',updatedAt:new Date().toISOString(),updatedBy:userId};
 l.countyWorkflow.steps[key]=saved;l.countyWorkflow.reviewed=true;
 if(['schedule_movein','moved_in'].includes(key)&&patch.status==='done')l.moveIn=patch.moveIn;
 const after=summary(l,building,today);if(after.next&&!after.next.due){const next=l.countyWorkflow.steps[after.next.key];next.due=after.next.sameDay?(String(l.moveIn||today).slice(0,10)):businessDays(today,2);}
 return def;
}
window.TLRoadmap={VERSION,GEO,paymentOptions,applyBuildingPolicy,config,isCalAIM,programOf,isTracked,date,businessDays,syncBuildings,ensure,migrate,summary,update};
})();

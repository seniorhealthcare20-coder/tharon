(async function(){
'use strict';const $=s=>document.querySelector(s),message=t=>{$('#message').textContent=t;};let setupToken=location.hash.slice(1);if(setupToken)history.replaceState(null,'',location.pathname);
async function post(url,data){const r=await fetch(url,{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(data)});const b=await r.json();if(!r.ok)throw new Error(b.error);return b;}
if(location.pathname==='/activate'&&!setupToken){location.replace('/login'+location.search);return;}
if(location.pathname==='/activate'){
 $('#loginForm').hidden=true;$('#heading').textContent='Welcome to Tharon Leads';$('#intro').textContent='Set up your staff account.';
 async function loadSetup(){try{const a=await post('/auth/setup',{token:setupToken});$('#activateForm').hidden=false;$('#account').textContent=a.name+' · '+a.email;if(a.totpSecret){$('#totpBox').hidden=false;$('#totpKey').textContent=a.totpSecret;}}catch(e){$('#activateForm').hidden=true;$('#loginForm').hidden=false;$('#heading').textContent='Sign in to Tharon Leads';$('#intro').textContent='Use your work email and password.';message('This setup link is no longer available. Sign in below, or ask Steven to set your password in Team.');}}
 await loadSetup();
}
const emailField=$('#loginForm').elements?.email,adminCode=$('#adminCodeField'),codeField=$('#loginForm').elements?.code;
function updateAdminCode(){if(!emailField||!codeField||!adminCode)return;const admin=emailField.value.trim().toLowerCase()==='steven@tharongroup.com';adminCode.hidden=!admin;codeField.disabled=!admin;codeField.required=admin;if(!admin)codeField.value='';}
if(emailField){emailField.addEventListener('input',updateAdminCode);emailField.addEventListener('change',updateAdminCode);updateAdminCode();}
$('#loginForm').onsubmit=async e=>{e.preventDefault();updateAdminCode();const f=e.currentTarget;f.querySelector('button').disabled=true;try{await post('/auth/login',Object.fromEntries(new FormData(f)));location.href=new URLSearchParams(location.search).get('next')==='/voice-test'?'/voice-test':'/';}catch(e){message(e.message);}finally{f.querySelector('button').disabled=false;}};
$('#activateForm').onsubmit=async e=>{e.preventDefault();const f=e.currentTarget,d=Object.fromEntries(new FormData(f));if(d.password!==d.confirm)return message('Passwords do not match.');f.querySelector('button').disabled=true;try{await post('/auth/activate',{token:setupToken,password:d.password,code:d.code});setupToken='';$('#totpKey').textContent='';location.href='/login';}catch(e){message(e.message);}finally{f.querySelector('button').disabled=false;}};
})();

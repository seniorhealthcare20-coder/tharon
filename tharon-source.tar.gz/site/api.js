/* Tharon Leads demo — data layer.
   One store, one set of mutations, one event stream. The UI, the assistant and the mock REST router
   all go through these functions, so the same shapes map 1:1 onto the production API in INTEGRATION.md.
   Demo: state lives in this browser's localStorage. Sample data only. */
(function(){
'use strict';
const KEY='tharon-marketer-preview-v2';
const {STAGES,DOCS,WDOCS}=window.TL_CONST;
const pad=n=>String(n).padStart(2,'0');
const iso=d=>d.getFullYear()+'-'+pad(d.getMonth()+1)+'-'+pad(d.getDate());
let T=new Date().toLocaleDateString('en-CA',{timeZone:'America/Los_Angeles'});
let TODAY=new Date(T+'T12:00:00');
function refreshDate(){const next=new Date().toLocaleDateString('en-CA',{timeZone:'America/Los_Angeles'});if(next===T)return false;T=next;TODAY=new Date(T+'T12:00:00');if(window.document&&typeof window.Event==='function')window.document.dispatchEvent(new window.Event('tl-date-change'));return true;}
const dayOf=ts=>ts?String(ts).slice(0,10):null;
const daysSince=ts=>{refreshDate();return ts?Math.round((Date.parse(T)-Date.parse(dayOf(ts)))/864e5):null;};
const daysUntil=ts=>{refreshDate();return ts?Math.round((Date.parse(dayOf(ts))-Date.parse(T))/864e5):null;};
const nowTs=()=>{const d=new Date();return iso(d)+'T'+pad(d.getHours())+':'+pad(d.getMinutes());};
const addDays=(n)=>{refreshDate();return new Date(Date.parse(T)+n*86400000).toISOString().slice(0,10);};

let S;
const listeners=[];
function load(){
  if(window.TL_BOOT&&window.TL_BOOT.state) return JSON.parse(JSON.stringify(window.TL_BOOT.state));
  try{const raw=localStorage.getItem(KEY); if(raw){const s=JSON.parse(raw); if(s&&s.version===3) return window.TL_SYNC_BUILDINGS?window.TL_SYNC_BUILDINGS(s):s;}}catch(e){}
  return fresh();
}
function fresh(){const s=window.TL_SEED(); s.done={}; s.snooze={}; s.emitted={}; s.checkin=s.checkin||{enabled:true,days:{hot:3,warm:7,cold:14},escalateAfter:2,autoCool:false}; s.leads.forEach(l=>{if(l.stage==='movein') l.bedCounted=true;}); return s;}
function save(){if(!window.TL_BOOT){try{localStorage.setItem(KEY,JSON.stringify(S));}catch(e){window.dispatchEvent&&window.dispatchEvent(new CustomEvent('tl-storage-error'));}} listeners.forEach(f=>f());}
function reset(){S=fresh(); save();}
S=load(); window.TLRoadmap?.migrate(S,T); if(!S.checkin) S.checkin={enabled:true,days:{hot:3,warm:7,cold:14},escalateAfter:2,autoCool:false};

/* ---------- lookups ---------- */
const U=id=>S.users.find(u=>u.id===id);
const B=id=>S.buildings.find(b=>b.id===id);
const Lead=id=>S.leads.find(l=>l.id===id);
const me=()=>U(S.me)||S.users[0];
const isAdmin=()=>me().role==='admin';
const leadName=l=>l.first+' '+l.last;
const stageLabel=k=>(STAGES.find(s=>s[0]===k)||[k,k])[1];
const docDef=k=>DOCS.find(d=>d.key===k)||WDOCS.find(d=>d.key===k);
const program=l=>l&&l.payer==='ALW waiver'?'alw':l&&l.payer==='CalAIM Community Supports'?'calaim':null;
const programLabel=p=>p==='alw'?'ALW':p==='calaim'?'CalAIM':'';
const wdocsFor=l=>{const p=program(l); return p?WDOCS.filter(d=>d.programs.includes(p)).map(d=>d.alt&&d.alt[p]?Object.assign({},d,d.alt[p],{verify:d.alt[p].src===''?true:(d.alt[p].verify!=null?d.alt[p].verify:d.verify)}):d):[];};
const isOpen=l=>l.stage!=='movein'&&l.stage!=='lost';
const visibleLeads=()=>S.leads;
function nextId(p){if(window.TL_ID_FACTORY)return window.TL_ID_FACTORY(p); S.seq=(S.seq||1000)+1;return p+S.seq;}

/* ---------- events (webhooks) ---------- */
function emit(type,data){
  const ev={id:nextId('evt_'),type,created_at:new Date().toISOString(),data,
    delivery:S.webhook&&S.webhook.url?('simulated: would POST to '+S.webhook.url):'recorded (no endpoint set)'};
  if(S.webhook&&S.webhook.events&&!S.webhook.events.includes(type)) ev.delivery='not subscribed';
  S.events.unshift(ev); S.events=S.events.slice(0,80);
  return ev;
}
function log(l,type,text,by){l.activity.unshift({at:nowTs(),by:by||S.me,type,text}); l.updated=nowTs();}

/* ---------- paperwork ---------- */
function ensureDocs(l){
  if(l.docs){for(const def of DOCS)if(!l.docs[def.key])l.docs[def.key]={status:'missing',due:null,requested:null,received:null};return l.docs;}
  const o={}; DOCS.forEach(d=>{o[d.key]={status:'missing',due:l.moveIn&&daysUntil(l.moveIn)>0?addDays(Math.max(1,daysUntil(l.moveIn)-2)):addDays(7),requested:null,received:null};});
  l.docs=o; return o;
}
/* Waiver / Medi-Cal checklist (ALW, CalAIM). Opens as soon as the payer is ALW or CalAIM; fills in new items if the payer changes. */
function ensureWDocs(l){
  const list=wdocsFor(l); if(!list.length) return l.wdocs||null;
  l.wdocs=l.wdocs||{};
  list.forEach(d=>{if(!l.wdocs[d.key]) l.wdocs[d.key]={status:'missing',due:l.moveIn&&daysUntil(l.moveIn)>0?addDays(Math.max(1,daysUntil(l.moveIn)-5)):addDays(7),requested:null,received:null};});
  return l.wdocs;
}
function wdocStats(l){
  const list=wdocsFor(l); if(!list.length) return {applies:false,req:0,got:0,missing:[]};
  ensureWDocs(l);
  const req=list.filter(d=>d.req&&l.wdocs[d.key].status!=='na'); const got=req.filter(d=>['received','approved'].includes(l.wdocs[d.key].status));
  return {applies:true,program:program(l),req:req.length,got:got.length,missing:req.filter(d=>!['received','approved'].includes(l.wdocs[d.key].status)).map(d=>d.key)};
}
function paperworkChecklist(l){
 const defs=wdocsFor(l);
 const labels={w_assess:'Assessment completed',w_informing:'Informing Notice',w_isp:'ISP packet',lic602a:'LIC 602A — physician report',agreement:'Admission Agreement',hmp:'H&P / HMP — History and Physical'};
 ensureWDocs(l);
 return ['agreement','lic602a','hmp',...(defs.length?['w_assess','w_informing','w_isp']:[])].map(key=>{const def=!/^w_/.test(key)?docDef(key):defs.find(d=>d.key===key);if(!def)return null;const value=(!/^w_/.test(key)?l.docs:l.wdocs)?.[key]||{status:'missing',due:null,requested:null,received:null};return {key,label:labels[key],status:value.status,due:value.due,received:value.received,optional:!def.req,requested:value.requested};}).filter(Boolean);
}
function setBuildingAccess(id,access){
 if(!isAdmin())throw new Error('Administrator only.');const u=U(id);if(!u||u.role!=='rep')throw new Error('Choose a marketer.');
 u.buildingAccess=access==='all'?'all':[...new Set(access)];save();return u;
}
function attachFile(id,file){
  const l=Lead(id); if(!l) throw new Error('lead not found');
  l.files=l.files||[];const existing=file.id&&l.files.find(f=>f.id===file.id);if(existing){existing.forms=[...new Set([...(existing.forms||[]),...(file.forms||[])])];log(l,'docs','Document classification updated: '+file.name);save();return l;}l.files.unshift(Object.assign({at:nowTs(),by:S.me},file));
  log(l,'docs','File attached: '+file.name+(file.forms&&file.forms.length?' ('+file.forms.join(', ')+')':'')+(file.id?'. Original file stored encrypted.':'. Preview: only the name is kept.'));
  save(); return l;
}
function docStats(l){
  const items=paperworkChecklist(l).filter(d=>d.status!=='na');
  const got=items.filter(d=>['received','approved'].includes(d.status));
  return {req:items.length,got:got.length,missing:items.filter(d=>['missing','pending'].includes(d.status)).map(d=>d.key),started:!!program(l)};
}
function setDoc(id,key,patch){
  const l=Lead(id); if(!l) throw new Error('lead not found');
  const bag=/^w_/.test(key)?ensureWDocs(l):ensureDocs(l);
  const d=bag&&bag[key]; if(!d) throw new Error('unknown document '+key);
  const before=d.status; Object.assign(d,patch);
  if(patch.status==='pending'&&before!=='pending'){d.requested=d.requested||T;d.received=null;d.approved=null;log(l,'docs',docDef(key).form+' pending.');}
  if(patch.status==='approved'&&before!=='approved'){d.approved=T;d.received=d.received||T;log(l,'docs',docDef(key).form+' marked approved.');}
  if(key==='w_assess'&&patch.status)l.assessmentStatus=['received','approved'].includes(patch.status)?'completed':patch.status==='pending'?'pending':'not_started';

  if(patch.status==='received'&&before!=='received'){d.received=T;d.approved=null; log(l,'docs',docDef(key).form+' received.');}
  if(patch.status==='missing'&&before!=='missing'){d.received=null;d.approved=null; log(l,'docs',docDef(key).form+' marked missing.'); emit('document.missing',{lead_id:l.id,document:key,form:docDef(key).form,due_date:d.due,assigned_rep_id:l.rep,building_id:l.building});}
  if(patch.status==='na'&&before!=='na') log(l,'docs',docDef(key).form+' marked not needed.');
  if('due' in patch && !('status' in patch)) log(l,'docs',docDef(key).form+' due date set to '+patch.due+'.');
  if(patch.requested && !('status' in patch)) log(l,'docs','Requested '+docDef(key).form+'.');
  save(); return l;
}


/* ---------- temperature, stale-lead check-ins, closing ----------
   Every open lead is Hot, Warm or Cold. Each temperature has an inactivity window (S.checkin.days). Past it, the rep
   gets a check-in on Today ("Any update on ...?"). After S.checkin.escalateAfter unanswered check-ins it goes to the
   admin as "needs a decision". Optional auto-cool steps Hot -> Warm -> Cold, never closes. In production this is a
   scheduled job (see CODEX-HANDOFF.md, Step 4b). */
const TEMPS=[['hot','Hot'],['warm','Warm'],['cold','Cold']];
const tempLabel=t=>(TEMPS.find(x=>x[0]===t)||['',''])[1];
const LOST_REASONS=['Chose another facility','Passed away','Too expensive','Not eligible','No response','Other'];
function lastActivity(l){let m=l.created||''; if(l.lastContact&&l.lastContact>m) m=l.lastContact; (l.activity||[]).forEach(a=>{if(!a.auto&&a.at>m) m=a.at;}); return m;}
function closedAt(l){if(isOpen(l)) return null; if(l.closedAt) return l.closedAt; const a=(l.activity||[]).find(a=>a.type==='stage'); return a?a.at:l.updated;}
function checkinState(l){
  if(!l||!isOpen(l)) return null; const c=S.checkin||{}; const t=l.temp||'hot'; const win=c.days&&c.days[t]; const idle=daysSince(lastActivity(l));
  const base={temp:t,idle,win,open:daysSince(l.created),stale:false};
  if(!c.enabled||!win||idle<win) return base;
  const sent=Math.floor(idle/win), unanswered=sent-1;
  return Object.assign(base,{stale:true,sent,unanswered,escalated:unanswered>=(c.escalateAfter||2)});
}
function setTemp(id,temp,how){
  const l=Lead(id); if(!l) throw new Error('lead not found'); if(!TEMPS.some(x=>x[0]===temp)) throw new Error('unknown temperature '+temp);
  const from=l.temp||'hot'; l.temp=temp;
  log(l,'temp',(how||'Temperature')+': '+(from===temp?'still '+tempLabel(temp).toLowerCase():tempLabel(from)+' \u2192 '+tempLabel(temp))+'.');
  emit('lead.temperature_changed',{lead_id:l.id,from,to:temp,assigned_rep_id:l.rep}); save(); return l;
}
function closeLead(id,outcome,reason){
  const l=Lead(id); if(!l) throw new Error('lead not found'); if(outcome==='lost'&&!reason) throw new Error('a reason is required to close a lead as lost');
  if(isOpen(l)) l.reopenTo=l.stage;
  setStage(id,outcome==='won'?'movein':'lost',reason); l.closedAt=nowTs(); l.closeOutcome=outcome;
  emit('lead.closed',{lead_id:l.id,outcome,reason:outcome==='lost'?reason:null,assigned_rep_id:l.rep,building_id:l.building}); save(); return l;
}
function reopenLead(id){
  const l=Lead(id); if(!l) throw new Error('lead not found'); if(isOpen(l)) return l;
  setStage(id,l.reopenTo&&!['movein','lost'].includes(l.reopenTo)?l.reopenTo:'contacted'); l.closedAt=null; l.closeOutcome=null; l.temp='hot';
  log(l,'stage','Reopened as a hot lead.'); save(); return l;
}
/* the "scheduled job" of the demo: runs on load and on every change */
function sweep(){
  const c=S.checkin; if(!c||!c.enabled||!c.autoCool) return false; let changed=false;
  S.leads.forEach(l=>{let st=checkinState(l), guard=0;
    while(st&&st.stale&&l.temp!=='cold'&&guard++<2){const from=l.temp||'hot'; l.temp=from==='hot'?'warm':'cold'; l.activity.unshift({at:nowTs(),by:'system',type:'temp',text:'Auto-cooled: '+tempLabel(from)+' \u2192 '+tempLabel(l.temp)+' after '+st.idle+' days with no activity.',auto:true}); changed=true; st=checkinState(l);}});
  if(changed) save(); return changed;
}
function checkinItems(l){
  const st=checkinState(l); if(!st||!st.stale) return [];
  const adm=S.users.find(u=>u.role==='admin'); const rep=U(l.rep);
  if(st.escalated) return [{id:'decide:'+l.id,rule:'needs_decision',checkin:true,channel:'none',leadId:l.id,rep:adm?adm.id:null,name:leadName(l),sev:'high',
    text:'Needs a decision: '+leadName(l)+'. '+st.unanswered+' check-ins unanswered'+(rep?' by '+rep.name.split(' ')[0]:'')+', no activity for '+st.idle+' days'}];
  return [{id:'checkin:'+l.id,rule:'checkin',checkin:true,channel:'none',leadId:l.id,rep:l.rep,name:leadName(l),sev:st.unanswered>0?'high':'med',
    text:'Any update on '+leadName(l)+'? Open '+st.open+' days, no activity for '+st.idle+(st.unanswered>0?' ('+((n=>n===2?'2nd':n===3?'3rd':n+'th')(st.unanswered+1))+' check-in)':'')}];
}
function marketerStats(id){
 const leads=S.leads.filter(l=>l.originRep===id);
 return {broughtIn:leads.length,movedIn:leads.filter(l=>l.stage==='movein').length,open:leads.filter(isOpen).length};
}
function pipelineStats(ls){
  const open=ls.filter(isOpen); const st=open.map(checkinState);
  const ages=open.map(l=>daysSince(l.created)||0); const m=T.slice(0,7);
  const closed=ls.filter(l=>!isOpen(l)&&String(closedAt(l)||'').slice(0,7)===m);
  return {open:open.length,avgAge:open.length?Math.round(ages.reduce((a,b)=>a+b,0)/open.length):0,stale:st.filter(x=>x&&x.stale).length,
    stalePct:open.length?Math.round(100*st.filter(x=>x&&x.stale).length/open.length):0,wonMonth:closed.filter(l=>l.stage==='movein').length,lostMonth:closed.filter(l=>l.stage==='lost').length,
    byTemp:Object.fromEntries(TEMPS.map(([k])=>[k,open.filter(l=>(l.temp||'hot')===k).length]))};
}

/* ---------- lead mutations ---------- */
function blankLead(){return {first:'',last:'',age:null,caller:{name:'',rel:'Self',phone:'',email:''},source:'Web',sourceDetail:'',cca:'',care:'',payer:'Other',budget:null,moveIn:null,rep:null,building:null,stage:'new',tourAt:null,touredAt:null,lostReason:'',notes:'',docs:null,lastContact:null,activity:[]};}
function roadmapActionId(l){const f=countySummary(l);return f?.next?[l.payer,f.config.county,f.next.key].join('|'):null;}
function matchesRoadmap(l,phase='all',action='all'){
 const f=countySummary(l);return (phase==='all'||phase==='untracked'&&!f||phase==='complete'&&f&&!f.next||String(f?.next?.phase)===phase)&&(action==='all'||roadmapActionId(l)===action);
}
function leadMatchesFilter(l,key){
 if(!l||l.stage==='lost')return false;
 const f=countySummary(l);const p=referralSummary(l);if(l.referralProgress&&p&&isOpen(l)){if(key==='assessment')return p.assessment!=='accepted';if(key==='awaiting-program')return !p.privatePay&&p.approval==='waiting';if(key==='approval-paperwork')return p.approval==='missing';if(key==='ready-movein')return p.stage==='movein';if(key==='overdue')return p.due<T;}
 if(key==='libertana-unsigned')return !!window.TLLibertana?.needsAttention(l,B(l.building));
 if(key==='awaiting-program')return !!f?.config.supported&&f.steps.some(s=>(s.phase===3||['authorization','loa_ready','informing_notice'].includes(s.key))&&s.status!=='done');
 if(key==='assessment')return isOpen(l)&&(f?f.steps.some(s=>s.key==='building_fit'&&s.status!=='done'):l.assessmentStatus==='pending'||l.stage==='assessment'&&l.assessmentStatus!=='completed');
 if(key==='overdue')return f?!!f.next&&f.due<T:isOpen(l)&&!!l.nextFollowUp&&l.nextFollowUp<T||isOpen(l)&&l.programReviewRequired&&l.programReviewDue<T;
 if(key==='blocked')return !!f?.steps.some(s=>s.status==='blocked');
 if(key==='needs-program')return isOpen(l)&&!!(l.programReviewRequired||l.programCorrectionReview||f?.config.unavailable);
 return isOpen(l);
}
function countySummary(l){refreshDate();const f=window.TLRoadmap?.summary(l,B(l?.building),T)||null;if(f?.next&&l.nextAction&&l.nextFollowUp)return {...f,due:l.nextFollowUp,next:{...f.next,label:'Staff follow-up: '+l.nextAction+' · Program next: '+f.next.label,owner:l.rep}};return f;}
function saveReferral(id,details,progress){const backup=JSON.parse(JSON.stringify(S));try{updateLead(id,details,true);return setReferralProgress(id,progress);}catch(error){S=backup;throw error;}}
function addReferrer(source,name){name=String(name||'').trim().replace(/\s+/g,' ');if(!window.TLCapture?.SOURCE?.includes(source)&&!['Hospital','SNF','Placement agency','Web','Referral','Other'].includes(source))throw Error('Choose a referral source.');if(!name||name.length>200)throw Error('Enter a name of up to 200 characters.');S.referrers=S.referrers||[];const existing=S.referrers.find(x=>x.source===source&&x.name.toLowerCase()===name.toLowerCase());if(existing)return existing;const entry={id:nextId('ref_'),source,name,createdBy:S.me,createdAt:nowTs()};S.referrers.push(entry);save();return entry;}
function addFollowupContact(input){
 if(!input||typeof input!=='object'||Array.isArray(input)||Object.keys(input).some(k=>!['name','role','email','phone'].includes(k)))throw Error('Check the follow-up contact details.');
 const c={};for(const key of ['name','role','email','phone']){if(typeof input[key]!=='string')throw Error('Check the follow-up contact details.');c[key]=input[key].trim();}
 c.name=c.name.replace(/\s+/g,' ');if(!c.name||c.name.length>200||!['Case manager','Social worker','Discharge planner','Other'].includes(c.role)||c.phone.length>80||c.email.length>254||c.email&&!/^[^\s@<>]+@[^\s@<>]+\.[^\s@<>]+$/.test(c.email)||/[\r\n]/.test(c.email+c.phone)||!c.email&&!c.phone)throw Error('Enter a name, role and an email or phone number.');
 S.followupContacts=S.followupContacts||[];const existing=S.followupContacts.find(x=>x.name.toLowerCase()===c.name.toLowerCase()&&x.role===c.role&&x.email.toLowerCase()===c.email.toLowerCase()&&x.phone===c.phone);if(existing)return existing;
 const entry={id:nextId('contact_'),...c,createdBy:S.me,createdAt:nowTs()};S.followupContacts.push(entry);save();return entry;
}
function referralSummary(l){refreshDate();const p=window.TLReferral?.summary(l,B(l?.building),T)||null;return p&&l.nextAction&&l.nextFollowUp?{...p,next:'Staff follow-up: '+l.nextAction+' · Program next: '+p.next,due:l.nextFollowUp}:p;}
function setReferralProgress(id,patch){const original=Lead(id);if(!original)throw Error('Lead not found.');const copy=JSON.parse(JSON.stringify(original));const result=window.TLReferral.apply(copy,B(copy.building),patch,S.me,T);const before=referralSummary(original);if(['assessment','approval','reason','moveStatus','due'].some(k=>(patch[k]||'')!==(before[k]||''))){copy.nextAction=null;copy.nextFollowUp=null;}Object.assign(original,copy);log(original,'followup','Referral progress: '+result.after.label+'. Next: '+result.after.next+(result.noteChanged&&patch.note.trim()?' Update: '+patch.note.trim():''));save();return original;}
function setCountyStep(id,key,patch){const l=Lead(id);if(!l)throw Error('Lead not found.');const def=window.TLRoadmap.update(l,B(l.building),key,patch,S.me,T,S.users);if(l.referralProgress){const p=l.referralProgress,flow=window.TLRoadmap.summary(l,B(l.building),T),approval=window.TLReferral.summary({...l,referralProgress:null},B(l.building),T);if(key==='building_fit')p.assessment=patch.status==='done'?'accepted':'pending';if(key===approval.approvalKey)p.approval=patch.status==='done'?'received':'waiting';if(flow?.next?.key===key&&patch.due)p.due=patch.due;}if(key==='moved_in'&&patch.status==='done')setStage(id,'movein');log(l,'followup',programLabel(program(l))+' '+B(l.building)?.county+': '+def.label+' — '+patch.status+'. Responsible: '+(U(patch.owner)?.name||'Unassigned')+'. '+(patch.note||''));save();return l;}
function createLead(data,how,progress){
  if(!data.building||!B(data.building))throw new Error('Choose a building before saving this lead.');
  const l=Object.assign(blankLead(),data); l.caller=Object.assign(blankLead().caller,data.caller||{});
  l.id=nextId('L'); l.created=nowTs(); l.updated=l.created; l.activity=[];
  if(!l.rep) l.rep=S.me;
  l.originRep=l.rep;l.createdBy=S.me;
  l.temp=l.temp||'hot'; log(l,'created',how||'Added by hand.'); ensureWDocs(l);
  window.TLRoadmap?.ensure(l,B(l.building),T);if(progress)window.TLReferral.apply(l,B(l.building),progress,S.me,T);S.leads.unshift(l);if(l.sourceDetail?.trim())addReferrer(l.source,l.sourceDetail); emit('lead.created',toApi(l)); save(); return l;
}
function updateLead(id,patch,quiet){
  const l=Lead(id); if(!l) throw new Error('lead not found');
  if(Object.hasOwn(patch,'libertana'))window.TLLibertana.validate(patch.libertana,l);
  if('building' in patch&&(!patch.building||!B(patch.building)))throw new Error('Choose a building.');
  if(patch.building&&patch.building!==l.building){assign(id,{building:patch.building});}
  if(Object.hasOwn(patch,'payer')&&patch.payer!==l.payer){
    const oldProgram=program(l)||'other',newProgram=program({payer:patch.payer})||'other';
    if(oldProgram!==newProgram){l.programRecords=l.programRecords||{};l.programRecords[oldProgram]={wdocs:JSON.parse(JSON.stringify(l.wdocs||{})),programStatus:l.programStatus||'not_started',referralProgress:l.referralProgress?JSON.parse(JSON.stringify(l.referralProgress)):null,tier:l.tier,assessmentStatus:l.assessmentStatus||(['received','approved'].includes(l.wdocs?.w_assess?.status)?'completed':'not_started')};
      const saved=l.programRecords[newProgram];l.referralProgress=saved?.referralProgress||null;l.wdocs=JSON.parse(JSON.stringify(saved?.wdocs||{}));l.programStatus=saved?.programStatus||'not_started';l.assessmentStatus=saved?.assessmentStatus||'not_started';}
  }
  if(patch.caller){l.caller=Object.assign({},l.caller,patch.caller); delete patch.caller;}
  Object.assign(l,patch);window.TLRoadmap?.ensure(l,B(l.building),T);ensureWDocs(l);if(patch.assessmentStatus&&l.wdocs?.w_assess){l.wdocs.w_assess.status=patch.assessmentStatus==='completed'?'received':patch.assessmentStatus==='pending'?'pending':'missing';if(patch.assessmentStatus==='completed')l.wdocs.w_assess.received=T;}const planned=('nextAction' in patch||'nextFollowUp' in patch);if(planned)l.lastReviewedAt=nowTs();if(l.sourceDetail?.trim())addReferrer(l.source,l.sourceDetail);if(!quiet)log(l,planned?'followup':'edit',planned?'Next step: '+l.nextAction+'. Due '+l.nextFollowUp+'.':'Lead details updated.');save();return l;
}
function setStage(id,stage,reason){
  const l=Lead(id); if(!l) throw new Error('lead not found');
  if(!STAGES.some(s=>s[0]===stage)) throw new Error('unknown stage '+stage);
  const from=l.stage; if(from===stage) return l;
  l.stage=stage;
  if(stage==='lost') l.lostReason=reason||l.lostReason||'No reason given';
  if(stage==='tour'&&!l.tourAt) l.tourAt=addDays(2)+'T11:00';
  if(stage==='toured'){l.touredAt=nowTs(); l.lastContact=nowTs();}
  if(stage==='contacted') l.lastContact=nowTs();
  if(stage==='assessment'||stage==='paperwork') ensureDocs(l);
  const b=B(l.building);
  if(stage==='movein'&&!l.bedCounted&&b&&Number.isFinite(b.licensed)&&Number.isFinite(b.occupied)){b.occupied=Math.min(b.licensed,b.occupied+1); l.bedCounted=true; if(!l.moveIn||daysUntil(l.moveIn)>0) l.moveIn=T;}
  if(from==='movein'&&l.bedCounted&&b){b.occupied=Math.max(0,b.occupied-1); l.bedCounted=false;}
  log(l,'stage','Stage: '+stageLabel(from)+' \u2192 '+stageLabel(stage)+(stage==='lost'?' ('+l.lostReason+')':'')+'.');
  emit('lead.stage_changed',{lead_id:l.id,from,to:stage,lost_reason:stage==='lost'?l.lostReason:null,building_id:l.building,assigned_rep_id:l.rep});
  save(); return l;
}
function assign(id,{building,rep}){
  const l=Lead(id); if(!l) throw new Error('lead not found');
  if(building!==undefined){
    if(!building||!B(building))throw new Error('Choose a building.');
    const ob=B(l.building),nb=B(building);
    if(l.bedCounted&&ob){ob.occupied=Math.max(0,ob.occupied-1); l.bedCounted=false;}
    l.building=building||null;
    if(l.stage==='movein'&&nb&&Number.isFinite(nb.licensed)&&Number.isFinite(nb.occupied)){nb.occupied=Math.min(nb.licensed,nb.occupied+1); l.bedCounted=true;}
    log(l,'assign',nb?'Assigned to '+nb.name+'.':'Building cleared.');
    emit('lead.assigned',{lead_id:l.id,building_id:l.building,assigned_rep_id:l.rep});
  }
  window.TLRoadmap?.ensure(l,B(l.building),T);
  if(rep!==undefined){const previousOwner=l.rep;l.rep=rep||null;for(const step of Object.values(l.countyWorkflow?.steps||{}))if(step.owner===previousOwner)step.owner=l.rep;S.tasks.filter(t=>t.leadId===id&&!t.done).forEach(t=>t.rep=l.rep); log(l,'assign',rep?'Rep: '+U(rep).name+'.':'Rep cleared.'); emit('lead.assigned',{lead_id:l.id,building_id:l.building,assigned_rep_id:l.rep});}
  save(); return l;
}
function addActivity(id,type,text){
  const l=Lead(id); if(!l) throw new Error('lead not found');
  log(l,type,text);if(type==='note')l.lastReviewedAt=nowTs(); if(type==='call'||type==='email'||type==='text') l.lastContact=nowTs(); save(); return l;
}
function addTask(t){const task=Object.assign({id:nextId('task_'),created:nowTs(),done:false,rep:S.me,due:T},t); S.tasks.unshift(task); if(task.leadId){const l=Lead(task.leadId); if(l) log(l,'task','Task added: '+task.text);} save(); return task;}

/* ---------- simulated messaging ---------- */
function simulateSend(channel,to,body,leadId){
  const m={id:nextId('msg_'),at:nowTs(),channel,to,body,leadId,status:'simulated \u2014 not sent'};
  S.outbox.unshift(m); S.outbox=S.outbox.slice(0,60);
  if(leadId){const l=Lead(leadId); if(l) log(l,channel==='sms'?'text':'email',(channel==='sms'?'Text':'Email')+' to '+to+' (simulated): \u201c'+body+'\u201d');}
  save(); return m;
}

/* ---------- reminders engine ---------- */
const fill=(tpl,v)=>tpl.replace(/\{(\w+)\}/g,(m,k)=>v[k]!=null?v[k]:m);
const fmtShort=d=>{if(!d)return '';const x=new Date(dayOf(d)+'T00:00:00');return x.toLocaleDateString('en-US',{month:'short',day:'numeric'});};
const fmtWhen=ts=>{if(!ts)return '';const n=daysUntil(ts);const day=n===0?'today':n===1?'tomorrow':fmtShort(ts);const hm=String(ts).slice(11,16);if(!hm)return day;let [h,m]=hm.split(':').map(Number);const ap=h>=12?'PM':'AM';h=h%12||12;return day+' '+h+':'+pad(m)+' '+ap;};
function remindersFor(l){
  const out=[]; if(!l) return out;if(l.programReviewRequired)return l.stage!=='lost'&&l.stage!=='movein'?[{id:'program-review:'+l.id,rule:'program_review',leadId:l.id,rep:l.rep,name:leadName(l),text:'Confirm the referral’s program: ALW, CalAIM or another program',due:l.programReviewDue||T,sev:'med',channel:'none'}]:[];const flow=countySummary(l);if(flow)return flow.next&&flow.due<=T?[{id:'county:'+l.id+':'+flow.next.key,rule:'county_step',leadId:l.id,rep:flow.next.owner,name:leadName(l),text:flow.next.label+(flow.next.waitingOn?' · Waiting on '+flow.next.waitingOn:''),due:flow.due,sev:flow.due<T?'high':'med',channel:'none'}]:[];
  const R=id=>id==='tour_confirm'?null:S.rules.find(r=>r.id===id&&r.enabled);
  const who=l.caller&&l.caller.name&&l.caller.rel!=='Self'?l.caller.name+' ('+l.caller.rel.toLowerCase()+' of '+l.first+')':leadName(l);
  const base={leadId:l.id,rep:l.rep,name:leadName(l)};
  const push=(rule,extra,vars)=>{const id=rule.id+':'+l.id;
    if(S.done[id]===T) return; if(S.snooze[id]&&S.snooze[id]>T) return;
    out.push(Object.assign({id,rule:rule.id,channel:rule.channel,text:fill(rule.text,Object.assign({name:leadName(l),who,source:l.source},vars))},base,extra));};
  let r;
  const lastTouch=l.lastReviewedAt||l.lastContact||l.created;
  if((r=R('new_first_call'))&&l.stage==='new'&&!l.lastContact&&!l.lastReviewedAt&&daysSince(l.created)>=r.days) {const n=daysSince(l.created); push(r,{sev:n>=r.days+2?'high':'med'},{n,ago:n===1?'yesterday':n+' days ago'});}
  if((r=R('tour_confirm'))&&l.stage==='tour'&&l.tourAt){const n=daysUntil(l.tourAt); if(n>=0&&n<=r.days&&l.tourConfirmedFor!==l.tourAt) push(r,{sev:n===0?'high':'med'},{n,when:fmtWhen(l.tourAt)});}
  if((r=R('post_tour'))&&l.stage==='toured'&&l.touredAt){const last=(l.lastContact&&l.lastContact>l.touredAt)?l.lastContact:l.touredAt; const n=daysSince(last); if(n>=r.days) push(r,{sev:n>=r.days+2?'high':'med'},{n:daysSince(l.touredAt)});}
  if((r=R('stale'))&&['contacted','tour','assessment'].includes(l.stage)){const n=daysSince(lastTouch); if(n>=r.days) push(r,{sev:'low'},{n});}
  const tracked=new Set(paperworkChecklist(l).filter(d=>/^w_/.test(d.key)||(d.key==='lic602a'&&wdocsFor(l).length)).map(d=>d.key));
  const agreeSoon=(()=>{const r2=R('movein_agreement'); if(!r2||!l.moveIn||!['toured','assessment','paperwork'].includes(l.stage)) return false; const n=daysUntil(l.moveIn); return n>=0&&n<=r2.days&&!(l.docs&&l.docs.agreement&&l.docs.agreement.status==='received');})();
  if(l.docs&&program(l)&&isOpen(l)){
    const rm=R('doc_missing'), ro=R('doc_overdue'); const late=[], over=[];
    DOCS.filter(d=>tracked.has(d.key)).forEach(d=>{const x=l.docs[d.key]; if(!x||(!d.req&&!x.requested)||!['missing','pending'].includes(x.status)) return; if(d.key==='agreement'&&agreeSoon) return;
      const reqDays=x.requested?daysSince(x.requested):null; const past=x.due&&daysUntil(x.due)<0;
      if(rm&&reqDays!=null&&reqDays>=rm.days) late.push({d,reqDays,past,due:x.due});
      else if(ro&&past) over.push({d,due:x.due});
    });
    const names=a=>a.length===1?a[0].d.form:a.length===2?a[0].d.form+' and '+a[1].d.form:a[0].d.form+', '+a[1].d.form+' and '+(a.length-2)+' more';
    if(late.length){const n=Math.max(...late.map(x=>x.reqDays)); const p=late.filter(x=>x.past);
      push(rm,{docs:late.map(x=>x.d.key),sev:p.length?'high':'med'},{doc:names(late),n}); const it=out[out.length-1];
      if(it&&it.rule==='doc_missing'&&it.leadId===l.id&&p.length) it.text+=' \u00b7 past due '+fmtShort(p[0].due);}
    if(over.length) push(ro,{docs:over.map(x=>x.d.key),sev:'high'},{doc:names(over),due:fmtShort(over[0].due)});
  }
  if((r=R('waiver_missing'))&&l.wdocs&&wdocsFor(l).length&&isOpen(l)){
    const late=[];
    wdocsFor(l).filter(d=>tracked.has(d.key)).forEach(d=>{const x=l.wdocs[d.key]; if(!x||(!d.req&&!x.requested)||!['missing','pending'].includes(x.status)) return; const reqDays=x.requested?daysSince(x.requested):null; const past=x.due&&daysUntil(x.due)<0;
      if((reqDays!=null&&reqDays>=r.days)||past) late.push({d,reqDays:reqDays||0,past,due:x.due});});
    if(late.length){const names=late.length===1?late[0].d.form:late.length===2?late[0].d.form+' and '+late[1].d.form:late[0].d.form+', '+late[1].d.form+' and '+(late.length-2)+' more';
      push(r,{docs:late.map(x=>x.d.key),sev:late.some(x=>x.past)?'high':'med'},{doc:names,n:Math.max(...late.map(x=>x.reqDays)),program:programLabel(program(l))});
      const it=out[out.length-1]; const p=late.filter(x=>x.past); if(it&&p.length) it.text+=' \u00b7 past due '+fmtShort(p[0].due);}
  }
  if(tracked.has('agreement')&&(r=R('movein_agreement'))&&['toured','assessment','paperwork'].includes(l.stage)&&l.moveIn){const n=daysUntil(l.moveIn); const ag=l.docs&&l.docs.agreement&&l.docs.agreement.status==='received'; if(n>=0&&n<=r.days&&!ag) push(r,{sev:'high'},{n});}
  checkinItems(l).forEach(x=>out.push(x));
  return out;
}
function taskActive(t){
 if(t.done||(!S.checkin?.enabled&&['checkin','needs_decision'].includes(t.sourceRule)))return false;const l=t.leadId?Lead(t.leadId):null;
 if(t.leadId&&(!l||!isOpen(l)))return false;if(t.sourceRule&&l?.nextFollowUp&&l.lastReviewedAt>=t.created)return false;
 if(t.docs?.length&&l){ensureWDocs(l);if(t.docs.every(k=>((/^w_/.test(k)?l.wdocs:l.docs)||{})[k]?.status!=='missing'))return false;}
 return true;
}
function upcomingTasks(scope){const legacy=legacyUpcomingTasks(scope).filter(t=>!Lead(t.leadId)?.referralProgress);if(!window.TLReferral)return legacy;const items=S.leads.filter(l=>isOpen(l)&&l.referralProgress).map(l=>{const p=referralSummary(l);return {id:'progress:'+l.id,text:p.next,due:p.due,rep:l.rep,leadId:l.id};}).filter(t=>t.due>T&&t.due<=addDays(7)&&(scope==='all'||!scope||t.rep===scope));return legacy.concat(items).sort((a,b)=>a.due.localeCompare(b.due));}
function legacyUpcomingTasks(scope){const plans=S.leads.filter(l=>isOpen(l)&&!countySummary(l)&&l.nextFollowUp>T&&l.nextFollowUp<=addDays(7)&&(scope==='all'||!scope||l.rep===scope)).map(l=>({id:'next:'+l.id,text:l.nextAction,due:l.nextFollowUp,rep:l.rep,leadId:l.id}));const programPlans=S.leads.map(l=>{const f=countySummary(l);return f?.next&&(scope==='all'||!scope||f.next.owner===scope)&&f.due>T&&f.due<=addDays(7)?{id:'county:'+l.id+':'+f.next.key,text:f.next.label,due:f.due,rep:f.next.owner,leadId:l.id}:null;}).filter(Boolean);return plans.concat(programPlans,S.tasks.filter(t=>taskActive(t)&&t.due>T&&t.due<=addDays(7)&&(scope==='all'||!scope||t.rep===scope))).sort((a,b)=>a.due.localeCompare(b.due));}
function allReminders(scope){
  refreshDate();  let list=[]; S.leads.forEach(l=>{list=list.concat(remindersFor(l));});
  list=list.filter(x=>!countySummary(Lead(x.leadId)));
  const contactRules=['new_first_call','stale','post_tour','checkin'];list=list.filter(x=>{const l=Lead(x.leadId);return !(l?.nextFollowUp&&contactRules.includes(x.rule));});
  S.leads.filter(l=>isOpen(l)&&!l.programReviewRequired&&!countySummary(l)&&l.nextFollowUp&&l.nextFollowUp<=T).forEach(l=>list.push({id:'next:'+l.id,rule:'next_action',leadId:l.id,rep:l.rep,name:leadName(l),text:l.nextAction,due:l.nextFollowUp,sev:l.nextFollowUp<T?'high':'med',channel:'none'}));
  for(const l of S.leads){const flow=countySummary(l);if(flow?.next&&flow.due<=T)list.push({id:'county:'+l.id+':'+flow.next.key,rule:'county_step',leadId:l.id,rep:flow.next.owner,name:leadName(l),text:flow.next.label+(flow.next.waitingOn?' · Waiting on '+flow.next.waitingOn:''),due:flow.due,sev:flow.due<T?'high':'med',channel:'none'});}
  const activeTasks=S.tasks.filter(t=>taskActive(t)&&(!countySummary(Lead(t.leadId))||!t.sourceRule));
  list=list.filter(x=>!activeTasks.some(t=>t.leadId&&t.leadId===x.leadId&&(t.suppressedRules||[t.sourceRule]).includes(x.rule)));
  activeTasks.filter(t=>t.due<=T).forEach(t=>{const l=Lead(t.leadId);list.push({id:t.id,rule:'task',sourceRule:t.sourceRule,docs:t.docs,due:t.due,channel:'none',text:t.text,leadId:t.leadId,rep:t.rep,name:l?leadName(l):'',sev:t.due<T?'high':'med',manual:true});});
  // document.missing webhooks fire once per day per missing item
  list.forEach(x=>{if(x.docs&&S.emitted[x.id]!==T){S.emitted[x.id]=T; const l=Lead(x.leadId); x.docs.forEach(k=>{const dk=(/^w_/.test(k)?l.wdocs:l.docs)[k]; emit('document.missing',{lead_id:x.leadId,document:k,checklist:/^w_/.test(k)?'waiver_medi_cal':'cdss_admission',form:docDef(k).form,due_date:dk.due,days_missing:dk.requested?daysSince(dk.requested):null,assigned_rep_id:l.rep,building_id:l.building,source:'reminder_rule'});});}});
  if(window.TLReferral){list=list.filter(x=>x.manual||!Lead(x.leadId)?.referralProgress);for(const lead of S.leads.filter(l=>isOpen(l)&&l.referralProgress)){const p=referralSummary(lead);if(p.due<=T)list.push({id:'progress:'+lead.id,rule:'referral_progress',leadId:lead.id,rep:lead.rep,name:leadName(lead),text:p.next,due:p.due,sev:p.due<T?'high':'med',channel:'none'});}}
  if(scope&&scope!=='all') list=list.filter(x=>x.rep===scope);
  const sv={high:0,med:1,low:2}; list.sort((a,b)=>sv[a.sev]-sv[b.sev]);
  return list;
}
function resolveTask(id,result){
 const x=allReminders(isAdmin()?'all':S.me).find(x=>x.id===id);if(!x)throw new Error('This task changed or is no longer due. Refresh and review it.');
 if(!result||Object.keys(result).some(k=>!['outcome','note','nextAction','nextDate'].includes(k)))throw new Error('Invalid follow-up details.');
 const rule=x.sourceRule||x.rule,docTask=!!x.docs?.length||rule==='movein_agreement',tourTask=rule==='tour_confirm';
 const allowed=docTask?['documents_requested','waiting_documents']:tourTask?['tour_confirmed','tour_completed','no_answer']:x.manual&&!x.sourceRule?['completed','contacted','no_answer','next_action']:['contacted','no_answer','next_action'];
 if(!allowed.includes(result.outcome))throw new Error('Choose an outcome for this task.');
 if(typeof result.note!=='string'||!result.note.trim()||result.note.length>4000)throw new Error('Record what happened before saving.');
 const needsNext=result.outcome!=='completed';
 if(needsNext&&(typeof result.nextAction!=='string'||!result.nextAction.trim()||result.nextAction.length>2000||!/^\d{4}-\d{2}-\d{2}$/.test(result.nextDate||'')||result.nextDate<T||result.nextDate>addDays(366)||!Number.isFinite(Date.parse(result.nextDate))||iso(new Date(result.nextDate+'T12:00'))!==result.nextDate))throw new Error('Choose a next action and a due date within the next year.');
 const l=x.leadId?Lead(x.leadId):null,old=S.tasks.find(t=>t.id===id);
 if(old){old.done=true;old.completedAt=nowTs();old.completedBy=S.me;old.outcome=result.outcome;old.result=result.note.trim();}else S.done[id]=T;
 if(l){
  log(l,'followup',result.outcome.replace(/_/g,' ')+': '+result.note.trim());
  if(result.outcome==='contacted'){l.lastContact=nowTs();if(l.stage==='new')setStage(l.id,'contacted');}
  if(result.outcome==='tour_confirmed')l.tourConfirmedFor=l.tourAt;
  if(result.outcome==='tour_completed')setStage(l.id,'toured');
  if(docTask){const keys=x.docs?.length?x.docs:['agreement'];ensureDocs(l);ensureWDocs(l);for(const key of keys){const d=(/^w_/.test(key)?l.wdocs:l.docs)?.[key];if(d?.status==='missing'){d.requested=T;d.due=result.nextDate;}}}
 }
 let nextTask=null;
 if(needsNext){const nextRule=result.outcome==='tour_completed'?'post_tour':rule;const suppressedRules=docTask?[nextRule]:['new_first_call','stale','post_tour','checkin','needs_decision',rule];nextTask=addTask({text:result.nextAction.trim(),due:result.nextDate,leadId:l?.id||null,rep:x.rep||S.me,sourceRule:nextRule,suppressedRules,docs:docTask?(x.docs?.length?x.docs:['agreement']):undefined});}
 save();return {leadId:l?.id||null,nextTask};
}
function completeReminder(id){const t=S.tasks.find(x=>x.id===id); if(t){t.done=true;} else S.done[id]=T; save();}
function snoozeReminder(id){const t=S.tasks.find(x=>x.id===id); if(t){t.due=addDays(1);} else S.snooze[id]=addDays(1); save();}

/* ---------- API shapes (snake_case, as in INTEGRATION.md) ---------- */
function toApi(l){
  return {id:l.id,first_name:l.first,last_name:l.last,age:l.age,
    contact:{name:l.caller.name,relationship:l.caller.rel,phone:l.caller.phone,email:l.caller.email},
    referral_source:l.source,referral_detail:l.sourceDetail,cca:l.cca||'',care_level:l.care,payer:l.payer,monthly_budget:l.budget,
    desired_move_in:l.moveIn,assigned_rep_id:l.rep,original_marketer_id:l.originRep||null,entered_by_id:l.createdBy||null,building_id:l.building,stage:l.stage,lost_reason:l.stage==='lost'?l.lostReason:null,
    tour_at:l.tourAt,notes:l.notes,created_at:l.created,updated_at:l.updated,last_contact_at:l.lastContact,
    paperwork:docStats(l).started?{required:docStats(l).req,received:docStats(l).got,missing:docStats(l).missing}:null,
    temperature:l.temp||'hot',status:isOpen(l)?'open':'closed',close_outcome:isOpen(l)?null:(l.closeOutcome||(l.stage==='movein'?'won':'lost')),closed_at:closedAt(l),
    last_activity_at:lastActivity(l),stale:!!(checkinState(l)&&checkinState(l).stale),checkins_unanswered:checkinState(l)&&checkinState(l).stale?checkinState(l).unanswered:0,
    payer_program:program(l),waiver_tier:l.tier||null,county:B(l.building)?.county||null,program_workflow:l.countyWorkflow||null,
    waiver_checklist:wdocStats(l).applies?{program:program(l),required:wdocStats(l).req,received:wdocStats(l).got,missing:wdocStats(l).missing}:null,
    attachments:(l.files||[]).map(f=>({file_name:f.name,mime_type:f.type,size_bytes:f.size,forms:f.forms||[],attached_at:f.at}))};
}
function fromApi(b){
  const c=b.contact||{}; const o={};
  const map={first_name:'first',last_name:'last',age:'age',referral_source:'source',referral_detail:'sourceDetail',cca:'cca',care_level:'care',payer:'payer',monthly_budget:'budget',desired_move_in:'moveIn',assigned_rep_id:'rep',building_id:'building',notes:'notes',tour_at:'tourAt',waiver_tier:'tier',temperature:'temp'};
  Object.keys(map).forEach(k=>{if(k in b) o[map[k]]=b[k];});
  if(b.contact) o.caller={name:c.name,rel:c.relationship,phone:c.phone,email:c.email};
  return o;
}
const docApi=(l)=>{ensureDocs(l); ensureWDocs(l); const row=(d,x,group)=>Object.assign({key:d.key,form:d.form,name:d.name,required:d.req,checklist:group},{status:x.status,due_date:x.due,requested_at:x.requested,received_at:x.received},d.src?{source_url:d.src,verify_with_cca:!!d.verify}:{}); return DOCS.map(d=>row(d,l.docs[d.key],'cdss_admission')).concat(wdocsFor(l).map(d=>row(d,l.wdocs[d.key],'waiver_medi_cal')));};
const bldApi=b=>{const ls=S.leads.filter(l=>l.building===b.id&&isOpen(l));return {id:b.id,name:b.name,city:b.city,licensed_beds:b.licensed,occupied_beds:b.occupied,open_beds:b.licensed-b.occupied,pipeline_leads:ls.length,license_number:b.lic};};
const userApi=u=>({id:u.id,name:u.name,role:u.role,title:u.title,email:u.email});
const taskApi=t=>({id:t.id,type:t.rule,text:t.text,lead_id:t.leadId,assigned_rep_id:t.rep,severity:t.sev,channel:t.channel,auto:!t.manual,due_date:T});

/* ---------- mock REST router: same paths as INTEGRATION.md, served from this browser ---------- */
function request(method,path,body){
  method=method.toUpperCase(); const [p,qs]=path.split('?'); const q=Object.fromEntries(new URLSearchParams(qs||''));
  const seg=p.replace(/^\/?(api\/v1\/)?/,'').split('/').filter(Boolean);
  const ok=(data,status)=>({status:status||200,body:data}); const nf=()=>({status:404,body:{error:'not_found'}});
  try{
    if(seg[0]==='users'&&method==='GET') return ok({data:S.users.map(userApi)});
    if(seg[0]==='buildings'){ if(seg[1]){const b=B(seg[1]); if(!b) return nf(); return ok(bldApi(b));} return ok({data:S.buildings.map(bldApi)});}
    if(seg[0]==='leads'){
      if(!seg[1]){
        if(method==='GET'){let ls=S.leads; if(q.rep_id) ls=ls.filter(l=>l.rep===q.rep_id); if(q.building_id) ls=ls.filter(l=>l.building===q.building_id); if(q.stage) ls=ls.filter(l=>l.stage===q.stage); if(q.temperature) ls=ls.filter(l=>isOpen(l)&&(l.temp||'hot')===q.temperature); if(q.status) ls=ls.filter(l=>q.status==='open'?isOpen(l):!isOpen(l)); if(q.stale==='true') ls=ls.filter(l=>{const s=checkinState(l);return !!(s&&s.stale);}); return ok({data:ls.map(toApi),count:ls.length});}
        if(method==='POST'){const l=createLead(fromApi(body||{}),'Created through the API.'); return ok(toApi(l),201);}
      }
      const l=Lead(seg[1]); if(!l) return nf();
      if(!seg[2]){ if(method==='GET') return ok(Object.assign(toApi(l),{activity:l.activity})); if(method==='PATCH'){const f=fromApi(body||{}); if(f.temp){setTemp(l.id,f.temp,'Temperature (API)'); delete f.temp;} if(Object.keys(f).length) updateLead(l.id,f); return ok(toApi(l));} }
      if(seg[2]==='stage'&&method==='POST'){setStage(l.id,body.stage,body.lost_reason); return ok(toApi(l));}
      if(seg[2]==='close'&&method==='POST'){closeLead(l.id,body.outcome,body.reason); return ok(toApi(l));}
      if(seg[2]==='reopen'&&method==='POST'){reopenLead(l.id); return ok(toApi(l));}
      if(seg[2]==='assign'&&method==='POST'){assign(l.id,{building:body.building_id,rep:body.assigned_rep_id}); return ok(toApi(l));}
      if(seg[2]==='activities'&&method==='POST'){addActivity(l.id,body.type||'note',body.text||''); return ok({data:l.activity.slice(0,1)},201);}
      if(seg[2]==='documents'){ if(!seg[3]) return ok({data:docApi(l)}); if(method==='PATCH'){setDoc(l.id,seg[3],{status:body.status,due:body.due_date}); return ok({data:docApi(l).find(d=>d.key===seg[3])});} }
    }
    if(seg[0]==='tasks'){
      if(method==='GET'){const list=allReminders(q.rep_id||'all'); return ok({data:list.map(taskApi),date:T});}
      if(method==='POST'){const t=addTask({text:body.text,leadId:body.lead_id,rep:body.assigned_rep_id,due:body.due_date||T}); return ok({id:t.id},201);}
      if(seg[1]&&method==='PATCH'&&body.done){completeReminder(seg[1]); return ok({id:seg[1],done:true});}
    }
    if(seg[0]==='export'&&method==='GET') return ok(exportJson());
    if(seg[0]==='webhooks'&&method==='GET') return ok({endpoint:S.webhook.url||null,events:S.webhook.events,recent:S.events.slice(0,10)});
    return {status:405,body:{error:'unsupported_in_demo',path:p,method}};
  }catch(e){return {status:422,body:{error:e.message}};}
}
function exportJson(){return {format:'tharon-leads/v1',exported_at:new Date().toISOString(),sample_data:true,users:S.users.map(userApi),buildings:S.buildings.map(bldApi),leads:S.leads.map(l=>Object.assign(toApi(l),{documents:l.docs?docApi(l):null,activity:l.activity})),tasks:allReminders('all').map(taskApi)};}
function importJson(obj,mode){
  if(!obj||obj.format!=='tharon-leads/v1'||!Array.isArray(obj.leads)) throw new Error('Not a Tharon Leads export file');
  let n=0;
  obj.leads.forEach(a=>{const ex=Lead(a.id); const data=fromApi(a); data.stage=a.stage||'new';
    if(a.documents){data.docs={}; a.documents.forEach(d=>{data.docs[d.key]={status:d.status,due:d.due_date,requested:d.requested_at,received:d.received_at};});}
    if(ex&&mode==='merge'){Object.assign(ex,data);} else if(!ex){const l=Object.assign(blankLead(),data); l.caller=Object.assign(blankLead().caller,data.caller||{}); l.id=a.id||nextId('L'); l.created=a.created_at||nowTs(); l.updated=nowTs(); l.activity=a.activity||[]; log(l,'created','Imported from a JSON export.'); S.leads.push(l); emit('lead.created',toApi(l));}
    n++;});
  save(); return n;
}

window.TL={get S(){return S;},replaceState:s=>{S=JSON.parse(JSON.stringify(s));},save,reset,onChange:f=>listeners.push(f),
  get T(){refreshDate();return T;},get TODAY(){refreshDate();return TODAY;},refreshDate,iso,addDays,daysSince,daysUntil,fmtShort,fmtWhen,nowTs,
  U,B,Lead,me,isAdmin,leadName,stageLabel,docDef,isOpen,visibleLeads,ensureDocs,docStats,ensureWDocs,wdocStats,wdocsFor,paperworkChecklist,program,programLabel,attachFile,
  TEMPS,tempLabel,LOST_REASONS,lastActivity,closedAt,checkinState,setTemp,closeLead,reopenLead,sweep,pipelineStats,marketerStats,
  referralSummary,addFollowupContact,addReferrer,saveReferral,setReferralProgress,createLead,updateLead,setStage,assign,setDoc,setBuildingAccess,addActivity,addTask,simulateSend,emit,countySummary,leadMatchesFilter,roadmapActionId,matchesRoadmap,setCountyStep,
  remindersFor,allReminders,upcomingTasks,resolveTask,completeReminder,snoozeReminder,
  toApi,request,exportJson,importJson,STAGES,DOCS,WDOCS};
/* For your sales system and for Codex: the same calls are reachable from the browser console, e.g.
   TharonLeadsAPI.request('GET','/api/v1/leads?building_id=b1') */
window.TharonLeadsAPI={request};
})();

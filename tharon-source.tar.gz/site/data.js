/* Tharon Leads demo — seed data.
   Every person, phone number, email, bed count and dollar amount in this file is FICTIONAL sample data.
   Real prospective-resident data is health information and belongs on Tharon's own secure hosting, never here. */
(function(){
  const pad=n=>String(n).padStart(2,'0');
  const iso=d=>d.getFullYear()+'-'+pad(d.getMonth()+1)+'-'+pad(d.getDate());
  const today=new Date(); today.setHours(0,0,0,0);
  const D=off=>{const d=new Date(today); d.setDate(d.getDate()+off); return iso(d);};
  const TS=(off,hm)=>D(off)+'T'+(hm||'10:00');

  const STAGES=[
    ['new','New'],['contacted','Contacted'],['tour','Tour scheduled'],['toured','Toured'],
    ['assessment','Assessment'],['paperwork','Paperwork'],['movein','Move-in'],['lost','Lost']
  ];

  /* California RCFE admission paperwork. Form numbers and names follow the CDSS forms list as read
     for the Tharon platform blueprint (Nov 10, 2026). The TB result is part of the physician's
     medical assessment under Title 22 section 87458. Confirm the final packet with your administrator. */
  const DOCS=[
    {key:'hmp',form:'H&P / HMP',name:'History and Physical',who:'Physician',req:false},
    {key:'lic602a',form:'LIC 602A',name:'Medical Assessment (physician\u2019s report)',who:'Physician',req:true},
    {key:'tb',form:'TB test',name:'TB test result (resident)',who:'Physician',req:true},
    {key:'lic603a',form:'LIC 603A',name:'Resident Appraisal (pre-admission)',who:'Administrator',req:true},
    {key:'lic601',form:'LIC 601',name:'Identification and Emergency Information',who:'Family',req:true},
    {key:'agreement',form:'LIC 604A',name:'Admission Agreement, signed',who:'Resident / representative',req:true},
    {key:'lic613c',form:'LIC 613C-2',name:'Personal Rights, signed receipt',who:'Resident / representative',req:true},
    {key:'lic627c',form:'LIC 627C',name:'Consent for Emergency Medical Treatment',who:'Resident / representative',req:true},
    {key:'lic605a',form:'LIC 605A',name:'Release of Medical Information',who:'Resident / representative',req:true},
    {key:'lic625',form:'LIC 625',name:'Appraisal / Needs and Services Plan',who:'Administrator',req:true},
    {key:'payer',form:'Payer',name:'Payer proof (ALW approval, LTC policy or deposit)',who:'Family',req:true},
    {key:'ids',form:'ID',name:'Photo ID, Medicare and insurance cards',who:'Family',req:true},
    {key:'polst',form:'POLST',name:'POLST / DNR, if the resident has one',who:'Physician',req:false}
  ];


  /* Waiver / Medi-Cal checklist for ALW and CalAIM Community Supports leads (Nov 12, 2026).
     The first four (steven:true) are Steven's own items, labelled in his words. The rest are the documents DHCS lists
     as required for a complete ALW application (DHCS 1327 / 1328 / 1331 checklists) and the CalAIM Community Supports
     Policy Guide's Assisted Living Facility Transitions rules. src = the official page each item comes from;
     verify:true = not confirmed on an official page, check with your CCA. alt = wording for one program.
     The physician's report (LIC 602A) is also an ALW application requirement; it is already in the CDSS list above. */
  const WDOCS=[
    {"key": "w_assess", "form": "Assessment", "name": "Assessment done: CCA RN assessment (Assessment Tool), with the tier level", "who": "Care Coordination Agency (RN)", "programs": ["alw", "calaim"], "req": true, "steven": true, "src": "https://www.dhcs.ca.gov/file/application-for-1915c-hcbs-waiver-ca0431r0400-march2024-pdf/", "note": "Tier 1–5. Submitted to DHCS within 60 days of the RN signature (45 for an existing resident).", "alt": {"calaim": {"name": "Assessment done: nursing facility level of care confirmed for Assisted Living Facility Transitions", "who": "Health plan / care manager", "src": "https://www.dhcs.ca.gov/file/dhcs-community-supports-policy-guide-pdf/", "note": "60+ days in a nursing facility, or meets nursing facility level of care in the community."}}, "verify": false},
    {"key": "w_hcode", "form": "H code", "name": "H code: Medi-Cal aid code consistent with the waiver (full scope, no share of cost)", "who": "Care Coordination Agency / county", "programs": ["alw", "calaim"], "req": true, "steven": true, "src": "https://www.dhcs.ca.gov/file/dhcs-0063-alw-informing-notice-form-pdf/", "verify": true, "note": "“H code” is Tharon’s term, not a DHCS one. DHCS requires an aid code consistent with the ALW; 1H / 6H (A&D FPL, full scope, no SOC) is our reading.", "alt": {"calaim": {"name": "H code: Medi-Cal aid code / eligibility confirmed", "src": "", "note": "Not on a DHCS page for CalAIM. Confirm with the health plan."}}},
    {"key": "w_informing", "form": "Informing Notice", "name": "Informing Notice (DHCS 0063) from the CCA: proof of ALW enrollment and its effective date", "who": "Care Coordination Agency", "programs": ["alw", "calaim"], "req": true, "steven": true, "src": "https://www.dhcs.ca.gov/file/alw-pl-26-002-pdf/", "note": "The facility uses it to verify enrollment before billing.", "verify": false, "alt": {"calaim": {"name": "Informing Notice — Tharon tracking item", "req": false, "verify": true, "src": "", "note": "Track when applicable to this lead. Confirm the requested document with the health plan or care manager; mark N/A when it is not needed."}}},
    {"key": "w_isp", "form": "ISP packet", "name": "ISP packet: Individualized Service Plan, signed", "who": "Care Coordination Agency (RN or social worker)", "programs": ["alw", "calaim"], "req": true, "steven": true, "src": "https://www.dhcs.ca.gov/file/individual-service-plan-desk-guide-aug2024-pdf/", "note": "Reviewed every 6 months.", "verify": false, "alt": {"calaim": {"name": "ISP packet / care plan — Tharon tracking item", "req": false, "verify": true, "src": "", "note": "Track when applicable to this lead. Confirm the requested document with the health plan or care manager; mark N/A when it is not needed."}}},
    {"key": "w_medical", "form": "Medi-Cal", "name": "Full-scope Medi-Cal: eligibility printout", "who": "Care Coordination Agency", "programs": ["alw"], "req": true, "src": "https://www.dhcs.ca.gov/services/long-term-care-alternatives-home-and-community-based-service-options/assisted-living-waiver/", "note": "The CCA re-checks eligibility monthly.", "verify": false, "steven": false},
    {"key": "w_soc", "form": "No SOC", "name": "No share of cost on the Medi-Cal", "who": "County / CCA", "programs": ["alw"], "req": true, "src": "https://www.dhcs.ca.gov/file/alw-program-descriptand-elig-2024-pdf/", "verify": false, "steven": false},
    {"key": "w_cca", "form": "CCA", "name": "Care Coordination Agency chosen and referral sent (phone pre-screen, then assessment)", "who": "Facility / family", "programs": ["alw"], "req": true, "src": "https://www.dhcs.ca.gov/file/alw-program-descriptand-elig-2024-pdf/", "verify": false, "steven": false},
    {"key": "w_waitlist", "form": "ALW slot", "name": "Waitlist request in, slot released (60 days to send a complete application)", "who": "Care Coordination Agency / DHCS", "programs": ["alw"], "req": true, "src": "https://www.dhcs.ca.gov/file/alw-pl24-002/", "verify": false, "steven": false},
    {"key": "w_foc", "form": "Freedom of Choice", "name": "Freedom of Choice form (DHCS 0062), signed", "who": "Resident / representative", "programs": ["alw"], "req": true, "src": "https://www.dhcs.ca.gov/file/dhcs-0062-alw-freedom-of-choice-form-pdf/", "verify": false, "steven": false},
    {"key": "w_amenity", "form": "Amenity form", "name": "Amenity form (DHCS 0060), signed", "who": "Resident / representative", "programs": ["alw"], "req": true, "src": "https://www.dhcs.ca.gov/file/dhcs-0060-alw-amenity-waiver-pdf/", "verify": false, "steven": false},
    {"key": "w_rights", "form": "Patient’s Rights", "name": "Patient’s Rights form (DHCS 1322), signed", "who": "RN or social worker + resident", "programs": ["alw"], "req": true, "src": "https://www.dhcs.ca.gov/file/alw-patients-rights-form-1322-pdf/", "verify": false, "steven": false},
    {"key": "w_mcp", "form": "Plan auth", "name": "Health plan authorization for Assisted Living Facility Transitions (auth number and dates)", "who": "Medi-Cal managed care plan", "programs": ["calaim"], "req": true, "src": "https://www.dhcs.ca.gov/file/dhcs-community-supports-policy-guide-pdf/", "note": "The plan must offer this Community Support; each plan uses its own forms.", "verify": false, "steven": false}
  ];

  const users=[
    {id:'u0',name:'Steven',role:'admin',title:'Owner \u00b7 admin',color:'#1d4d43',phone:'(555) 010-4000',email:'steven@example.com'},
    {id:'u1',name:'Maria Gonzalez',role:'rep',title:'Admissions \u00b7 Riverside & Bakersfield',color:'#b5541c',phone:'(555) 010-4001',email:'maria@example.com'},
    {id:'u2',name:'David Kim',role:'rep',title:'Admissions \u00b7 Pasadena',color:'#1d5fa8',phone:'(555) 010-4002',email:'david@example.com'},
    {id:'u3',name:'Jasmine Reed',role:'rep',title:'Community relations \u00b7 Van Nuys',color:'#7a3fa0',phone:'(555) 010-4003',email:'jasmine@example.com'},
    {id:'u4',name:'Tony Alvarez',role:'rep',title:'Hospital liaison',color:'#a35f00',phone:'(555) 010-4004',email:'tony@example.com'},
    {id:'u5',name:'Priya Patel',role:'rep',title:'Admissions \u00b7 Bakersfield',color:'#0f7b7b',phone:'(555) 010-4005',email:'priya@example.com'},
    {id:'u6',name:'Marcus Bell',role:'rep',title:'Placement agencies & web',color:'#8a2846',phone:'(555) 010-4006',email:'marcus@example.com'}
  ];

  /* Same sample buildings as the Tharon Care demo, plus Bakersfield. Bed numbers are sample numbers. */
  const buildings=[
    {id:'b1',name:'The Gardens of Riverside',short:'Riverside',city:'Riverside, CA',licensed:24,occupied:21,rate:'$5,800\u2013$7,200',lic:'DEMO-1001'},
    {id:'b2',name:'Maple Court',short:'Maple Court',city:'Pasadena, CA',licensed:18,occupied:16,rate:'$6,200\u2013$7,500',lic:'DEMO-1002'},
    {id:'b3',name:'Sunset Terrace',short:'Sunset',city:'Van Nuys, CA',licensed:12,occupied:11,rate:'$5,400\u2013$6,600',lic:'DEMO-1003'},
    {id:'b4',name:'Hallmark of Bakersfield',short:'Bakersfield',city:'Bakersfield, CA',licensed:99,occupied:88,rate:'$4,600\u2013$6,100',lic:'DEMO-1004'}
  ];

  /* docs helper: rec = keys received, reqAgo = days since the rest were requested, due = due-date offset */
  function docs(rec,reqAgo,due,na){
    const o={};
    DOCS.forEach(d=>{
      if(na && na.includes(d.key)) o[d.key]={status:'na',due:null,requested:null,received:null};
      else if(rec==='all' || rec.includes(d.key)) o[d.key]={status:'received',due:D(due),requested:D(-reqAgo),received:D(-Math.max(1,reqAgo-2))};
      else o[d.key]={status:'missing',due:D(due),requested:reqAgo>0?D(-reqAgo):null,received:null};
    });
    return o;
  }
  let n=0;
  function L(o){
    n++;
    const lead=Object.assign({
      id:'L'+String(100+n),
      age:null, caller:{}, source:'Web', sourceDetail:'', care:'Level 1 \u00b7 light assist', payer:'Private pay', budget:null,
      moveIn:null, rep:null, building:null, stage:'new', tier:null, wdocs:null, tourAt:null, touredAt:null, lostReason:'', notes:'', docs:null,
      created:TS(-1,'09:00'), updated:null, lastContact:null, activity:[]
    },o);
    lead.updated=lead.updated||lead.created;
    return lead;
  }
  const A=(off,hm,by,type,text)=>({at:TS(off,hm),by,type,text});

  const leads=[
    /* ---------- New ---------- */
    L({first:'Walter',last:'Brooks',age:81,caller:{name:'Walter Brooks',rel:'Self',phone:'(555) 010-3101',email:'w.brooks@example.com'},source:'Web',sourceDetail:'Website tour form',care:'Level 1 \u00b7 light assist',payer:'Private pay',budget:5500,moveIn:D(30),rep:'u2',building:'b2',stage:'new',created:TS(-2,'19:40'),
      activity:[A(-2,'19:40','system','created','Came in from the website tour form.')]}),
    L({first:'June',last:'Okafor',age:88,caller:{name:'Grace Okafor',rel:'Daughter',phone:'(555) 010-3102',email:'grace.o@example.com'},source:'Hospital',sourceDetail:'Valley General discharge planner (sample)',care:'Level 2 \u00b7 moderate assist',payer:'Private pay',budget:6500,moveIn:D(9),rep:'u4',building:'b1',stage:'new',created:TS(0,'08:15'),
      notes:'Discharge expected end of next week. Daughter wants a ground-floor room.',
      activity:[A(0,'08:15','u4','created','Referral from the discharge planner. Daughter is the main contact.')]}),
    L({first:'Samuel',last:'Reyes',age:79,caller:{name:'Lucia Reyes',rel:'Wife',phone:'(555) 010-3103',email:'lucia.r@example.com'},source:'Placement agency',sourceDetail:'Golden Path Placement (sample)',care:'Memory care',payer:'Long-term care insurance',budget:7000,moveIn:D(21),rep:'u6',building:null,stage:'new',created:TS(-1,'14:05'),
      activity:[A(-1,'14:05','u6','created','Agency sent the referral. Needs a secured memory care setting.')]}),
    L({first:'Beverly',last:'Tran',age:85,caller:{name:'Kevin Tran',rel:'Son',phone:'(555) 010-3104',email:'kevin.t@example.com'},source:'Web',sourceDetail:'Google search',care:'Level 1 \u00b7 light assist',payer:'VA Aid & Attendance',budget:4800,moveIn:D(45),rep:'u5',building:'b4',stage:'new',created:TS(-4,'11:30'),
      activity:[A(-4,'11:30','system','created','Came in from the website chat.')]}),

    /* ---------- Contacted ---------- */
    L({first:'Ruth',last:'Cohen',age:84,caller:{name:'Daniel Cohen',rel:'Son',phone:'(555) 010-3105',email:'daniel.cohen@example.com'},source:'Hospital',sourceDetail:'Mercy Ridge case manager (sample)',care:'Level 2 \u00b7 moderate assist',payer:'Private pay',budget:6000,moveIn:D(14),rep:'u1',building:null,stage:'contacted',created:TS(-3,'10:20'),lastContact:TS(-2,'15:10'),
      notes:'Son lives in Bakersfield and wants Mom close to him. Building not picked yet.',
      activity:[A(-3,'10:20','u1','created','Hospital case manager referral.'),A(-2,'15:10','u1','call','Spoke with Daniel. Wants a building near Bakersfield. Sending brochure.')]}),
    L({first:'Harold',last:'Jensen',age:90,caller:{name:'Karen Jensen',rel:'Daughter',phone:'(555) 010-3106',email:'karen.j@example.com'},source:'SNF',sourceDetail:'Pacific Rehab SNF (sample)',care:'Level 3 \u00b7 high assist',payer:'ALW waiver',budget:null,moveIn:D(20),rep:'u4',building:'b1',stage:'contacted',created:TS(-8,'09:00'),lastContact:TS(-7,'13:00'),
      notes:'ALW waiver application in progress with the care coordination agency.',
      activity:[A(-8,'09:00','u4','created','SNF social worker referral.'),A(-7,'13:00','u4','call','Karen confirmed ALW waiver interest. Waiting on her to call back with a tour time.')]}),
    L({first:'Nora',last:'Fitzgerald',age:77,caller:{name:'Nora Fitzgerald',rel:'Self',phone:'(555) 010-3107',email:'nora.fitz@example.com'},source:'Referral',sourceDetail:'Current resident\u2019s family',care:'Independent with reminders',payer:'Private pay',budget:5800,moveIn:D(60),rep:'u2',building:'b2',stage:'contacted',created:TS(-5,'16:00'),lastContact:TS(-1,'11:00'),
      activity:[A(-5,'16:00','u2','created','Friend of a Maple Court family.'),A(-1,'11:00','u2','email','Sent pricing sheet and menu.')]}),
    L({first:'Eugene',last:'Watts',age:83,caller:{name:'Pam Watts',rel:'Niece',phone:'(555) 010-3108',email:'pam.w@example.com'},source:'Placement agency',sourceDetail:'CareMatch Partners (sample)',care:'Level 2 \u00b7 moderate assist',payer:'SSI/SSP',budget:null,moveIn:D(10),rep:'u5',building:'b4',stage:'contacted',created:TS(-14,'10:00'),lastContact:TS(-9,'10:30'),
      activity:[A(-14,'10:00','u5','created','Agency referral.'),A(-9,'10:30','u5','call','Left a message for Pam.')]}),

    /* ---------- Tour scheduled ---------- */
    L({first:'Irene',last:'Wallace',age:86,caller:{name:'Tom Wallace',rel:'Son',phone:'(555) 010-3109',email:'tom.w@example.com'},source:'Web',sourceDetail:'A Place for Mom (sample)',care:'Level 2 \u00b7 moderate assist',payer:'Private pay',budget:6300,moveIn:D(18),rep:'u3',building:'b3',stage:'tour',tourAt:TS(1,'14:00'),created:TS(-6,'12:00'),lastContact:TS(-2,'10:00'),
      activity:[A(-6,'12:00','u3','created','Online referral.'),A(-2,'10:00','u3','stage','Tour booked for tomorrow at 2:00 PM.')]}),
    L({first:'Clarence',last:'Moody',age:92,caller:{name:'Denise Moody',rel:'Daughter',phone:'(555) 010-3110',email:'denise.m@example.com'},source:'Hospital',sourceDetail:'Valley General discharge planner (sample)',care:'Level 3 \u00b7 high assist',payer:'Private pay',budget:7200,moveIn:D(7),rep:'u1',building:'b1',stage:'tour',tourAt:TS(0,'16:30'),created:TS(-4,'09:45'),lastContact:TS(-1,'17:00'),
      activity:[A(-4,'09:45','u1','created','Hospital referral, urgent discharge.'),A(-1,'17:00','u1','stage','Tour today 4:30 PM.')]}),
    L({first:'Lorraine',last:'Pike',age:80,caller:{name:'Lorraine Pike',rel:'Self',phone:'(555) 010-3111',email:'lpike@example.com'},source:'Web',sourceDetail:'Facebook ad',care:'Level 1 \u00b7 light assist',payer:'Private pay',budget:5200,moveIn:D(40),rep:'u6',building:'b4',stage:'tour',tourAt:TS(3,'11:00'),created:TS(-3,'20:10'),lastContact:TS(-3,'20:30'),
      activity:[A(-3,'20:10','system','created','Facebook lead form.'),A(-3,'20:30','u6','stage','Booked a tour.')]}),

    /* ---------- Toured ---------- */
    L({first:'Dorothy',last:'Hayes',age:87,caller:{name:'Linda Hayes',rel:'Daughter',phone:'(555) 010-3112',email:'linda.h@example.com'},source:'Placement agency',sourceDetail:'Golden Path Placement (sample)',care:'Level 2 \u00b7 moderate assist',payer:'Private pay',budget:6800,moveIn:D(12),rep:'u1',building:'b1',stage:'toured',tourAt:TS(-3,'11:00'),touredAt:TS(-3,'12:00'),created:TS(-10,'10:00'),lastContact:TS(-3,'12:00'),
      notes:'Loved the garden. Comparing with one other community.',
      activity:[A(-10,'10:00','u1','created','Agency referral.'),A(-3,'12:00','u1','stage','Toured Riverside with daughter. Very positive.')]}),
    L({first:'Arnold',last:'Stein',age:89,caller:{name:'Rachel Stein',rel:'Daughter',phone:'(555) 010-3113',email:'rachel.s@example.com'},source:'Referral',sourceDetail:'Rabbi Levin (sample)',care:'Level 2 \u00b7 moderate assist',payer:'Long-term care insurance',budget:7000,moveIn:D(25),rep:'u2',building:'b2',stage:'toured',tourAt:TS(-1,'15:00'),touredAt:TS(-1,'16:00'),created:TS(-9,'13:00'),lastContact:TS(-1,'16:00'),
      activity:[A(-9,'13:00','u2','created','Community referral.'),A(-1,'16:00','u2','stage','Toured Maple Court. Wants kosher meal options.')]}),
    L({first:'Gladys',last:'Ortiz',age:82,caller:{name:'Ramon Ortiz',rel:'Son',phone:'(555) 010-3114',email:'ramon.o@example.com'},source:'SNF',sourceDetail:'Kern Valley Post-Acute (sample)',care:'Level 2 \u00b7 moderate assist',payer:'ALW waiver',budget:null,moveIn:D(16),rep:'u5',building:'b4',stage:'toured',tourAt:TS(-5,'10:00'),touredAt:TS(-5,'11:00'),created:TS(-12,'09:00'),lastContact:TS(-5,'11:00'),
      activity:[A(-12,'09:00','u5','created','SNF referral.'),A(-5,'11:00','u5','stage','Toured Bakersfield.')]}),

    /* ---------- Assessment ---------- */
    L({first:'Frances',last:'Delgado',age:85,caller:{name:'Michelle Delgado',rel:'Daughter',phone:'(555) 010-3115',email:'michelle.d@example.com'},source:'Hospital',sourceDetail:'Mercy Ridge case manager (sample)',care:'Level 3 \u00b7 high assist',payer:'Private pay',budget:7400,moveIn:D(8),rep:'u1',building:'b4',stage:'assessment',tourAt:TS(-7,'10:00'),touredAt:TS(-7,'11:00'),created:TS(-15,'10:00'),lastContact:TS(-1,'09:30'),
      docs:docs(['lic601','ids'],4,4,['polst']),
      activity:[A(-15,'10:00','u1','created','Hospital referral.'),A(-7,'11:00','u1','stage','Toured Bakersfield.'),A(-4,'10:00','u1','docs','Requested physician paperwork and appraisal.'),A(-1,'09:30','u1','call','Michelle says the doctor\u2019s office is slow. Following up.')]}),
    L({first:'Vincent',last:'Russo',age:78,caller:{name:'Vincent Russo',rel:'Self',phone:'(555) 010-3116',email:'vrusso@example.com'},source:'Web',sourceDetail:'Website tour form',care:'Level 1 \u00b7 light assist',payer:'Private pay',budget:5900,moveIn:D(20),rep:'u3',building:'b3',stage:'assessment',tourAt:TS(-6,'13:00'),touredAt:TS(-6,'14:00'),created:TS(-16,'09:00'),lastContact:TS(-2,'14:00'),
      docs:docs(['lic601','ids','payer','tb'],2,10,[]),
      activity:[A(-16,'09:00','system','created','Website tour form.'),A(-6,'14:00','u3','stage','Toured Sunset Terrace.'),A(-2,'14:00','u3','docs','Appraisal visit booked.')]}),
    L({first:'Mabel',last:'Chen',age:91,caller:{name:'Alice Chen',rel:'Granddaughter',phone:'(555) 010-3117',email:'alice.c@example.com'},source:'Placement agency',sourceDetail:'CareMatch Partners (sample)',care:'Level 4 \u00b7 hospice',payer:'Private pay',budget:7500,moveIn:D(5),rep:'u4',building:'b1',stage:'assessment',tourAt:TS(-5,'10:00'),touredAt:TS(-5,'11:00'),created:TS(-11,'10:00'),lastContact:TS(-1,'12:00'),
      docs:docs(['lic601','ids','polst'],3,3,[]),
      notes:'Hospice agency already involved. Hospice election paperwork comes with the physician packet.',
      activity:[A(-11,'10:00','u4','created','Agency referral.'),A(-5,'11:00','u4','stage','Toured Riverside.'),A(-3,'09:00','u4','docs','Requested LIC 602A from physician.')]}),

    /* ---------- Paperwork ---------- */
    L({first:'Margaret',last:'Silva',age:84,caller:{name:'Paul Silva',rel:'Son',phone:'(555) 010-3118',email:'paul.s@example.com'},source:'Hospital',sourceDetail:'Valley General discharge planner (sample)',care:'Level 2 \u00b7 moderate assist',payer:'Private pay',budget:6600,moveIn:D(3),rep:'u1',building:'b1',stage:'paperwork',tourAt:TS(-12,'10:00'),touredAt:TS(-12,'11:00'),created:TS(-20,'10:00'),lastContact:TS(-1,'16:00'),
      docs:docs(['tb','lic603a','lic601','lic613c','lic627c','lic605a','lic625','payer','ids'],5,1,['polst']),
      activity:[A(-20,'10:00','u1','created','Hospital referral.'),A(-12,'11:00','u1','stage','Toured Riverside. Chose room 105.'),A(-5,'10:00','u1','docs','Sent move-in packet and physician request.'),A(-1,'16:00','u1','call','Paul will sign the agreement this week. Doctor still hasn\u2019t sent the 602A.')]}),
    L({first:'Albert',last:'Nguyen',age:86,caller:{name:'Susan Nguyen',rel:'Wife',phone:'(555) 010-3119',email:'susan.n@example.com'},source:'SNF',sourceDetail:'Pacific Rehab SNF (sample)',care:'Level 3 \u00b7 high assist',payer:'ALW waiver',budget:null,moveIn:D(9),rep:'u2',building:'b2',stage:'paperwork',tourAt:TS(-14,'10:00'),touredAt:TS(-14,'11:00'),created:TS(-25,'10:00'),lastContact:TS(-3,'10:00'),
      docs:docs(['lic602a','tb','lic603a','lic601','lic625','ids'],6,5,[]),
      notes:'Waiting on ALW waiver approval letter from the care coordinator.',
      activity:[A(-25,'10:00','u2','created','SNF referral.'),A(-14,'11:00','u2','stage','Toured Maple Court.'),A(-6,'10:00','u2','docs','Sent packet.'),A(-3,'10:00','u2','call','Susan is gathering cards and ID.')]}),
    L({first:'Rose',last:'Bauer',age:88,caller:{name:'Ellen Bauer',rel:'Daughter',phone:'(555) 010-3120',email:'ellen.b@example.com'},source:'Referral',sourceDetail:'Dr. Hale\u2019s office (sample)',care:'Memory care',payer:'Private pay',budget:7900,moveIn:D(6),rep:'u5',building:'b4',stage:'paperwork',tourAt:TS(-10,'10:00'),touredAt:TS(-10,'11:00'),created:TS(-18,'10:00'),lastContact:TS(-2,'10:00'),
      docs:docs(['lic602a','tb','lic603a','lic601','agreement','lic613c','lic625','payer'],4,2,[]),
      activity:[A(-18,'10:00','u5','created','Physician referral.'),A(-10,'11:00','u5','stage','Toured Bakersfield memory care wing.'),A(-4,'10:00','u5','docs','Packet sent by email.')]}),
    L({first:'Leonard',last:'Price',age:80,caller:{name:'Leonard Price',rel:'Self',phone:'(555) 010-3121',email:'lprice@example.com'},source:'Web',sourceDetail:'Website chat',care:'Level 1 \u00b7 light assist',payer:'Private pay',budget:5600,moveIn:D(15),rep:'u3',building:'b3',stage:'paperwork',tourAt:TS(-9,'10:00'),touredAt:TS(-9,'11:00'),created:TS(-19,'10:00'),lastContact:TS(-1,'10:00'),
      docs:docs(['lic602a','tb','lic603a','lic601','agreement','lic613c','lic627c','lic605a','payer','ids'],3,8,['polst']),
      activity:[A(-19,'10:00','system','created','Website chat.'),A(-9,'11:00','u3','stage','Toured Sunset Terrace.'),A(-3,'10:00','u3','docs','Packet sent.')]}),

    /* ---------- Move-in ---------- */
    L({first:'Edith',last:'Morales',age:83,caller:{name:'Carlos Morales',rel:'Son',phone:'(555) 010-3122',email:'carlos.m@example.com'},source:'Hospital',sourceDetail:'Mercy Ridge case manager (sample)',care:'Level 2 \u00b7 moderate assist',payer:'Private pay',budget:6400,moveIn:D(-5),rep:'u1',building:'b1',stage:'movein',tourAt:TS(-20,'10:00'),touredAt:TS(-20,'11:00'),created:TS(-30,'10:00'),lastContact:TS(-5,'10:00'),
      docs:docs('all',14,-6,[]),
      activity:[A(-30,'10:00','u1','created','Hospital referral.'),A(-5,'10:00','u1','stage','Moved in to Riverside, room 108.')]}),
    L({first:'Stanley',last:'Wright',age:87,caller:{name:'Joan Wright',rel:'Wife',phone:'(555) 010-3123',email:'joan.w@example.com'},source:'Placement agency',sourceDetail:'Golden Path Placement (sample)',care:'Level 3 \u00b7 high assist',payer:'Long-term care insurance',budget:7300,moveIn:D(-2),rep:'u5',building:'b4',stage:'movein',tourAt:TS(-16,'10:00'),touredAt:TS(-16,'11:00'),created:TS(-26,'10:00'),lastContact:TS(-2,'10:00'),
      docs:docs('all',12,-3,[]),
      activity:[A(-26,'10:00','u5','created','Agency referral.'),A(-2,'10:00','u5','stage','Moved in to Bakersfield.')]}),
    L({first:'Thelma',last:'Ross',age:90,caller:{name:'Brian Ross',rel:'Son',phone:'(555) 010-3124',email:'brian.r@example.com'},source:'SNF',sourceDetail:'Kern Valley Post-Acute (sample)',care:'Level 2 \u00b7 moderate assist',payer:'ALW waiver',budget:null,moveIn:D(-40),rep:'u2',building:'b2',stage:'movein',tourAt:TS(-55,'10:00'),touredAt:TS(-55,'11:00'),created:TS(-62,'10:00'),lastContact:TS(-40,'10:00'),
      docs:docs('all',50,-41,['polst']),
      activity:[A(-62,'10:00','u2','created','SNF referral.'),A(-40,'10:00','u2','stage','Moved in to Maple Court.')]}),

    /* ---------- Lost ---------- */
    L({first:'Howard',last:'Klein',age:85,caller:{name:'Amy Klein',rel:'Daughter',phone:'(555) 010-3125',email:'amy.k@example.com'},source:'Web',sourceDetail:'Google search',care:'Level 2 \u00b7 moderate assist',payer:'Private pay',budget:4000,moveIn:null,rep:'u6',building:'b3',stage:'lost',lostReason:'Budget too low for private pay',created:TS(-21,'10:00'),lastContact:TS(-15,'10:00'),
      activity:[A(-21,'10:00','system','created','Website lead.'),A(-15,'10:00','u6','stage','Lost: budget too low.')]}),
    L({first:'Florence',last:'Abbott',age:93,caller:{name:'George Abbott',rel:'Son',phone:'(555) 010-3126',email:'george.a@example.com'},source:'Hospital',sourceDetail:'Valley General discharge planner (sample)',care:'Level 4 \u00b7 hospice',payer:'Private pay',budget:7000,moveIn:null,rep:'u4',building:'b1',stage:'lost',lostReason:'Chose a community closer to family',created:TS(-35,'10:00'),lastContact:TS(-28,'10:00'),
      activity:[A(-35,'10:00','u4','created','Hospital referral.'),A(-28,'10:00','u4','stage','Lost: chose a community closer to family.')]}),

    /* ---------- CalAIM Community Supports (added for the waiver checklist) ---------- */
    L({first:'Rosalind',last:'Hughes',age:81,caller:{name:'Terrence Hughes',rel:'Son',phone:'(555) 010-3131',email:'terrence.h@example.com'},source:'Hospital',sourceDetail:'Mercy Ridge case manager (sample)',care:'Level 2 \u00b7 moderate assist',payer:'CalAIM Community Supports',budget:null,moveIn:D(12),rep:'u5',building:'b4',stage:'assessment',tourAt:TS(-6,'10:00'),touredAt:TS(-6,'11:00'),created:TS(-10,'09:30'),lastContact:TS(-2,'14:00'),
      notes:'Health plan care manager is sending the Community Supports authorization.',
      activity:[A(-10,'09:30','u5','created','Hospital case manager referral, CalAIM Community Supports.'),A(-2,'14:00','u5','call','Spoke with Terrence. Plan authorization still pending.')]}),
    L({first:'Ernest',last:'Mendoza',age:77,caller:{name:'Ernest Mendoza',rel:'Self',phone:'(555) 010-3132',email:'ernest.m@example.com'},source:'Referral',sourceDetail:'Church friend (sample)',care:'Level 1 \u00b7 light assist',payer:'CalAIM Community Supports',budget:null,moveIn:D(40),rep:'u1',building:'b1',stage:'new',created:TS(0,'09:10'),
      activity:[A(0,'09:10','u1','created','Called in himself. Has Medi-Cal through a health plan.')]})
  ];

  /* Waiver checklist state for the ALW / CalAIM sample leads. r = received keys, req = days since the rest were requested. */
  const progOf=l=>l.payer==='ALW waiver'?'alw':l.payer==='CalAIM Community Supports'?'calaim':null;
  function wstate(last,r,req,due,tier){
    const l=leads.find(x=>x.last===last); if(!l) return; const p=progOf(l); const o={};
    WDOCS.filter(d=>d.programs.includes(p)).forEach(d=>{
      if(r==='all'||r.includes(d.key)) o[d.key]={status:'received',due:D(due),requested:D(-req-2),received:D(-Math.max(1,req-1))};
      else o[d.key]={status:'missing',due:D(due),requested:req>0?D(-req):null,received:null};
    });
    l.wdocs=o; if(tier) l.tier=tier;
  }
  wstate('Jensen',['w_medical'],4,10);
  wstate('Ortiz',['w_medical','w_hcode','w_cca','w_waitlist','w_soc','w_foc'],5,8);
  wstate('Nguyen',['w_medical','w_hcode','w_cca','w_waitlist','w_informing','w_soc','w_foc','w_amenity','w_rights'],6,4);
  wstate('Ross','all',50,-45,2);
  wstate('Hughes',['w_hcode','w_assess'],4,6);
  wstate('Mendoza',[],0,14);

  /* Hot / Warm / Cold. With the default windows (Hot 3, Warm 7, Cold 14 days without activity) Beverly Tran and
     Harold Jensen are due a check-in today and Eugene Watts has two unanswered check-ins, so he goes to Steven. */
  const TEMP={Warm:['Jensen','Ortiz','Pike','Hayes','Wallace','Stein','Russo','Nguyen','Bauer','Hughes','Reyes'],Cold:['Abbott','Klein']};
  leads.forEach(l=>{l.temp=TEMP.Warm.includes(l.last)?'warm':TEMP.Cold.includes(l.last)?'cold':'hot';});


  /* Reminder rules: visible and editable on the Reminders page. {n} = days, {who} = caller, {name} = prospective resident. */
  const rules=[
    {id:'new_first_call',enabled:true,days:1,channel:'none',name:'First call on a new lead',text:'First call: {name} came in {ago} ({source})',desc:'A lead in New with no contact after this many days.'},
    {id:'tour_confirm',enabled:true,days:1,channel:'sms',name:'Confirm upcoming tour',text:'Confirm the tour with {who} ({when})',desc:'A tour is this many days away or less. Sends the family a reminder text.'},
    {id:'post_tour',enabled:true,days:2,channel:'none',name:'Call back after tour',text:'Call back {who}: {n} days since the tour',desc:'A lead in Toured with no contact since the tour after this many days.'},
    {id:'stale',enabled:true,days:5,channel:'none',name:'No contact for a while',text:'Check in with {who}: no contact in {n} days',desc:'An open lead (before Paperwork) with no logged contact for this many days.'},
    {id:'doc_missing',enabled:true,days:3,channel:'email',name:'Paperwork still missing',text:'{doc} still missing for {name}: {n} days',desc:'A required document requested this many days ago or more and not received. Emails the family or physician a nudge.'},
    {id:'waiver_missing',enabled:true,days:3,channel:'none',name:'Waiver / Medi-Cal item missing',text:'{doc} still missing for {name} ({program}): {n} days',desc:'An ALW or CalAIM checklist item requested this many days ago or more, or past its due date, and not received.'},
    {id:'doc_overdue',enabled:true,days:0,channel:'none',name:'Document past its due date',text:'{doc} for {name} is past due ({due})',desc:'A required document whose due date has passed.'},
    {id:'movein_agreement',enabled:true,days:3,channel:'sms',name:'Move-in soon, agreement unsigned',text:'Move-in in {n} days for {name}: admission agreement unsigned',desc:'Desired move-in is this many days away or less and the admission agreement is not received.'}
  ];

  const SAMPLE_CSV=[
    'Resident name,Age,Contact name,Relationship,Phone,Email,Referral source,Referred by,Care needs,Payer,Monthly budget,Move-in date,Building,Notes',
    'Agnes Whitaker,86,Robert Whitaker,Son,(555) 010-5201,robert.w@example.com,Hospital,Valley General (sample),Level 2,Private pay,6200,'+D(20)+',Riverside,Needs a walker-friendly room',
    'Oscar Delacruz,82,Oscar Delacruz,Self,(555) 010-5202,oscar.d@example.com,Web,Website form,Level 1,Private pay,5400,'+D(35)+',Hallmark of Bakersfield,Wants to visit with his daughter',
    'Pearl Jacobs,89,Miriam Jacobs,Daughter,(555) 010-5203,miriam.j@example.com,SNF,Pacific Rehab (sample),Level 3,ALW waiver,,'+D(14)+',Hallmark of Bakersfield,ALW application started',
    'Curtis Bowman,80,Lena Bowman,Wife,(555) 010-5204,lena.b@example.com,Placement agency,CareMatch Partners (sample),Memory care,Long-term care insurance,7600,'+D(28)+',,Agency says wandering risk',
    'Ida Ferreira,91,Paulo Ferreira,Grandson,(555) 010-5205,paulo.f@example.com,Hospital,Mercy Ridge (sample),Level 4 hospice,Private pay,7400,'+D(7)+',The Lakes at Banning,Hospice already involved',
    'Ruth Cohen,84,Daniel Cohen,Son,(555) 010-3105,daniel.cohen@example.com,Hospital,Mercy Ridge (sample),Level 2,Private pay,6000,'+D(14)+',,Possible duplicate of an existing lead'
  ].join('\n');

  window.TL_SEED=function(){
    return JSON.parse(JSON.stringify({version:3,seedDay:D(0),users,buildings,leads,rules,tasks:[],events:[],outbox:[],chat:[],webhook:{url:'',secret:'',events:['lead.created','lead.stage_changed','document.missing']},me:'u0',seq:1000,checkin:{enabled:true,days:{hot:3,warm:7,cold:14},escalateAfter:2,autoCool:false}}));
  };
  window.TL_CONST={STAGES,DOCS,WDOCS,SAMPLE_CSV};
})();

/* Cache only public static assets. Never cache sign-in responses, records or files. */
const CACHE='tharon-leads-shell-v42';
const SHELL=['brand/tharon-group.png','styles.css','data.js','roster.js','capture.js','libertana.js','libertana-ui.js','libertana-pdf.js','county-roadmap.js','referral-progress.js','followup-contacts.js','pdf-intake.js','import-utils.js','api.js','remote.js','assistant.js','document-viewer.js','app.js','vendor/xlsx.full.min.js','manifest.webmanifest','icons/tharon-symbol-white-192.png','icons/tharon-symbol-white-512.png'];
self.addEventListener('install',e=>e.waitUntil(caches.open(CACHE).then(c=>c.addAll(SHELL)).then(()=>self.skipWaiting())));
self.addEventListener('activate',e=>e.waitUntil(caches.keys().then(ks=>Promise.all(ks.filter(k=>k!==CACHE).map(k=>caches.delete(k)))).then(()=>self.clients.claim())));
self.addEventListener('fetch',e=>{const u=new URL(e.request.url);if(e.request.method!=='GET'||u.origin!==self.location.origin||!SHELL.some(s=>u.pathname.endsWith('/'+s)))return;
 e.respondWith(fetch(e.request).catch(()=>caches.match(e.request)));
});

self.addEventListener('push',e=>{e.waitUntil(self.registration.showNotification('Tharon Leads',{body:'You have follow-ups waiting. Open the app to review them.',icon:'icons/tharon-symbol-white-192.png',tag:'tharon-followups',data:{path:'./#/today'}}));});
self.addEventListener('notificationclick',e=>{e.notification.close();e.waitUntil(self.clients.openWindow(new URL('./#/today',self.registration.scope).href));});

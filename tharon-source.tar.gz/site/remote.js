/* Authenticated transport: no resident records or session tokens in browser storage. */
(function(){
'use strict';
if(!window.TL_BOOT)return;
const TL=window.TL,boot=window.TL_BOOT;
const originals={},queue=[];let running=false,broken=false,replaying=false,lastError=null,importing=false,refreshing=false;
let confirmed=structuredClone(boot.state),lastSettings=JSON.stringify({rules:confirmed.rules,checkin:confirmed.checkin});
const clone=x=>JSON.parse(JSON.stringify(x));
let forced=null;
window.TL_ID_FACTORY=p=>(forced&&forced[p])||(p+'_'+crypto.randomUUID());
function status(text,kind='saved'){const el=document.getElementById('syncStatus');if(el){el.textContent=text;el.dataset.state=kind;}}
function error(text){status(text,'error');const t=document.getElementById('toast');if(t){t.textContent=text;t.classList.add('show');}document.dispatchEvent(new CustomEvent('tl-sync-error',{detail:text}));}
async function request(url,options={}){const r=await fetch(url,{credentials:'same-origin',...options,headers:{'X-CSRF-Token':boot.csrf,...options.headers}});let b;try{b=await r.json();}catch{throw new Error('The server could not be reached. Keep this page open and retry.');}if(r.status===401){location.href='/login';throw new Error('Please sign in again.');}if(!r.ok)throw Object.assign(new Error(b.error||'Could not save.'),{status:r.status});return b;}
function apply(item){if(item.op==='settings'){Object.assign(TL.S,clone(item.args[0]));return;}
 forced=item.createdId?{L:item.createdId,task_:item.createdId,ref_:item.createdId,contact_:item.createdId}:null;try{originals[item.op](...clone(item.args));}finally{forced=null;}}
function rebuild(){replaying=true;try{TL.replaceState(confirmed);for(const item of queue)apply(item);}finally{replaying=false;}document.dispatchEvent(new Event('tl-remote-state'));}
async function pump(){if(running||broken||!queue.length)return;running=true;status('Saving to shared database…','saving');
 try{while(queue.length){const item=queue[0],command=clone(item);if(['updateLead','setStage','assign','setDoc','addActivity','attachFile','setTemp','closeLead','reopenLead','setCountyStep','setReferralProgress','saveReferral'].includes(item.op))command.expectedVersion=confirmed.leads.find(l=>l.id===item.args[0])?.version||0;
  if(item.op==='resolveTask'&&item.recordId)command.expectedVersion=confirmed.leads.find(l=>l.id===item.recordId)?.version||0;
  const result=await request('/api/commands',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(command)});confirmed=result.state;queue.shift();rebuild();}
  status('Saved to shared database');
 }catch(e){broken=true;lastError=e;error((e.status===409?'Conflict: ':e.status?'Save failed: ':'Connection lost: ')+e.message+' Your unsaved changes remain on this screen.');}
 finally{running=false;}
}
for(const op of ['createLead','updateLead','setStage','assign','setDoc','addActivity','attachFile','setTemp','closeLead','reopenLead','addTask','completeReminder','snoozeReminder','resolveTask','setBuildingAccess','setCountyStep','setReferralProgress','saveReferral','addReferrer','addFollowupContact']){
 originals[op]=TL[op];TL[op]=function(...args){if(replaying)return originals[op](...args);if(boot.mode==='setup')throw new Error('Account setup only: lead capture is not open yet.');if(importing)throw new Error('Wait for the spreadsheet import to finish.');if(broken)throw new Error('Resolve the unsaved changes before making another change.');const captured=clone(args),value=originals[op](...args);const item={id:crypto.randomUUID(),op,args:captured};if(op==='createLead'||op==='addTask'||op==='addReferrer'||op==='addFollowupContact')item.createdId=value.id;if(op==='resolveTask'){item.recordId=value.leadId;if(value.nextTask)item.createdId=value.nextTask.id;}queue.push(item);pump();return value;};
}
const originalSave=TL.save;TL.save=function(){originalSave();if(replaying)return;const next={rules:TL.S.rules,checkin:TL.S.checkin},signature=JSON.stringify(next);if(signature!==lastSettings){if(!TL.isAdmin())return;lastSettings=signature;queue.push({id:crypto.randomUUID(),op:'settings',args:[clone(next)]});pump();}};
TL.sweep=()=>false;TL.reset=()=>{throw new Error('Reset is unavailable in the shared app.');};
TL.simulateSend=()=>{error('Messaging is not connected. This reminder is available in Today; nothing was sent.');};
TL.importJson=()=>{throw new Error('Use the CSV or Excel importer to add leads. Database replacement is disabled.');};
TL.request=(m)=>({status:405,body:{error:'Use the app controls to make changes.'}});
const uploadIds=new WeakMap();TL.uploadFile=async file=>{if(!uploadIds.has(file))uploadIds.set(file,'file_'+crypto.randomUUID());return request('/api/files',{method:'POST',headers:{'Content-Type':file.type||'application/octet-stream','X-File-Name':encodeURIComponent(file.name),'X-Upload-ID':uploadIds.get(file)},body:file});};
TL.flush=async()=>{while(running)await new Promise(r=>setTimeout(r,30));if(queue.length)throw new Error('This change has not reached the database. Keep the app open and retry.');};
async function refresh(){TL.refreshDate();if(refreshing||importing||running||queue.length||broken||!navigator.onLine||!document.getElementById('modal')?.hidden||['INPUT','TEXTAREA','SELECT'].includes(document.activeElement?.tagName))return;refreshing=true;try{const result=await request('/api/state');if(importing||running||queue.length||broken)return;if(result.state.revision>confirmed.revision||result.state.accessSignature!==confirmed.accessSignature){confirmed=result.state;rebuild();}status('Saved to shared database');}catch(e){if(!queue.length)status('Cannot refresh · check connection','error');}finally{refreshing=false;}}
async function reviewConflict(){
 try{const result=await request('/api/state'),item=queue[0],current=result.state.leads.find(l=>l.id===item?.args[0]);const host=document.getElementById('modal'),content=document.getElementById('modalBody');
 content.replaceChildren();const heading=document.createElement('h3');heading.id='modalTitle';heading.textContent='Review unsaved changes';content.append(heading);
 const message=document.createElement('p');message.textContent='The database could not accept this change. Your unsaved work remains in this open tab. Compare it before choosing what to do.';content.append(message);
 const title=document.createElement('b');title.textContent='Your pending change';content.append(title);const draft=document.createElement('pre');draft.className='code';draft.textContent=JSON.stringify({action:item?.op,details:item?.args},null,2);content.append(draft);
 const latest=document.createElement('p');latest.textContent=current?'Current database record: '+current.first+' '+current.last+' · '+current.stage+' · '+(current.building||'unassigned'):'The current record is unavailable, or this is a new lead matching an existing record.';content.append(latest);
 if(current&&lastError?.status===409){const keep=document.createElement('button');keep.className='btn primary';keep.textContent='Apply my change to current version';keep.onclick=()=>{confirmed=result.state;broken=false;lastError=null;host.hidden=true;rebuild();pump();};content.append(keep);}
 const discard=document.createElement('button');discard.className='btn ghost';discard.textContent='Discard unsaved changes and refresh';discard.onclick=()=>{queue.splice(0);confirmed=result.state;broken=false;lastError=null;host.hidden=true;rebuild();status('Loaded current database version');};content.append(discard);
 const cancel=document.createElement('button');cancel.className='btn ghost';cancel.textContent='Keep reviewing';cancel.onclick=()=>{host.hidden=true;};content.append(cancel);host.hidden=false;
 }catch(e){error(e.message);}
}
window.TLRemote={request,refresh,importLeads:async batch=>{await TL.flush();if(importing)throw new Error('An import is already running.');importing=true;status('Saving spreadsheet to shared database…','saving');try{const result=await request('/api/import',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(batch)});confirmed=result.state;rebuild();status('Saved to shared database');return result;}catch(e){status('Import not confirmed · retry the same file','error');throw e;}finally{importing=false;}},enableNotifications:async()=>{if(!('Notification' in window)||!('PushManager' in window))throw new Error('On iPhone, add the app to your Home Screen in Safari, then open it there to enable reminders.');const permission=await Notification.requestPermission();if(permission!=='granted')throw new Error('Notifications were not enabled. Your follow-ups remain in Today.');const reg=await navigator.serviceWorker.ready;const {publicKey}=await request('/api/push/key');const bytes=Uint8Array.from(atob(publicKey.replace(/-/g,'+').replace(/_/g,'/')+'='.repeat((4-publicKey.length%4)%4)),c=>c.charCodeAt(0));const sub=await reg.pushManager.getSubscription()||await reg.pushManager.subscribe({userVisibleOnly:true,applicationServerKey:bytes});await request('/api/push/subscribe',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(sub)});},disableNotifications:async()=>{const reg=await navigator.serviceWorker.ready,sub=await reg.pushManager.getSubscription();if(sub){await request('/api/push/unsubscribe',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({endpoint:sub.endpoint})});await sub.unsubscribe();}},retry:async()=>{if(lastError?.status&&lastError.status<500){await reviewConflict();return;}broken=false;pump();},get pending(){return queue.length;},get broken(){return broken;}};
window.addEventListener('beforeunload',e=>{if(queue.length){e.preventDefault();e.returnValue='';}});
window.addEventListener('online',()=>{if(queue.length){broken=false;pump();}else refresh();});
window.addEventListener('offline',()=>status('Offline · keep this page open until changes save','error'));
window.addEventListener('focus',refresh);setInterval(refresh,10000);
let lastTouch=0;function touchSession(){if(Date.now()-lastTouch<60000)return;lastTouch=Date.now();request('/api/activity',{method:'POST'}).catch(()=>{});}document.addEventListener('pointerdown',touchSession);document.addEventListener('keydown',touchSession);
window.addEventListener('DOMContentLoaded',()=>{
 const sel=document.getElementById('userSel');sel.disabled=true;
 const banner=document.querySelector('.demo-banner');if(boot.mode==='live')banner.hidden=true;else if(boot.mode==='setup')banner.innerHTML='<strong>Account setup</strong> · Lead capture opens after the live launch checks are complete.';else banner.innerHTML='<strong>Sample data only</strong> · Shared test environment · real resident data is not enabled.';
 document.querySelector('[data-act="reset"]')?.remove();
 const box=document.createElement('div');box.className='connection-box';box.innerHTML='<span id="syncStatus" role="status">Saved to shared database</span><button id="retrySync" class="btn tiny ghost" type="button">Retry save</button><button id="logout" class="btn tiny ghost" type="button">Sign out</button>';document.querySelector('.side-foot').append(box);
 document.getElementById('retrySync').onclick=()=>window.TLRemote.retry();document.getElementById('logout').onclick=async()=>{if(queue.length){error('Save your pending changes before signing out.');return;}try{await window.TLRemote.disableNotifications();}catch{}await request('/api/logout',{method:'POST'});location.href='/login';};
 const mobile=document.createElement('div');mobile.className='mobile-sync';mobile.id='mobileSync';document.querySelector('.main-col').prepend(mobile);
 mobile.setAttribute('role','button');mobile.tabIndex=0;mobile.onclick=()=>{if(broken)window.TLRemote.retry();};mobile.onkeydown=e=>{if((e.key==='Enter'||e.key===' ')&&broken)window.TLRemote.retry();};
 const observer=new MutationObserver(()=>{mobile.textContent=document.getElementById('syncStatus').textContent;mobile.dataset.state=document.getElementById('syncStatus').dataset.state;if(broken)mobile.textContent+=' · Tap to review';});observer.observe(document.getElementById('syncStatus'),{childList:true,attributes:true});
});
})();

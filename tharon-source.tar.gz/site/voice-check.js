'use strict';
const start=document.querySelector('#start'),stop=document.querySelector('#stop'),status=document.querySelector('#status'),words=document.querySelector('#words'),playback=document.querySelector('#playback');
let stream,recorder,timer,blobUrl,phase='idle';
const release=()=>{clearTimeout(timer);stream?.getTracks().forEach(t=>t.stop());};
function stopRecording(){if(phase!=='recording')return;phase='stopping';stop.disabled=true;status.textContent='Stopping recording…';try{recorder.stop();}catch(e){release();phase='idle';start.disabled=false;status.textContent='Could not finish the recording. Please try again.';}}
start.addEventListener('click',async()=>{
 if(phase!=='idle')return;phase='requesting';start.disabled=true;words.textContent='';status.textContent='Waiting for microphone permission…';
 try{
  if(!navigator.mediaDevices?.getUserMedia||!window.MediaRecorder)throw new Error('Please open this link directly in Safari to record.');
  const stateResponse=await fetch('/api/state');if(!stateResponse.ok)throw new Error('Please sign in to Tharon Leads, then reopen this test link.');const state=await stateResponse.json();
  stream=await navigator.mediaDevices.getUserMedia({audio:true});const chunks=[];
  const type=['audio/mp4','audio/webm;codecs=opus','audio/webm'].find(t=>MediaRecorder.isTypeSupported(t));recorder=new MediaRecorder(stream,type?{mimeType:type}:undefined);
  recorder.ondataavailable=e=>{if(e.data.size)chunks.push(e.data);};
  recorder.onerror=()=>{release();phase='idle';start.disabled=false;stop.disabled=true;status.textContent='The phone could not record audio. Close other apps using the microphone and try again.';};
  recorder.onstop=async()=>{
   release();phase='transcribing';status.textContent='Turning your recording into words…';
   try{const blob=new Blob(chunks,{type:recorder.mimeType||type||'audio/mp4'});if(!blob.size)throw new Error('The phone returned an empty recording. Please try again in Safari.');
    if(blobUrl)URL.revokeObjectURL(blobUrl);blobUrl=URL.createObjectURL(blob);playback.src=blobUrl;playback.hidden=false;
    const response=await fetch('/api/voice-test',{method:'POST',headers:{'Content-Type':blob.type,'X-CSRF-Token':state.csrf},body:blob,signal:AbortSignal.timeout(150000)});const result=await response.json();if(!response.ok)throw new Error(result.error||'Transcription failed.');if(!result.text?.trim())throw new Error('No words were detected. Play the recording to check whether your voice is audible.');
    words.textContent=result.text;status.textContent='Test complete. Check that these words match what you said.';
   }catch(e){status.textContent=e.name==='TimeoutError'?'Transcription took too long. Your recording is available to play below.':e.message;}
   finally{phase='idle';start.disabled=false;stop.disabled=true;}
  };
  recorder.start(1000);phase='recording';stop.disabled=false;status.textContent='Recording. Speak the test sentence, then tap Stop. Words appear afterward.';timer=setTimeout(stopRecording,15000);
 }catch(e){release();phase='idle';start.disabled=false;stop.disabled=true;status.textContent=e.name==='NotAllowedError'?'Microphone access is blocked. In Safari, open the page menu, Website Settings, then allow Microphone.':e.message;}
});
stop.addEventListener('click',stopRecording);
window.addEventListener('pagehide',()=>{release();if(blobUrl)URL.revokeObjectURL(blobUrl);});

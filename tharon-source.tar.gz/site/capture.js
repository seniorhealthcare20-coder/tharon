/* Tharon Leads demo — "no typing" lead capture: the parser.
   Pure functions, no DOM. Turns a spoken transcript or the text pulled out of a file (PDF, photo OCR, DOCX)
   into lead fields with a confidence for each, and spots admission / waiver paperwork.
   DEMO: these are local rules. PRODUCTION: send the same text (or the file itself) to a structured-extraction
   call with the JSON schema in CODEX-HANDOFF.md, on a vendor that signs a BAA. The output shape stays the same. */
(function(root){
'use strict';
const CARE=['Independent with reminders','Level 1 \u00b7 light assist','Level 2 \u00b7 moderate assist','Level 3 \u00b7 high assist','Level 4 \u00b7 hospice','Memory care'];
const PAYER=['Private pay','ALW waiver','CalAIM Community Supports','Long-term care insurance','VA Aid & Attendance','SSI/SSP','Other'];
const SOURCE=['Hospital','SNF','Placement agency','Web','Referral','Other'];
const REL=['Self','Daughter','Son','Wife','Husband','Niece','Nephew','Granddaughter','Grandson','Friend','Case manager','Other'];
const MONTHS=['jan','feb','mar','apr','may','jun','jul','aug','sep','oct','nov','dec'];
const ORD={first:1,second:2,third:3,fourth:4,fifth:5,sixth:6,seventh:7,eighth:8,ninth:9,tenth:10,eleventh:11,twelfth:12,thirteenth:13,fourteenth:14,fifteenth:15,sixteenth:16,seventeenth:17,eighteenth:18,nineteenth:19,twentieth:20,'twenty-first':21,'twenty first':21,'twenty-second':22,'twenty second':22,'twenty-third':23,'twenty third':23,'twenty-fourth':24,'twenty fourth':24,'twenty-fifth':25,'twenty fifth':25,'twenty-sixth':26,'twenty sixth':26,'twenty-seventh':27,'twenty seventh':27,'twenty-eighth':28,'twenty eighth':28,'twenty-ninth':29,'twenty ninth':29,thirtieth:30,'thirty-first':31,'thirty first':31};
const DIG={zero:'0',oh:'0',o:'0',one:'1',two:'2',three:'3',four:'4',for:'4',five:'5',six:'6',seven:'7',eight:'8',nine:'9'};
const NUMW={one:1,two:2,three:3,four:4,five:5,six:6,seven:7,eight:8,nine:9,ten:10};
const STOP=new Set(['for','to','she','he','they','today','named','name','will','would','has','have','who','that','called','calling','call','her','his','the','a','an','and','from','at','is','was','needs','need','wants','new','lead','coming','referred','says','who','with','private','memory','care','mom','dad','mother','father','phone','number','email']);

const pad=n=>String(n).padStart(2,'0');
const iso=d=>d.getFullYear()+'-'+pad(d.getMonth()+1)+'-'+pad(d.getDate());
const cap=w=>w?w.charAt(0).toUpperCase()+w.slice(1).toLowerCase():w;
const titleCase=s=>s.split(/\s+/).map(w=>w.split('-').map(p=>/^(mc|o')/i.test(p)&&p.length>3?p.charAt(0).toUpperCase()+p.slice(1):cap(p)).join('-')).join(' ');
const clean=s=>String(s||'').replace(/\s+/g,' ').trim();
const tidy=s=>clean(s).replace(/[\s,;:\-\u2013]+$/,'');
const isNameWord=w=>/^[A-Za-z][A-Za-z'\u2019-]*$/.test(w)&&!STOP.has(w.toLowerCase());

/* Spoken numbers: "five five five one two three..." -> digits; "ann at gmail dot com" -> ann@gmail.com */
function normalizeSpeech(t){
  let s=' '+String(t||'')+' ';
  s=s.replace(/((?:\b(?:zero|oh|one|two|three|four|five|six|seven|eight|nine)\b[\s,-]*){7,})/gi,m=>' '+m.split(/[\s,-]+/).filter(Boolean).map(w=>DIG[w.toLowerCase()]||'').join('')+' ');
  s=s.replace(/\b([a-z0-9._-]+(?:\s+dot\s+[a-z0-9_-]+)*)\s+at\s+([a-z0-9-]+(?:\s+dot\s+[a-z0-9-]+)*\s+dot\s+(?:com|net|org|edu|gov|us))\b/gi,(m,u,dm)=>(u.replace(/\s+dot\s+/gi,'.')+'@'+dm.replace(/\s+dot\s+/gi,'.')).replace(/\s+/g,''));
  return s.trim();
}
function phones(t){
  const out=[]; const re=/(?:\+?1[\s.-]?)?\(?\b(\d{3})\)?[\s.-]?(\d{3})[\s.-]?(\d{4})\b/g; let m;
  while((m=re.exec(t))){out.push({v:'('+m[1]+') '+m[2]+'-'+m[3],i:m.index});}
  return out;
}
function emails(t){const out=[]; const re=/[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}/g; let m; while((m=re.exec(t))) out.push({v:m[0].toLowerCase(),i:m.index}); return out;}

function nextDate(month,day,year,today){
  const t=today||new Date(); t.setHours(0,0,0,0);
  if(year){if(year<100) year+=2000; const d=new Date(year,month,day); return isNaN(d)?null:d;}
  let d=new Date(t.getFullYear(),month,day); if(d<t) d=new Date(t.getFullYear()+1,month,day); return d;
}
/* returns {date:'YYYY-MM-DD', conf, raw} for the first date in s */
function findDate(s,today){
  const T0=today?new Date(today):new Date(); T0.setHours(0,0,0,0);
  let m;
  const mre=/\b(jan(?:uary)?|feb(?:ruary)?|mar(?:ch)?|apr(?:il)?|may|june?|july?|aug(?:ust)?|sep(?:t(?:ember)?)?|oct(?:ober)?|nov(?:ember)?|dec(?:ember)?)\.?\s+(?:the\s+)?(\d{1,2}|first|second|third|fourth|fifth|sixth|seventh|eighth|ninth|tenth|eleventh|twelfth|thirteenth|fourteenth|fifteenth|sixteenth|seventeenth|eighteenth|nineteenth|twentieth|twenty[- ](?:first|second|third|fourth|fifth|sixth|seventh|eighth|ninth)|thirtieth|thirty[- ]first)(?:st|nd|rd|th)?\b(?:,?\s*(\d{4}))?/i;
  if((m=mre.exec(s))){const mo=MONTHS.indexOf(m[1].slice(0,3).toLowerCase()); const dd=/^\d/.test(m[2])?parseInt(m[2]):ORD[m[2].toLowerCase()]; const d=nextDate(mo,dd,m[3]?parseInt(m[3]):null,new Date(T0)); if(d) return {date:iso(d),conf:'high',raw:m[0],i:m.index};}
  if((m=/\b(\d{1,2})\/(\d{1,2})(?:\/(\d{2,4}))?\b/.exec(s))){const d=nextDate(parseInt(m[1])-1,parseInt(m[2]),m[3]?parseInt(m[3]):null,new Date(T0)); if(d&&parseInt(m[1])<=12) return {date:iso(d),conf:m[3]?'high':'low',raw:m[0],i:m.index};}
  if((m=/\b(\d{4})-(\d{2})-(\d{2})\b/.exec(s))) return {date:m[0],conf:'high',raw:m[0],i:m.index};
  const add=n=>{const d=new Date(T0); d.setDate(d.getDate()+n); return iso(d);};
  if((m=/\btomorrow\b/i.exec(s))) return {date:add(1),conf:'low',raw:m[0],i:m.index};
  if((m=/\bnext week\b/i.exec(s))) return {date:add(7),conf:'low',raw:m[0],i:m.index};
  if((m=/\bin\s+(a|one|two|three|four|five|six|\d)\s+weeks?\b/i.exec(s))){const n=m[1].toLowerCase()==='a'?1:(NUMW[m[1].toLowerCase()]||parseInt(m[1])); return {date:add(7*n),conf:'low',raw:m[0],i:m.index};}
  if((m=/\bnext month\b/i.exec(s))) return {date:add(30),conf:'low',raw:m[0],i:m.index};
  if((m=/\b(asap|as soon as possible|right away|immediately)\b/i.exec(s))) return {date:add(3),conf:'low',raw:m[0],i:m.index};
  return null;
}
function ageFromDob(s,today){
  const m=/\b(\d{1,2})\/(\d{1,2})\/(\d{4})\b/.exec(s)||null; let d=null;
  if(m) d=new Date(parseInt(m[3]),parseInt(m[1])-1,parseInt(m[2]));
  else {const m2=/\b(jan|feb|mar|apr|may|jun|jul|aug|sep|oct|nov|dec)[a-z]*\.?\s+(\d{1,2}),?\s+(\d{4})\b/i.exec(s); if(m2) d=new Date(parseInt(m2[3]),MONTHS.indexOf(m2[1].slice(0,3).toLowerCase()),parseInt(m2[2]));}
  if(!d||isNaN(d)) return null; const t=today?new Date(today):new Date();
  let a=t.getFullYear()-d.getFullYear(); if(t.getMonth()<d.getMonth()||(t.getMonth()===d.getMonth()&&t.getDate()<d.getDate())) a--; return a>40&&a<120?a:null;
}
function relFrom(w){
  const s=String(w||'').toLowerCase();
  if(!s) return null;
  if(/\b(self|herself|himself|resident|patient)\b/.test(s)) return 'Self';
  const direct=REL.find(r=>r.toLowerCase()===s); if(direct) return direct;
  if(/daughter[- ]in[- ]law/.test(s)) return 'Daughter';
  if(/son[- ]in[- ]law/.test(s)) return 'Son';
  if(/social worker|discharge planner|case manager|caseworker|case worker/.test(s)) return 'Case manager';
  for(const r of REL) if(new RegExp('\\b'+r.toLowerCase()+'\\b').test(s)) return r;
  if(/sister|brother|cousin|aunt|uncle|guardian|conservator|neighbor|poa|power of attorney/.test(s)) return 'Other';
  return null;
}
function careFrom(s){
  s=String(s||'').toLowerCase(); if(!s) return null;
  if(/memory|dementia|alzheimer|wander/.test(s)) return CARE[5];
  if(/hospice|end of life|comfort care|level\s*4\b|tier\s*5/.test(s)) return CARE[4];
  if(/level\s*3\b|high assist|heavy assist|two[- ]person|2[- ]person|total care|max(?:imum)? assist|hoyer/.test(s)) return CARE[3];
  if(/level\s*2\b|moderate|mod assist|help with (?:bathing|dressing|showering)|assist with adls|adl assist/.test(s)) return CARE[2];
  if(/level\s*1\b|light assist|minimal|stand[- ]?by|med(?:ication)? management|medication reminders/.test(s)) return CARE[1];
  if(/independent/.test(s)) return CARE[0];
  return null;
}
function payerFrom(s){
  s=String(s||'').toLowerCase(); if(!s) return null;
  if(/cal[- ]?aim|community supports?|kalam/.test(s)) return 'CalAIM Community Supports';
  if(/\balw\b|assisted living waiver|a\.l\.w|\bwaiver\b/.test(s)) return 'ALW waiver';
  if(/long[- ]term care (?:insurance|policy)|\bltc\b|ltci/.test(s)) return 'Long-term care insurance';
  if(/\bva\b|veteran|aid (?:and|&) attendance/.test(s)) return 'VA Aid & Attendance';
  if(/\bssi\b|\bssp\b/.test(s)) return 'SSI/SSP';
  if(/private[- ]?pay|self[- ]?pay|\bprivate\b|out of pocket|cash pay/.test(s)) return 'Private pay';
  return null;
}
function sourceFrom(s){
  s=String(s||'').toLowerCase(); if(!s) return null;
  if(/\bsnf\b|skilled nursing|rehab|post[- ]acute|nursing (?:home|facility)|convalescent/.test(s)) return 'SNF';
  if(/hospital|medical cent(?:er|re)|\ber\b|emergency room|discharge planner|cedars|kaiser/.test(s)) return 'Hospital';
  if(/placement|agency|a place for mom|caring\.com/.test(s)) return 'Placement agency';
  if(/website|\bweb\b|online|google|facebook|instagram|yelp|internet/.test(s)) return 'Web';
  if(/referr|friend|word of mouth|church|doctor|physician/.test(s)) return 'Referral';
  return null;
}
function buildingFrom(s,buildings,kind){
 const matcher=root.TLImport||(typeof module!=='undefined'&&module.exports?require('./import-utils.js'):null);if(!matcher||!buildings)return null;
 const roster=buildings.map(b=>({...b,aliases:[...(b.aliases||[]),...(b.id==='b4'?['hallmark']:[]),...(kind==='voice'&&b.id==='pointe'?['pointed summer hills','point summer hills','pointe summer hills','pointed summit hills','point summit hills','point at summit hills']:[])]}));
 return matcher.matchBuilding(s,roster)?.id||null;
}

function splitName(raw){
  let s=clean(raw).replace(/\(.*?\)/g,'').replace(/\b(mr|mrs|ms|miss|dr)\.?\s+/i,'').trim();
  s=s.split(/\s{2,}|\t|\s+(?:DOB|Age|Sex|Gender|MRN|D\.O\.B)\b/i)[0];
  if(/,/.test(s)){const [a,b]=s.split(',').map(clean); if(a&&b&&!/\s/.test(a)) s=b.split(/\s+/)[0]+' '+a;}
  const words=s.split(/\s+/).filter(w=>/^[A-Za-z][A-Za-z'\u2019.-]*$/.test(w));
  if(!words.length) return null;
  const first=titleCase(words[0]); const last=words.length>1?titleCase(words[words.length-1].replace(/\.$/,'')):'';
  return {first,last};
}

/* Scanned LIC 602 / 602A resident table: values sit on the row below numbered headings. */
function read602Resident(lines,today){
 const start=lines.findIndex(l=>/(?:RESIDENT\s*\/\s*PATIENT|PROSPECTIVE\s+RESIDENT(?:\s*\/\s*RESIDENT)?|CLIENT)\s+INFORMATION/i.test(l));
 if(start<0||!/(?:LIC\s*602|PHYSICIAN.{0,8}REPORT|MEDICAL ASSESSMENT)/i.test(lines.join(' ')))return null;
 const out={};const end=lines.findIndex((l,i)=>i>start&&/(?:AUTHORIZATION FOR RELEASE|PATIENT.{0,4}DIAGNOSIS|MEDICAL PROFESSIONAL INFORMATION)/i.test(l));
 const section=lines.slice(start+1,end>start?end:start+9);const header=section.findIndex(l=>/^\s*(?:1\s*[.,):]?\s*)?NAME\b/i.test(l));
 if(header<0)return out;
 const candidates=[section[header].replace(/^\s*(?:1\s*[.,):]?\s*)?NAME\s*[:.-]?\s*/i,''),...section.slice(header+1,header+5)];
 for(const row of candidates){const raw=row.split('|')[0].replace(/\b\d.*$/,'').replace(/\b(?:BIRTH DATE|DATE OF BIRTH|AGE)\b.*$/i,'').trim();
  if(!raw||/\b(?:NAME|BIRTH|DATE|AGE|INFORMATION|ADDRESS|SIGNATURE)\b/i.test(raw))continue;
  const name=splitName(raw);if(!name?.last)continue;out.first=name.first;out.last=name.last;
  const dob=/\b(\d{1,2}\/\d{1,2}\/\d{4})\b/.exec(row);if(dob){const age=ageFromDob(dob[1],today);if(age)out.age=age;}break;
 }
 return out;
}

/* Labelled lines in forms: "Patient Name: Eleanor Whitfield" */
function labelled(lines,re){for(const ln of lines){const m=re.exec(ln); if(m&&clean(m[1])) return clean(m[1]);} return null;}

/* Admission + waiver paperwork recognisers. strong = form number, or the form's title near the top. */
const DOC_RULES=[
  {key:'hmp',num:null,title:/history (?:and|&) physical|\bH\s*&\s*P\b|\bHMP\b/i},
  {key:'lic602a',num:/\b(?:LIC\s*-?\s*)?602\s*A?\b/i,title:/physician'?s report|medical assessment/i},
  {key:'tb',num:null,title:/\b(?:TB|tuberculosis)\s+(?:test|screening|clearance|skin test)\b|tuberculin skin test|quantiferon|\bIGRA\b/i},
  {key:'lic603a',num:/\bLIC\s*-?\s*603\s*A?\b/i,title:/resident appraisal|preplacement appraisal/i},
  {key:'lic601',num:/\bLIC\s*-?\s*601\b/i,title:/identification and emergency information/i},
  {key:'agreement',num:/\bLIC\s*-?\s*604\s*A?\b/i,title:/admission agreement/i},
  {key:'lic613c',num:/\bLIC\s*-?\s*613\s*C/i,title:/personal rights/i},
  {key:'lic627c',num:/\bLIC\s*-?\s*627\s*C/i,title:/consent for emergency medical/i},
  {key:'lic605a',num:/\bLIC\s*-?\s*605\s*A/i,title:/release of (?:client\/resident )?medical information/i},
  {key:'lic625',num:/\bLIC\s*-?\s*625\b/i,title:/needs and services plan/i},
  {key:'polst',num:/\bPOLST\b/,title:/physician orders for life[- ]sustaining treatment/i},
  {key:'w_assess',num:null,title:/(?:ALW|waiver|care coordination agency|CCA)\b.{0,60}\bassessment\b|\bRN assessment\b|assessment (?:summary|results?).{0,40}\btier\b/i},
  {key:'w_hcode',num:null,title:/\baid code\b|eligibility (?:verification|printout|response|status)|medi-cal eligibility|\bH[- ]code\b/i},
  {key:'w_mcp',num:null,title:/authori[sz]ation (?:notice|letter|approval|form|determination)|notice of authori[sz]ation|approved.{0,40}community supports?/i},
  {key:'w_informing',num:/\bDHCS\s*0063\b/i,title:/informing notice/i},
  {key:'w_foc',num:/\bDHCS\s*0062\b/i,title:/freedom of choice/i},
  {key:'w_amenity',num:/\bDHCS\s*0060\b/i,title:/amenity (?:form|waiver)/i},
  {key:'w_rights',num:/\bDHCS\s*1322\b/i,title:/patient'?s rights/i},
  {key:'w_isp',num:null,title:/individual(?:ized)? service plan|\bISP\b/i},
];
function detectDocs(text){
  const t=String(text||''); const head=t.slice(0,500); const found=[];
  for(const r of DOC_RULES){
    const numHit=r.num&&r.num.test(t); const titleTop=r.title&&r.title.test(head);
    if(numHit||titleTop) found.push({key:r.key,strong:true});
  }
  return found;
}

/* main entry. kind: 'voice' | 'doc'. ctx: {buildings, today} */
function parseLead(input,ctx){
  ctx=ctx||{}; const kind=ctx.kind||'voice'; const today=ctx.today?new Date(ctx.today+'T00:00:00'):new Date();
  let text=String(input||''); const spokenEmail=kind==='voice'&&/\s+at\s+[a-z0-9-]+\s+dot\s+/i.test(text); if(kind==='voice') text=normalizeSpeech(text);
  const flat=clean(text); const lower=flat.toLowerCase();
  const lines=text.split(/\r?\n/).map(clean).filter(Boolean);
  const f={}, c={};
  const set=(k,v,conf)=>{if(v==null||v==='') return; if(f[k]!=null&&c[k]==='high'&&conf!=='high') return; f[k]=v; c[k]=conf;};

  const table602=kind==='doc'?read602Resident(lines,today):null;
  if(table602?.first){set('first',table602.first,'high');set('last',table602.last,'high');if(table602.age)set('age',table602.age,'high');}

  /* --- labelled form lines (documents and "name: x" dictation) --- */
  const L=re=>labelled(lines,re);
  const nameL=L(/^(?:patient|resident|client|member|participant|applicant|prospective resident|resident's|patient's)(?:'s)?\s*(?:full\s*|legal\s*)?name\s*[:\-#]\s*(.+)$/i)||L(/^name(?: of (?:patient|resident))?\s*[:\-]\s*(.+)$/i);
  if(nameL&&f.first==null){const n=splitName(nameL); if(n){set('first',n.first,'high'); set('last',n.last,n.last?'high':'low');}}
  const dobL=L(/^(?:DOB|D\.O\.B\.?|date of birth|birth\s*date)\s*[:\-]?\s*(.+)$/i)||(()=>{const m=/\b(?:DOB|date of birth)\s*[:\-]?\s*([0-9\/]{8,10}|[A-Za-z]{3,9}\.? \d{1,2},? \d{4})/i.exec(flat); return m?m[1]:null;})();
  if(dobL){const a=ageFromDob(dobL,today); if(a) set('age',a,'high');}
  const ageL=L(/^age\s*[:\-]\s*(\d{2,3})\b/i); if(ageL) set('age',parseInt(ageL),'high');
  const contactL=L(/^(?:emergency contact|responsible party|family contact|primary contact|contact person|contact name|caller(?: name)?|representative|authorized representative|family member|inquiry from|person calling)\s*(?:name)?\s*[:\-]\s*(.+)$/i);
  if(contactL){
    const relInLine=/\(([^)]+)\)/.exec(contactL)||/,\s*([A-Za-z -]+)$/.exec(contactL); const r=relInLine&&relFrom(relInLine[1]);
    const nm=clean(contactL.replace(/\(.*?\)/g,'').split(/,|\s{2,}|\s+[-\u2013]\s+|\s+(?:phone|cell|tel)\b/i)[0]).replace(/[\d()+.-]{7,}.*$/,'').trim();
    if(nm&&/[A-Za-z]/.test(nm)) set('callerName',titleCase(nm),'high');
    if(r) set('rel',r,'high');
    const ph=phones(contactL); if(ph[0]) set('phone',ph[0].v,'high');
    const em=emails(contactL); if(em[0]) set('email',em[0].v,'high');
  }
  const relL=L(/^relationship(?: to (?:patient|resident|client))?\s*[:\-]\s*(.+)$/i); if(relL){const r=relFrom(relL); if(r) set('rel',r,'high');}
  const phoneL=L(/^(?:contact |family |caller |cell |mobile |home )?(?:phone|cell|mobile|tel(?:ephone)?)(?: number| #)?\s*[:\-]\s*(.+)$/i); if(phoneL){const p=phones(phoneL); if(p[0]) set('phone',p[0].v,'high');}
  const emailL=L(/^(?:contact |family |caller )?e-?mail(?: address)?\s*[:\-]\s*(.+)$/i); if(emailL){const e=emails(emailL); if(e[0]) set('email',e[0].v,'high');}
  const srcL=L(/^(?:referral source|referred by|referring (?:facility|hospital|agency|organization)|referral from|source of referral|discharging (?:facility|hospital)|lead source|how did you hear(?: about us)?\??)\s*[:\-]\s*(.+)$/i);
  if(srcL){const st=sourceFrom(srcL); set('source',st||'Other',st?'high':'low'); set('sourceDetail',tidy(srcL.replace(/[\d()+.-]{7,}.*$/,'')),'high');}
  const careL=L(/^(?:level of care|care level|care needs?|care needed|services needed|type of care(?: needed)?)\s*(?:requested)?\s*[:\-]\s*(.+)$/i); if(careL){const cv=careFrom(careL); if(cv) set('care',cv,'high');}
  const payL=L(/^(?:payer|payor|payer source|payment source|funding(?: source)?|pay(?:ment)? type|primary (?:insurance|payer)|insurance|financial)\s*[:\-]\s*(.+)$/i); if(payL){const pv=payerFrom(payL); if(pv) set('payer',pv,'high');}
  const dateL=L(/^(?:anticipated discharge(?: date)?|expected discharge(?: date)?|discharge date|desired move[- ]in(?: date)?|target move[- ]in(?: date)?|move[- ]in date|requested move[- ]in(?: date)?|anticipated move[- ]in(?: date)?|move[- ]in)\s*[:\-]\s*(.+)$/i);
  if(dateL){const dd=findDate(dateL,today); if(dd) set('moveIn',dd.date,dd.conf);}
  const bldL=L(/^(?:preferred (?:community|building|facility|location)|community requested|building|facility requested|requested (?:community|building)|location preference)\s*[:\-]\s*(.+)$/i);
  if(bldL){const b=buildingFrom(bldL,ctx.buildings,kind); if(b) set('building',b,'high');}
  const budL=L(/^(?:monthly )?budget\s*[:\-]\s*(.+)$/i); if(budL){const n=Number(budL.replace(/[$,\s]/g,'')); if(n>=500&&n<50000) set('budget',n,'high');}
  const tierL=/\btier(?: level)?\s*[:\-]?\s*([1-5]|one|two|three|four|five)\b/i.exec(flat); if(tierL) set('tier',/\d/.test(tierL[1])?parseInt(tierL[1]):NUMW[tierL[1].toLowerCase()],'high');
  const reasonL=L(/^(?:reason for referral|reason for placement|primary diagnosis|diagnosis|notes?|comments?|summary)\s*[:\-]\s*(.+)$/i);

  /* --- free text (dictation, letters, emails) --- */
  // Explicit first/last labels can be dictated in separate sentences.
  if(kind==='voice'){
    const lastLabel=/\b(?:last|family|sur)\s*name\s*(?:is|:|=)?\s*([A-Za-z][A-Za-z'’-]*(?:\s+[A-Za-z][A-Za-z'’-]*){0,2})/i.exec(flat);
    const firstLabel=/\bfirst\s*name\s*(?:is|:|=)?\s*([A-Za-z][A-Za-z'’-]*)/i.exec(flat)
      ||(lastLabel&&/\b(?:(?:resident|patient|client)(?:'s)?\s+name|(?:her|his|their)\s+name|name)\s*(?:is|:|=)\s*([A-Za-z][A-Za-z'’-]*)/i.exec(flat));
    if(firstLabel&&isNameWord(firstLabel[1]))set('first',titleCase(firstLabel[1]),'high');
    if(lastLabel){const parts=[];for(const word of lastLabel[1].split(/\s+/)){if(!isNameWord(word)||/^(age|aged|years|please|building|first|last|resident)$/i.test(word))break;parts.push(word);}if(parts.length)set('last',titleCase(parts.join(' ')),'high');}
  }
  // resident name
  if(kind==='voice'&&f.first==null){
    const named=/\b(?:(?:her|his|their)\s+name(?:\s+is)?|(?:resident|patient|client)(?:'s)?\s+name(?:\s+is)?|name is)\s*[:,.-]?\s*([A-Za-z][A-Za-z'’-]+(?:\s+[A-Za-z][A-Za-z'’-]+){1,2})/i.exec(flat);
    const leading=/^([A-Za-z][A-Za-z'’-]+(?:\s+[A-Za-z][A-Za-z'’-]+){1,2})\s*(?=,|\s+(?:is|aged|age|needs|wants|would|has)\b)/i.exec(flat);
    const raw=(named||leading)?.[1];if(raw){const parts=raw.split(/\s+/),words=[];for(const word of parts){if(!isNameWord(word))break;words.push(word);}if(words.length>=2){set('first',titleCase(words[0]),'low');set('last',titleCase(words.at(-1)),'low');}}
  }
  if(f.first==null){
    let m=/\b(?:new lead|add (?:a )?(?:new )?lead|lead)\s*(?:for|is|named|called)?\s*[,:.\-]?\s*(?:(?:mrs?|ms|miss|mr)\.?\s+)?([A-Za-z][A-Za-z'\u2019-]+(?:\s+[A-Za-z][A-Za-z'\u2019-]+){1,2})/i.exec(flat)
      ||/\b(?:resident|patient|client|mom|mother|dad|father|grandma|grandmother|grandpa|grandfather)(?:'s)?\s*(?:name\s*)?(?:is|named|called)\s+([A-Za-z][A-Za-z'\u2019-]+(?:\s+[A-Za-z][A-Za-z'\u2019-]+){1,2})/i.exec(flat)
      ||/\b(?:for|regarding|re:?)\s+((?:mrs?|ms)\.?\s+)?([A-Z][a-z'\u2019-]+\s+[A-Z][a-z'\u2019-]+)\b/.exec(flat);
    if(m){const raw=m[m.length-1]; const words=raw.split(/\s+/).filter(isNameWord).slice(0,3);
      if(words.length>=2&&!/^(her|his|the)$/i.test(words[0])){const proper=words.every(w=>/^[A-Z]/.test(w)); set('first',titleCase(words[0]),proper?'high':'low'); set('last',titleCase(words[words.length-1]),proper?'high':'low');}
      else if(words.length===1){set('first',titleCase(words[0]),'low');}}
  }
  // caller relationship + name: "her daughter Ann called", "son, Michael Silva"
  if(!table602&&(f.rel==null||f.callerName==null)){
    const m=/\b(?:her|his|their|the|my)?\s*(daughter[- ]in[- ]law|son[- ]in[- ]law|daughter|son|wife|husband|niece|nephew|granddaughter|grandson|friend|case manager|social worker|discharge planner|sister|brother|guardian)\b\s*,?\s*(?:named|is|called)?\s*([A-Z][a-z'\u2019-]+(?:\s+[A-Z][a-z'\u2019-]+)?)?/i.exec(flat);
    if(m){const r=relFrom(m[1]); if(r&&f.rel==null) set('rel',r,'high');
      if(m[2]&&f.callerName==null){const w=m[2].split(/\s+/).filter(isNameWord); if(w.length) set('callerName',titleCase(w.join(' ')),w.length>1?'high':'low');}}
    else if(/\b(?:calling for (?:herself|himself)|it'?s for (?:herself|himself|me)|self[- ]referr|for myself)\b/i.test(flat)&&f.rel==null) set('rel','Self','high');
  }
  // phone / email anywhere
  if(f.phone==null&&!table602){const p=phones(flat); if(p.length) set('phone',p[0].v,kind==='voice'||p.length===1?'high':'low');}
  if(f.email==null&&!table602){const e=emails(flat); if(e.length) set('email',e[0].v,spokenEmail?'low':(kind==='voice'||e.length===1?'high':'low'));}
  // referral source + detail
  if(f.source==null&&!table602){
    const m=/\b(?:coming from|discharg\w* from|referred by|referral from|referred from|from|at)\s+((?:the\s+)?[A-Za-z][\w'&.-]*(?:\s+[A-Za-z][\w'&.-]*){0,4}?\s+(?:hospital|medical cent(?:er|re)|rehab(?:ilitation)?(?: center)?|skilled nursing(?: facility)?|post[- ]acute|nursing home|health(?: system)?|placement(?: agency| services)?|agency))\b/i.exec(flat);
    if(m){const det=titleCase(m[1].replace(/^the\s+/i,'')); set('source',sourceFrom(det)||'Other','high'); set('sourceDetail',det,'high');}
    else {const st=sourceFrom(lower); if(st) set('source',st,'low');}
  }
  if(f.care==null&&!table602){const cv=careFrom(lower); if(cv) set('care',cv,kind==='voice'?'high':'low');}
  if(f.payer==null){const pv=payerFrom(lower); if(pv) set('payer',pv,kind==='voice'?'high':'low');}
  if(f.moveIn==null){
    const cue=/\b(?:move[- ]?in|moving in|move|discharge|discharged|admit|admission|start)\b[^.;\n]{0,40}/i.exec(flat);
    let dd=cue?findDate(flat.slice(cue.index,cue.index+60),today):null;
    if(!dd&&kind==='voice') dd=findDate(flat,today);
    if(dd) set('moveIn',dd.date,cue?dd.conf:'low');
  }
  if(f.building==null){const b=buildingFrom(lower,ctx.buildings,kind); if(b) set('building',b,kind==='voice'?'high':'low');}
  if(f.age==null){const m=/\b(\d{2,3})[- ]?(?:years?|yrs?)[- ]old\b|\bage(?:d)?\s*(?:is\s*)?(\d{2,3})\b|\b(?:she|he)(?:'s| is)\s+(\d{2,3})\b/i.exec(flat); if(m){const a=parseInt(m[1]||m[2]||m[3]); if(a>40&&a<120) set('age',a,'high');}}
  if(f.budget==null){const m=/\$\s?(\d{1,2},?\d{3})\b|\b(\d{1,2},?\d{3})\s*(?:dollars|a month|per month|\/\s?mo(?:nth)?)\b|\bbudget\b[^\d$]{0,20}\$?\s?(\d{1,2},?\d{3})\b/i.exec(flat); if(m){const n=parseInt((m[1]||m[2]||m[3]).replace(/,/g,'')); if(n>=500&&n<50000) set('budget',n,'low');}}
  if(f.rel==='Self'&&f.callerName==null&&f.first) set('callerName',f.first+(f.last?' '+f.last:''),'high');

  // Notes contain explicit remarks; the full voice transcript is reviewed separately.
  const notes=[];
  if(reasonL) notes.push(reasonL);
  if(kind==='voice'&&!reasonL){const explicit=/\b(?:notes?:|note that|add a note(?: that)?|also note)\s+(.+)$/i.exec(flat);if(explicit)notes.push(explicit[1]);}
  if(notes.length) set('notes',notes.join(' \u00b7 '),'high');

  const docs=kind==='doc'?detectDocs(text):[];
  const filled=Object.keys(f).filter(k=>k!=='notes');
  return {fields:f,conf:c,docs,found:filled.length,low:filled.filter(k=>c[k]==='low'),text:flat};
}

function captureProfile(fields,ctx){
 const f=fields||{},selected=ctx.selectedBuilding||null,building=selected||f.building||null;
 const missing=[];if(!f.first?.trim())missing.push('first name');if(!f.last?.trim())missing.push('last name');if(!ctx.buildings.some(b=>b.id===building))missing.push('building');
 const conflict=!!(selected&&f.building&&selected!==f.building);
 return {missing,conflict,lead:{first:f.first||'',last:f.last||'',age:f.age||null,caller:{name:f.callerName||'',rel:f.rel||'Other',phone:f.phone||'',email:f.email||''},building,rep:ctx.rep,care:f.care||'',payer:f.payer||'Other',source:f.source||'Other',sourceDetail:f.sourceDetail||'',cca:f.cca||'',budget:f.budget||null,moveIn:f.moveIn||null,tier:f.tier||null,notes:f.notes||''}};
}

const API={captureProfile,CARE,PAYER,SOURCE,REL,parseLead,normalizeSpeech,findDate,detectDocs,careFrom,payerFrom,sourceFrom,relFrom,buildingFrom,splitName,phones,emails};
root.TLCapture=API;
if(typeof module!=='undefined'&&module.exports) module.exports=API;
})(typeof window!=='undefined'?window:this);

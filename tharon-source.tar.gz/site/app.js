/* Tharon Leads demo — UI. Client-side only; data layer in api.js, assistant in assistant.js. Sample data only. */
(function(){
'use strict';
const TL=window.TL, AS=window.TLAssistant, {STAGES,DOCS,SAMPLE_CSV}=window.TL_CONST;
const $=s=>document.querySelector(s);
const esc=s=>String(s==null?'':s).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const S=()=>TL.S;
const sortedBuildings=()=>[...S().buildings].sort((a,b)=>String(a.name||a.short||'').localeCompare(String(b.name||b.short||''),'en',{sensitivity:'base',numeric:true}));
const money=n=>n==null||n===''?'\u2014':'$'+Number(n).toLocaleString('en-US');
const fmtDate=d=>d?TL.fmtShort(d):'\u2014';
const fmtRecorded=at=>at?new Date(at).toLocaleString('en-US',{timeZone:'America/Los_Angeles',month:'short',day:'numeric',hour:'numeric',minute:'2-digit'}):'Date not recorded';
const fmtAgo=ts=>{const n=TL.daysSince(ts);return n==null?'never':n===0?'today':n===1?'yesterday':n+' days ago';};
const initials=n=>n.split(' ').map(x=>x[0]).slice(0,2).join('').toUpperCase();
const avatar=(u,sm)=>u?`<span class="avatar${sm?' sm':''}" style="background:${u.color}" title="${esc(u.name)}">${initials(u.name)}</span>`:`<span class="avatar${sm?' sm':''} none" title="Unassigned">?</span>`;
const bname=id=>{const b=TL.B(id);return b?b.short:'No building';};
const buildingTag=id=>`<span class="building-tag${TL.B(id)?'':' needs-building'}" data-building="${esc(id||'none')}"><span aria-hidden="true">▣</span><span><small>BUILDING</small><b>${esc(TL.B(id)?.name||'Needs building assignment')}</b></span></span>`;
const stageChip=k=>`<span class="stage st-${k}">${esc(({new:'Active',contacted:'Active',tour:'Active',toured:'Active',movein:'Moved in',lost:'Closed'})[k]||TL.stageLabel(k))}</span>`;
const SIMPLE_STAGES=[['new','Active'],['assessment','Assessment'],['paperwork','Paperwork'],['movein','Moved in'],['lost','Closed']];
const simpleStage=k=>['new','contacted','tour','toured'].includes(k)?'new':k;
const OPEN_STAGES=SIMPLE_STAGES.filter(s=>s[0]!=='movein'&&s[0]!=='lost');
const lostForm=id=>`<h3 id="modalTitle">Close as lost</h3><p class="muted small">It leaves the active pipeline and goes to Closed. You can reopen it any time.</p><form data-form="close" data-id="${id}" data-o="lost"><label>Reason<select class="input" name="reason" required><option value="">\u2014 Pick a reason \u2014</option>${TL.LOST_REASONS.map(r=>`<option>${esc(r)}</option>`).join('')}</select></label><label class="mt block">Details <small class="muted">(optional)</small><input class="input" name="detail" placeholder="e.g. chose a place closer to her son"></label><div class="btnrow mt"><button class="btn bad">Close as lost</button><button type="button" class="btn ghost" data-act="closeModal">Cancel</button></div></form>`;
const bar=(a,b)=>`<div class="bar${a<b?' warnbar':''}"><i style="width:${b?Math.round(a/b*100):0}%"></i></div>`;
const reps=()=>S().users.filter(u=>u.role==='rep');
const CAP=window.TLCapture;
const REMOTE=!!window.TL_BOOT;
const saveText=()=>REMOTE?'Saving to shared database…':'Saved in this test browser.';
const CARE=CAP.CARE, PAYER=CAP.PAYER, SOURCE=CAP.SOURCE, REL=CAP.REL;
const opt=(list,val)=>list.map(x=>Array.isArray(x)?`<option value="${esc(x[0])}"${x[0]===val?' selected':''}>${esc(x[1])}</option>`:`<option${x===val?' selected':''}>${esc(x)}</option>`).join('');
const ICON={
  today:'<path d="M8 2v4M16 2v4M3 9h18M5 5h14a2 2 0 0 1 2 2v12a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V7a2 2 0 0 1 2-2z"/><path d="m9 15 2 2 4-4"/>',
  leads:'<path d="M3 5h4v14H3zM10 5h4v9h-4zM17 5h4v6h-4z"/>',
  ask:'<path d="M21 12a8 8 0 0 1-11.6 7.1L4 20l1-4.6A8 8 0 1 1 21 12z"/><path d="M8.5 11h.01M12 11h.01M15.5 11h.01"/>',
  buildings:'<path d="M3 21h18M5 21V7l7-4 7 4v14M9 21v-5h6v5M9 10h.01M15 10h.01"/>',
  import:'<path d="M12 3v12M7 10l5 5 5-5M5 21h14"/>',
  rules:'<path d="M18 8a6 6 0 1 0-12 0c0 7-3 9-3 9h18s-3-2-3-9M13.7 21a2 2 0 0 1-3.4 0"/>',
  api:'<path d="m8 8-5 4 5 4M16 8l5 4-5 4M14 4l-4 16"/>',
  add:'<path d="M12 5v14M5 12h14"/>',
  mic:'<rect x="9" y="3" width="6" height="11" rx="3"/><path d="M5 11a7 7 0 0 0 14 0M12 18v3M8 21h8"/>',
  file:'<path d="M14 3H7a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h10a2 2 0 0 0 2-2V8z"/><path d="M14 3v5h5M9 13h6M9 17h6"/>',
  lock:'<rect x="5" y="11" width="14" height="10" rx="2"/><path d="M8 11V7a4 4 0 0 1 8 0v4"/>',
  more:'<circle cx="5" cy="12" r="1.5"/><circle cx="12" cy="12" r="1.5"/><circle cx="19" cy="12" r="1.5"/>'
};
const svg=k=>`<svg viewBox="0 0 24 24" aria-hidden="true">${ICON[k]}</svg>`;
const NAV=[['today','Today'],['add','Add a lead'],['leads','Leads'],['ask','Ask'],['buildings','Buildings'],['import','Upload leads'],['rules','Reminder rules'],['team','Team']];
const TABS=[['today','Today'],['leads','Leads'],['add','Add'],['ask','Ask'],['buildings','Buildings'],['more','More']];
const LEAD_FILTERS=[['all','All open referrals'],['libertana-unsigned','Libertana forms — incomplete / unsigned'],['awaiting-program','Awaiting CCA / program approval'],['assessment','Assessment pending'],['approval-paperwork','Approved — paperwork needed'],['ready-movein','Move-in date not set'],['overdue','Overdue next step'],['blocked','Blocked referrals'],['needs-program','Program needs confirmation']];
let UI={view:'buildings',rep:'all',bld:'all',stage:'all',q:'',todayRep:'all',imp:null,chatBusy:false};

function toast(m){if(REMOTE&&window.TLRemote?.pending&&/\b(?:saved|completed|updated|created|moved|closed|assigned|recorded|received|marked|reopened|logged)\b/i.test(m)){TL.flush().then(()=>showToast(m)).catch(()=>showToast('Save not confirmed. Keep the app open and use Retry save.'));return;}showToast(m);}
function showToast(m){const t=$('#toast');t.textContent=m;t.classList.add('show');clearTimeout(toast.h);toast.h=setTimeout(()=>t.classList.remove('show'),2600);}
function modal(html){$('#modalBody').innerHTML=html;$('#modal').hidden=false;const f=$('#modalBody input,#modalBody select,#modalBody textarea,#modalBody button');f&&f.focus();const form=$('#modalBody .simple-referral-form');if(form)updateProgressPreview(form);}
function closeModal(){$('#modal').hidden=true;$('#modalBody').innerHTML='';}
function download(name,text,type){const a=document.createElement('a');a.href=URL.createObjectURL(new Blob([text],{type:type||'text/plain'}));a.download=name;document.body.appendChild(a);a.click();setTimeout(()=>{URL.revokeObjectURL(a.href);a.remove();},500);}

/* ---------- shell ---------- */
function renderShell(route){
  const badge=new Set(TL.allReminders(TL.isAdmin()?'all':S().me).map(t=>(t.rep||'none')+':'+(t.leadId||t.id))).size;
  $('#nav').innerHTML=NAV.filter(([k])=>TL.isAdmin()||!['rules','team'].includes(k)).map(([k,l])=>`<a href="#/${k}" class="${route===k||(route==='lead'&&k==='leads')||(route==='building'&&k==='buildings')?'on':''}">${svg(k==='team'?'lock':k==='import'?'import':k)}<span>${l}</span>${k==='today'&&badge?`<em>${badge}</em>`:''}</a>`).join('');
  const more=['import','rules','api','team','more'].includes(route);
  $('#tabbar').innerHTML=TABS.map(([k,l])=>`<a href="#/${k}" class="${route===k||(k==='more'&&more)||(route==='lead'&&k==='leads')||(route==='building'&&k==='buildings')?'on':''}${k==='add'?' add':''}">${svg(k)}<span>${l}</span>${k==='today'&&badge?`<em>${badge}</em>`:''}</a>`).join('');
  $('#userSel').innerHTML=(REMOTE?S().users.filter(u=>u.id===S().me):S().users).map(u=>`<option value="${u.id}"${u.id===S().me?' selected':''}>${esc(u.name)}${u.role==='admin'?' (admin)':''}</option>`).join('');
}

/* ---------- Today ---------- */
const V={};
V.today=function(view){
  const dueOnly=view==='due';
  const m=TL.me(), admin=TL.isAdmin();
  const scope=admin?UI.todayRep:m.id;
  const grouped=new Map();for(const task of TL.allReminders(scope)){const key=(task.rep||'none')+':'+(task.leadId||task.id);if(!grouped.has(key))grouped.set(key,{...task,reasons:[]});const row=grouped.get(key);row.reasons.push(task);if(task.sev==='high')row.sev='high';}const list=[...grouped.values()];
  const mine=TL.visibleLeads();
  const open=mine.filter(TL.isOpen);const libertanaUnsigned=mine.filter(l=>TL.leadMatchesFilter(l,'libertana-unsigned'));
  const tours=mine.filter(l=>TL.leadMatchesFilter(l,'assessment'));
  const paper=mine.filter(l=>TL.leadMatchesFilter(l,'awaiting-program'));const overdue=mine.filter(l=>TL.leadMatchesFilter(l,'overdue')),blocked=mine.filter(l=>TL.leadMatchesFilter(l,'blocked')),needsProgram=mine.filter(l=>TL.leadMatchesFilter(l,'needs-program'));
    const groups={};
  list.forEach(x=>{(groups[x.rep||'none']=groups[x.rep||'none']||[]).push(x);});
  const item=x=>{const l=TL.Lead(x.leadId);let reasons=x.reasons||[x];const contact=['new_first_call','stale','post_tour','checkin'];let contactShown=false;reasons=reasons.filter(r=>{if(!contact.includes(r.rule))return true;if(contactShown)return false;contactShown=true;return true;});return `<li class="rem sev-${x.sev}"><span class="dot" aria-hidden="true"></span><div class="grow">${l?`<a class="rem-t" href="#/lead/${l.id}" data-act="openReferral" data-id="${l.id}">${esc(TL.leadName(l))}</a><small class="muted">${esc(bname(l.building))} · ${esc(TL.stageLabel(l.stage))}</small>`:`<b>${esc(x.text)}</b>`}<ul class="task-reasons">${reasons.map(r=>`<li>${r.manual&&!r.sourceRule?`<label class="check"><input type="checkbox" data-change="customTaskDone" data-id="${esc(r.id)}">${esc(r.text)}</label>`:esc(r.text)}${r.due?` <strong>${r.due<TL.T?'Overdue · ':''}${fmtDate(r.due)}</strong>`:''}</li>`).join('')}</ul>${l?.nextFollowUp&&!TL.countySummary(l)?`<p class="small muted">Next step: ${esc(l.nextAction)} · ${fmtDate(l.nextFollowUp)}</p>`:''}</div>${l?`<a class="btn small ghost" href="#/lead/${l.id}" data-act="openReferral" data-id="${l.id}">Open lead</a>`:''}</li>`;};
  const followUps=`<section class="card"><div class="card-h"><h3>${admin&&UI.todayRep==='all'?'Team today':'Today\u2019s list'}</h3>
    ${admin?`<label class="sr-only" for="todayRep">Rep</label><select id="todayRep" class="input slim" data-change="todayRep"><option value="all">All reps</option>${reps().map(u=>`<option value="${u.id}"${UI.todayRep===u.id?' selected':''}>${esc(u.name)}</option>`).join('')}</select>`:`<button type="button" class="btn small ghost" data-act="newTask">+ Task</button>`}</div>
    <p class="task-help">Each referral shows its next step and follow-up date. Open it to update progress or add a dated note. County roadmaps remain under Program details.</p>
    ${list.length?(admin&&UI.todayRep==='all'?Object.keys(groups).map(k=>{const u=TL.U(k);return `<div class="grp"><h4>${avatar(u,1)} ${esc(u?u.name:'Unassigned')} <span class="muted">${groups[k].length}</span></h4><ul class="rems">${groups[k].map(item).join('')}</ul></div>`;}).join(''):`<ul class="rems">${list.map(item).join('')}</ul>`):`<div class="empty">All caught up. Nothing due today.</div>`}</section>`;
  if(dueOnly)return `<section class="hello"><h2>Due today · ${list.length}</h2><p>Follow-ups due today and overdue items that still need attention.</p><a class="btn small ghost mt" href="#/today">Back to homepage</a></section>${followUps}`;
  const hour=new Date().getHours();
  return `<section class="hello"><h2>Good ${hour<12?'morning':hour<17?'afternoon':'evening'}, ${esc(m.name.split(' ')[0])}</h2><p>${admin?'You see every marketer’s leads, assignments, paperwork and follow-ups.':'See referrals for your assigned buildings. Your follow-ups appear below.'}</p></section>
  <a class="quick-add" href="#/add"><span class="qa-ic">${svg('mic')}</span><span class="grow"><b>Add a lead without typing</b><small>Say it, or drop in a referral, a photo or a form</small></span><span class="qa-go" aria-hidden="true">›</span></a>
  <div class="stats">
    <a class="stat" href="#/today/due"><small>Due today</small><b>${list.length}</b><em class="mini">${list.filter(x=>x.sev==='high').length} urgent</em></a>
    <a class="stat" href="#/leads" data-act="dashboardFilter" data-filter="all"><small>Open referrals</small><b>${open.length}</b><em class="mini">${mine.filter(l=>l.stage==='new').length} new</em></a>
    <a class="stat" href="#/leads/assessment" data-act="dashboardFilter" data-filter="assessment"><small>Assessments pending</small><b>${tours.length}</b><em class="mini">Awaiting completion</em></a>
    <a class="stat" href="#/leads/awaiting-program" data-act="dashboardFilter" data-filter="awaiting-program"><small>Awaiting CCA / program approval</small><b>${paper.length}</b><em class="mini">CCA / approval / LOA</em></a>
  </div>
  <a class="quick-add libertana-attention" href="#/leads/libertana-unsigned" data-act="dashboardFilter" data-filter="libertana-unsigned"><span class="qa-ic">${svg('file')}</span><span class="grow"><b>Libertana forms — incomplete / unsigned</b><small>Needs information or signatures · Open to follow up</small></span><span class="chip">${libertanaUnsigned.length}</span><span class="qa-go" aria-hidden="true">›</span></a>
  <div class="stats stats2" aria-label="Referrals needing attention"><a class="stat" href="#/leads/overdue" data-act="dashboardFilter" data-filter="overdue"><small>Overdue next steps</small><b>${overdue.length}</b><em class="mini">Past the follow-up date</em></a><a class="stat" href="#/leads/blocked" data-act="dashboardFilter" data-filter="blocked"><small>Blocked referrals</small><b>${blocked.length}</b><em class="mini">A step marked blocked</em></a><a class="stat" href="#/leads/needs-program" data-act="dashboardFilter" data-filter="needs-program"><small>Program needs confirmation</small><b>${needsProgram.length}</b><em class="mini">Choose or review the program</em></a></div>
  ${(()=>{if(mine.some(l=>TL.countySummary(l)))return '';const ps=TL.pipelineStats(mine);return `<div class="stats stats2" aria-label="Pipeline health">
    <a class="stat" href="#/leads"><small>Open leads</small><b>${ps.open}</b><em class="mini">Active referrals</em></a>
    <a class="stat" href="#/leads"><small>Average age</small><b>${ps.avgAge} days</b><em class="mini">since the lead came in</em></a>
    <a class="stat" href="#/today"><small>Stale</small><b>${ps.stalePct}%</b><em class="mini">${ps.stale} need a check-in</em></a>
    <a class="stat" href="#/leads" data-act="arch" data-v="1"><small>Closed this month</small><b>${ps.wonMonth+ps.lostMonth}</b><em class="mini">${ps.wonMonth} won \u00b7 ${ps.lostMonth} lost</em></a>
  </div>`;})()}
  ${progressDashboard(open)}
  ${admin?teamActivityPanel(false):''}
  ${followUps}
  <section class="card">
    <h4 class="mt">Scheduled next actions · next 7 days</h4>${(()=>{const upcoming=TL.upcomingTasks(scope);return upcoming.length?`<ul class="scheduled-tasks">${upcoming.map(t=>`<li><div><b>${esc(t.text)}</b><small>${esc(TL.U(t.rep)?.name||'Needs assignment')} · ${fmtDate(t.due)}${t.leadId?' · '+esc(TL.leadName(TL.Lead(t.leadId))):''}</small></div>${t.leadId?`<a class="btn tiny ghost" href="#/lead/${t.leadId}">Open lead</a>`:''}</li>`).join('')}</ul>`:'<p class="muted small">No next steps scheduled yet. Open a lead to set its next step and follow-up date.</p>';})()}
    <p class="muted small mt">Follow-ups appear in Today. External email and text delivery is not connected. <a href="#/rules">Edit the rules</a></p>
  </section>`;
};

function providerKey(v){return String(v||'not-recorded').toLowerCase().replace(/[^a-z0-9]/g,'');}
function providerOptions(selected){const rows=new Map();for(const l of TL.visibleLeads().filter(TL.isOpen)){const p=TL.referralSummary(l);if(p.waiting){const key=providerKey(p.provider),old=rows.get(key)||{label:p.provider||'Provider not recorded',count:0};old.count++;rows.set(key,old);}}return '<option value="all">All waiting providers</option>'+[...rows].sort((a,b)=>a[1].label.localeCompare(b[1].label)).map(([key,v])=>`<option value="${esc(key)}" ${selected===key?'selected':''}>${esc(v.label)} · ${v.count}</option>`).join('');}
function progressDashboard(open){const old=open.filter(l=>(TL.referralSummary(l).waitingDays||0)>=14);return `<section class="card"><div class="card-h"><h3>Referrals by stage</h3>${old.length?`<button type="button" class="btn small ghost" data-act="oldWaiting">Waiting 14+ days · ${old.length}</button>`:''}</div><div class="filters compact-stage-filters"><label>Stage<select class="input" id="homeStage">${opt([['all','All open stages'],...window.TLReferral.statuses.filter(x=>!['moved','county'].includes(x[0]))],'all')}</select></label><label>Waiting on<select class="input" id="homeProvider">${providerOptions('all')}</select></label></div><button class="btn small primary" type="button" data-act="progressFilter">Show referrals</button><p class="small muted mt">Open a referral to see when waiting was recorded, the latest dated update, and the next follow-up.</p></section>`;}

/* ---------- Leads: board + list ---------- */
function filtered(){
  let ls=TL.visibleLeads();
  if(UI.rep!=='all') ls=ls.filter(l=>UI.rep==='none'?!l.rep:l.rep===UI.rep);
  if(UI.bld!=='all') ls=ls.filter(l=>UI.bld==='none'?!l.building:l.building===UI.bld);
  ls=ls.filter(l=>UI.closed?!TL.isOpen(l):UI.issue&&UI.issue!=='all'?TL.leadMatchesFilter(l,UI.issue):TL.isOpen(l));
  if(UI.roadmapPhase||UI.roadmapAction)ls=ls.filter(l=>TL.matchesRoadmap(l,UI.roadmapPhase||'all',UI.roadmapAction||'all'));
  if(UI.progressStage&&UI.progressStage!=='all')ls=ls.filter(l=>(UI.progressStage==='approval'?['approval','county'].includes(TL.referralSummary(l).stage):TL.referralSummary(l).stage===UI.progressStage));
  if(UI.waitProvider&&UI.waitProvider!=='all')ls=ls.filter(l=>{const p=TL.referralSummary(l);return p.waiting&&providerKey(p.provider)===UI.waitProvider;});
  if(UI.waitingAge)ls=ls.filter(l=>(TL.referralSummary(l).waitingDays||0)>=14);
  if(UI.q){const q=UI.q.toLowerCase(); ls=ls.filter(l=>(l.first+' '+l.last+' '+l.caller.name+' '+l.caller.phone+' '+l.sourceDetail).toLowerCase().includes(q));}
  return ls;
}
function marketerTag(l){
 const owner=TL.U(l.rep),origin=TL.U(l.originRep);
 return `<div class="marketer-tag"><small>LEAD OWNER</small><strong>${esc(owner?owner.name:'Needs assignment')}</strong>${origin&&origin.id!==l.rep?`<span>Originally from ${esc(origin.name)}</span>`:''}</div>`;
}
function paperworkMini(l){const p=TL.referralSummary(l);return `<p class="small county-card-next"><span class="chip">${esc(p.label)}</span><br><b>Next:</b> ${esc(p.next)}<br><span class="muted">Follow up ${fmtDate(p.due)}</span>${p.waiting?`<br>${waitingText(p)}`:''}${p.note?`<br><span class="muted">${fmtRecorded(p.noteAt)}: ${esc(p.note)}</span>`:''}</p>`;}

function countyRoadmapCard(l,canEdit,inlineStep=null){
 const flow=TL.countySummary(l);if(!flow)return l.programReviewRequired?`<section class="card"><h3>Confirm the referral’s program</h3><p>Choose the actual payment / program above to show its roadmap.</p></section>`:'';const current=flow.next,owner=TL.U(current?.owner),legacy=l.countyWorkflow?.legacy||{};const lastStep=flow.steps.filter(x=>x.note&&x.updatedAt).sort((a,b)=>String(b.updatedAt).localeCompare(String(a.updatedAt)))[0];const latest=lastStep?.note||(l.activity||[]).find(x=>['note','followup'].includes(x.type))?.text||l.notes||'No progress update has been recorded yet.';
 const status={not_started:'Not confirmed',pending:'In progress / waiting',blocked:'Blocked',done:'Confirmed complete'};
 return `<section class="card county-next-card"><div class="card-h"><div><small>${esc(TL.programLabel(TL.program(l)))} · ${esc(flow.config.county)} County</small><h3>${flow.config.unavailable?'Program needs review':current?'Next step':l.stage==='lost'?'Referral closed':'All tracked steps complete'}</h3></div>${current?`<span class="chip ${flow.due<TL.T?'warn':''}">${flow.due<TL.T?'Overdue · ':''}${fmtDate(flow.due)}</span>`:''}</div>
 <div class="county-context"><b>Latest recorded update</b><p>${esc(latest)}</p></div>
 ${!flow.reviewed?'<p class="county-review">Review this referral’s starting point. Earlier information is preserved; unverified steps have not been marked complete.</p>':''}
 ${current?`<h3 class="county-action">${esc(current.label)}</h3><dl class="dl"><dt>Responsible</dt><dd>${esc(owner?.name||'Needs staff assignment')}</dd><dt>Waiting on</dt><dd>${esc(current.waitingOn||current.party)}</dd><dt>Follow up</dt><dd>${fmtDate(flow.due)}</dd></dl>${canEdit||(inlineStep||current).owner===S().me?inlineStep?`<div class="inline-referral-step mt">${countyStepForm(l,inlineStep.key,true)}</div>`:`<button type="button" class="btn primary" data-act="countyStep" data-id="${esc(l.id)}" data-key="${esc(current.key)}">Update next step</button>`:''}`:'<p>Review the history below for confirmations.</p>'}
 <div class="county-context"><b>Approval tracking:</b> ${esc(flow.steps.find(s=>s.key==='authorization')?.status==='done'?'Approval paperwork verified':flow.steps.find(s=>s.key==='loa_ready')?.status==='done'?'LOA confirmed drafted':flow.steps.find(s=>s.key==='informing_notice')?.status==='done'?'Informing Notice verified':legacy.programApproval==='approved'?'Previously marked approved — paperwork still needs verification':'Not yet verified')}<br><b>Plan:</b> ${esc(flow.plan)} ${TL.program(l)==='alw'||l.countyWorkflow?.plan?'':' · needs confirmation'}<br><b>CCA / provider:</b> ${esc(l.cca||'Not recorded')}${flow.config.partner&&!l.cca?' · roadmap partner: '+esc(flow.config.partner):''}</div>
 ${flow.ready&&l.stage!=='movein'?'<p class="small">Tracking prerequisites confirmed. Coordinate the move-in with the facility.</p>':''}
 <p class="county-route"><b>Your county roadmap:</b> ${esc(flow.config.note)}</p>
 <div class="county-milestones">${['Referral','Building assessment','Program approval','Move-in'].map((title,i)=>{const steps=flow.steps.filter(s=>s.phase===i+1),next=steps.find(s=>s.status!=='done'),complete=steps.length>0&&!next;return `<section class="county-milestone"><h4>${i+1}. ${title} <span class="chip ${complete?'':'ghost'}">${complete?'Complete':next?.status==='blocked'?'Blocked':next?.status==='pending'?'Waiting':next?'To do':'Not applicable'}</span></h4>${next?`<p><b>${esc(next.label)}</b></p><p class="small">Responsible: ${esc(TL.U(next.owner)?.name||'Needs assignment')} · Follow up: ${fmtDate(next.due||flow.due)}</p>`:''}${next&&(canEdit||next.owner===S().me)?`<button type="button" class="btn small primary" data-act="countyStep" data-id="${esc(l.id)}" data-key="${esc(next.key)}">Update</button>`:''}<details class="mt"><summary>${steps.length?`Review ${steps.length} step${steps.length===1?'':'s'}`:'No additional steps'}</summary><ol>${steps.map(step=>`<li class="county-step"><div><b>${esc(step.label)}</b><small class="block muted">${esc(status[step.status])} · ${esc(TL.U(step.owner)?.name||'Unassigned')}</small>${step.waitingOn?`<small>Waiting on ${esc(step.waitingOn)}</small>`:''}</div>${canEdit||step.owner===S().me?`<button class="btn small ghost" data-act="countyStep" data-id="${esc(l.id)}" data-key="${esc(step.key)}">Update</button>`:''}</li>`).join('')}</ol></details></section>`;}).join('')}</div>
 ${TL.program(l)==='alw'?`<p class="small">CCA status: ${esc(({unknown:'Not confirmed',waitlist:'On waitlist',coming_off:'Coming off waitlist',pended:'Pended — awaiting RCFE acceptance',submitted:'Assessment / ISP sent to DHCS',notice_received:'Informing Notice reported received'})[l.countyWorkflow?.slotStatus]||'Not confirmed')}${l.countyWorkflow?.placementDeadline?' · Placement deadline: '+fmtDate(l.countyWorkflow.placementDeadline):''}</p>`:''}
 <details><summary class="small">Earlier information &amp; process notes</summary>${legacy.assessment||legacy.programApproval?`<p class="small">Earlier assessment: ${esc(legacy.assessment||'Not recorded')}; earlier program status: ${esc(legacy.programApproval||'Not recorded')}. These do not establish building acceptance or verified approval paperwork.</p>`:''}${legacy.nextAction?`<p class="small">Earlier next step: ${esc(legacy.nextAction)}${legacy.nextFollowUp?' · '+fmtDate(legacy.nextFollowUp):''}</p>`:''}<p class="small">${esc(flow.config.note)}</p></details></section>`;
}
function countyStepForm(l,key,inline=false){
 const flow=TL.countySummary(l),step=flow?.steps.find(s=>s.key===key);if(!step)return '';
 const alw=TL.program(l)==='alw',saved=l.countyWorkflow||{};
 const owners=S().users.filter(u=>u.role==='admin'||u.buildingAccess==='all'||u.buildingAccess?.includes(l.building));
 return `<h3 id="modalTitle">${esc(step.label)}</h3><form data-form="countyStep" data-inline="${inline}" data-id="${esc(l.id)}" data-key="${esc(key)}"><label>Status<select class="input" name="status">${opt([['not_started','Not confirmed'],['pending','In progress / waiting'],['blocked','Blocked'],['done','Confirmed complete']],step.status)}</select></label><label class="block mt">Responsible staff member<select class="input" name="owner" required>${owners.map(u=>`<option value="${esc(u.id)}" ${step.owner===u.id?'selected':''}>${esc(u.name)}</option>`).join('')}</select></label><label class="block mt">Waiting on<input class="input" name="waitingOn" value="${esc(step.waitingOn||'')}" placeholder="Person / agency — ${esc(step.party)}" maxlength="2000"></label><label class="block mt">Follow up on<input type="date" class="input" name="due" value="${esc(step.due||flow.due||TL.T)}"></label><label class="block mt">Update / confirmation details<textarea class="input" name="note" rows="3" maxlength="2000" placeholder="Who confirmed it? What was received or what are we waiting for?">${esc(step.note||'')}</textarea></label>
 ${key==='confirm_pathway'?`<label class="block mt">Actual health plan<input class="input" name="plan" value="${esc(saved.plan||'')}" placeholder="${esc(flow.config.plan)}" maxlength="2000"></label>`:''}
 ${['schedule_movein','moved_in'].includes(key)?`<label class="block mt">${key==='moved_in'?'Actual':'Scheduled'} move-in date<input type="date" class="input" name="moveIn" value="${esc(key==='moved_in'?TL.T:l.moveIn||'')}"></label>`:''}
 ${alw?`<details class="mt" ${['transition','cca_verification','slot_release'].includes(key)?'open':''}><summary>ALW transition &amp; CCA status</summary><label>Transition<select class="input" name="transition"><option value="">Not confirmed</option>${opt([['community','Community / from home'],['snf','SNF'],['aps','SNF fast-track — APS letter'],['ombudsman','SNF fast-track — Ombudsman letter']],saved.transition)}</select></label><label class="block mt">CCA-reported status<select class="input" name="slotStatus">${opt([['unknown','Not confirmed'],['waitlist','On waitlist'],['coming_off','Coming off waitlist'],['pended','Pended — released, awaiting acceptance'],['submitted','Assessment / ISP sent to DHCS'],['notice_received','Informing Notice reported received']],saved.slotStatus||'unknown')}</select></label><label class="block mt">Waitlist date confirmed by CCA<input type="date" class="input" name="waitlistDate" value="${esc(saved.waitlistDate||'')}"></label><label class="block mt">Placement deadline confirmed by CCA<input type="date" class="input" name="placementDeadline" value="${esc(saved.placementDeadline||'')}"></label></details>`:''}
 <p class="small muted">Marking complete records your confirmation. Uploaded files and AI do not approve this referral.</p><div class="btnrow mt"><button type="submit" class="btn primary">Save step</button><button type="button" class="btn ghost" data-act="${inline?'backToResults':'closeModal'}">${inline?'Back to results':'Cancel'}</button></div><p role="alert" class="tbad" data-step-error></p></form>`;
}
function paymentButtons(l,canEdit){return `<div class="program-choice"><b>Payment / program</b><div class="seg" role="group" aria-label="Payment program">${window.TLRoadmap.paymentOptions(l.building).map(([key,label,payer])=>`<button class="${l.payer===payer?'on':''}" aria-pressed="${l.payer===payer}" type="button" data-act="programChoice" data-id="${esc(l.id)}" data-program="${key}" ${canEdit?'':'disabled'}>${label}</button>`).join('')}</div>${l.building==='crenshaw'?'<small>Crenshaw referrals use CalAIM.</small>':''}</div>`;}
function profileWorkflow(l,canEdit){
 if(TL.countySummary(l))return paymentButtons(l,canEdit);
 const assessment=l.assessmentStatus||'not_started';
 return `${paymentButtons(l,canEdit)}<div class="assign mt"><label class="check"><input type="checkbox" data-change="tourCompleted" data-id="${l.id}" ${l.touredAt?'checked':''} ${canEdit?'':'disabled'}> Tour completed</label><label>Building assessment<select class="input" data-change="assessmentStatus" data-id="${l.id}" ${canEdit?'':'disabled'}>${opt([['not_started','Not started'],['pending','Pending'],['completed','Completed']],assessment)}</select></label></div>`;
}
function paperworkCard(l,canEdit){
 if(TL.countySummary(l)){const saved=UI.profileTab;UI.profileTab='paperwork';const items=TL.paperworkChecklist(l);UI.profileTab=saved;return `<details class="card"><summary>Paperwork checklist</summary><ul class="core-checklist">${items.map(x=>`<li><b>${esc(x.label)}</b><span>${esc(x.status)}</span></li>`).join('')}</ul><p class="small muted">Documents support the steps above. Review attachments below; receipt alone does not confirm program approval.</p></details>`;}
 const items=TL.paperworkChecklist(l);if(!items.length||UI.profileTab!=='paperwork')return '';
 const labels={missing:'Not received',pending:'Pending',received:'Received / completed',approved:'Approved',na:'N/A'};
 const applicable=items.filter(x=>x.status!=='na'),done=applicable.filter(x=>['received','approved'].includes(x.status)).length;
 return `<section class="card core-paperwork" id="paperwork-checklist"><div class="card-h"><h3>${TL.program(l)?esc(TL.programLabel(TL.program(l)))+' ':''}Paperwork</h3><span class="muted small">${done} of ${applicable.length} complete</span></div><ul class="core-checklist">${items.map(x=>`<li class="paperwork-${x.status}"><div><b>${esc(x.label)}</b><small class="block muted">${x.received?'Received '+fmtDate(x.received):''}${x.optional?' · When applicable':''}</small></div><div class="paperwork-controls"><label>Status<select class="input" data-change="paperworkStatus" data-id="${l.id}" data-k="${x.key}" ${canEdit?'':'disabled'}>${opt(Object.entries(labels),x.status)}</select></label>${['missing','pending'].includes(x.status)?`<label>Follow up on<input class="input" type="date" value="${esc(x.due||'')}" data-change="docDue" data-id="${l.id}" data-k="${x.key}" ${canEdit?'':'disabled'}></label>`:''}</div></li>`).join('')}</ul><p class="muted small">Updates are saved in this lead’s activity. CalAIM forms depend on the health plan; use N/A when an item does not apply.</p></section>`;
}
function leadCard(l){
  const s=TL.docStats(l), r=TL.U(l.rep), rem=TL.remindersFor(l).length,canEdit=TL.isAdmin()||l.rep===S().me;
  return `<article class="lcard" ><a class="lc-main" href="#/lead/${l.id}" data-act="openReferral" data-id="${l.id}">${buildingTag(l.building)}${marketerTag(l)}<b>${esc(TL.leadName(l))}${l.age?', '+l.age:''}</b>
  <small>${esc(l.caller.rel==='Self'?'Self':l.caller.name+' \u00b7 '+l.caller.rel)}</small>
  <span class="chips"><span class="chip ghost">${esc(l.source)}</span>${rem?`<span class="chip warn">${rem} due</span>`:''}</span>
  ${paperworkMini(l)}${s.started&&l.stage!=='movein'?`<span class="mini-docs">${bar(s.got,s.req)}<small>${s.got}/${s.req} documents</small></span>`:''}</a>
  <div class="lc-foot">${avatar(r,1)}<small>Open referral to review and update its next step</small></div></article>`;
}
V.leads=function(){
  const ls=filtered(), admin=TL.isAdmin();const filtering=UI.progressStage&&UI.progressStage!=='all'||UI.waitProvider&&UI.waitProvider!=='all'||UI.waitingAge||UI.rep!=='all'||UI.bld!=='all'||!!UI.q.trim()||UI.issue&&UI.issue!=='all'||UI.roadmapPhase&&UI.roadmapPhase!=='all'||UI.roadmapAction&&UI.roadmapAction!=='all';const roadmapActions=[...new Map(TL.visibleLeads().filter(l=>l.stage!=='lost').map(l=>{const f=TL.countySummary(l);return f?.next?[TL.roadmapActionId(l),`${f.next.label} · ${TL.programLabel(TL.program(l))} · ${f.config.county}`]:null;}).filter(Boolean)).entries()].sort((a,b)=>a[1].localeCompare(b[1]));
  const filters=`${UI.issue&&UI.issue!=='all'?`<section class="card active-lead-filter"><h3>${esc(LEAD_FILTERS.find(x=>x[0]===UI.issue)?.[1]||'Filtered referrals')} · ${ls.length}</h3><p class="small">${UI.issue==='libertana-unsigned'?'Every applicable lead whose Libertana packet is not yet complete and signed. Includes current residents with outstanding paperwork; closed lost referrals are excluded.':UI.issue==='awaiting-program'?'Only referrals with unfinished CCA, authorization, LOA or ALW approval steps. Completed approvals and private-pay referrals are excluded.':UI.issue==='overdue'?'Only referrals whose next-step follow-up date has passed.':UI.issue==='assessment'?'Only open referrals with an unfinished building assessment.':UI.issue==='blocked'?'Only referrals with a roadmap step marked blocked.':'Only referrals needing their program selected or reviewed.'}</p><a class="btn small ghost" href="#/leads" data-act="dashboardFilter" data-filter="all">Show all open referrals</a></section>`:''}<div class="filters">
    <label class="filter-search" for="fq">Search<input id="fq" class="input" type="search" placeholder="Name, phone or referrer" value="${esc(UI.q)}" data-input="q"></label>
    ${!UI.closed?`<label>Needs attention<select class="input" data-change="leadIssue">${opt(LEAD_FILTERS,UI.issue||'all')}</select></label>`:''}
    <label for="fbld">Building<select id="fbld" class="input" data-change="fbld"><option value="all">All buildings</option>${sortedBuildings().map(b=>`<option value="${b.id}"${UI.bld===b.id?' selected':''}>${esc(b.short)}</option>`).join('')}<option value="none"${UI.bld==='none'?' selected':''}>No building</option></select></label>
    <label for="frep">Lead owner<select id="frep" class="input" data-change="frep"><option value="all">All lead owners</option>${S().users.map(u=>`<option value="${u.id}"${UI.rep===u.id?' selected':''}>${esc(u.name)}</option>`).join('')}<option value="none"${UI.rep==='none'?' selected':''}>Unassigned</option></select></label>
    ${!UI.closed?`<label>Referral stage<select class="input" data-change="progressStage">${opt([['all','All stages'],...window.TLReferral.statuses.filter(x=>!['moved','county'].includes(x[0]))],UI.progressStage||'all')}</select></label><label>Waiting on provider<select class="input" data-change="waitProvider">${providerOptions(UI.waitProvider||'all')}</select></label><label class="check"><input type="checkbox" data-change="waitingAge" ${UI.waitingAge?'checked':''}> Waiting 14+ days</label>`:''}
  </div>`;
  const nClosed=TL.visibleLeads().filter(l=>!TL.isOpen(l)).length;
  const viewSeg=UI.closed?'':`<div class="seg" role="tablist" aria-label="Lead views"><button type="button" role="tab" aria-selected="${UI.view==='buildings'}" class="${UI.view==='buildings'?'on':''}" data-act="view" data-v="buildings">By building</button><button type="button" role="tab" aria-selected="${UI.view==='list'}" class="${UI.view==='list'?'on':''}" data-act="view" data-v="list">List</button></div>`;
  const head=`<div class="lhead"><div class="seg" role="group" aria-label="Open or closed leads"><button type="button" class="${UI.closed?'':'on'}" aria-pressed="${!UI.closed}" data-act="arch" data-v="0">Open</button><button type="button" class="${UI.closed?'on':''}" aria-pressed="${!!UI.closed}" data-act="arch" data-v="1">Closed <small>${nClosed}</small></button></div>${viewSeg}
    <span class="muted small">${ls.length} lead${ls.length===1?'':'s'}</span><span class="grow"></span>
    <a class="btn small ghost" href="#/import">Upload</a><a class="btn small primary" href="#/add/${TL.B(UI.bld)?UI.bld:''}">+ Add lead</a></div>`;
  if(UI.closed){
    const rows=ls.slice().sort((a,b)=>String(TL.closedAt(b)).localeCompare(String(TL.closedAt(a))));
    return head+filters+`<p class="muted small hint">Closed leads are out of the active pipeline but stay searchable. Reopen one to return it to the active referrals.</p><section class="card flush"><div class="tablewrap"><table class="ltable"><thead><tr><th>Lead</th><th>Outcome</th><th>Closed</th><th>Building</th><th>Lead owner</th><th></th></tr></thead><tbody>
    ${rows.map(l=>{const r=TL.U(l.rep);return `<tr><td data-l="Lead"><a href="#/lead/${l.id}" data-act="openReferral" data-id="${l.id}"><b>${esc(TL.leadName(l))}</b></a><small class="block muted">${esc(l.source)}</small></td><td data-l="Outcome">${l.stage==='movein'?'<span class="chip">Won \u00b7 moved in</span>':'<span class="chip warn">Lost</span> <small class="muted">'+esc(l.lostReason||'')+'</small>'}</td><td data-l="Closed">${fmtDate(TL.closedAt(l))}</td><td data-l="Building">${buildingTag(l.building)}</td><td data-l="Lead owner">${marketerTag(l)}</td><td><button type="button" class="btn tiny ghost" data-act="reopen" data-id="${l.id}">Reopen</button></td></tr>`;}).join('')||'<tr><td colspan="6" class="muted">No closed leads match.</td></tr>'}
    </tbody></table></div></section>`;
  }
  if(UI.view==='buildings'){
    const unassigned=ls.filter(l=>!TL.B(l.building));
    const groups=sortedBuildings().filter(b=>(UI.bld==='all'||UI.bld===b.id)&&(!filtering||ls.some(l=>l.building===b.id))).map(b=>{const leads=ls.filter(l=>l.building===b.id);return `<details class="building-group" ${leads.length?'open':''}><summary><span>${esc(b.name)}</span><span class="chip">${leads.length} lead${leads.length===1?'':'s'}</span></summary><div class="building-group-body"><div class="row-tools"><p class="muted small">Every lead below is assigned to ${esc(b.name)}.</p><a class="btn small primary" href="#/add/${b.id}">+ Add lead for this building</a></div><div class="building-lead-grid">${leads.map(leadCard).join('')||'<p class="muted">No leads match these filters.</p>'}</div></div></details>`;}).join('');
    return head+filters+`<p class="muted small">Leads are grouped by their assigned building. Open a building to see its leads or add a new one directly.</p>${unassigned.length?`<section class="card assignment-needed"><h3>Needs building assignment · ${unassigned.length}</h3><p>These older records need a building selected. Open each profile to assign it.</p><div class="building-lead-grid">${unassigned.map(leadCard).join('')}</div></section>`:''}${groups||'<section class="card"><p>No referrals match these filters.</p></section>'}`;
  }
  if(UI.view==='list'){
    const rows=ls.slice().sort((a,b)=>String(b.updated).localeCompare(String(a.updated)));
    return head+filters+`<section class="card flush"><div class="tablewrap"><table class="ltable"><thead><tr><th>Lead</th><th>Next step</th><th>Building</th><th>Lead owner</th><th>Source</th><th>Payer</th><th>Move-in</th><th>Paperwork</th><th>Last contact</th></tr></thead><tbody>
    ${rows.map(l=>{const s=TL.docStats(l);const r=TL.U(l.rep);return `<tr><td data-l="Lead"><a href="#/lead/${l.id}" data-act="openReferral" data-id="${l.id}"><b>${esc(TL.leadName(l))}</b></a><small class="block muted">${esc(l.caller.rel==='Self'?'Self':l.caller.name+' ('+l.caller.rel+')')}</small></td><td data-l="Next step">${esc(TL.referralSummary(l).next)}</td><td data-l="Building">${buildingTag(l.building)}</td><td data-l="Lead owner">${marketerTag(l)}</td><td data-l="Source">${esc(l.source)}</td><td data-l="Payer">${esc(l.payer)}</td><td data-l="Move-in">${fmtDate(l.moveIn)}</td><td data-l="Paperwork">${s.started?s.got+'/'+s.req:'\u2014'}</td><td data-l="Last contact">${fmtAgo(l.lastContact)}</td></tr>`;}).join('')||'<tr><td colspan="9" class="muted">No leads match these filters.</td></tr>'}
    </tbody></table></div></section>`;
  }
  return head+filters;
};

/* ---------- Lead detail ---------- */
V.lead=function(id){const l=TL.Lead(id);if(!l)return '<section class="card">Referral not found.</section>';const canEdit=TL.isAdmin()||l.rep===S().me,p=TL.referralSummary(l),rems=TL.allReminders('all').filter(x=>x.leadId===l.id);return `<a class="back" href="${esc(UI.returnToResults||'#/leads')}" data-act="backToResults">‹ Back</a><section class="card lead-head">${buildingTag(l.building)}${marketerTag(l)}<h2>${esc(TL.leadName(l))}${l.age?', '+l.age:''}</h2><p>${esc(l.payer)}${l.payer!=='Private pay'&&l.tier?' · Tier '+l.tier:l.payer==='Private pay'&&l.budget?' · Resident budget '+money(l.budget)+'/month':''}</p>${!TL.isOpen(l)?`<p class="closedbar">${l.stage==='movein'?'Moved in':'Closed'}${canEdit?` <button type="button" class="btn small ghost" data-act="reopen" data-id="${l.id}">Reopen</button>`:''}</p>`:''}</section>${rems.length?`<section class="card alert-card"><h3>Due now</h3><ul class="rems">${rems.map(x=>`<li class="rem sev-${x.sev}"><span class="dot"></span><div class="grow">${esc(x.text)}</div></li>`).join('')}</ul></section>`:''}<section class="card">${canEdit?leadForm(l,{inline:true}):`<h3>Referral progress</h3><p>${esc(p.label)}</p><p><b>Next:</b> ${esc(p.next)}</p><p>${waitingText(p)}</p><p>${esc(l.caller?.name||'')} · ${esc(l.caller?.phone||'')} · ${esc(l.caller?.email||'')}</p><p>${esc(l.notes||'')}</p>`}</section>${window.TLLibertanaUI?.card(l,canEdit)||''}<details class="card"><summary>Program details · county roadmap &amp; paperwork</summary>${countyRoadmapCard(l,canEdit)}${paperworkCard(l,canEdit)}</details><section class="card"><h3>Documents</h3><label class="btn small ghost" for="scan-${l.id}">Upload a document</label><input id="scan-${l.id}" ${canEdit?'':'disabled'} class="sr-only" type="file" accept=".pdf,.docx,.txt,.heic,.heif,image/*" data-change="capFile" data-id="${l.id}"></section>
  ${(l.files||[]).length?`<section class="card"><h3>Documents on file</h3><ul class="files">${l.files.map(fl=>`<li>${svg('file')}<div class="grow">${REMOTE&&fl.id?`<a href="/api/files/${encodeURIComponent(fl.id)}" data-act="viewDocument" data-id="${esc(l.id)}" data-file="${esc(fl.id)}"><b>${esc(fl.name)}</b></a>${canEdit?` <button type="button" class="btn small ghost" data-act="readDocument" data-id="${esc(l.id)}" data-file="${esc(fl.id)}">Read paperwork</button>`:''}`:`<b>${esc(fl.name)}</b>`}<small class="muted block">${fl.forms&&fl.forms.length?'Received: '+esc(fl.forms.join(', '))+' · ':''}${fmtDate(fl.at)} · ${esc((TL.U(fl.by)||{}).name||'')}</small></div></li>`).join('')}</ul><p class="muted small">${REMOTE?'Original files are encrypted in storage. Downloads require a signed-in account with access to this lead.':'Preview: only the file name is kept. No original file is uploaded.'}</p></section>`:''}
  <section class="card"><h3>Activity</h3>
    <form data-form="note" data-id="${l.id}" class="noteform"><label class="sr-only" for="note-${l.id}">Add a note</label><input id="note-${l.id}" class="input" name="text" placeholder="Add a note\u2026" autocomplete="off" ${canEdit?'':'disabled'} required><button class="btn small primary" ${canEdit?'':'disabled'}>Add</button></form>
    <ul class="activity">${l.activity.map(a=>{const u=TL.U(a.by);return `<li><span class="atype t-${esc(a.type)}">${esc(a.type)}</span><div class="grow">${esc(a.text)}<small class="muted block">${esc(u?u.name:'System')} \u00b7 ${fmtDate(a.at)} ${esc(String(a.at).slice(11,16))}</small></div></li>`;}).join('')}</ul>
  </section>`;
};


function docRow(l,d,x,canEdit){
  const over=x.status==='missing'&&x.due&&TL.daysUntil(x.due)<0;
  return `<li class="doc ds-${x.status}${over?' over':''}"><div class="doc-h"><span class="form">${esc(d.form)}</span><div class="grow"><b>${esc(d.name)}</b><small class="muted">From: ${esc(d.who)}${d.req?'':' \u00b7 if applicable'}${x.status==='received'?' \u00b7 received '+fmtDate(x.received):x.requested?' \u00b7 requested '+fmtDate(x.requested)+' ('+fmtAgo(x.requested)+')':' \u00b7 not requested yet'}${over?' \u00b7 <b class="tbad">past due</b>':''}</small>
    ${d.src||d.verify||d.steven?`<small class="srcline">${d.steven?'<span class="chip">Tharon item</span> ':''}${d.verify?'<span class="chip warn">verify with your CCA</span> ':''}${d.src?`<a href="${esc(d.src)}" target="_blank" rel="noopener">source</a>`:''}${d.note?' \u00b7 '+esc(d.note):''}</small>`:''}</div></div>
    <div class="doc-c"><div class="seg sm" role="group" aria-label="${esc(d.form)} status">${[['received','Received'],['missing','Missing'],['na','N/A']].map(([k,lab])=>`<button type="button" class="${x.status===k?'on':''}" aria-pressed="${x.status===k}" data-act="docStatus" data-id="${l.id}" data-k="${d.key}" data-s="${k}" ${canEdit?'':'disabled'}>${lab}</button>`).join('')}</div>
    ${x.status==='missing'?`<label class="due">Due <input type="date" class="input slim" value="${esc(x.due||'')}" ${canEdit?'':'disabled'} data-change="docDue" data-id="${l.id}" data-k="${d.key}"></label><button type="button" class="btn tiny ghost" disabled title="Automatic delivery is not connected" data-act="docRequest" data-id="${l.id}" data-k="${d.key}">Manual follow-up required</button>`:''}</div></li>`;
}
function waiverCard(l,ws,canEdit){
  const p=TL.programLabel(ws.program);
  return `<section class="card waiver"><div class="card-h"><h3>Waiver / Medi-Cal checklist <span class="chip">${esc(p)}</span></h3><span class="muted small">${ws.got} of ${ws.req} done</span></div>
    ${bar(ws.got,ws.req)}
    <div class="tierrow"><label>Tier level<select class="input slim" data-change="tier" data-id="${l.id}" ${canEdit?'':'disabled'}><option value="">\u2014 not assessed \u2014</option>${[1,2,3,4,5].map(n=>`<option value="${n}"${l.tier===n?' selected':''}>Tier ${n}</option>`).join('')}</select></label></div>
    <ul class="docs">${TL.wdocsFor(l).map(d=>docRow(l,d,l.wdocs[d.key],canEdit)).join('')}</ul>
    <p class="muted small">${p==='ALW'?'Assisted Living Waiver application, per the DHCS checklists. The physician\u2019s report (LIC 602A) is also required and is in the CDSS list.':'CalAIM Community Supports, Assisted Living Facility Transitions, per the DHCS policy guide. Each health plan uses its own forms.'} \u201cTharon item\u201d = your own checklist. Each item links to its source. \u201cVerify\u201d = not confirmed on an official page. Missing items go on the rep\u2019s Today list.</p>
  </section>`;
}

/* ---------- Buildings ---------- */
V.buildings=function(){
 const all=TL.visibleLeads();
 return `<section class="hello"><h2>Choose a building</h2><p>The ${S().buildings.length} buildings from your Command Center. Lead assignments are managed here; live census is not connected.</p></section><div class="bgrid">${sortedBuildings().map(b=>{const ls=all.filter(l=>l.building===b.id),open=ls.filter(TL.isOpen);return `<a class="card bcard" href="#/building/${b.id}"><div class="card-h"><div><h3>${esc(b.name)}</h3><small class="muted">${esc(b.county||'County needs confirmation')} County · ${esc(b.contact||'Tharon Group')}</small></div><span class="beds"><b>${open.length}</b><small>open leads</small></span></div><div class="pipe">${[['new','New'],['tour','Tours'],['paperwork','Paperwork'],['movein','Won']].map(([k,n])=>`<span><b>${ls.filter(l=>l.stage===k).length}</b><small>${n}</small></span>`).join('')}</div><p class="small muted">View profiles, assignments and paperwork ›</p></a>`;}).join('')}</div>`;
};
V.building=function(id){
 const b=TL.B(id);if(!b)return V.buildings();const ls=TL.visibleLeads().filter(l=>l.building===id);
 return `<a class="back" href="#/buildings">‹ All buildings</a><section class="hello"><h2>${esc(b.name)}</h2><p>${ls.filter(TL.isOpen).length} active leads · ${esc(b.contact||'Tharon Group')}</p></section><section class="card"><h3>Lead profiles</h3><ul class="plain">${ls.map(l=>`<li><a href="#/lead/${l.id}" data-act="openReferral" data-id="${l.id}"><b>${esc(TL.leadName(l))}</b></a> ${stageChip(l.stage)} <small>${esc(TL.U(l.rep)?.name||'Unassigned')}</small></li>`).join('')||'<li class="muted">No leads assigned yet. Capture a lead and choose this building.</li>'}</ul></section>`;
};
let teamAccounts=null;
function marketerSummary(u){const stats=TL.marketerStats(u.id);return `<div class="marketer-stats" aria-label="${esc(u.name)} lead totals"><div><b>${stats.broughtIn}</b><small>Leads brought in</small></div><div><b>${stats.movedIn}</b><small>Moved in</small></div><div><b>${stats.open}</b><small>Still open</small></div><p class="muted small">All time · credited to the original marketer</p></div>`;}
function buildingAccessForm(u){
 if(u.role==='admin')return '<p class="muted small">Administrator · all buildings</p>';
 const access=u.buildingAccess??(u.id==='u3'?['pointe','carrington','hallmark']:['u1','u2'].includes(u.id)?'all':[]),all=access==='all';
 return `<details class="building-access"><summary>Building access · ${all?'All buildings':access.length+' assigned'}</summary><form data-form="buildingAccess" data-id="${u.id}"><label class="check"><input type="checkbox" name="allBuildings" data-change="accessAll" ${all?'checked':''}> All buildings</label><fieldset class="building-options" ${all?'disabled':''}>${sortedBuildings().map(b=>`<label class="check"><input type="checkbox" name="buildings" value="${b.id}" ${!all&&access.includes(b.id)?'checked':''}>${esc(b.name)}</label>`).join('')}</fieldset><button class="btn small primary" type="submit">Save building access</button></form></details>`;
}
function staffPasswordForm(u){
 if(!REMOTE||u.role!=='rep')return '';
 return `<section class="card"><h3>Set or reset password</h3><form data-form="staffPassword" data-id="${u.id}"><p class="small muted">${esc(u.name)} signs in with their work email and this password. Share it privately. Saving signs them out on all devices.</p><label>New password<input class="input" name="password" type="password" autocomplete="new-password" minlength="14" maxlength="200" required></label><label>Confirm password<input class="input" name="confirm" type="password" autocomplete="new-password" minlength="14" maxlength="200" required></label><button class="btn small primary" type="submit">Save staff password</button></form></section>`;
}
V.team=function(){if(!TL.isAdmin())return V.today();setTimeout(loadTeam,0);return `<section class="hello"><h2>Your team</h2><p>See how many leads each person brought in and how many moved in. Totals stay with the original marketer when a lead is reassigned. Set or reset staff passwords below. Staff sign in directly with their work email and password.</p></section>${teamActivityPanel(true)}<section class="card"><div id="teamStatus">${REMOTE?'Loading account status…':'Preview only · staff passwords are managed on the shared server.'}</div><ul class="plain">${S().users.map(u=>{const active=teamAccounts?.find(a=>a.id===u.id)?.active;return `<li class="team-row"><div class="team-person"><b>${esc(u.name)}</b><small class="muted block">${esc(u.email)} · ${u.role==='admin'?'Administrator':'Marketer'}</small></div>${REMOTE&&u.role==='rep'?(active?'<span class="chip">Active</span>':'<span class="chip">Password needed</span>'):''}${REMOTE&&u.authType==='private_link'?'<p class="muted small">Private admin link · <button type="button" class="btn small ghost" data-act="revokeDelegateAccess">Revoke Efrain’s access</button></p>':''}${staffPasswordForm(u)}${marketerSummary(u)}${buildingAccessForm(u)}</li>`;}).join('')}</ul></section>`;};
let activityData=null,activityError='',activityBusy=false,activityLoadedAt=0;
const activityTime=at=>at?new Date(at).toLocaleString('en-US',{timeZone:'America/Los_Angeles',dateStyle:'medium',timeStyle:'short'}):'Not recorded';
function teamActivityContent(full){
 if(!REMOTE)return '<p class="muted small">Sign-ins and saved updates are shown in the live app. Preview activity is not staff usage.</p>';
 if(!activityData)return `<p class="muted small" role="status">${esc(activityError||'Loading team activity…')}</p>`;
 const data=activityData,events=full?data.recent:data.recent.slice(0,3);
 return `${activityError?`<p class="twarn small">${esc(activityError)} Showing the last loaded report.</p>`:''}${full?'':'<details class="activity-signins"><summary>Marketer sign-ins and saved updates</summary>'}<div class="activity-users">${data.users.map(u=>`<article class="activity-user"><b>${esc(u.name)}</b><dl><dt>Last sign-in</dt><dd>${esc(activityTime(u.lastSignInAt))}</dd><dt>Last saved update</dt><dd>${esc(activityTime(u.lastSavedAt))}</dd></dl><p class="small"><strong>${u.savedActions7Days}</strong> saved actions in the past 7 days</p><a href="#/leads" data-act="marketerLeads" data-id="${esc(u.id)}">View this marketer’s leads</a></article>`).join('')}</div>${full?'':'</details>'}<h4 class="mt">Recent saved changes</h4>${events.length?`<ul class="activity-events">${events.map(e=>`<li><div><strong>${esc(data.users.find(u=>u.id===e.userId)?.name||'Marketer')}</strong> · ${esc(e.label)}${e.fields.length?`<small class="block muted">Changed: ${esc(e.fields.join(', '))}</small>`:''}${e.leadId?`<a class="block" href="#/lead/${esc(e.leadId)}" data-act="openReferral" data-id="${esc(e.leadId)}">${esc(e.leadName)}</a>`:''}<small class="block muted">${esc(activityTime(e.at))}${e.building?' · '+esc(e.building):''}</small></div></li>`).join('')}</ul>`:'<p class="muted small">No saved marketer changes in the past 30 days.</p>'}<p class="muted small">Sign-in times record successful logins. Saved updates also show work done in an existing session. Automatic refreshes are not counted.</p><small class="muted">Report updated ${esc(activityTime(data.generatedAt))} · Pacific time</small>${full?'':'<p><a href="#/team">See all recent team activity</a></p>'}`;
}
function teamActivityPanel(full=false){if(!TL.isAdmin())return '';if(REMOTE)setTimeout(()=>loadTeamActivity(),0);return `<section class="card team-activity"><div class="card-h"><h3>Team Activity <small class="muted">Admin only</small></h3>${REMOTE?'<button type="button" class="btn small ghost" data-act="refreshTeamActivity">Refresh</button>':''}</div><div id="${full?'teamActivityFull':'teamActivityHome'}">${teamActivityContent(full)}</div></section>`;}
if(REMOTE)setInterval(()=>{if(TL.isAdmin()&&document.visibilityState==='visible'&&/^#\/(?:today|team)(?:\/|$)/.test(location.hash||'#/today'))loadTeamActivity();},30000);
async function loadTeamActivity(force=false){if(!REMOTE||!TL.isAdmin()||activityBusy||!force&&Date.now()-activityLoadedAt<30000)return;activityBusy=true;try{activityData=await TLRemote.request('/api/admin/activity');activityError='';activityLoadedAt=Date.now();}catch(error){activityError='Could not refresh team activity. Tap Refresh to retry.';}finally{activityBusy=false;for(const [id,full] of [['#teamActivityHome',false],['#teamActivityFull',true]]){const el=$(id);if(el)el.innerHTML=teamActivityContent(full);}}}
async function loadTeam(){if(!REMOTE)return;try{const r=await TLRemote.request('/api/users');teamAccounts=r.users;const el=$('#teamStatus');if(el)el.textContent=r.users.map(u=>u.name+': '+(u.authType==='private_link'?(u.active?'private admin link active':'private link inactive'):(u.active?'active':'password needed'))).join(' · ');}catch(err){toast(err.message);}}
/* ---------- Upload ---------- */
const FIELDS=[
  ['name','Resident name (full)',['resident name','name','full name','patient','prospect','resident']],
  ['first','First name',['first name','first','fname','given name']],
  ['last','Last name',['last name','last','lname','surname','family name']],
  ['age','Age',['age']],
  ['callerName','Contact name',['contact name','contact','caller','family member','responsible party','caller name']],
  ['rel','Relationship',['relationship','relation','rel','who is calling']],
  ['phone','Phone',['phone','phone number','mobile','cell','telephone']],
  ['email','Email',['email','e-mail','email address']],
  ['source','Referral source',['referral source','source','lead source','referral type']],
  ['sourceDetail','Referred by',['referred by','referrer','referral','referral detail','agency','hospital']],
  ['cca','CCA / program provider',['cca','care coordination agency','program provider']],
  ['care','Care needs',['care needs','care level','level of care','care','needs']],
  ['payer','Payer',['payer','payment','payor','funding','insurance']],
  ['budget','Monthly budget',['monthly budget','budget','rate']],
  ['moveIn','Move-in date',['move-in date','move in date','move in','movein','desired move-in','move-in']],
  ['building','Building',['building','facility','community','location']],
  ['rep','Rep',['rep','assigned to','owner','sales rep']],
  ['notes','Notes',['notes','note','comments','comment']]
];
function guessMap(headers){
  const m={}; const h=headers.map(x=>String(x).toLowerCase().trim());
  FIELDS.forEach(([k,,syn])=>{const i=h.findIndex(x=>syn.includes(x)); if(i>=0&&!Object.values(m).includes(i)) m[k]=i;});
  if(m.name!=null&&(m.first!=null||m.last!=null)){delete m.first;delete m.last;}
  return m;
}
function pickList(val,list,fallback){if(!val) return fallback; const v=String(val).toLowerCase(); return list.find(x=>x.toLowerCase()===v)||list.find(x=>v.includes(x.toLowerCase().split(' ')[0].replace('\u00b7','').trim())||x.toLowerCase().includes(v))||fallback;}
function careFrom(v){if(!v)return '';const s=String(v).toLowerCase();if(s.includes('memory')||s.includes('dementia'))return CARE[5];if(s.includes('hospice')||s.includes('4'))return CARE[4];if(s.includes('3')||s.includes('high'))return CARE[3];if(s.includes('2')||s.includes('moderate'))return CARE[2];if(s.includes('indep'))return CARE[0];return '';}
function dateFrom(v){if(v==null||v==='')return null;if(typeof v==='number'){const d=new Date(Math.round((v-25569)*864e5));return d.toISOString().slice(0,10);}const s=String(v).trim();if(/^\d{4}-\d{2}-\d{2}/.test(s))return s.slice(0,10);const d=new Date(s);return isNaN(d)?null:TL.iso(d);}
function rowToLead(row,m){
  const g=k=>m[k]!=null?row[m[k]]:'';
  let first=String(g('first')||'').trim(), last=String(g('last')||'').trim();
  if(m.name!=null){const parts=String(g('name')||'').trim().split(/\s+/); first=parts.shift()||''; last=parts.join(' ');}
  const bq=String(g('building')||'').toLowerCase().trim(); const b=window.TLImport.matchBuilding(bq,S().buildings);
  const rq=String(g('rep')||'').toLowerCase().trim(); const r=rq?S().users.find(u=>u.name.toLowerCase().includes(rq)||rq.includes(u.name.toLowerCase().split(' ')[0])):null;
  const rel=pickList(g('rel'),REL,'Self');
  return {first,last,age:parseInt(g('age'))||null,caller:{name:String(g('callerName')||'').trim()||(rel==='Self'?first+' '+last:''),rel,phone:String(g('phone')||'').trim(),email:String(g('email')||'').trim()},
    source:pickList(g('source'),SOURCE,'Other'),sourceDetail:String(g('sourceDetail')||'').trim(),cca:String(g('cca')||'').trim(),care:careFrom(g('care')),payer:pickList(g('payer'),PAYER,'Other'),budget:window.TLImport.parseAmount(g('budget')),
    moveIn:dateFrom(g('moveIn')),building:b?b.id:(!bq?(UI.imp?.building||null):null),rep:r?r.id:null,notes:String(g('notes')||'').trim(),_bq:bq,_bldMiss:bq&&!b,_budgetInvalid:String(g('budget')||'').trim()!==''&&window.TLImport.parseAmount(g('budget'))===null};
}
const dupOf=l=>S().leads.find(x=>(l.caller.phone&&x.caller.phone&&x.caller.phone.replace(/\D/g,'')===l.caller.phone.replace(/\D/g,''))||(x.first.toLowerCase()===l.first.toLowerCase()&&x.last.toLowerCase()===l.last.toLowerCase()));
V.import=function(){
  const st=UI.imp;
  let step2='';
  if(st){
    const leads=st.rows.map(r=>rowToLead(r,st.map));
    const valid=leads.filter(l=>l.first&&l.last&&l.building);const missingBuilding=leads.filter(l=>(l.first||l.last)&&!l.building).length;
    const dups=valid.filter(dupOf).length,invalid=leads.filter(l=>!l.first||!l.last||l._budgetInvalid).length;
    step2=`<section class="card" id="mapcard"><div class="card-h"><h3>2. Match the columns</h3><span class="muted small">${esc(st.file)} \u00b7 ${st.rows.length} rows</span></div>
    <label class="block">Worksheet<select class="input" data-change="importSheet">${st.workbook.SheetNames.map(n=>`<option value="${esc(n)}" ${n===st.sheet?'selected':''}>${esc(n)}</option>`).join('')}</select></label><p class="muted small">Only worksheet <b>${esc(st.sheet)}</b> will be imported (${st.workbook.SheetNames.length} sheet(s) in this workbook). Other sheets are not included; select and review each separately. Blank program and care remain unknown. Preview shows the first 6 rows; all ${st.rows.length} selected-sheet rows are included.</p>
    <div class="mapgrid">${FIELDS.map(([k,lab])=>`<label>${esc(lab)}<select class="input slim" data-change="map" data-k="${k}"><option value="">\u2014 skip \u2014</option>${st.headers.map((h,i)=>`<option value="${i}"${st.map[k]===i?' selected':''}>${esc(h)}</option>`).join('')}</select></label>`).join('')}</div>
    <h4 class="mt">Preview</h4>${invalid?`<p class="tbad">${invalid} row(s) need a first/last name or valid budget. Correct the file or mapping before importing; no rows will be silently omitted.</p>`:''}<div class="tablewrap"><table class="ltable prev"><thead><tr><th>Resident</th><th>Contact</th><th>Source</th><th>Care</th><th>Payer</th><th>Budget / month</th><th>CCA</th><th>Owner</th><th>Move-in</th><th>Building</th><th></th></tr></thead><tbody>
    ${leads.slice(0,6).map(l=>`<tr><td data-l="Resident"><b>${esc(l.first+' '+l.last)}</b>${l.age?', '+l.age:''}</td><td data-l="Contact">${esc(l.caller.name)} \u00b7 ${esc(l.caller.rel)}<small class="block muted">${esc(l.caller.phone)}</small></td><td data-l="Source">${esc(l.source)}</td><td data-l="Care">${esc(l.care||'Unknown')}</td><td data-l="Payer">${esc(l.payer==='Other'?'Unknown / needs review':l.payer)}</td><td data-l="Budget">${l.budget==null?'Unknown':esc(l.budget.toFixed(2))}</td><td data-l="CCA">${esc(l.cca||'Unknown')}</td><td data-l="Owner">${esc(TL.U(st.rep||l.rep||S().me)?.name||'Unassigned')}</td><td data-l="Move-in">${fmtDate(l.moveIn)}</td><td data-l="Building">${l.building?esc(bname(l.building)):l._bldMiss?'<span class="twarn">"'+esc(l._bq)+'" not found</span>':'<span class="muted">none</span>'}</td><td>${dupOf(l)?'<span class="chip warn">possible duplicate</span>':''}</td></tr>`).join('')}
    </tbody></table></div>${leads.length>6?`<p class="muted small">\u2026and ${leads.length-6} more.</p>`:''}
    <div class="row-tools mt"><label>Building for rows missing a building<select class="input slim" data-change="impBuilding"><option value="">Choose a building</option>${sortedBuildings().map(b=>`<option value="${b.id}"${st.building===b.id?' selected':''}>${esc(b.name)}</option>`).join('')}</select></label>${missingBuilding?`<p class="twarn">${missingBuilding} rows need a building. The selector fills blank building cells only. Correct unknown or ambiguous names in the file before importing.</p>`:''}
      <label>Assign to rep<select class="input slim" data-change="impRep"><option value="">${TL.isAdmin()?'From the file / unassigned':'Me'}</option>${reps().map(u=>`<option value="${u.id}"${st.rep===u.id?' selected':''}>${esc(u.name)}</option>`).join('')}</select></label>
      ${dups?`<label class="check"><input type="checkbox" data-change="impDup" ${st.skipDup?'checked':''}> Skip ${dups} possible duplicate${dups>1?'s':''}</label>`:''}
      <button type="button" class="btn primary" data-act="doImport" ${missingBuilding||invalid||!leads.length?'disabled':''}>Import ${valid.length-(st.skipDup?dups:0)} leads</button><button type="button" class="btn ghost" data-act="cancelImport">Cancel</button></div></section>`;
  }
  return `<section class="hello"><h2>Upload leads</h2><p>Bring in a spreadsheet from any rep. CSV and Excel both work. Review the columns, then save the leads. The shared app saves them to the team database.</p></section>
  <section class="card"><h3>1. Choose a file</h3>
    <label class="drop" for="file"><b>Tap to choose a CSV or Excel file</b><small class="muted">or drop it here \u00b7 .csv, .xlsx, .xls</small></label>
    <input id="file" class="sr-only" type="file" accept=".csv,.xlsx,.xls,text/csv" data-change="file">
    <div class="btnrow"><button type="button" class="btn small ghost" data-act="sampleCsv">Download sample CSV</button><button type="button" class="btn small ghost" data-act="useSample">Try it with the sample file</button></div>
    <p class="muted small">Use sample data only in this demo.</p></section>
  ${step2}
  <section class="card"><div class="card-h"><h3>Or add one by hand</h3></div><button type="button" class="btn primary" data-act="quickAdd">+ Quick add a lead</button>
  <h4 class="mt">Move data in and out</h4><p class="muted small">JSON export only; JSON import is unavailable. Use CSV / Excel to import. Export format <code>tharon-leads/v1</code>, described in INTEGRATION.md).</p>
  <div class="btnrow"><button type="button" class="btn small ghost" data-act="exportJson">Export JSON</button></div></section>`;
};
function parseFile(name,buf){
  if(!window.XLSX){toast('The spreadsheet reader is still loading. Try again in a second.');return;}
  const wb=XLSX.read(buf,{type:'array',cellDates:false});
  UI.imp={file:name,workbook:wb,rep:'',building:'',skipDup:true};selectImportSheet(wb.SheetNames[0]);
}
window.addEventListener('beforeunload',e=>{if(UI.imp?.importRequest){e.preventDefault();e.returnValue='';}});
function selectImportSheet(name){const st=UI.imp;if(!st?.workbook.SheetNames.includes(name))return;const aoa=XLSX.utils.sheet_to_json(st.workbook.Sheets[name],{header:1,defval:'',raw:true}).filter(r=>r.some(c=>String(c).trim()!==''));st.sheet=name;st.headers=(aoa[0]||[]).map(h=>String(h).trim()||'(blank)');st.rows=aoa.slice(1);st.map=guessMap(st.headers);st.importRequest=null;render();}

async function doImport(){
  const st=UI.imp;if(!st||st.busy)return;
  const pending=st.rows.map(r=>rowToLead(r,st.map));
  if(pending.some(l=>!l.first||!l.last||l._budgetInvalid)){toast('Correct names and budgets before importing.');return;}
  if(pending.some(l=>!l.building)){toast('Choose a building for every row before importing.');return;}
  if(!pending.length){toast('No named leads to import.');return;}
  let n=0,skipped=0;st.busy=true;
  const button=document.querySelector('[data-act="doImport"]');if(button){button.disabled=true;button.textContent='Saving…';}
  try{
    const records=pending.map(l=>{delete l._bq;delete l._bldMiss;delete l._budgetInvalid;if(st.rep&&TL.isAdmin())l.rep=st.rep;if(!TL.isAdmin())l.rep=S().me;return l;});
    if(REMOTE){
      st.importRequest=st.importRequest||{id:crypto.randomUUID(),records,skipDuplicates:st.skipDup};
      const result=await TLRemote.importLeads(st.importRequest);n=result.imported;skipped=result.skipped;
    }else{
      for(const l of records){if(st.skipDup&&dupOf(l)){skipped++;continue;}TL.createLead(l,'Imported from '+st.file+'.');n++;}
    }
    UI.imp=null;toast(`Imported ${n} lead${n===1?'':'s'}${skipped?`, skipped ${skipped} duplicate${skipped>1?'s':''}`:''}.`);
    UI.view='list';UI.rep='all';UI.bld='all';UI.stage='new';location.hash='#/leads';render();
  }catch(e){if(e.status&&e.status<500)st.importRequest=null;toast(e.message+' Your file is still on this screen. Retry to confirm the same batch, or cancel to review it again.');}
  finally{st.busy=false;if(UI.imp===st)render();}
}

/* ---------- Ask ---------- */
V.ask=function(){
  const chat=S().chat;
  return `<section class="card chat"><div class="card-h"><div><h3>Ask Tharon</h3><small class="muted">Keyword-based lead helper. Changes require review and confirmation.</small></div><button type="button" class="btn tiny ghost" data-act="clearChat">Clear</button></div>
  <div id="thread" class="thread" aria-live="polite">${chat.length?chat.map(m=>`<div class="msg ${m.who}">${m.who==='me'?esc(m.text):m.html}</div>`).join(''):`<div class="msg bot">Hi ${esc(TL.me().name.split(' ')[0])}. Ask me about leads, paperwork and today's follow-ups. Census and bed availability are not connected.</div>`}</div>
  <div class="sugs">${AS.suggestions().map(s=>`<button type="button" class="chip btnchip" data-act="sug" data-q="${esc(s)}">${esc(s)}</button>`).join('')}</div>
  <form data-form="ask" class="askform"><button type="button" class="btn ghost mic-sm" data-act="mic" data-t="ask" aria-label="Speak your question or a new lead">${svg('mic')}</button><label class="sr-only" for="askq">Your question</label><input id="askq" class="input" name="q" placeholder="e.g. what's due today for Morgan?" autocomplete="off" required><button class="btn primary">Send</button></form>
  <p class="muted small">Tap the mic to ask out loud. Start with “new lead” and it fills in a lead for you to review.</p></section>
  <p class="small muted">Ask uses matching rules, not a general AI model. It supports only the suggestions above. Email and text delivery, census and financial synchronization are not connected.</p>`;
};
function ask(q){
  const chat=S().chat; chat.push({who:'me',text:q});
  if(NEW_LEAD_RE.test(q)){const r=CAP.parseLead(q,{kind:'voice',buildings:S().buildings,today:TL.T});
    chat.push({who:'bot',html:`I filled in a new lead${r.fields.first?' for <b>'+esc((r.fields.first+' '+(r.fields.last||'')).trim())+'</b>':''} from that: ${r.found} field${r.found===1?'':'s'}${r.low.length?', '+r.low.length+' to check':''}. Review it and tap Save. Nothing is saved until you do.`});
    S().chat=chat.slice(-40); TL.save(); render(); openReview(q,{kind:'voice'}); return;}
  let a; try{a=AS.askLocal(q);}catch(e){a={html:'Sorry, I couldn\u2019t work that one out.'};}
  if(a.proposal){const id=crypto.randomUUID();UI.pendingAsk={...a.proposal,id};a.html+='<div class="btnrow"><button class="btn primary" data-act="confirmAsk" data-id="'+id+'">Apply proposed change</button><button class="btn ghost" data-act="cancelAsk">Cancel</button></div>';}
  chat.push({who:'bot',html:a.html}); S().chat=chat.slice(-40); TL.save(); render();
  const t=$('#thread'); t&&(t.scrollTop=t.scrollHeight); const i=$('#askq'); i&&i.focus({preventScroll:true});
}

/* ---------- Rules ---------- */
V.rules=function(){
  return `<section class="hello"><h2>Reminder rules</h2><p>These rules build everyone's Today list from the leads. Change a number and the lists update right away.</p></section>
  ${S().rules.filter(r=>r.id!=='tour_confirm').map(r=>`<section class="card rule${r.enabled?'':' off'}"><div class="card-h"><label class="check"><input type="checkbox" data-change="ruleOn" data-id="${r.id}" ${r.enabled?'checked':''}> <b>${esc(r.name)}</b></label>
    <span class="muted small">${TL.allReminders('all').filter(x=>x.rule===r.id).length} due today</span></div>
    <p class="muted small">${esc(r.desc)}</p>
    <div class="rule-f"><label>Days<input class="input slim" type="number" min="0" max="60" value="${r.days}" data-change="ruleDays" data-id="${r.id}"></label>
    <label>Also send<select class="input slim" data-change="ruleCh" data-id="${r.id}">${opt(REMOTE?[['none','In-app follow-up list']]:[['none','Nothing, just remind the rep'],['sms','Text to family (simulated)'],['email','Email (simulated)']],r.channel)}</select></label>
    <label class="span2">Reminder wording<input class="input" value="${esc(r.text)}" data-change="ruleText" data-id="${r.id}"></label></div></section>`).join('')}
  <section class="card"><div class="card-h"><h3>Outbox <span class="muted small">simulated</span></h3></div>
  ${S().outbox.length?`<ul class="plain outbox">${S().outbox.slice(0,15).map(m=>`<li><span class="chip">${m.channel==='sms'?'Text':'Email'}</span> to ${esc(m.to)} \u00b7 <span class="muted small">${esc(m.at.replace('T',' '))}</span><br><small>\u201c${esc(m.body)}\u201d \u00b7 <b>${esc(m.status)}</b></small></li>`).join('')}</ul>`:`<p class="muted">Automatic email and text delivery is not connected. Follow-up email templates open your own email app; review and send them manually.</p>`}</section>`;
};

/* ---------- Connect & API ---------- */
const ENDPOINTS=[
  ['GET','/api/v1/leads?building_id=b1'],['GET','/api/v1/leads/L118'],['GET','/api/v1/leads/L118/documents'],['GET','/api/v1/buildings'],['GET','/api/v1/users'],['GET','/api/v1/tasks?rep_id=u1'],['POST','/api/v1/leads/L105/assign'],['POST','/api/v1/leads/L101/stage'],['POST','/api/v1/leads'],['GET','/api/v1/webhooks']
];
const BODIES={'POST /api/v1/leads/L105/assign':{building_id:'b4'},'POST /api/v1/leads/L101/stage':{stage:'contacted'},'POST /api/v1/leads':{first_name:'Sample',last_name:'Person',contact:{name:'Sample Family',relationship:'Daughter',phone:'(555) 010-9999'},referral_source:'Web',building_id:'b2'}};
V.api=function(){return `<section class="card"><h3>Integrations</h3><p>QuickBooks, Command Center synchronization, outgoing webhooks and live census are not connected. No data is sent to those systems from this screen.</p><p>Use CSV / Excel for reviewed imports, or Export JSON for a manual export. JSON import is unavailable.</p><button class="btn ghost" data-act="exportJson">Export JSON</button></section>`;};

V.more=function(){
const items=[['add','Add a lead','Voice note, PDF, photo or Word file'],['import','Upload leads','CSV and Excel with column review']];if(TL.isAdmin())items.push(['rules','Reminder rules','Set team follow-up windows'],['team','Team & passwords','Set or reset staff passwords']);
return `<section class="card menu">${items.map(([k,t,d])=>`<a href="#/${k}">${svg(k==='team'?'lock':k)}<span><b>${t}</b><small class="muted">${d}</small></span></a>`).join('')}</section><section class="card"><h3>Tharon Leads</h3><p class="small">${REMOTE?'Signed in as '+esc(TL.me().name)+'. Your access is enforced by the server.':'Sample preview: every lead is fictional. User switching is for testing only.'}</p><p class="small muted">Install on iPhone: open in Safari, tap Share, then Add to Home Screen.</p>${REMOTE?'<div class="btnrow"><button class="btn primary" data-act="pushOn">Enable phone reminders</button><button class="btn ghost" data-act="pushOff">Turn off phone reminders</button><button class="btn ghost" data-act="signout">Sign out</button></div><p class="small muted">Morning notifications contain no resident names. On iPhone, install to your Home Screen first.</p>':''}</section>`;};

/* ---------- forms in modals ---------- */
function payerOptions(building,payer){const options=window.TLRoadmap.paymentOptions(building);const selected=building==='crenshaw'?options[0][2]:payer;return `${options.some(x=>x[2]===selected)?'':'<option value="" selected disabled>Choose payment / program</option>'}${options.map(([,label,value])=>`<option value="${value}" ${value===selected?'selected':''}>${label}</option>`).join('')}`;}
function progressFields(x){
 const p=TL.referralSummary(x);if(!x.id&&x.moveIn)p.moveStatus='none';const priv=x.payer==='Private pay';
 return `<section class="span2 simple-progress" data-progress><h3>Progress</h3><div class="simple-step"><label>Assessment passed / building accepted?<select class="input" name="progressAssessment" data-change="progressAnswer">${opt([['pending','Not yet'],['accepted','Yes']],p.assessment)}</select></label></div><div class="simple-step"><label data-approval-label>${priv?'Payment arrangements':TL.programLabel(TL.program(x))+' approval'}<select class="input" name="progressApproval" data-change="progressAnswer">${opt(priv?[['waiting','Not confirmed'],['missing','Confirmed — paperwork needed'],['received','Confirmed — paperwork received']]:[['waiting','Waiting for approval'],['missing','Approved — paperwork needed'],['received','Approved — paperwork received']],p.approval)}</select></label><label class="block mt" data-wait-reason ${p.approval==='waiting'?'':'hidden'}>What are we waiting for?<select class="input" name="progressReason" data-change="progressAnswer"><option value="">Choose reason / needs review</option>${opt(window.TLReferral.waitingOptions(x,TL.B(x.building),TL.T),p.reason)}</select></label>${x.id?`<div data-approval-upload ${p.approval==='missing'?'':'hidden'}><label class="btn small ghost mt" for="approval-file-${esc(x.id)}">Upload ${esc(p.document)}</label><input id="approval-file-${esc(x.id)}" type="file" class="sr-only" accept=".pdf,.docx,image/*" data-change="approvalFile" data-id="${esc(x.id)}"><small class="block muted">Attach the document, review it, then confirm paperwork received.</small></div>`:'<p class="small muted" data-approval-upload '+(p.approval==='missing'?'':'hidden')+'>Save the referral, then attach the approval document in its profile.</p>'}</div><div class="simple-step"><label>Move-in<select class="input" name="progressMove" data-change="progressAnswer">${opt([['none','Not scheduled'],['scheduled','Scheduled'],['moved','Moved in']],p.moveStatus)}</select></label><label class="block mt" data-move-date ${p.moveStatus==='none'?'hidden':''}>Move-in date<input class="input" name="progressMoveDate" type="date" value="${esc(x.moveIn||'')}"></label></div><section class="simple-next"><small>NEXT STEP</small><h3 data-progress-next>${esc(p.next)}</h3><p class="small" data-wait-age>${!x.id&&p.waiting?'Waiting time starts automatically when this profile is saved.':waitingText(p)}</p><label>Remind me<input type="date" name="progressDue" class="input" value="${esc(p.due||TL.addDays(3))}" required></label></section><label class="block mt">Update note <small>Optional · automatically dated when saved</small><textarea class="input" name="progressNote" data-original-note="${esc(p.note||'')}" rows="2" placeholder="e.g. Spoke with Libertana; approval letter expected Tuesday"></textarea></label>${p.note?`<p class="small"><b>Latest update${p.noteAt?' · '+fmtRecorded(p.noteAt):''}:</b> ${esc(p.note)}</p>`:''}</section>`;
}
function waitingText(p){return p.waiting?(p.waitingSince?`${esc(p.provider||'Program provider')} · Waiting for approval since ${fmtDate(p.waitingSince)} · ${p.waitingDays} ${p.waitingDays===1?'day':'days'}${p.waitingDays>=14?' · Update needed':''}`:`Waiting on ${esc(p.provider||'program provider')} · Start date not recorded`):'';}
function progressInput(f){return {assessment:f.elements.progressAssessment.value,approval:f.elements.progressApproval.value,reason:f.elements.progressReason.value,moveStatus:f.elements.progressMove.value,moveDate:f.elements.progressMoveDate.value,due:f.elements.progressDue.value,note:f.elements.progressNote.value.trim()||(f.elements.progressNote.dataset.originalNote||'')};}
function updateProgressPreview(f,reset=false){
 const existing=TL.Lead(f.dataset.id),x={...(existing||{}),...readLeadForm(f)};
 if(reset){f.elements.progressNote.dataset.originalNote='';f.elements.tier.value='';f.elements.progressAssessment.value='pending';f.elements.progressApproval.value='waiting';f.elements.progressReason.innerHTML='<option value="">Choose reason / needs review</option>'+opt(window.TLReferral.waitingOptions(x,TL.B(x.building),TL.T),'');}
 const priv=x.payer==='Private pay';f.querySelector('[data-tier-field]').hidden=priv;const libCard=document.querySelector('.libertana-card'),libEligible=window.TLLibertana.applicable(x,TL.B(x.building)),libNeedsSave=!existing||existing.payer!==x.payer||existing.building!==x.building;if(libCard)libCard.hidden=!libEligible||libNeedsSave;f.querySelector('[data-lib-save-hint]').hidden=!libEligible||(!libNeedsSave&&!!libCard);f.querySelector('[data-provider-field]').hidden=priv;f.querySelector('[data-budget-field]').hidden=!priv;
 f.elements.progressApproval.innerHTML=opt(priv?[['waiting','Not confirmed'],['missing','Confirmed — paperwork needed'],['received','Confirmed — paperwork received']]:[['waiting','Waiting for approval'],['missing','Approved — paperwork needed'],['received','Approved — paperwork received']],f.elements.progressApproval.value);
 const previewProvider=TL.referralSummary(x).provider,input=progressInput(f);x.referralProgress={programKey:[x.payer,x.building].join('|'),assessment:input.assessment,approval:input.approval,reason:input.reason,moveStatus:input.moveStatus,due:input.due,waitingSince:reset?null:TL.referralSummary(existing||x).waitingSince,waitingOn:previewProvider,waitingBasis:'tracking'};
 const p=TL.referralSummary(x);f.querySelector('[data-progress-next]').textContent=p.next;f.querySelector('[data-wait-age]').innerHTML=!x.id&&p.waiting?'Waiting time starts automatically when this profile is saved.':waitingText(p);f.querySelector('[data-wait-reason]').hidden=input.approval!=='waiting';f.querySelector('[data-move-date]').hidden=input.moveStatus==='none';f.querySelector('[data-approval-upload]').hidden=input.approval!=='missing';
 const title=f.querySelector('[data-approval-label]');title.firstChild.textContent=priv?'Payment arrangements':TL.programLabel(TL.program(x))+' approval';
}
function referrerOptions(source){const names=new Map();for(const row of [...(S().referrers||[]),...S().leads.filter(l=>l.source===source&&l.sourceDetail).map(l=>({source:l.source,name:l.sourceDetail}))])if(row.source===source&&row.name?.trim())names.set(row.name.trim().toLowerCase(),row.name.trim());return [...names.values()].sort((a,b)=>a.localeCompare(b,'en',{sensitivity:'base'})).map(name=>`<option value="${esc(name)}"></option>`).join('');}
function leadForm(l,o){
 o=o||{};const x=o.x||l||{caller:{rel:'Self'},source:'Other',payer:'',building:UI.captureBuilding||null};
 const priv=x.payer==='Private pay';
 return `<h3 id="modalTitle">${esc(o.title||(l?'Resident details':'New resident referral'))}</h3>${o.pre||''}<form data-form="${o.form||'lead'}" data-inline="${!!o.inline}" data-id="${l?l.id:''}" class="form-grid simple-referral-form"><input type="hidden" name="originalNotes" value="${esc(x.notes||'')}"><div class="span2"><button type="button" class="btn small ghost" data-act="${o.inline?'backToResults':'closeModal'}">‹ Back</button></div><label class="span2 primary-building-field">Building<select class="input" name="building" required data-change="formBuilding"><option value="" disabled ${x.building?'':'selected'}>Choose a building</option>${sortedBuildings().map(b=>`<option value="${b.id}"${b.id===x.building?' selected':''}>${esc(b.name)}</option>`).join('')}</select></label><label>First name<input class="input" name="first" required value="${esc(x.first||'')}"></label><label>Last name<input class="input" name="last" required value="${esc(x.last||'')}"></label><label>Age<input class="input" name="age" type="number" min="0" max="125" value="${esc(x.age||'')}"></label><label>Lead owner<select class="input" name="rep" ${TL.isAdmin()?'':'disabled'}>${S().users.filter(u=>u.id===S().me||u.role==='rep').map(u=>`<option value="${u.id}"${u.id===(x.rep||S().me)?' selected':''}>${esc(u.name)}</option>`).join('')}</select></label>
 <label>Referral source<select class="input" name="source" data-change="referralSource">${opt(SOURCE,x.source)}</select></label><label>Referred by<div class="referrer-entry"><input class="input" name="sourceDetail" list="referrers-${esc(x.id||o.form||'new')}" value="${esc(x.sourceDetail||'')}" placeholder="Choose a saved name or type a new one" autocomplete="off"><button type="button" class="btn small ghost" data-act="addReferrerName">+ Add name</button></div><datalist id="referrers-${esc(x.id||o.form||'new')}">${referrerOptions(x.source)}</datalist><small class="muted" data-referrer-status>Saved names are reusable for this referral source.</small></label>
 <label>Program<select class="input" name="payer" required data-change="formProgram">${payerOptions(x.building,x.payer)}</select></label><label data-tier-field ${priv?'hidden':''}>Tier<select class="input" name="tier"><option value="">Unknown / pending</option>${[1,2,3,4,5].map(n=>`<option value="${n}"${String(x.tier||'')===String(n)?' selected':''}>Tier ${n}</option>`).join('')}</select></label><label class="span2" data-budget-field ${priv?'':'hidden'}>Resident budget · per month ($)<input class="input" name="budget" type="number" min="0" step="0.01" value="${esc(x.budget??'')}"></label><p class="span2 small muted" data-lib-save-hint hidden>Save changes to open the Los Angeles County CalAIM fillable paperwork and email template in this referral.</p><label class="span2" data-provider-field ${priv?'hidden':''}>CCA / program provider<input class="input" name="cca" data-change="progressProvider" value="${esc(x.cca||'')}" placeholder="e.g. Libertana, MasterCare"></label>
 <div class="span2 card-h"><h3>Contact</h3><button type="button" class="btn small ghost" data-act="residentContact">Same as resident</button></div><p class="span2 small muted" data-contact-status hidden></p><label>Who is calling<select class="input" name="rel">${opt(REL,x.caller?.rel||'Self')}</select></label><label>Contact name<input class="input" name="callerName" value="${esc(x.caller?.name||'')}" placeholder="Leave blank if resident"></label><label>Phone<input class="input" name="phone" type="tel" value="${esc(x.caller?.phone||'')}"></label><label>Email<input class="input" name="email" type="email" value="${esc(x.caller?.email||'')}"></label>${window.TLFollowupContacts.field(x)}${progressFields(x)}${x.notes?`<details class="span2"><summary>Existing referral notes</summary><p class="note">${esc(x.notes)}</p></details>`:''}<div class="span2 btnrow"><button type="submit" class="btn primary">${esc(o.submit||'Save changes')}</button>${o.extraBtn||''}</div><p class="span2 tbad" data-referral-error role="alert"></p></form>${o.post||''}`;
}

function readLeadForm(f){const v=n=>(f.elements[n]?.value||'').trim(),l=TL.Lead(f.dataset.id),rel=v('rel');const d={followupContactId:v('followupContactId')||null,notes:v('originalNotes'),first:v('first'),last:v('last'),age:parseInt(v('age'))||null,caller:{name:v('callerName')||(rel==='Self'?v('first')+' '+v('last'):''),rel,phone:v('phone'),email:v('email')},source:v('source'),sourceDetail:v('sourceDetail'),cca:v('cca'),payer:v('payer'),building:v('building')||null,rep:TL.isAdmin()?(v('rep')||null):S().me};if(d.payer==='Private pay')d.budget=v('budget')===''?null:Number(v('budget'));else d.tier=parseInt(v('tier'))||null;return d;}



/* ---------- Add a lead without typing: speak it, or drop a file ----------
   Everything below runs in this browser. PDFs are read with pdf.js, photos with Tesseract OCR,
   Word files with mammoth, all loaded from this site's own /vendor folder. Nothing is uploaded.
   Voice uses the browser's built-in speech recognition (Safari / Chrome); the browser maker's speech
   service may process the audio, which is why production moves voice to a BAA-covered vendor. */
const SRClass=REMOTE?null:(window.SpeechRecognition||window.webkitSpeechRecognition);
const isStandalone=()=>(window.matchMedia&&matchMedia('(display-mode: standalone)').matches)||navigator.standalone===true;
const SAMPLES=[
  {f:'samples/sample-hospital-referral.pdf',t:'Hospital referral',k:'PDF',d:'Face sheet from a fictional hospital. New lead.'},
  {f:'samples/sample-intake-sheet-photo.jpg',t:'Photo of an intake sheet',k:'Photo',d:'A phone photo, read with OCR. ALW lead.'},
  {f:'samples/sample-placement-referral.docx',t:'Placement agency referral',k:'Word',d:'A .docx from an agency. CalAIM lead.'},
  {f:'samples/sample-lic602a-margaret-silva.pdf',t:'LIC 602A for Margaret Silva',k:'PDF',d:'Admission form. Ticks her checklist.'},
  {f:'samples/sample-alw-assessment-isp.docx',t:'ALW assessment + ISP',k:'Word',d:'Ticks Albert Nguyen\u2019s waiver items.'}
];
const PRIVACY=REMOTE?'Review the extracted details before saving. The original file is encrypted and saved with the lead.':'Sample files are read in this browser. This preview does not upload files.';
let VOICE={on:false,rec:null,final:'',interim:'',err:'',target:'add',timer:null};

V.add=function(buildingId){
  if(TL.B(buildingId)&&UI.captureRoute!==location.hash){UI.captureBuilding=buildingId;UI.captureRoute=location.hash;}
  const vt=UI.voiceText||'';
  return `<section class="hello"><h2>Add a lead without typing</h2><p>Speak or drop a file. Review the extracted details, then tap Create profile. Nothing is saved before your confirmation.</p></section>
  <section class="card capture-building"><label for="captureBuilding"><b>Which building is this lead for?</b></label><select id="captureBuilding" class="input" data-change="captureBuilding"><option value="">Choose a building</option>${sortedBuildings().map(b=>`<option value="${b.id}" ${UI.captureBuilding===b.id?'selected':''}>${esc(b.name)}</option>`).join('')}</select><p class="muted small">Choose here, or mention it in your voice note. You must confirm one building before saving.</p></section>
  <div class="grid2 cap-grid">
  <section class="card capture" aria-labelledby="capSpeak"><h3 id="capSpeak">Speak it</h3>
    <button type="button" id="micBtn" class="mic${VOICE.on&&VOICE.target==='add'?' live':''}" data-act="mic" data-t="add" aria-label="Speak the lead">${svg('mic')}</button>
    <button type="button" class="btn ghost" data-act="stopVoice" ${VOICE.on||recordPhase==='recording'?'':'disabled'}>Stop recording</button>
    <p id="micState" class="mic-state" aria-live="polite">${VOICE.on&&VOICE.target==='add'?'Listening\u2026 tap to stop':'Tap the mic and say the lead'}</p>
    <p class="muted small mic-eg">Like: \u201cNew lead, Margaret Silva, her daughter Ann called, 555-123-4567, coming from Cedars hospital, ALW, tier 4, referred by the nursing home, Hallmark of Bakersfield.\u201d</p>
    <label for="voiceText"><b>Your transcript</b></label>
    <textarea id="voiceText" class="input" rows="3" data-input="voiceText" placeholder="Your words show up here. You can also type, or use your keyboard\u2019s mic.">${esc(vt)}</textarea>
    <div class="btnrow"><button type="button" class="btn primary" data-act="parseText">Review lead</button><button type="button" class="btn ghost" data-act="quickAdd">Type it by hand</button></div>
    <p class="muted small" id="voiceNote">${REMOTE?'Tap Record, speak, then tap Stop. Your words appear after the recording is processed.':SRClass?'Voice uses your phone\u2019s built-in speech recognition.':'This browser has no speech recognition. Tap the box above and use your keyboard\u2019s mic instead, it fills the same form.'}</p>
  </section>
  <section class="card capture" aria-labelledby="capDrop"><h3 id="capDrop">Drop a file</h3>
    <label class="drop any" for="capFile">${svg('file')}<b>Drop a file or tap to choose</b><small class="muted">Read the file, review the extracted details, then choose whether to create a profile.</small></label>
    <input id="capFile" class="sr-only" type="file" accept=".pdf,.docx,.csv,.xlsx,.xls,.txt,.heic,.heif,image/*,application/pdf" data-change="capFile">
    <label class="block mt" for="capturePaste">Or paste a file, image or referral text</label><textarea id="capturePaste" class="input" rows="2" placeholder="Tap here, then Paste"></textarea><p class="small muted">If Safari pastes only a file name or link, use Choose file to provide the actual document.</p>
    <p class="privacy">${svg('lock')}<span>${PRIVACY}</span></p>
  </section>
  </div>
  `;
};

/* --- small helpers --- */
const loaded={};
function loadScript(src){return loaded[src]||(loaded[src]=new Promise((res,rej)=>{const s=document.createElement('script'); s.src=src; s.onload=()=>res(); s.onerror=()=>{delete loaded[src]; rej(new Error('Could not load the reader ('+src.split('/').pop()+'). Check your connection and try again.'));}; document.head.appendChild(s);}));}
const absUrl=p=>new URL(p,location.href).href;
function progressModal(name,msg){modal(`<h3 id="modalTitle">Reading ${esc(name)}</h3><p id="capStage" class="small">${esc(msg)}</p><div class="bar prog"><i id="capBar" style="width:6%"></i></div><p class="privacy small">${svg('lock')}<span>${PRIVACY}</span></p><div class="btnrow"><button type="button" class="btn ghost small" data-act="closeModal">Cancel</button></div>`);}
function setProg(msg,frac){const s=$('#capStage'), b=$('#capBar'); if(s&&msg) s.textContent=msg; if(b&&frac!=null) b.style.width=Math.max(6,Math.min(100,Math.round(frac*100)))+'%';}

/* --- readers --- */
async function pdfText(buf){setProg('Opening the PDF…',.1);await loadScript('vendor/pdfjs/pdf.min.js');const pdfjs=window.pdfjsLib;pdfjs.GlobalWorkerOptions.workerSrc=absUrl('vendor/pdfjs/pdf.worker.min.js');const doc=await pdfjs.getDocument({data:buf,isEvalSupported:false}).promise;try{return await window.TLPDFIntake.read(doc,{ocr,abortOCR:async()=>{if(ocrWorker){await ocrWorker.terminate();ocrWorker=null;}},imageOps:[pdfjs.OPS.paintImageXObject,pdfjs.OPS.paintInlineImageXObject,pdfjs.OPS.paintImageMaskXObject],canvas:()=>document.createElement('canvas'),progress:(p,total)=>setProg('Reading page '+p+' of '+total,.15+.7*p/total)});}finally{await doc.destroy();}}
let ocrWorker=null, ocrLabel='Reading the text';
async function ocr(source,label){
  ocrLabel=label||'Reading the text';
  setProg('Loading the text reader (first time only)\u2026',.1);
  await loadScript('vendor/tesseract/tesseract.min.js');
  if(!ocrWorker){
    ocrWorker=await Tesseract.createWorker('eng',1,{workerPath:absUrl('vendor/tesseract/worker.min.js'),corePath:absUrl('vendor/tesseract/core'),langPath:absUrl('vendor/tesseract/lang'),workerBlobURL:false,gzip:true,
      logger:m=>{if(m.status==='recognizing text') setProg(ocrLabel+'\u2026 '+Math.round(m.progress*100)+'%',.35+.6*m.progress); else if(m.status) setProg(cap1(m.status)+'\u2026',.2);}});
  }
  const r=await ocrWorker.recognize(source); return r.data.text||'';
}
const cap1=s=>s.charAt(0).toUpperCase()+s.slice(1);
async function imageCanvas(file){
  let img;
  try{img=await createImageBitmap(file);}catch(e){
    img=await new Promise((res,rej)=>{const im=new Image(); const u=URL.createObjectURL(file); im.onload=()=>res(im); im.onerror=()=>rej(new Error(/hei[cf]/i.test(file.name+file.type)?'This browser can\u2019t open HEIC photos. On iPhone, Safari can; elsewhere, share the photo as JPG.':'Couldn\u2019t open that image.')); im.src=u;});
  }
  const max=2200, sc=Math.min(1,max/Math.max(img.width,img.height)); const c=document.createElement('canvas'); c.width=Math.round(img.width*sc); c.height=Math.round(img.height*sc);
  const g=c.getContext('2d'); g.drawImage(img,0,0,c.width,c.height); return c;
}
function fileKind(name,type){
  const ext=(String(name).split('.').pop()||'').toLowerCase(); type=type||'';
  if(['csv','xlsx','xls'].includes(ext)||/spreadsheetml|ms-excel|text\/csv/.test(type)) return 'sheet';
  if(ext==='pdf'||type==='application/pdf') return 'pdf';
  if(ext==='docx'||/wordprocessingml/.test(type)) return 'docx';
  if(ext==='doc'||type==='application/msword') return 'doc';
  if(/^image\//.test(type)||['jpg','jpeg','png','heic','heif','webp','gif','bmp','tif','tiff'].includes(ext)) return 'image';
  if(ext==='txt'||type==='text/plain') return 'txt';
  return null;
}
async function handleFile(file,opts){
  opts=opts||{};if(file.size>20*1024*1024){toast('Choose a file smaller than 20 MB.');return;} const name=file.name||'file'; const kind=fileKind(name,file.type);
  if(kind==='sheet'){const b=new Uint8Array(await file.arrayBuffer()); closeModal(); location.hash='#/import'; setTimeout(()=>parseFile(name,b),80); toast('Spreadsheet: sent to the lead importer.'); return;}
  if(!kind) return modal(`<h3 id="modalTitle">Can\u2019t read that file type</h3><p>${esc(name)} isn\u2019t a PDF, photo, Word (.docx), Excel or CSV file.</p><div class="btnrow"><button type="button" class="btn primary" data-act="closeModal">OK</button></div>`);
  if(kind==='doc') return modal(`<h3 id="modalTitle">Old Word format</h3><p>${esc(name)} is an older .doc file. Save it as .docx or PDF and drop it in again.</p><div class="btnrow"><button type="button" class="btn primary" data-act="closeModal">OK</button></div>`);
  progressModal(name,'Starting\u2026'); const t0=Date.now();
  try{
    let text='', how=kind,coverage=null;
    if(kind==='pdf'){const r=await pdfText(await file.arrayBuffer()); text=r.text; how=r.how;coverage=r.coverage;}
    else if(kind==='docx'){setProg('Opening the Word file\u2026',.3); await loadScript('vendor/mammoth.browser.min.js'); const r=await mammoth.extractRawText({arrayBuffer:await file.arrayBuffer()}); text=r.value||'';}
    else if(kind==='image'){setProg('Preparing the photo\u2026',.08); const c=await imageCanvas(file); text=await ocr(c,'Reading the photo'); how='ocr';}
    else text=await file.text();
    if($('#modal').hidden) return; // cancelled
    setProg('Done',1);
    if(!text.replace(/\s/g,'')&&!coverage?.partial) throw new Error('No text found in '+name+'. If it\u2019s a photo, try a sharper, well-lit shot.');
    openReview(text,{rawFile:file,kind:'doc',how,coverage,secs:Math.round((Date.now()-t0)/100)/10,file:{name,type:file.type||kind,size:file.size},leadId:opts.leadId,storedFile:opts.storedFile});
  }catch(e){
    modal(`<h3 id="modalTitle">Couldn\u2019t read ${esc(name)}</h3><p>${esc(e.message||String(e))}</p><div class="btnrow"><button type="button" class="btn primary" data-act="closeModal">OK</button></div>`);
  }
}

/* --- review before saving --- */
function findMatch(fd){
  const ph=(fd.phone||'').replace(/\D/g,'');
  return S().leads.find(l=>fd.first&&fd.last&&l.first.toLowerCase()===String(fd.first).toLowerCase()&&l.last.toLowerCase()===String(fd.last).toLowerCase())
    ||(ph.length>=10?S().leads.find(l=>(l.caller.phone||'').replace(/\D/g,'')===ph):null);
}
const FIELD_LABEL={first:'first name',last:'last name',age:'age',callerName:'contact',rel:'who\u2019s calling',phone:'phone',email:'email',source:'referral source',sourceDetail:'referred by',cca:'CCA / program provider',care:'care needed',payer:'payer',budget:'budget',moveIn:'move-in',building:'building',tier:'tier',notes:'notes'};
/* automatic capture */
function markCapturedDocuments(lead,r){const forms=[];if(UI.cap?.meta.coverage?.partial)return forms;for(const d of r.docs||[]){const def=TL.docDef(d.key);if(!def||(/^w_/.test(d.key)&&!TL.wdocsFor(lead).some(w=>w.key===d.key)))continue;const current=(/^w_/.test(d.key)?lead.wdocs:lead.docs)?.[d.key];if(current?.status!=='approved')TL.setDoc(lead.id,d.key,{status:'received'});forms.push(def.form);}return forms;}
async function openReview(text,meta){
 if(UI.captureSaving)return;
 let r=CAP.parseLead(text,{kind:meta.kind==='voice'?'voice':'doc',buildings:S().buildings,today:TL.T});
 if(REMOTE&&typeof window!=='undefined'&&window.TL_BOOT?.extractionEnabled){
  toast('Reading the lead details…');
  try{r=await TLRemote.request('/api/extract-lead',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({text,kind:meta.kind==='voice'?'voice':'doc'}),signal:AbortSignal.timeout(70000)});}
  catch(e){toast(e.message);UI.cap={r,meta,text};if(meta.leadId){r.docs=[];return modal(attachView(r,meta,[]));}return showReviewForm();}
 }
 if(meta.coverage?.partial)r.docs=[];
 UI.cap={r,meta,text,plan:CAP.captureProfile(r.fields,{buildings:S().buildings,selectedBuilding:UI.captureBuilding,rep:S().me})};
 if(meta.leadId)return modal(attachView(r,meta,r.docs.filter(x=>TL.docDef(x.key))));
 return showReviewForm();
}
function coverageWarning(meta){const c=meta.coverage;if(!c)return '';return `<p class="${c.partial?'dupwarn':'small muted'}">Read ${c.read.length} of ${c.total} PDF pages. ${c.partial?'NOT READ: '+c.unread.map(p=>p.page+(p.through?'–'+p.through:'')+' ('+esc(p.reason)+')').join(', ')+'. No paperwork is checked off from this partial read. Review the complete original.':'All pages processed; verify extracted details. OCR can make mistakes.'} The complete original file is retained when you save.</p>${c.partial?'<label class="check"><input type="checkbox" name="extractionReviewed" required> I reviewed the unread pages in the original document; these details need manual verification.</label>':''}`;}
/* manual capture review */
function showReviewForm(){
  const {r,meta}=UI.cap; const f=r.fields;
  const x=UI.cap.plan?.lead||{first:f.first||'',last:f.last||'',age:f.age||'',caller:{name:f.callerName||'',rel:f.rel||'Self',phone:f.phone||'',email:f.email||''},source:f.source||'Other',sourceDetail:f.sourceDetail||'',cca:f.cca||'',
    care:f.care||'',payer:f.payer||'Other',budget:f.budget||'',moveIn:f.moveIn||'',building:UI.captureBuilding||f.building||null,rep:null,tier:f.tier||'',notes:f.notes||(meta.file?'From '+meta.file.name+'.':'')};
  const dup=findMatch(f);
  const from=meta.kind==='voice'?'what you said':esc(meta.file.name)+(meta.how==='ocr'?' (read from the image: check the spelling)':'');
  const pre=`${coverageWarning(meta)}${meta.kind==='voice'?`<section class="captext" aria-label="Your transcript"><h4>Words from your recording</h4><pre>${esc(UI.cap.text.trim().slice(0,4000))}</pre><p class="small muted">Check whether the name and building appear here.</p></section>`:''}${UI.captureBuilding&&f.building&&UI.captureBuilding!==f.building?`<p class="dupwarn">You selected <b>${esc(TL.B(UI.captureBuilding).name)}</b>; the capture suggests <b>${esc(TL.B(f.building)?.name)}</b>. Check the building before saving.</p>`:''}<p class="small">${UI.cap.plan?.missing.length?'To create this profile, complete: '+esc(UI.cap.plan.missing.join(', '))+'.':dup?'Check the possible duplicate below before creating another profile.':'Check the building assignment before creating this profile.'} Filled in from ${from}.</p>
    <p class="cap-legend small"><span class="lg hit">found</span> <span class="lg low">check this</span> <span class="lg miss">not found</span> \u00b7 ${r.found} field${r.found===1?'':'s'} filled${r.low.length?', '+r.low.length+' to check':''}</p>
    ${dup?`<p class="dupwarn small">Possible duplicate: <a href="#/lead/${dup.id}" data-act="closeModal">${esc(TL.leadName(dup))}</a> is already a lead (${esc(TL.stageLabel(dup.stage))}). Save only if this is someone new.</p>`:''}`;
  const post=meta.kind==='voice'?'':`<details class="captext"><summary class="small">What I read from the file</summary><pre>${esc(UI.cap.text.trim().slice(0,4000))}</pre></details><p class="privacy small">${svg('lock')}<span>${PRIVACY}</span></p>`;
  modal(leadForm(null,{x,form:'capture',title:'Complete the lead profile',submit:'Create profile',pre,post,extraBtn:meta.kind==='voice'?'<button type="button" class="btn ghost" data-act="voiceAgain">Say it again</button>':''}));
  const form=$('#modalBody form');const check=$('#modalBody input[name=extractionReviewed]');if(check&&!form.contains(check))form.prepend(check.closest('label'));
  Object.keys(FIELD_LABEL).forEach(k=>{
    const el=form.elements[k]; if(!el) return; const lab=el.closest('label'); if(!lab) return;
    const c=k==='building'&&UI.captureBuilding?'high':r.conf[k]; const cls=c==='high'?'cap-hit':c==='low'?'cap-low':(['first','last','phone','rel','care','payer','moveIn','source','building'].includes(k)?'cap-miss':'');
    if(!cls) return; lab.classList.add(cls);
    const tag=document.createElement('span'); tag.className='ctag'; tag.textContent=k==='building'&&UI.captureBuilding?'selected by you':cls==='cap-hit'?'found':cls==='cap-low'?'check this':'not found'; lab.insertBefore(tag,el);
  });
  const first=form.querySelector('.cap-low input,.cap-low select')||form.elements.first; first&&first.focus({preventScroll:true});
}
function attachView(r,meta,docs){
  const f=r.fields; const match=meta.leadId?TL.Lead(meta.leadId):findMatch(f);
  const opts=TL.visibleLeads().filter(TL.isOpen).sort((a,b)=>TL.leadName(a).localeCompare(TL.leadName(b)));
  if(match&&!opts.includes(match)) opts.unshift(match);
  const lead=match||null;
  const allowed=lead?TL.paperworkChecklist(lead).map(d=>d.key):[];
  docs=docs.filter(d=>allowed.includes(d.key));
  const det=docs.map(d=>d.key); const wkeys=lead?TL.wdocsFor(lead).map(d=>d.key):[];
  const item=(d,checked)=>{const wv=/^w_/.test(d.key); const off=wv&&lead&&!wkeys.includes(d.key);
    return `<label class="check docpick${checked?' cap-hit':''}"><input type="checkbox" name="doc" value="${d.key}" ${checked&&!off?'checked':''} ${off?'disabled':''}> <span><b>${esc(d.form)}</b> ${esc(d.name)}${off?' <small class="muted">(lead isn\u2019t ALW/CalAIM)</small>':''}</span></label>`;};
  const others=TL.DOCS.concat(TL.WDOCS).filter(d=>allowed.includes(d.key)&&!det.includes(d.key));
  return `${coverageWarning(meta)}<h3 id="modalTitle">${docs.length?(docs.every(d=>/^w_/.test(d.key))?'This looks like a waiver / Medi-Cal document':'This looks like an admission document'):'Attach this document'}</h3>
  <p class="small">${esc(meta.file.name)}${docs.length?': I found '+docs.map(d=>'<b>'+esc(TL.docDef(d.key).form)+'</b>').join(', ')+'.':'. This file will be saved with the lead.'}${f.first?` Resident on the file: <b>${esc(f.first+' '+(f.last||''))}</b>${match&&!meta.leadId?' (matches a lead).':'.'}`:''}</p>
  <form data-form="attach" class="attachform">
    <input type="hidden" name="lead" value="${match?esc(match.id):''}"><p>Save to <b>${match?esc(TL.leadName(match)):'the current lead profile'}</b>${match?' · '+esc(bname(match.building)):''}.</p>
    <p class="small mt"><b>${allowed.length?'Mark received paperwork, if applicable':'Save this document to the profile'}</b></p>
    ${docs.map(d=>item(TL.docDef(d.key),true)).join('')}
    <details class="mt"><summary class="small">Other document types</summary>${others.map(d=>item(d,false)).join('')}</details>
    ${f.tier&&det.includes('w_assess')?`<p class="small mt">Tier on the assessment: <b>Tier ${f.tier}</b>. It\u2019s saved on the lead too.</p>`:''}
    <div class="btnrow mt"><button class="btn primary" ${match?'':'disabled'}>Save document</button><button type="button" class="btn ghost" data-act="closeModal">Cancel</button></div>
  </form>
  <details class="captext"><summary class="small">What I read from the file</summary><pre>${esc(UI.cap.text.trim().slice(0,4000))}</pre></details>
  <p class="privacy small">${svg('lock')}<span>${PRIVACY}</span></p>`;
}

/* --- voice --- */
function paintVoice(){
  const live=REMOTE?recordPhase==='recording':VOICE.on; if(REMOTE&&recordPhase==='transcribing'){const st=$('#micState');if(st)st.textContent='Turning your recording into words…';document.querySelectorAll('[data-act="stopVoice"]').forEach(b=>b.disabled=true);return;} const t=(VOICE.final+' '+VOICE.interim).replace(/\s+/g,' ').trim();
  document.querySelectorAll('[data-act="stopVoice"]').forEach(b=>b.disabled=!live);
  document.querySelectorAll('[data-act="mic"]').forEach(b=>{const on=live&&b.dataset.t===VOICE.target; b.classList.toggle('live',on); b.setAttribute('aria-pressed',on?'true':'false');});
  if(VOICE.target==='add'){const st=$('#micState'); if(st) st.textContent=live?(t?'Listening\u2026 tap to stop':'Listening\u2026 go ahead'):'Tap the mic and say the lead'; const ta=$('#voiceText'); if(ta&&(live||t)){ta.value=t; UI.voiceText=t;}}
  else {const q=$('#askq'); if(q&&live) q.value=t; if(q) q.placeholder=live?'Listening\u2026':'e.g. what\u2019s due today for Maria?';}
}
function voiceMsg(err){
  const sa=isStandalone();
  const ios=/iPhone|iPad|iPod/.test(navigator.userAgent)||(navigator.platform==='MacIntel'&&navigator.maxTouchPoints>1);
  if(err==='not-allowed'||err==='service-not-allowed') return 'The microphone or speech recognition is blocked.'+(sa?' Some iPhones block voice inside home-screen apps: open the link in Safari instead, or':ios?' On iPhone: in Settings, open Safari \u203a Microphone \u203a Allow, and turn on Siri (Talk & Type / Dictation). Or':' Allow the microphone for this site in your browser\u2019s settings, or')+' tap the text box and use your keyboard\u2019s mic.';
  if(err==='no-speech') return 'I didn\u2019t catch anything. Tap the mic and try again.';
  if(err==='audio-capture') return 'No microphone was found.';
  if(err==='network') return 'The speech service couldn\u2019t be reached. Check your connection, or use your keyboard\u2019s mic.';
  if(err==='unsupported') return 'This browser has no speech recognition (it works in iPhone Safari and in Chrome). Tap the text box and use your keyboard\u2019s mic instead.';
  return 'Voice stopped ('+err+'). Try again, or use your keyboard\u2019s mic.';
}
function startVoice(target){
  if(VOICE.on)return stopVoice();if(VOICE.stopping)return;
  if(!SRClass){if(target==='ask'){const q=$('#askq'); q&&q.focus();} return modal(`<h3 id="modalTitle">Voice isn\u2019t available here</h3><p>${esc(voiceMsg('unsupported'))}</p><div class="btnrow"><button type="button" class="btn primary" data-act="closeModal">OK</button></div>`);}
  let rec; try{rec=new SRClass();}catch(e){return toast(voiceMsg('unsupported'));}
  rec.lang='en-US'; rec.interimResults=true; rec.continuous=false; rec.maxAlternatives=1;
  VOICE={on:true,rec,final:'',interim:'',err:'',target,timer:null};
  const session=VOICE;let finished=false;
  const finish=()=>{if(finished||VOICE!==session)return;finished=true;session.stopping=false;clearTimeout(session.timer);clearTimeout(session.stopTimer);clearTimeout(session.maxTimer);session.on=false;const t=(session.final+' '+session.interim).replace(/\s+/g,' ').trim();paintVoice();if(!t){const message=voiceMsg(session.err&&session.err!=='aborted'?session.err:'no-speech');toast(message);const note=$('#voiceNote');if(note)note.textContent=message+' You can also tap the text box and use the keyboard microphone.';return;}if(target==='add'){UI.voiceText=t;openReview(t,{kind:'voice',rawFile:UI.recordedFile,file:UI.recordedFile?{name:UI.recordedFile.name,type:UI.recordedFile.type,size:UI.recordedFile.size}:null});}else ask(t);};
  session.finish=finish;
  const arm=()=>{clearTimeout(VOICE.timer); VOICE.timer=setTimeout(()=>{if(VOICE.on&&VOICE.final.trim()&&!VOICE.interim.trim())stopVoice()},3500);};
  rec.onresult=e=>{
    if(finished||VOICE!==session)return;
    let fin='',int='';
    for(let i=0;i<e.results.length;i++){const res=e.results[i]; const t=res[0].transcript.trim(); if(!t) continue;
      if(res.isFinal){const F=fin.trim().toLowerCase(), L=t.toLowerCase(); if(F&&L.startsWith(F)) fin=t+' '; else if(!(F&&F.endsWith(L))) fin+=t+' ';} else int+=t+' ';}
    VOICE.final=fin; VOICE.interim=int; paintVoice(); arm();
  };
  rec.onerror=e=>{if(VOICE!==session||finished)return;session.err=e.error||'error';stopVoice();};
  rec.onend=finish;
  session.maxTimer=setTimeout(()=>{if(VOICE===session&&!finished)stopVoice();},60000);
  try{rec.start();paintVoice();}catch(e){session.err='start';finish();}
}
function stopVoice(){
 const session=VOICE;if(!session.rec||session.stopping)return;session.stopping=true;session.on=false;paintVoice();
 session.stopTimer=setTimeout(()=>{try{session.rec.abort();}catch{}session.finish?.();},1000);
 try{session.rec.stop();}catch{session.finish?.();}
}
const NEW_LEAD_RE=/^\s*(?:new lead|add (?:a )?(?:new )?lead|create (?:a )?(?:new )?lead|lead for)\b/i;

let recorder=null,recordStream=null,recordTimer=null,recordPhase='idle',recordFinish=null,recordStopTimer=null;
function stopRecording(){
 if(recordPhase!=='recording')return;recordPhase='stopping';paintVoice();clearTimeout(recordTimer);
 const activeRecorder=recorder,stream=recordStream;
 const st=$('#micState');if(st)st.textContent='Finishing your recording…';
 // Safari can deliver its final audio after stop() returns. Only onstop may read it.
 recordStopTimer=setTimeout(()=>{if(recorder!==activeRecorder||recordPhase!=='stopping')return;activeRecorder.onerror?.();},10000);
 try{activeRecorder.stop();}catch{activeRecorder.onerror?.();}
}
async function recordVoice(target){
 if(recordPhase==='recording'){stopRecording();return;}if(recordPhase!=='idle')return;
 if(!navigator.mediaDevices?.getUserMedia||!window.MediaRecorder){toast('Recording is unavailable in this browser. Type the note or attach an audio file.');return;}
 recordPhase='requesting';VOICE.target=target;
 try{
  recordStream=await navigator.mediaDevices.getUserMedia({audio:true});const stream=recordStream,chunks=[];
  const mime=['audio/mp4','audio/webm;codecs=opus','audio/webm'].find(t=>MediaRecorder.isTypeSupported?.(t));
  const activeRecorder=recorder=new MediaRecorder(stream,mime?{mimeType:mime}:undefined);let finished=false;
  const release=()=>{clearTimeout(recordTimer);clearTimeout(recordStopTimer);stream.getTracks().forEach(t=>t.stop());};
  activeRecorder.ondataavailable=e=>{if(!finished&&e.data.size)chunks.push(e.data);};
  activeRecorder.onerror=()=>{if(finished||recorder!==activeRecorder)return;finished=true;release();recordPhase='idle';paintVoice();toast('The phone could not finish recording. Please try again in Safari.');};
  activeRecorder.onstop=recordFinish=async()=>{
   if(finished||recorder!==activeRecorder)return;finished=true;release();recordPhase='transcribing';paintVoice();
   const type=activeRecorder.mimeType||mime||'audio/mp4';const file=new File(chunks,'lead-note.'+(type.includes('mp4')?'mp4':'webm'),{type});UI.recordedFile=file.size?file:null;
   try{
    if(!file.size)throw new Error('The phone returned an empty recording. Please record for a few seconds and try again in Safari.');
    toast('Transcribing recording…');const r=await TLRemote.request('/api/transcribe',{method:'POST',headers:{'Content-Type':file.type},body:file,signal:AbortSignal.timeout(150000)});
    if(!r.text?.trim())throw new Error('No words were detected. Please try again, speaking clearly near the microphone.');
    UI.voiceText=r.text;
    if(target==='add'){render();openReview(r.text,{kind:'voice',rawFile:file,file:{name:file.name,type:file.type,size:file.size}});}
    else{render();const input=$('#askq');if(input)input.value=r.text;toast('Transcript ready. Review it before sending.');}
   }catch(e){UI.voiceText='';render();toast(e.message);const note=$('#voiceNote');if(note)note.textContent=file.size?'Your recording is retained. Try again or type the lead details.':e.message;}
   finally{recordPhase='idle';paintVoice();}
  };
  activeRecorder.start(1000);recordPhase='recording';paintVoice();const st=$('#micState');if(st)st.textContent='Recording… speak, then tap Stop recording. Words appear afterward.';
  recordTimer=setTimeout(()=>{if(recorder===activeRecorder&&recordPhase==='recording')stopRecording();},120000);
 }catch(e){recordPhase='idle';recordStream?.getTracks().forEach(t=>t.stop());paintVoice();toast(e.name==='NotAllowedError'?'Microphone access is blocked. Allow Microphone in Safari’s Website Settings.':'The microphone could not start. Close other apps using it and try again.');}
}
function dateViewChanged(){if(!document.querySelector('.simple-referral-form[data-dirty="true"]')&&$('#modal').hidden&&!window.TLFollowupContacts?.isOpen()&&!window.TLDocumentViewer?.isOpen())render();else toast('The calendar date changed. Your unsaved work is retained; review the follow-up date before saving.');}
function refreshCalendar(){TL.refreshDate();}
document.addEventListener('tl-date-change',dateViewChanged);window.addEventListener('focus',refreshCalendar);document.addEventListener('visibilitychange',()=>{if(!document.hidden)refreshCalendar();});setInterval(refreshCalendar,30000);
document.addEventListener('tl-remote-state',()=>{if($('#modal').hidden&&!window.TLFollowupContacts?.isOpen()&&!document.querySelector('.simple-referral-form[data-dirty="true"]')&&!window.TLDocumentViewer?.isOpen()&&!['INPUT','TEXTAREA','SELECT'].includes(document.activeElement?.tagName))render();});
window.addEventListener('error',e=>{if(REMOTE&&e.message)toast(e.message);});
window.addEventListener('tl-storage-error',()=>toast('This browser could not save. Export your test leads before closing the page.'));

/* ---------- router ---------- */
const TITLES={today:'Today',add:'Add a lead',leads:'Leads',lead:'Lead',ask:'Ask Tharon',buildings:'Buildings',building:'Building',import:'Upload leads',rules:'Reminder rules',api:'Connect & API',more:'More',team:'Team'};
let lastRoute='';
function render(){
  const parts=(location.hash.replace(/^#\/?/,'')||'today').split('/');
  let route=parts[0];if(route==='leads'){UI.issue=LEAD_FILTERS.some(x=>x[0]===parts[1])?parts[1]:'all';if(UI.issue!=='all')UI.closed=false;} if(!V[route]||(!TL.isAdmin()&&['rules','team','api'].includes(route))) route='today';
  if(!TL.isAdmin()&&route==='lead'){const l=TL.Lead(parts[1]); if(l&&l.rep!==S().me){/* reps can open any lead by link but only edit their own */}}
  TL.sweep();
  renderShell(route);
  const title=route==='today'&&parts[1]==='due'?'Due today':TITLES[route];$('#pageTitle').textContent=title;
  document.title=title+' — Tharon Leads';
  const v=$('#view');v.dataset.page=route;const y=window.scrollY;
  v.innerHTML=V[route](parts[1]);
  if(route!==lastRoute||route==='lead'&&location.hash!==render.h){window.scrollTo(0,0);} else window.scrollTo(0,y);
  lastRoute=route; render.h=location.hash;
  if(route==='ask'){const t=$('#thread'); t&&(t.scrollTop=t.scrollHeight);}
}
window.addEventListener('hashchange',()=>{if(UI.ignoreHash){UI.ignoreHash=false;return;}const form=document.querySelector('.simple-referral-form');if(form?.dataset.dirty&&render.h!==location.hash&&!confirm('Discard unsaved changes and leave this referral?')){UI.ignoreHash=true;location.hash=render.h;return;}render(); $('#view').focus({preventScroll:true});});

/* ---------- events ---------- */
document.addEventListener('click',async e=>{
  const el=e.target.closest('[data-act]'); if(!el) return;
  const a=el.dataset.act, id=el.dataset.id;
  if(a==='revokeDelegateAccess'){if(!confirm('Revoke Efrain’s private link and sign him out?'))return;try{await TLRemote.request('/api/admin/delegate-access',{method:'DELETE'});await loadTeam();toast('Efrain’s private access revoked.');}catch(err){toast(err.message);}return;}
  if(a==='paperworkEmail'){const form=el.closest('form');try{if(!form.reportValidity())return;let lead;if(form.dataset.id){if(form.dataset.dirty)TL.saveReferral(form.dataset.id,readLeadForm(form),progressInput(form));lead=TL.Lead(form.dataset.id);}else{lead=TL.createLead(readLeadForm(form),'Added by hand.',progressInput(form));form.dataset.id=lead.id;el.dataset.id=lead.id;}if(REMOTE)await TL.flush();form.dataset.dirty='';window.TLFollowupContacts.email(lead);}catch(error){toast(error.message);}return;}
  if(a==='residentContact'){const form=el.closest('form'),oldRel=form.elements.rel.value;form.elements.callerName.value=[form.elements.first.value.trim(),form.elements.last.value.trim()].filter(Boolean).join(' ');form.elements.rel.value='Self';if(oldRel!=='Self'){form.elements.phone.value='';form.elements.email.value='';}form.dataset.sameAsResident='true';form.dataset.dirty='true';const status=form.querySelector('[data-contact-status]');status.hidden=false;status.textContent='Resident selected as contact. Enter their own phone or email below, if known.';return;}
  if(a==='addReferrerName'){window.TLFollowupContacts.addReferrer(el.closest('form'));return;}
  if(a==='refreshTeamActivity'){await loadTeamActivity(true);return;}
  if(a==='marketerLeads'){e.preventDefault();UI.rep=id;UI.bld='all';UI.view='buildings';UI.q='';UI.closed=false;UI.roadmapPhase='all';UI.roadmapAction='all';location.hash='#/leads';render();return;}
  if(a==='openReferral'){e.preventDefault();UI.returnToResults=location.hash;UI.referralContext=location.hash.startsWith('#/leads')?(UI.issue||'all'):'all';UI.editingReferral=id;location.hash='#/lead/'+id;render();return;}
  if(a==='backToResults'){e.preventDefault();const form=el.closest('form')||document.querySelector('.simple-referral-form');if(form?.dataset.dirty&&!confirm('Discard unsaved changes and go back?'))return;if(form)form.dataset.dirty='';location.hash=UI.returnToResults||'#/leads';render();return;}
  if(a==='countyStep'){const lead=TL.Lead(id);return modal(countyStepForm(lead,el.dataset.key));}
  if(a==='viewDocument'){e.preventDefault();const file=TL.Lead(id)?.files?.find(x=>x.id===el.dataset.file);if(file)window.TLDocumentViewer.open({url:'/api/files/'+encodeURIComponent(file.id),name:file.name,opener:el}).catch(error=>toast(error.message));return;}
  if(a==='readDocument'){const lead=TL.Lead(id),file=lead?.files?.find(x=>x.id===el.dataset.file);if(!file)return;el.disabled=true;fetch('/api/files/'+encodeURIComponent(file.id),{credentials:'same-origin'}).then(async r=>{if(!r.ok)throw Error('Please sign in again to open this file.');await handleFile(new File([await r.blob()],file.name,{type:r.headers.get('Content-Type')||file.type}),{leadId:id,storedFile:file});}).catch(e=>toast(e.message)).finally(()=>el.disabled=false);return;}
  if(a==='closeModal'){const form=$('#modalBody .simple-referral-form');if(form?.dataset.dirty&&!confirm('Discard unsaved changes and go back?'))return;return closeModal();}
  if(a==='confirmAsk'){const proposal=UI.pendingAsk;if(!proposal||proposal.id!==id)return toast('This proposal is no longer active. Ask again.');if(!AS.proposalCurrent(proposal)){UI.pendingAsk=null;return toast('The referral changed. Ask again and review the new proposal.');}el.disabled=true;UI.pendingAsk=null;try{TL[proposal.op](...proposal.args);if(REMOTE)await TL.flush();S().chat.push({who:'bot',html:'Saved the confirmed change: '+esc(proposal.description)});render();}catch(error){toast('Save not confirmed: '+error.message+' Use Retry save; do not repeat the change.');}return;}
  if(a==='cancelAsk'){UI.pendingAsk=null;S().chat.push({who:'bot',html:'Change cancelled.'});render();return;}
  if(a==='pushOn'){TLRemote.enableNotifications().then(()=>toast('Morning phone reminders enabled.')).catch(e=>toast(e.message));return;}
  if(a==='pushOff'){TLRemote.disableNotifications().then(()=>toast('Phone reminders turned off.')).catch(e=>toast(e.message));return;}
  if(a==='signout'){document.getElementById('logout')?.click();return;}
  if(a==='reset'){if(confirm('Reset all demo data back to the samples?')){TL.reset(); UI.imp=null; closeModal(); toast('Demo data reset.'); location.hash='#/today'; render();} return;}
  if(a==='view'){UI.view=['buildings','list'].includes(el.dataset.v)?el.dataset.v:'buildings'; if(UI.view!=='list') UI.stage='all'; return render();}
  if(a==='quickAdd') return modal(leadForm(null));
  if(a==='stopVoice'){if(REMOTE)stopRecording();else stopVoice();return;}
  if(['mic','parseText'].includes(a)&&UI.captureSaving)return toast('Creating lead profile…');
  if(a==='mic'&&REMOTE){recordVoice(el.dataset.t||'add');return;}
  if(a==='mic') return startVoice(el.dataset.t||'add');
  if(a==='progressFilter'){e.preventDefault();UI.progressStage=$('#homeStage').value;UI.waitProvider=$('#homeProvider').value;UI.rep='all';UI.bld='all';UI.q='';UI.closed=false;UI.roadmapPhase='all';UI.roadmapAction='all';UI.waitingAge=false;location.hash='#/leads';render();return;}
  if(a==='oldWaiting'){UI.waitingAge=true;UI.progressStage='all';UI.waitProvider='all';UI.rep='all';UI.bld='all';UI.q='';UI.closed=false;UI.roadmapPhase='all';UI.roadmapAction='all';location.hash='#/leads';render();return;}
  if(a==='dashboardFilter'){e.preventDefault();UI.roadmapPhase='all';UI.roadmapAction='all';UI.progressStage='all';UI.waitProvider='all';UI.waitingAge=false;UI.rep='all';UI.bld='all';UI.stage='all';UI.q='';UI.closed=false;location.hash=el.dataset.filter==='all'?'#/leads':'#/leads/'+el.dataset.filter;render();return;}
  if(a==='arch'){if(el.dataset.v==='0'&&UI.issue&&UI.issue!=='all'){UI.issue='all';UI.closed=false;location.hash='#/leads';return;}UI.closed=el.dataset.v==='1'; UI.stage='all';if(UI.closed&&UI.issue&&UI.issue!=='all'){UI.issue='all';location.hash='#/leads';return;} if(location.hash.startsWith('#/leads')) return render(); return;}
  if(a==='checkin'||a==='closeAs'){const v=el.dataset.v; const l=TL.Lead(id); if(!l) return;
    if(v==='lost') return modal(lostForm(id));
    if(v==='won'){TL.closeLead(id,'won'); toast(TL.leadName(l)+' closed as won. It\u2019s under Closed now.'); return render();}
    TL.setTemp(id,v,a==='checkin'?'Check-in':'Temperature'); toast(TL.leadName(l)+': '+TL.tempLabel(v)+(a==='checkin'?'. Check-in answered.':'.')); return render();}
  if(a==='reopen'){const l=TL.reopenLead(id); toast(TL.leadName(l)+' reopened.'); return render();}
  if(a==='parseText'){const t=($('#voiceText')&&$('#voiceText').value||'').trim(); if(!t){toast(UI.recordedFile?'Enter the lead’s name and details so you can save the recording with its profile.':'Say or type the lead first.'); const ta=$('#voiceText'); ta&&ta.focus(); return;} UI.voiceText=t; return openReview(t,{kind:'voice',rawFile:UI.recordedFile,file:UI.recordedFile?{name:UI.recordedFile.name,type:UI.recordedFile.type,size:UI.recordedFile.size}:null});}
  if(a==='voiceAgain'){closeModal(); if(!location.hash.startsWith('#/add')) location.hash='#/add'; return setTimeout(()=>REMOTE?recordVoice('add'):startVoice('add'),120);}
  if(a==='capAsLead') return showReviewForm();
  if(a==='sample'){const f=el.dataset.f; const nm=f.split('/').pop(); progressModal(nm,'Opening the sample…');
    fetch(f).then(r=>{if(!r.ok) throw new Error('Could not open the sample ('+r.status+').'); return r.blob();}).then(b=>handleFile(new File([b],nm,{type:b.type||''}),{})).catch(err=>modal(`<h3 id="modalTitle">Couldn’t open the sample</h3><p>${esc(err.message)}</p><div class="btnrow"><button type="button" class="btn primary" data-act="closeModal">OK</button></div>`)); return;}
  if(a==='editLead') return modal(leadForm(TL.Lead(id)));
  if(a==='setStage'&&(el.dataset.s==='lost'||el.dataset.s==='movein')){if(el.dataset.s==='lost') return modal(lostForm(id)); TL.closeLead(id,'won'); toast('Closed as won: moved in.'); return render();}
  if(a==='profileTab'){UI.profileTab=el.dataset.tab;return render();}
  if(a==='programChoice'){const choice=window.TLRoadmap.paymentOptions(TL.Lead(id).building).find(x=>x[0]===el.dataset.program);if(!choice)return;try{TL.updateLead(id,{payer:choice[2]});UI.profileTab='paperwork';render();if(REMOTE)await TL.flush();render();toast('Program and roadmap saved.');}catch(error){toast(error.message);render();}return;}
  if(a==='setStage'){const s=el.dataset.s; if(s==='lost'){return modal(`<h3 id="modalTitle">Mark as lost</h3><form data-form="lost" data-id="${id}"><label>Why?<select class="input" name="reason">${opt(['Budget too low for private pay','Chose another community','Chose a community closer to family','Care needs too high (SNF)','Staying home with in-home care','Passed away','No response','Other'],'')}</select></label><div class="btnrow mt"><button class="btn bad">Mark lost</button><button type="button" class="btn ghost" data-act="closeModal">Cancel</button></div></form>`);} TL.setStage(id,s); toast('Moved to '+TL.stageLabel(s)+'.'); return render();}
  if(a==='docStatus'){TL.setDoc(id,el.dataset.k,{status:el.dataset.s}); if(el.dataset.s==='missing') toast(TL.docDef(el.dataset.k).form+' is missing. A follow-up goes on the rep\u2019s Today list.'); return render();}
  if(['docRequest','remSend','sendText'].includes(a)){toast('Automatic messages are unavailable. Use the Follow-up contact email template in the referral and send it manually.');return;}
  if(a==='docRequest'){const l=TL.Lead(id),d=TL.docDef(el.dataset.k); TL.setDoc(id,el.dataset.k,{requested:TL.T}); const to=d.who==='Physician'?'physician\u2019s office':(l.caller.email||l.caller.name); TL.simulateSend('email',to,`Hi, this is Tharon Group. We still need the ${d.form} (${d.name}) for ${TL.leadName(l)}. Reply or call us with any questions.`,id); toast('Request logged. Email simulated, nothing sent.'); return render();}
  if(a==='startDocs'){if(REMOTE)TL.setStage(id,'assessment');else{TL.ensureDocs(TL.Lead(id));TL.save();}return render();}
  if(a==='remDone'){TL.completeReminder(id); toast('Done.'); return render();}
  if(a==='remSnooze'){TL.snoozeReminder(id); toast('Moved to tomorrow.'); return render();}
  if(a==='remSend'){const x=TL.allReminders('all').find(r=>r.id===id); if(!x) return; const l=TL.Lead(x.leadId); TL.simulateSend(x.channel,x.channel==='sms'?(l.caller.phone||'family'):(l.caller.email||'family'),x.channel==='sms'?`Hi ${l.caller.name?l.caller.name.split(' ')[0]:''}, this is ${TL.U(l.rep)?TL.U(l.rep).name.split(' ')[0]:'Tharon Group'} from ${TL.B(l.building)?TL.B(l.building).name:'Tharon Group'}. ${x.rule==='tour_confirm'?'Just confirming your tour '+TL.fmtWhen(l.tourAt)+'.':'Quick reminder: we still need the signed admission agreement before move-in.'} Reply here with any questions.`:x.text,l.id); toast('Delivery is unavailable. Nothing was sent.'); return render();}
  if(a==='logCall') return modal(`<h3 id="modalTitle">Log a call</h3><form data-form="call" data-id="${id}"><label>What happened?<textarea class="input" name="text" rows="3" required placeholder="Spoke with the daughter, booking a tour\u2026"></textarea></label><div class="btnrow mt"><button class="btn primary">Save call</button><button type="button" class="btn ghost" data-act="closeModal">Cancel</button></div></form>`);
  if(a==='sendText'){const l=TL.Lead(id); return modal(`<h3 id="modalTitle">Text ${esc(l.caller.name||TL.leadName(l))}</h3><p class="muted small">Simulated in the demo. It's logged on the lead, nothing is sent.</p><form data-form="text" data-id="${id}"><label>Message<textarea class="input" name="text" rows="3" required>Hi ${esc((l.caller.name||l.first).split(' ')[0])}, this is ${esc(TL.me().name.split(' ')[0])} from Tharon Group. </textarea></label><div class="btnrow mt"><button class="btn primary">Send (simulated)</button><button type="button" class="btn ghost" data-act="closeModal">Cancel</button></div></form>`);}
  if(a==='newTask') return modal(`<h3 id="modalTitle">New task</h3><form data-form="task" data-id="${id||''}"><label>Task<input class="input" name="text" required placeholder="Call the daughter about the tour"></label><label class="mt block">Due<input class="input" type="date" name="due" value="${TL.T}"></label><div class="btnrow mt"><button class="btn primary">Add task</button><button type="button" class="btn ghost" data-act="closeModal">Cancel</button></div></form>`);
  if(a==='sampleCsv'){download('tharon-sample-leads.csv',SAMPLE_CSV,'text/csv'); toast('Sample CSV downloaded.'); return;}
  if(a==='useSample'){parseFile('tharon-sample-leads.csv',new TextEncoder().encode(SAMPLE_CSV)); return;}
  if(a==='doImport') return doImport();
  if(a==='cancelImport'){if(UI.imp?.importRequest){toast('This import has an uncertain outcome. Retry the same batch before closing it.');return;}UI.imp=null; return render();}
  if(a==='exportJson'&&REMOTE){location.href='/api/export';return;}
  if(a==='exportJson'){download('tharon-leads-export-'+TL.T+'.json',JSON.stringify(TL.exportJson(),null,2),'application/json'); toast('Exported.'); return;}
  if(a==='sug') return ask(el.dataset.q);
  if(a==='clearChat'){S().chat=[]; TL.save(); return render();}
});
document.addEventListener('change',async e=>{if(e.target.closest('.simple-referral-form'))e.target.closest('form').dataset.dirty='true';
  const el=e.target; const c=el.dataset&&el.dataset.change; if(!c) return; const id=el.dataset.id;
  if(c==='user'){S().me=el.value; UI.todayRep='all'; UI.rep='all'; TL.save(); toast('Signed in as '+TL.me().name+(TL.isAdmin()?' (admin).':'.')); return render();}
  if(c==='customTaskDone'){if(el.checked){TL.completeReminder(id);toast('Task completed.');render();}return;}
  if(c==='todayRep'){UI.todayRep=el.value; return render();}
  if(c==='frep'){UI.rep=el.value;UI.bld='all';UI.view='buildings';return render();}
  if(c==='captureBuilding'){UI.captureBuilding=el.value||null;return;}
  if(c==='impBuilding'){UI.imp.building=el.value;return render();}
  if(c==='progressStage'){UI.progressStage=el.value;return render();}
  if(c==='waitProvider'){UI.waitProvider=el.value;return render();}
  if(c==='waitingAge'){UI.waitingAge=el.checked;return render();}
  if(c==='fbld'){UI.bld=el.value; return render();}
  if(c==='leadIssue'){UI.closed=false;location.hash=el.value==='all'?'#/leads':'#/leads/'+el.value;render();return;}
  if(c==='roadmapPhase'){UI.roadmapPhase=el.value;UI.roadmapAction='all';return render();}
  if(c==='roadmapAction'){UI.roadmapAction=el.value;return render();}
  if(c==='stage'&&(el.value==='lost'||el.value==='movein')){const v=el.value; el.value=TL.Lead(id).stage; if(v==='lost') return modal(lostForm(id)); TL.closeLead(id,'won'); toast(TL.leadName(TL.Lead(id))+' closed as won. It\u2019s under Closed now.'); return render();}
  if(c==='stage'){if(el.value==='lost'){const v=el.value; el.value=TL.Lead(id).stage; return modal(`<h3 id="modalTitle">Mark as lost</h3><form data-form="lost" data-id="${id}"><label>Why?<input class="input" name="reason" required placeholder="Chose another community"></label><div class="btnrow mt"><button class="btn bad">Mark lost</button><button type="button" class="btn ghost" data-act="closeModal">Cancel</button></div></form>`);} TL.setStage(id,el.value); toast(TL.leadName(TL.Lead(id))+' \u2192 '+TL.stageLabel(el.value)); return render();}
  if(c==='formBuilding'){const payer=el.form.elements.payer;payer.innerHTML=payerOptions(el.value,payer.value);updateProgressPreview(el.form,true);return;}
  if(c==='referralSource'){el.form.querySelector('datalist').innerHTML=referrerOptions(el.value);return;}
  if(c==='formProgram'){updateProgressPreview(el.form,true);return;}
  if(c==='progressAnswer'||c==='progressProvider'){updateProgressPreview(el.form);return;}
  if(c==='leadBld'){TL.assign(id,{building:el.value||null}); toast(el.value?'Assigned to '+TL.B(el.value).short+'.':'Building cleared.'); return render();}
  if(c==='leadRep'){TL.assign(id,{rep:el.value||null}); toast('Rep updated.'); return render();}
  if(c==='tourCompleted'){TL.updateLead(id,{touredAt:el.checked?TL.nowTs():null});return render();}
  if(c==='assessmentStatus'){TL.updateLead(id,{assessmentStatus:el.value});return render();}
  if(c==='programStatus'){TL.updateLead(id,{programStatus:el.value});return render();}
  if(c==='accessAll'){el.closest('form').querySelector('.building-options').disabled=el.checked;return;}
  if(c==='paperworkDone'){TL.setDoc(id,el.dataset.k,{status:el.checked?'received':'missing'});return render();}
  if(c==='paperworkStatus'){TL.setDoc(id,el.dataset.k,{status:el.value});return render();}
  if(c==='docDue'){TL.setDoc(id,el.dataset.k,{due:el.value}); return render();}
  if(c==='approvalFile'){const file=el.files?.[0];el.value='';if(!file)return;const form=el.closest('form');try{if(form.dataset.dirty){if(!form.reportValidity())return;TL.saveReferral(id,readLeadForm(form),progressInput(form));if(REMOTE)await TL.flush();form.dataset.dirty='';}await handleFile(file,{leadId:id});}catch(error){toast(error.message);}return;}
  if(c==='capFile'){const f=el.files&&el.files[0]; const lid=el.dataset.id; el.value=''; if(f) handleFile(f,{leadId:lid}); return;}
  if(c==='attachLead'){const cap=UI.cap; if(!cap) return; const docs=cap.r.docs.filter(x=>TL.docDef(x.key)); return modal(attachView(cap.r,Object.assign({},cap.meta,{leadId:el.value||null}),docs));}
  if(c==='tier'){TL.updateLead(id,{tier:parseInt(el.value)||null},true); TL.addActivity(id,'docs','Waiver tier set to '+(el.value?'Tier '+el.value:'none')+'.'); return render();}
  if(c==='file'){const f=el.files[0]; if(!f) return; f.arrayBuffer().then(b=>parseFile(f.name,new Uint8Array(b))); return;}
  if(c==='importSheet'){if(UI.imp?.busy||UI.imp?.importRequest){toast('Resolve or cancel the pending import before selecting another worksheet.');return;}selectImportSheet(el.value);return;}
  if(c==='jsonIn'){toast('JSON import is unavailable. Use CSV / Excel.');return;}
  if(c==='jsonIn'){const f=el.files[0]; if(!f) return; f.text().then(t=>{try{const n=TL.importJson(JSON.parse(t),'merge'); toast('Imported '+n+' leads from JSON.'); render();}catch(err){toast(err.message);}}); return;}
  if(['map','impRep','impBuilding','impDup'].includes(c)&&UI.imp?.importRequest){toast('Resolve the pending import with Retry before changing its mapping.');render();return;}
  if(c==='map'){UI.imp.map[el.dataset.k]=el.value===''?null:Number(el.value); return render();}
  if(c==='impRep'){UI.imp.rep=el.value; return;}
  if(c==='impDup'){UI.imp.skipDup=el.checked; return render();}
  const rule=id&&S().rules.find(r=>r.id===id);
  if(c==='ruleOn'){rule.enabled=el.checked; TL.save(); return render();}
  if(c==='ruleDays'){rule.days=Math.max(0,parseInt(el.value)||0); TL.save(); toast('Rule updated. Today lists recalculated.'); return render();}
  if(c==='ruleCh'){rule.channel=el.value; TL.save(); return render();}
  if(c==='ruleText'){rule.text=el.value; TL.save(); return render();}
  if(c==='hookEv'){const w=S().webhook,ev=el.dataset.e; w.events=el.checked?[...new Set(w.events.concat(ev))]:w.events.filter(x=>x!==ev); TL.save(); return;}
});
document.addEventListener('input',e=>{const el=e.target;if(el.closest('.simple-referral-form')){const form=el.closest('form');form.dataset.dirty='true';if(form.dataset.sameAsResident==='true'&&['first','last'].includes(el.name))form.elements.callerName.value=[form.elements.first.value.trim(),form.elements.last.value.trim()].filter(Boolean).join(' ');} if(el.dataset&&el.dataset.input==='voiceText'){UI.voiceText=el.value; return;} if(el.dataset&&el.dataset.input==='q'){UI.q=el.value; clearTimeout(UI.qh); UI.qh=setTimeout(()=>{const pos=el.selectionStart; render(); const n=$('#fq'); if(n){n.focus(); try{n.setSelectionRange(pos,pos);}catch(_){}}},250);}});
document.addEventListener('submit',async e=>{
  const f=e.target; const k=f.dataset.form; if(!k) return; e.preventDefault(); const id=f.dataset.id;
  if(k==='countyStep'){const button=f.querySelector('button[type="submit"]');button.disabled=true;try{const patch={status:f.elements.status.value,owner:f.elements.owner.value,waitingOn:f.elements.waitingOn.value,due:f.elements.due.value,note:f.elements.note.value};for(const key of ['plan','moveIn','transition','waitlistDate','slotStatus','placementDeadline'])if(f.elements[key]&&f.elements[key].value)patch[key]=f.elements[key].value;TL.setCountyStep(id,f.dataset.key,patch);if(REMOTE)await TL.flush();closeModal();if(f.dataset.inline==='true')location.hash=UI.returnToResults||'#/leads';render();toast('Step and reminder saved.');}catch(error){f.querySelector('[data-step-error]').textContent=error.message;}finally{button.disabled=false;}return;}
  if(k==='lead'){if(f.dataset.saving==='true')return;f.dataset.saving='true';const button=f.querySelector('button[type="submit"]');button.disabled=true;try{const d=readLeadForm(f),progress=progressInput(f);let lead;if(f.dataset.pendingId){if(REMOTE&&TLRemote.pending){await TLRemote.retry();await TL.flush();}lead=TL.Lead(f.dataset.pendingId);if(!lead)throw Error('The saved record is not confirmed. Use Retry save and review the conflict.');if(f.pendingSignature!==JSON.stringify({d,progress})){f.dataset.pendingId='';f.dataset.id=lead.id;f.dataset.dirty='true';toast('Earlier save confirmed. Your newer edits are still here; press Save changes to save them.');return;}}else{if(id)lead=TL.saveReferral(id,d,progress);else lead=TL.createLead(d,'Added by hand.',progress);f.dataset.pendingId=lead.id;f.pendingSignature=JSON.stringify({d,progress});if(REMOTE)await TL.flush();}f.dataset.pendingId='';f.dataset.dirty='';closeModal();toast('Referral and next step saved.');location.hash='#/lead/'+lead.id;render();}catch(error){f.querySelector('[data-referral-error]').textContent=error.message+' Keep this page open and use Retry save to confirm the same operation.';}finally{f.dataset.saving='false';button.disabled=false;}return;}
  if(k==='capture'){const cap=UI.cap;if(!cap||UI.captureSaving)return;UI.captureSaving=true;const button=f.querySelector('[type=submit]');button.disabled=true;try{if(!f.reportValidity())return;const m=cap.meta||{};let l;if(cap.createdId){if(REMOTE)await TLRemote.retry();l=TL.Lead(cap.createdId);}else{const d=readLeadForm(f);if(REMOTE&&m.rawFile)m.storedFile=m.storedFile||await TL.uploadFile(m.rawFile);l=TL.createLead(d,'Extracted profile explicitly reviewed before saving.',progressInput(f));cap.createdId=l.id;if(m.kind==='voice'&&cap.text)TL.addActivity(l.id,'note','Voice transcript: '+cap.text.slice(0,11000));if(m.file)TL.attachFile(l.id,{...(m.storedFile||{}),name:m.file.name,type:m.file.type,size:m.file.size,forms:markCapturedDocuments(l,cap.r)});}if(REMOTE)await TL.flush();UI.cap=null;UI.voiceText='';UI.recordedFile=null;closeModal();location.hash='#/lead/'+l.id;render();toast('Profile saved.');}catch(error){toast('Save not confirmed: '+error.message+' Keep this review open and use Retry save.');button.textContent='Retry save';if(cap.createdId)for(const field of f.querySelectorAll('input,select,textarea'))field.disabled=true;}finally{UI.captureSaving=false;button.disabled=false;}return;}
  if(k==='attach'){if(f.dataset.saving==='true')return;f.dataset.saving='true';try{if(UI.cap?.meta.attachQueued){try{await TLRemote.retry();await TL.flush();const lid=f.elements.lead.value;UI.cap=null;closeModal();location.hash='#/lead/'+lid;render();toast('Attachment saved.');}catch(error){toast('Save still not confirmed. Keep this page open.');}return;}if(UI.cap?.meta.coverage?.partial&&!confirm('Some PDF pages were not read. Attach the full original without marking any paperwork complete?'))return;const lid=f.elements.lead.value; if(!lid){toast('Pick the lead to attach it to.'); return;} const l=TL.Lead(lid); const m=UI.cap.meta;
    if(REMOTE&&m.rawFile){const button=f.querySelector('button[type=submit],button:not([type])');if(button)button.disabled=true;try{m.storedFile=m.storedFile||await TL.uploadFile(m.rawFile);}catch(err){toast(err.message);return;}finally{if(button)button.disabled=false;}}
    const keys=UI.cap.meta.coverage?.partial?[]:[...f.querySelectorAll('input[name="doc"]:checked')].map(i=>i.value); const done=[];
    keys.forEach(k2=>{if(/^w_/.test(k2)&&!TL.wdocsFor(l).some(d=>d.key===k2)) return; if((/^w_/.test(k2)?l.wdocs:l.docs)?.[k2]?.status!=='approved')TL.setDoc(lid,k2,{status:'received'}); done.push(TL.docDef(k2).form);});
    if(UI.cap.r.fields.tier&&keys.includes('w_assess')) TL.updateLead(lid,{tier:UI.cap.r.fields.tier},true);
    if(!m.attachQueued){TL.attachFile(lid,{...(m.storedFile||{}),name:m.file.name,type:m.file.type,size:m.file.size,forms:done});m.attachQueued=true;}
    if(REMOTE)try{await TL.flush();}catch(error){toast('Attachment save not confirmed. Keep the app open and use Retry save.');return;}UI.cap=null; closeModal(); toast(done.length?'Received: '+done.join(', ')+'.':'Attached to '+TL.leadName(l)+'.'); location.hash='#/lead/'+lid; render(); return;}finally{f.dataset.saving='false';}}
  if(k==='close'){const rs=f.elements.reason.value; if(!rs){toast('Pick a reason.'); return;} const det=(f.elements.detail&&f.elements.detail.value||'').trim(); const l=TL.closeLead(id,'lost',det?rs+': '+det:rs); closeModal(); toast(TL.leadName(l)+' closed as lost. It\u2019s under Closed now.'); return render();}
  if(k==='lost'){TL.setStage(id,'lost',f.elements.reason.value); closeModal(); toast('Marked lost.'); return render();}
  if(k==='nextStep'){const button=f.querySelector('button');button.disabled=true;try{TL.updateLead(id,{nextAction:f.elements.nextAction.value.trim(),nextFollowUp:f.elements.nextFollowUp.value});if(REMOTE)await TL.flush();closeModal();toast('Next step saved.');render();}catch(e){toast(e.message);}finally{button.disabled=false;}return;}
  if(k==='call'){TL.addActivity(id,'call',f.elements.text.value.trim()); closeModal(); toast('Call logged.'); return render();}
  if(k==='text'){const l=TL.Lead(id); TL.simulateSend('sms',l.caller.phone||'family',f.elements.text.value.trim(),id); closeModal(); toast('Text delivery is unavailable. Nothing was sent.'); return render();}
  if(k==='staffPassword'){
    if(f.elements.password.value!==f.elements.confirm.value){toast('Passwords do not match.');return;}
    const button=f.querySelector('button');button.disabled=true;
    try{await TLRemote.request('/api/users/password',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({userId:id,password:f.elements.password.value})});f.reset();await loadTeam();toast('Password saved. Staff can sign in directly.');}catch(err){toast(err.message);}finally{button.disabled=false;}return;
  }
  if(k==='buildingAccess'){try{const d=new FormData(f);TL.setBuildingAccess(id,f.elements.allBuildings.checked?'all':d.getAll('buildings'));if(REMOTE)await TL.flush();toast('Building access saved.');render();}catch(err){toast(err.message);}return;}
  if(k==='task'){const l=id?TL.Lead(id):null; TL.addTask({text:f.elements.text.value.trim(),due:f.elements.due.value||TL.T,leadId:id||null,rep:l&&l.rep?l.rep:S().me}); closeModal(); toast('Task added.'); return render();}
  if(k==='note'){const t=f.elements.text.value.trim(); if(t){TL.addActivity(id,'note',t); render();} return;}
  if(k==='ask'){const q=f.elements.q.value.trim(); if(q) ask(q); return;}
  if(k==='beds'){const b=TL.B(id); b.occupied=Math.max(0,Math.min(b.licensed,parseInt(f.elements.occupied.value)||0)); TL.save(); toast('Census updated.'); return render();}
  if(k==='hook'){S().webhook.url=f.elements.url.value.trim(); TL.save(); toast('Saved. Delivery stays simulated in the demo.'); return render();}
  if(k==='api'){const [m,p]=ENDPOINTS[Number(f.elements.ep.value)]; const body=BODIES[m+' '+p]; const r=TL.request(m,p,body); $('#apiout').textContent=`${m} ${p}${body?'\n'+JSON.stringify(body,null,2):''}\n\n\u2192 ${r.status}\n${JSON.stringify(r.body,null,2)}`; if(m!=='GET') setTimeout(()=>renderShell(lastRoute),0); return;}
});
$('#modal').addEventListener('click',e=>{if(e.target.id==='modal') closeModal();});
document.addEventListener('keydown',e=>{if(e.key==='Escape'&&!$('#modal').hidden) closeModal();});

/* Clipboard capture: only actual files or user-pasted referral text are processed. */
function readCaptureClipboard(data){
 if(!data)return {};const files=Array.from(data.files||[]);if(!files.length)for(const item of Array.from(data.items||[])){if(item.kind==='file'){const file=item.getAsFile();if(file)files.push(file);}}
 return {file:files[0]||null,count:files.length,text:(data.getData?.('text/plain')||'').trim()};
}
function handleCapturePaste(e){
 if(!location.hash.startsWith('#/add')||UI.captureSaving)return;const capture=readCaptureClipboard(e.clipboardData);
 if(capture.file){e.preventDefault();if(capture.count>1){toast('Paste one file at a time.');return;}handleFile(capture.file);return;}
 if(!e.target.closest?.('#capturePaste'))return;
 if(capture.text){e.preventDefault();if(/^(?:https?:\/\/|file:|\/)/i.test(capture.text)&&!capture.text.includes('\n')){toast('That is a file link or path. Use Choose file to provide the document itself.');return;}openReview(capture.text,{kind:'doc'});}
 else toast('Safari did not provide a file to paste. Use Choose file instead.');
}
document.addEventListener('paste',handleCapturePaste);

/* ---------- drag and drop on the board (desktop) ---------- */
document.addEventListener('dragstart',e=>{const c=e.target.closest&&e.target.closest('[data-drag]'); if(!c) return; e.dataTransfer.setData('text/plain',c.dataset.drag); c.classList.add('dragging');});
document.addEventListener('dragend',e=>{const c=e.target.closest&&e.target.closest('[data-drag]'); c&&c.classList.remove('dragging'); document.querySelectorAll('.col.over').forEach(x=>x.classList.remove('over'));});
document.addEventListener('dragover',e=>{const col=e.target.closest&&e.target.closest('[data-drop]'); if(!col) return; e.preventDefault(); col.classList.add('over');});
document.addEventListener('dragleave',e=>{const col=e.target.closest&&e.target.closest('[data-drop]'); col&&!col.contains(e.relatedTarget)&&col.classList.remove('over');});
document.addEventListener('drop',e=>{const col=e.target.closest&&e.target.closest('[data-drop]'); if(!col) return; e.preventDefault(); const id=e.dataTransfer.getData('text/plain'); const s=col.dataset.drop; const l=TL.Lead(id); if(!l||l.stage===s) return;
  if(s==='lost') return modal(lostForm(id));
  if(s==='movein'){TL.closeLead(id,'won'); toast(TL.leadName(l)+' closed as won.'); return render();}
  TL.setStage(id,s); toast(TL.leadName(l)+' \u2192 '+TL.stageLabel(s)); render();});
document.addEventListener('dragover',e=>{const d=$('.drop'); if(d&&e.target.closest&&e.target.closest('.drop')){e.preventDefault(); d.classList.add('over');}});
document.addEventListener('drop',e=>{let d=e.target.closest&&e.target.closest('.drop'); if(!d&&location.hash.startsWith('#/add')&&e.dataTransfer&&e.dataTransfer.files.length) d=$('.drop.any'); if(!d) return; e.preventDefault(); d.classList.remove('over'); const f=e.dataTransfer.files[0]; if(!f) return;
  if(fileKind(f.name,f.type)==='sheet'&&!d.classList.contains('any')) f.arrayBuffer().then(b=>parseFile(f.name,new Uint8Array(b))); else handleFile(f,{leadId:d.dataset.id});});
document.addEventListener('dragover',e=>{if(location.hash.startsWith('#/add')&&e.dataTransfer&&[...(e.dataTransfer.types||[])].includes('Files')){e.preventDefault(); const d=$('.drop.any'); d&&d.classList.add('over');}});

render();
if('serviceWorker' in navigator){window.addEventListener('load',()=>{navigator.serviceWorker.register('sw.js').catch(()=>{});});}
})();

window.addEventListener('beforeunload',e=>{if(document.querySelector('.simple-referral-form[data-dirty=\"true\"]')){e.preventDefault();e.returnValue='';}});

(async function(){
 'use strict';
 const accessToken=location.hash.slice(1);
 history.replaceState(null,'','/access');
 const message=document.getElementById('accessMessage');
 if(!accessToken){message.textContent='Open the full private link from your email. There is no code to enter.';return;}
 try{const response=await fetch('/auth/access',{method:'POST',credentials:'same-origin',headers:{'Content-Type':'application/json'},body:JSON.stringify({token:accessToken})});const result=await response.json();if(!response.ok)throw new Error(result.error||'Unable to open this private link.');location.replace('/');}
 catch(error){message.textContent=error.message;}
})();

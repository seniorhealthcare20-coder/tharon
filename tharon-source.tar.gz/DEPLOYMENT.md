# Railway deployment and activation

## Current state

The application and deployment source have been prepared. Railway is connected and PostgreSQL is provisioned. No
live resident import or staff invitation has been performed. A shared sample staging deployment is running at https://tharon-leads-app-staging.up.railway.app, with private PostgreSQL and the local speech image.
The separately published private Site is a standalone **sample-only preview**, not the Railway application.

## Services

Use a dedicated Railway project for Tharon Leads with:

1. A PostgreSQL service reachable only over the project's private network.
2. An app service built from this repository's Dockerfile. It serves the web UI, API, and local speech transcription.
   The image installs faster-whisper and downloads the public tiny.en model at build time. Runtime transcription
   uses local weights in offline mode; audio is never sent to Hugging Face or a consumer speech service.
3. An HTTPS Railway/custom domain for the app only. Keep the database's public TCP proxy disabled.

The transcription model and container consume CPU and memory and need a real recording/performance test before
staff rollout. The provided health check is `/health`. Keep the app running for the scheduled morning reminder job;
if enabling scale-to-zero, provide a separate scheduled trigger first.

## Variables

- NODE_ENV=production
- APP_ORIGIN: the exact HTTPS app origin, no trailing slash
- DATABASE_URL: Railway's private PostgreSQL connection reference
- APP_MODE=sample for initial deployment; use a separate empty database for live
- PHI_APPROVED=false until the real-data approval steps are complete
- SESSION_SECRET and FILE_ENCRYPTION_KEY: independent random values of at least 32 characters
- ADMIN_SETUP_TOKEN: one long random operator-provisioned bootstrap token
- ADMIN_SETUP_EXPIRES_AT: its ISO 8601 expiry time (24 hours for staging setup)
- TRANSCRIBE_LOCAL=true, WHISPER_MODEL_DIR=/opt/whisper/tiny.en (already set in Dockerfile)
- REPORTING_TOKEN: leave unset until connecting the Command Center; then use an independent random token

Never store real values in Git or a source archive. Set them through Railway's protected variable UI/connection.
Keep FILE_ENCRYPTION_KEY in the company's secret manager with backup/recovery controls: losing it makes stored
files unreadable. The current release does not implement automatic encryption-key rotation.

## Account access

Existing accounts sign in at `/login`. Staff do not need activation links or private setup codes. In Team, Steven can set an initial staff password or reset an existing one. Share it privately with the matching staff member. Resetting revokes all sessions and pending invitations for that staff member, without changing leads or building access.

Administrator bootstrap remains available with a protected `/activate#<token>` link for a new installation; it requires authenticator enrollment. A bare `/activate` opens sign-in. Invalid or consumed links show sign-in and password-recovery instructions. Never paste tokens or passwords into chat.

## Before real-data activation

Confirm the applicable Railway agreement/BAA and eligible workload setup with Railway. Do not infer that a standard
account includes a BAA. Railway's current official compliance/security documentation describes enterprise BAA support:
https://docs.railway.com/enterprise/compliance
https://docs.railway.com/enterprise/security

Verify database/volume encryption and access controls in the selected Railway environment, configure backups and
retention, restore a backup into an isolated test environment, document access and incident procedures, and verify
that no platform logging/analytics captures request bodies or resident information. Agree the final document packet
and retention policy with the Tharon administrator. Staff exports/downloads must be handled under company policy.

Create a separate production database. Set APP_MODE=live and PHI_APPROVED=true only after those checks and agreement
approvals. Sample-data databases are rejected in live mode. Back up and retain the sample database separately if needed;
do not delete or overwrite data as part of promotion.

## Acceptance checks after deployment

- Health check succeeds and the app redirects unauthenticated visitors to sign-in.
- Activate the admin and both staff users; verify actual email addresses and the admin authenticator.
- Morgan creates a fictional test lead by voice and by PDF, chooses a building, and sees it from another device.
- Olivia cannot view or download that lead's documents; Steven can view and reassign it.
- Add a task, mark paperwork received, close won/lost, and reopen. Verify Today and activity updates.
- Disconnect/reconnect a phone and verify the pending-save warning. Do not close a page containing unsaved work.
- Attempt conflicting edits and verify the review screen rather than silent overwrite.
- Restart/redeploy the service and verify database records and encrypted files remain accessible.
- Test local transcription with a real iPhone recording and review names/phone numbers before saving. The decoder is pinned to av==16.0.1 because faster-whisper 1.2.1 is incompatible with PyAV 19. A public speech fixture passed the local runtime check.
- Install the app to an iPhone Home Screen, enable phone reminders from More, and verify a morning push notification. Push payloads contain no resident names or document details. The app stores the VAPID private key and subscription data encrypted in PostgreSQL; messages use the browser’s push provider. Signing out removes that device’s subscription. Email and SMS are intentionally not connected.
- Verify backups/restore and a morning reminder pass.

## Command Center connection (later)

Enable REPORTING_TOKEN and have the Command Center server call `GET /api/reporting/buildings` with that bearer token.
The response contains building IDs and counts only. Do not put the reporting token into browser JavaScript.
No QuickBooks access is needed by the marketers' app. Configure QuickBooks in the separate Command Center.

Railway service settings use the native configuration (Dockerfile path, /health, port 3000, one US-West replica, 2-vCPU/1-GB cap); no deprecated railway.json file is required.

## Launch checkpoint — November 12, 2026

The public sample entry is password-free and uses browser-local fictional records. Staff sign-in remains available at `/login?staff=1`; live mode never exposes the preview.

- Railway app and private PostgreSQL: online.
- Automatic volume backup schedule: blocked by Railway because this workspace is not Pro. No plan upgrade was performed.
- Isolated PostgreSQL acceptance: shared saving, account isolation, atomic import and retries, original PDF download, service restart, encrypted logical restore and local voice transcription passed with fictional/public fixtures. These were local checks, not a deployed-container or real-phone result.
- Three named existing leads were identified in Command Center version 19; two summary placeholders were excluded. A private review packet preserves source building and status notes. No real leads have been imported. Source status, dates, funding and paperwork must be reviewed; one scheduled admission date has passed. No document is marked received from a summary alone.
- Live launch remains blocked on the hosting agreement/BAA decision, Pro backup scheduling and deployed restore drill, separate empty production database, actual account activation, and staff-phone microphone/push acceptance.

`GET /health` publishes only a boolean `launch_ready`. It is true only in live mode, with all three accounts activated and the operator explicitly setting LAUNCH_ACCEPTED=true after the above evidence is recorded. It is not inferred from a successful deploy.

## Separate production setup environment

A separate production environment now has its own private Postgres service and independent session/file/bootstrap secrets. The app is deployed at https://tharon-leads-production.up.railway.app with APP_MODE=setup and PHI_APPROVED=false. This creates no fictional leads and blocks lead writes, import, file upload and audio intake while allowing staff account activation. The staging sample stays unchanged.

For Steven: open the production app service (tharon-leads) in Railway, copy its ADMIN_SETUP_TOKEN from Variables, then use https://tharon-leads-production.up.railway.app/activate. Create your own password and authenticator entry. Generate staff links from Team. Never paste setup codes or passwords into chat. The bootstrap expires 24 hours after provisioning.

The final operator changes are APP_MODE=live and PHI_APPROVED=true only after hosting approval, backup configuration, deployed recovery and device checks; LAUNCH_ACCEPTED=true only after all three accounts are active and final acceptance is recorded. Existing source leads are still review-only and have not been loaded.

import test from 'node:test';
import assert from 'node:assert/strict';
import {createRequire} from 'node:module';
import {mkdtempSync,rmSync} from 'node:fs';
import {tmpdir} from 'node:os';
import path from 'node:path';
import {createHmac} from 'node:crypto';
import {initialState,execute,engine,libertana} from '../server/engine.mjs';
import {createApplication} from '../server/index.mjs';
const {PDFDocument}=createRequire(import.meta.url)('../site/vendor/pdf-lib.min.js');
test('every lead has its own filled packet link; unsigned filter includes moved-in residents and excludes completed/lost packets',()=>{
 let s=execute(initialState(false),'u0',{op:'createLead',createdId:'L_packet_reference',args:[{first:'Fictional',last:'Current',building:'crenshaw',payer:'CalAIM Community Supports',rep:'u2'}]});
 const l=s.leads[0];assert.equal(l.referenceDocuments[0].prefilledUrl,'/api/leads/L_packet_reference/libertana/packet.pdf');let tl=engine(s,'u0');assert.equal(tl.leadMatchesFilter(l,'libertana-unsigned'),true);
 l.stage='movein';assert.equal(tl.leadMatchesFilter(l,'libertana-unsigned'),true);l.stage='lost';assert.equal(tl.leadMatchesFilter(l,'libertana-unsigned'),false);l.stage='new';l.files=[{id:'signed',type:'application/pdf'}];l.libertana={fields:{},signedFileId:'signed',reviewed:true,signatures:Object.fromEntries(['member1','cca1','member2','agency2','client4','witness4','member5','agency5'].map(k=>[k,true]))};assert.equal(tl.leadMatchesFilter(l,'libertana-unsigned'),false);
});
test('authenticated prefilled PDF contains current lead data, preserves unsigned fields, and denies unauthorized building access',async()=>{
 const folder=mkdtempSync(path.join(tmpdir(),'libertana-pdf-')),secret='s'.repeat(64);
 const app=await createApplication({env:{NODE_ENV:'test',APP_MODE:'live',PHI_APPROVED:'true',DATABASE_URL:'',SQLITE_PATH:path.join(folder,'app.sqlite'),SESSION_SECRET:secret,FILE_ENCRYPTION_KEY:'f'.repeat(64),APP_ORIGIN:''},schedule:false});
 await new Promise(r=>app.server.listen(0,'127.0.0.1',r));const origin='http://127.0.0.1:'+app.server.address().port;
 try{
 let s=execute(initialState(false),'u0',{op:'createLead',createdId:'L_autofilled_packet',args:[{first:'Fictional',last:'Current',building:'crenshaw',payer:'CalAIM Community Supports',rep:'u2',caller:{name:'Fictional Contact',rel:'Case manager',email:'case@example.invalid',phone:'5550100000'}}]});
 await app.store.query('UPDATE app_state SET data=$1 WHERE id=$2',[JSON.stringify(s),'main']);
 for(const uid of ['u0','u3'])await app.store.query('INSERT INTO sessions (token_hash,user_id,expires_at,csrf) VALUES ($1,$2,$3,$4)',[createHmac('sha256',secret).update('token-'+uid).digest('hex'),uid,Date.now()+60000,'fictional-csrf']);
 const url=origin+s.leads[0].referenceDocuments[0].prefilledUrl;
 assert.equal((await fetch(url)).status,401);assert.equal((await fetch(url,{headers:{Cookie:'tl_session=token-u3'}})).status,404);
 async function read(){const r=await fetch(url,{headers:{Cookie:'tl_session=token-u0'}});assert.equal(r.status,200);assert.equal(r.headers.get('content-type'),'application/pdf');assert.equal(r.headers.get('cache-control'),'no-store');return PDFDocument.load(await r.arrayBuffer());}
 let pdf=await read(),form=pdf.getForm();assert.equal(pdf.getPageCount(),8);assert.equal(form.getTextField('Members Name').getText(),'Fictional Current');assert.equal(form.getTextField('Home Phone Number').getText(),undefined);assert.equal(form.getTextField('Applicant/Legal Rep Signature').getText(),undefined);
 s=execute(s,'u0',{op:'updateLead',expectedVersion:s.leads[0].version,args:[s.leads[0].id,{last:'Updated',libertana:{fields:{dob:'1950-04-02'},signatures:{},reviewed:false}}]});await app.store.query('UPDATE app_state SET data=$1 WHERE id=$2',[JSON.stringify(s),'main']);
 pdf=await read();form=pdf.getForm();assert.equal(form.getTextField('Members Name').getText(),'Fictional Updated');assert.equal(form.getTextField('Date of Birth').getText(),'04/02/1950');assert.equal(form.getTextField('Tharon_page2_name').getText(),'Fictional Updated');assert.equal(form.getTextField('Tharon_page5_name').getText(),'Fictional Updated');assert.equal(s.leads[0].libertana.signedFileId,undefined);
 const headers={Cookie:'tl_session=token-u0',Origin:origin,'X-CSRF-Token':'fictional-csrf','Content-Type':'application/json'};
 const update=await fetch(origin+'/api/commands',{method:'POST',headers,body:JSON.stringify({id:'inline_pdf_save_test',op:'updateLead',expectedVersion:s.leads[0].version,args:[s.leads[0].id,{libertana:{fields:{dob:'1950-04-02'},signatures:{},reviewed:false,pdfFields:{Address:'456 Fictional Saved Street',Tharon_release_scope_medical:true}}}]})});
 assert.equal(update.status,200);const state=(await update.json()).state;
 const saved=await read();assert.equal(saved.getForm().getTextField('Address').getText(),'456 Fictional Saved Street');assert.equal(saved.getForm().getCheckBox('Tharon_release_scope_medical').isChecked(),true);
 const bad=await fetch(origin+'/api/commands',{method:'POST',headers,body:JSON.stringify({id:'inline_pdf_bad_test',op:'updateLead',expectedVersion:state.leads[0].version,args:[s.leads[0].id,{libertana:{fields:{},signatures:{},pdfFields:{unrecognized:'not allowed'}}}]})});assert.equal(bad.status,422);
 // An ALW referral must not receive the automatic LA CalAIM packet, even when its CCA is Libertana.
 let switched=execute(state,'u0',{op:'updateLead',expectedVersion:state.leads[0].version,args:[state.leads[0].id,{building:'bellevue',payer:'ALW waiver',cca:'Libertana'}]});
 await app.store.query('UPDATE app_state SET data=$1 WHERE id=$2',[JSON.stringify(switched),'main']);
 assert.equal((await fetch(url,{headers:{Cookie:'tl_session=token-u0'}})).status,404);
 assert.equal(switched.leads[0].libertana.pdfFields.Address,'456 Fictional Saved Street');
 switched=execute(switched,'u0',{op:'updateLead',expectedVersion:switched.leads[0].version,args:[switched.leads[0].id,{payer:'CalAIM Community Supports'}]});
 await app.store.query('UPDATE app_state SET data=$1 WHERE id=$2',[JSON.stringify(switched),'main']);
 const restored=await read();assert.equal(restored.getForm().getTextField('Address').getText(),'456 Fictional Saved Street');

 }finally{await app.close();rmSync(folder,{recursive:true,force:true});}
});

test('blank packet contact fields still autofill a newly saved case-management contact',()=>{const l={first:'Fictional',last:'Resident',caller:{rel:'Case manager',name:'Fictional Case Manager',email:'case@example.invalid'},libertana:{fields:{recipientEmail:'',recipientName:''}}};const v=libertana.values(l);assert.equal(v.recipientEmail,'case@example.invalid');assert.equal(v.recipientName,'Fictional Case Manager');assert.match(libertana.email(l,{name:'Fictional Staff'}).body,/reply email with the signed PDF/);});

test('remaining packet fields and consent choices are editable and survive saving without marking signatures complete',async()=>{
 const {prepareLibertanaPDF}=await import('../server/libertana-pdf.mjs');
 const pdf=await PDFDocument.load(await prepareLibertanaPDF({name:'Fictional Resident',program:'ALWP'})),form=pdf.getForm();
 for(const f of form.getFields())if(f.constructor.name!=='PDFSignature')assert.equal(f.isReadOnly(),false);
 form.getTextField('Tharon_release_names_family').setText('Fictional Family Contact');
 form.getTextField('Tharon_services_patient_relationship_or_title').setText('Daughter');
 form.getTextField('Tharon_waitlist_patient_date').setText('11/12/2026');
 form.getRadioGroup('Tharon_service_program').select('CCT');
 form.getCheckBox('Tharon_release_scope_medical').check();
 const saved=await PDFDocument.load(await pdf.save()),f=saved.getForm();
 assert.equal(saved.getPageCount(),8);assert.equal(f.getTextField('Members Name').getText(),'Fictional Resident');
 assert.equal(f.getTextField('Tharon_release_names_family').getText(),'Fictional Family Contact');
 assert.equal(f.getTextField('Tharon_services_patient_relationship_or_title').getText(),'Daughter');
 assert.equal(f.getTextField('Tharon_waitlist_patient_date').getText(),'11/12/2026');
 assert.equal(f.getRadioGroup('Tharon_service_program').getSelected(),'CCT');assert.equal(f.getCheckBox('Tharon_release_scope_medical').isChecked(),true);
 assert.equal(f.getTextField('Tharon_services_patient_signature').getText(),undefined);
});

test('in-app PDF edits persist as editable values, synchronize repeated names and keep signature verification open',async()=>{
 const {prepareLibertanaPDF}=await import('../server/libertana-pdf.mjs');
 const packet={fields:{},signatures:{},reviewed:true};libertana.applyPDFEdits(packet,{'Tharon_page2_name':'Fictional Edited','Address':'123 Fictional Avenue','Date of Birth':'4/2/1950','Tharon_release_scope_medical':true});
 assert.equal(packet.fields.name,'Fictional Edited');assert.equal(packet.fields.address,'123 Fictional Avenue');assert.equal(packet.fields.dob,'1950-04-02');assert.equal(packet.reviewed,false);
 libertana.validate(packet,{files:[]});const pdf=await PDFDocument.load(await prepareLibertanaPDF(packet.fields,packet.pdfFields)),form=pdf.getForm();
 assert.equal(form.getTextField('Members Name').getText(),'Fictional Edited');assert.equal(form.getTextField('Tharon_page5_name').getText(),'Fictional Edited');assert.equal(form.getTextField('Address').getText(),'123 Fictional Avenue');assert.equal(form.getCheckBox('Tharon_release_scope_medical').isChecked(),true);
 assert.throws(()=>libertana.validate({...packet,pdfFields:{Address:123}},{files:[]}),/editable PDF/);
 await assert.rejects(()=>prepareLibertanaPDF({}, {unrecognized:'bad'}),/cannot be edited/);
});

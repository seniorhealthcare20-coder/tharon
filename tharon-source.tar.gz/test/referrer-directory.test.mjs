import test from 'node:test';import assert from 'node:assert/strict';import {initialState,execute,engine} from '../server/engine.mjs';
test('saved referrers persist across users, are source-specific and deduplicate without changing existing names',()=>{
 let s=execute(initialState(false),'u3',{op:'addReferrer',createdId:'ref_directory_test',args:['SNF',"Alex’s Nursing Home"]});
 assert.equal(s.referrers.length,1);assert.equal(s.referrers[0].name,"Alex’s Nursing Home");assert.equal(s.referrers[0].createdBy,'u3');
 s=execute(s,'u2',{op:'addReferrer',createdId:'ref_directory_duplicate',args:['SNF',"  alex’s   nursing home  "]});assert.equal(s.referrers.length,1);
 s=execute(s,'u1',{op:'addReferrer',createdId:'ref_directory_hospital',args:['Hospital',"Alex’s Nursing Home"]});assert.equal(s.referrers.length,2);
 const loaded=JSON.parse(JSON.stringify(s)),tl=engine(loaded,'u2');assert.equal(tl.S.referrers.filter(r=>r.source==='SNF').length,1);assert.equal(tl.S.leads.length,0);
 assert.throws(()=>execute(s,'u3',{op:'addReferrer',args:['not-a-source','Name']}),/source/);assert.throws(()=>execute(s,'u3',{op:'addReferrer',args:['SNF','x'.repeat(201)]}),e=>e.status===422);
});
test('saving a new referral remembers its referrer and later saves do not erase or duplicate it',()=>{
 let s=execute(initialState(false),'u0',{op:'createLead',createdId:'L_directory_lead',args:[{first:'Fictional',last:'Directory',building:'hallmark',payer:'ALW waiver',rep:'u3',source:'SNF',sourceDetail:'Example Skilled Nursing'}]});
 assert.equal(s.referrers.length,1);assert.equal(s.referrers[0].name,'Example Skilled Nursing');
 s=execute(s,'u3',{op:'updateLead',expectedVersion:1,args:['L_directory_lead',{sourceDetail:'Example Skilled Nursing'}]});assert.equal(s.referrers.length,1);
 s=execute(s,'u3',{op:'updateLead',expectedVersion:2,args:['L_directory_lead',{sourceDetail:'Another Example SNF'}]});assert.equal(s.referrers.length,2);assert.equal(s.referrers[0].name,'Example Skilled Nursing');
});

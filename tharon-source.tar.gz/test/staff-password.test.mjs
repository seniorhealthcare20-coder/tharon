import test from 'node:test';
import assert from 'node:assert/strict';
import {mkdtempSync,rmSync} from 'node:fs';
import {tmpdir} from 'node:os';
import path from 'node:path';
import {createHmac} from 'node:crypto';
import {createApplication} from '../server/index.mjs';
import {passwordHash,hash} from '../server/security.mjs';

test('admin provisions or resets staff sign-in without activation; reset revokes old access',async()=>{
 const folder=mkdtempSync(path.join(tmpdir(),'tharon-password-')),secret='test-session-secret',csrf='test-csrf';
 const app=await createApplication({env:{NODE_ENV:'test',APP_MODE:'live',PHI_APPROVED:'true',DATABASE_URL:'',SQLITE_PATH:path.join(folder,'app.sqlite'),SESSION_SECRET:secret,APP_ORIGIN:''},schedule:false});
 await new Promise(r=>app.server.listen(0,'127.0.0.1',r));const origin='http://127.0.0.1:'+app.server.address().port;
 const sessionHash=t=>createHmac('sha256',secret).update(t).digest('hex');
 for(const uid of ['u0','u1'])await app.store.query('INSERT INTO sessions (token_hash,user_id,expires_at,csrf) VALUES ($1,$2,$3,$4)',[sessionHash(uid),uid,Date.now()+60000,csrf]);
 const post=(p,data,uid='u0',withCsrf=true)=>fetch(origin+p,{method:'POST',headers:{Origin:origin,Cookie:'tl_session='+uid,...(withCsrf?{'X-CSRF-Token':csrf}:{}),'Content-Type':'application/json'},body:JSON.stringify(data)});
 const password='fictional-new-staff-password';
 try{
  assert.equal((await post('/api/users/password',{userId:'u1',password},'u1')).status,403);
  assert.equal((await post('/api/users/password',{userId:'u1',password},'u0',false)).status,403);
  assert.equal((await post('/api/users/password',{userId:'u0',password})).status,422);
  assert.equal((await post('/api/users/password',{userId:'u1',password:'short'})).status,422);
  await app.store.query('UPDATE users SET password_hash=$1 WHERE id=$2',[passwordHash('fictional-old-staff-password'),'u1']);
  await app.store.query('INSERT INTO invitations (token_hash,user_id,expires_at) VALUES ($1,$2,$3)',[hash('test-invite-that-must-be-revoked'),'u1',Date.now()+60000]);
  const stateBefore=(await app.store.query('SELECT data FROM app_state'))[0].data;
  assert.equal((await post('/api/users/password',{userId:'u1',password})).status,200);
  assert.equal((await app.store.query('SELECT * FROM sessions WHERE user_id=$1',['u1'])).length,0);
  assert.equal((await app.store.query('SELECT * FROM invitations WHERE user_id=$1',['u1'])).length,0);
  assert.equal((await post('/auth/login',{email:'mwilliams@tharongroup.com',password})).status,200);
  assert.equal((await post('/auth/login',{email:'mwilliams@tharongroup.com',password:'fictional-old-staff-password'})).status,401);
  assert.equal((await post('/api/users/password',{userId:'u2',password})).status,200);
  assert.equal((await post('/auth/login',{email:'ofielder@tharongroup.com',password})).status,200);
  assert.equal((await app.store.query('SELECT data FROM app_state'))[0].data,stateBefore);
  const audits=await app.store.query('SELECT * FROM audit_log');assert.ok(audits.some(a=>a.action==='staff.password_set'));assert.ok(!JSON.stringify(audits).includes(password));
 }finally{await app.close();rmSync(folder,{recursive:true,force:true});}
});

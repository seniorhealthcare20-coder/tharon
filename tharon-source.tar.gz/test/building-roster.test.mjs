import test from 'node:test';
import assert from 'node:assert/strict';
import vm from 'node:vm';
import {readFileSync} from 'node:fs';
import {initialState,execute} from '../server/engine.mjs';
const read=f=>readFileSync(new URL('../'+f,import.meta.url),'utf8');
test('Pasadena profiles are empty and can receive leads',()=>{
 let s=initialState(false);
 for(const [id,name,alias] of [['bellevue','Bella View','Bella Vista'],['lincoln','Lincoln Grove','Lincoln']]){
  const b=s.buildings.find(b=>b.id===id);assert.equal(b.name,name);assert.equal(b.city,'Pasadena');assert.ok(b.aliases.includes(alias));assert.equal(b.occupied,null);assert.equal(b.licensed,null);
  s=execute(s,'u1',{op:'createLead',createdId:'L_test_'+id,args:[{first:'Sample',last:id,building:id,rep:'u1'}]});
  assert.equal(s.leads.find(l=>l.id==='L_test_'+id).building,id);
 }
});
test('existing browser data gains profiles once without replacing saved data',()=>{
 const previous=initialState(true);previous.buildings=previous.buildings.filter(b=>!['bellevue','lincoln'].includes(b.id));previous.buildings[0].occupied=42;
 const ctx={Date,JSON,Math,URLSearchParams,console,localStorage:{getItem:()=>JSON.stringify(previous),setItem:()=>{}}};ctx.window=ctx;vm.createContext(ctx);
 for(const f of ['data.js','roster.js','api.js'])vm.runInContext(read('site/'+f),ctx);
 assert.equal(ctx.TL.S.buildings.length,19);assert.equal(ctx.TL.S.buildings[0].occupied,42);assert.deepEqual(JSON.parse(JSON.stringify(ctx.TL.S.leads)),previous.leads);
 const bella=ctx.TL.S.buildings.find(b=>b.id==='bellevue');bella.name='Bellevue View';bella.occupied=7;
 ctx.TL_SYNC_BUILDINGS(ctx.TL.S);assert.equal(ctx.TL.S.buildings.length,19);assert.equal(bella.name,'Bella View');assert.equal(bella.occupied,7);assert.ok(bella.aliases.includes('Bellevue View'));
});

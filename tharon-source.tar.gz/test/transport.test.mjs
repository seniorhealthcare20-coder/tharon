import test from 'node:test';
import assert from 'node:assert/strict';
import vm from 'node:vm';
import {readFileSync} from 'node:fs';
import {randomUUID} from 'node:crypto';
import { initialState,execute,scoped } from '../server/engine.mjs';
const source=f=>readFileSync(new URL('../site/'+f,import.meta.url),'utf8');

test('rapid client edits stay ordered, retain IDs, and reach shared storage without localStorage',async()=>{
 let server=initialState(false),release;const gate=new Promise(r=>release=r),commands=[];let persisted=0;
 const ctx={Date,JSON,Math,URLSearchParams,console,structuredClone,crypto:{randomUUID},Event,
  TL_BOOT:{state:scoped(server,'u1'),csrf:'test'},localStorage:{getItem:()=>null,setItem:()=>persisted++},
  document:{addEventListener:()=>{},dispatchEvent:()=>{},getElementById:()=>null,activeElement:null},
  navigator:{onLine:true},location:{},setInterval:()=>0,setTimeout,addEventListener:()=>{},
  fetch:async(url,opts)=>{assert.equal(url,'/api/commands');const command=JSON.parse(opts.body);commands.push(command);if(commands.length===1)await gate;
   server=execute(server,'u1',command);return {ok:true,status:200,json:async()=>({state:scoped(server,'u1')})};}};
 ctx.window=ctx;vm.createContext(ctx);for(const f of ['data.js','api.js','remote.js'])vm.runInContext(source(f),ctx,{filename:f});
 const lead=ctx.TL.createLead({first:'Fictional',last:'Transport',rep:'u1',building:'riverside'});
 ctx.TL.updateLead(lead.id,{notes:'Second quick edit'});ctx.TL.setStage(lead.id,'contacted');release();await ctx.TL.flush();
 assert.equal(server.leads.length,1);assert.equal(server.leads[0].id,lead.id);assert.equal(server.leads[0].notes,'Second quick edit');assert.equal(server.leads[0].stage,'contacted');assert.equal(server.leads[0].version,3);
 assert.deepEqual(commands.map(c=>c.expectedVersion),[undefined,1,2]);assert.equal(persisted,0);assert.equal(ctx.TLRemote.pending,0);
});

test('saved preview leads survive a calendar day change',()=>{
 const store={},base=Date.now();let offset=0;
 class Clock extends Date{constructor(...args){super(...(args.length?args:[base+offset]));}static now(){return base+offset;}}
 function boot(){const c={Date:Clock,JSON,Math,URLSearchParams,console,localStorage:{getItem:k=>store[k]||null,setItem:(k,v)=>store[k]=v}};c.window=c;vm.createContext(c);for(const f of ['data.js','api.js'])vm.runInContext(source(f),c);return c;}
 let c=boot();const l=c.TL.createLead({first:'Fictional',last:'Overnight',building:'b1'});offset=86400000;c=boot();assert.ok(c.TL.S.leads.some(x=>x.id===l.id&&x.last==='Overnight'));
});

test('a shared follow-up saves its outcome and one stable next-task ID with version checks',async()=>{
 const id='L_'+randomUUID();let server=execute(initialState(false),'u1',{op:'createLead',createdId:id,args:[{first:'Fictional',last:'Followup Transport',building:'sierra',payer:'Private pay'}]});
 server.leads[0].created='2020-01-01T10:00';const commands=[];
 const ctx={Date,JSON,Math,URLSearchParams,console,structuredClone,crypto:{randomUUID},Event,TL_BOOT:{state:scoped(server,'u1'),csrf:'test'},localStorage:{getItem:()=>null,setItem:()=>assert.fail('Shared records must not enter localStorage')},document:{addEventListener:()=>{},dispatchEvent:()=>{},getElementById:()=>null,activeElement:null},navigator:{onLine:true},location:{},setInterval:()=>0,setTimeout,addEventListener:()=>{},fetch:async(url,opts)=>{assert.equal(url,'/api/commands');const command=JSON.parse(opts.body);commands.push(command);server=execute(server,'u1',command);return {ok:true,status:200,json:async()=>({state:scoped(server,'u1')})};}};
 ctx.window=ctx;vm.createContext(ctx);for(const f of ['data.js','api.js','remote.js'])vm.runInContext(source(f),ctx,{filename:f});
 const task=ctx.TL.allReminders('u1').find(x=>x.rule==='new_first_call');
 const result=ctx.TL.resolveTask(task.id,{outcome:'no_answer',note:'Fictional voicemail outcome.',nextAction:'Call again in three days',nextDate:ctx.TL.addDays(3)});await ctx.TL.flush();
 assert.equal(commands.length,1);assert.equal(commands[0].expectedVersion,1);assert.equal(server.tasks.length,1);assert.equal(server.tasks[0].id,result.nextTask.id);assert.equal(server.leads[0].stage,'new');assert.equal(server.leads[0].version,2);assert.equal(ctx.TLRemote.pending,0);
});


test('background polls preserve the screen when unchanged and skip stale concurrent responses',async()=>{
 let server=initialState(false),renders=0,requests=0,release;
 const ctx={Date,JSON,Math,URLSearchParams,console,structuredClone,crypto:{randomUUID},Event,
 TL_BOOT:{state:scoped(server,'u0'),csrf:'test'},localStorage:{getItem:()=>null,setItem:()=>{}},
 document:{addEventListener:()=>{},dispatchEvent:()=>renders++,getElementById:id=>id==='modal'?{hidden:true}:null,activeElement:null},navigator:{onLine:true},location:{},setInterval:()=>0,setTimeout,addEventListener:()=>{},
 fetch:async()=>{requests++;const state=scoped(server,'u0');if(release)await release;return {ok:true,status:200,json:async()=>({state})};}};
 ctx.window=ctx;vm.createContext(ctx);for(const f of ['data.js','api.js','remote.js'])vm.runInContext(source(f),ctx);
 await ctx.TLRemote.refresh();assert.equal(renders,0,'unchanged polls must not clear invitations or move the screen');
 server.revision++;await ctx.TLRemote.refresh();assert.equal(renders,1,'new shared data still arrives');
 release=new Promise(r=>{ctx.finish=r;});const poll=ctx.TLRemote.refresh();await ctx.TLRemote.refresh();assert.equal(requests,3,'overlapping polls are skipped');ctx.finish();await poll;
 ctx.document.activeElement={tagName:'INPUT'};await ctx.TLRemote.refresh();assert.equal(requests,3,'typing is uninterrupted');
});

test('uncertain client save stays visible and retries the identical command after a lost committed response',async()=>{
 let state=initialState(false),drop=true;const receipts=new Set(),ids=[],sync={dataset:{},textContent:''};
 const ctx={Date,JSON,Math,URLSearchParams,console,structuredClone,crypto:{randomUUID},Event,CustomEvent,
 TL_BOOT:{state:scoped(state,'u1'),csrf:'test'},localStorage:{getItem:()=>null,setItem:()=>assert.fail('resident records must not be cached')},document:{addEventListener(){},dispatchEvent(){},getElementById:id=>id==='syncStatus'?sync:null,activeElement:null},navigator:{onLine:true},location:{},setInterval:()=>0,setTimeout,addEventListener(){},fetch:async(url,opts)=>{const cmd=JSON.parse(opts.body);ids.push(cmd.id);if(!receipts.has(cmd.id)){state=execute(state,'u1',cmd);receipts.add(cmd.id);}if(drop){drop=false;throw Error('Synthetic lost response after commit');}return {ok:true,status:200,json:async()=>({state:scoped(state,'u1')})};}};
 ctx.window=ctx;vm.createContext(ctx);for(const f of ['data.js','api.js','remote.js'])vm.runInContext(source(f),ctx);ctx.TL.createLead({first:'Synthetic',last:'Uncertain',building:'hallmark',payer:'Other'});await assert.rejects(ctx.TL.flush(),/has not reached/);assert.equal(state.leads.length,1);assert.equal(ctx.TLRemote.pending,1);assert.equal(ctx.TLRemote.broken,true);assert.match(sync.textContent,/Connection lost/);await ctx.TLRemote.retry();await ctx.TL.flush();assert.equal(ctx.TLRemote.pending,0);assert.equal(state.leads.length,1);assert.equal(ids[0],ids[1]);assert.equal(sync.textContent,'Saved to shared database');
});

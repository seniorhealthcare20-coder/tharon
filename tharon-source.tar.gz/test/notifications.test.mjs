import test from 'node:test';
import assert from 'node:assert/strict';
import webpush from 'web-push';
import { validateSubscription } from '../server/notifications.mjs';
test('push subscriptions allow supported HTTPS providers and reject server-side request forgery',()=>{
 const s={endpoint:'https://web.push.apple.com/test-fixture-not-a-real-subscription',keys:{p256dh:webpush.generateVAPIDKeys().publicKey,auth:Buffer.alloc(16,1).toString('base64url')}};
 assert.equal(validateSubscription(s).endpoint,s.endpoint);
 for(const endpoint of ['http://web.push.apple.com/x','https://127.0.0.1/x','https://169.254.169.254/x','https://web.push.apple.com.evil.example/x','https://user:secret@web.push.apple.com/x','https://web.push.apple.com:8443/x'])assert.throws(()=>validateSubscription({...s,endpoint}),e=>e.status===422);
});

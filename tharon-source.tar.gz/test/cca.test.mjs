import test from 'node:test';
import assert from 'node:assert/strict';
import {initialState,execute,engine} from '../server/engine.mjs';
test('CCA is independent of payer, persists on edit, and exports with the lead',()=>{
 let state=execute(initialState(false),'u0',{op:'createLead',createdId:'L_cca_test',args:[{first:'Fictional',last:'Provider',building:'hallmark',rep:'u2',cca:'Libertana',payer:'Other'}]});
 let tl=engine(state,'u0');assert.equal(tl.Lead('L_cca_test').cca,'Libertana');assert.equal(tl.Lead('L_cca_test').payer,'Other');assert.equal(tl.toApi(tl.Lead('L_cca_test')).cca,'Libertana');
 state=execute(state,'u0',{op:'updateLead',args:['L_cca_test',{cca:'Master Care'}],expectedVersion:1});tl=engine(state,'u0');assert.equal(tl.Lead('L_cca_test').cca,'Master Care');assert.equal(tl.Lead('L_cca_test').rep,'u2');
});

import test from 'node:test';
import assert from 'node:assert/strict';
import vm from 'node:vm';
import fs from 'node:fs';
import {initialState,execute,engine,migrateCountyRoadmaps} from '../server/engine.mjs';
const ctx={window:{}};vm.createContext(ctx);vm.runInContext(fs.readFileSync(new URL('../site/libertana.js',import.meta.url),'utf8'),ctx);const P=ctx.window.TLLibertana;
function fixture(){return execute(initialState(false),'u0',{op:'createLead',createdId:'L_libertana_test',args:[{first:'Fictional',last:'Resident',building:'crenshaw',rep:'u2',payer:'CalAIM Community Supports',cca:'Libertana',caller:{name:'Case Manager',rel:'Case manager',email:'case@example.invalid',phone:'5550101234'}}]});}
function command(s,op,args){return execute(s,'u0',{op,expectedVersion:s.leads[0].version,args:[s.leads[0].id,...args]});}
test('Libertana packet requires both LA County and CalAIM, regardless of the provider name',()=>{
 const l=fixture().leads[0];
 assert.equal(P.applicable(l,{county:'Los Angeles'}),true);
 assert.equal(P.applicable({...l,payer:'ALW waiver'},{county:'Los Angeles'}),false);
 assert.equal(P.applicable({...l,payer:'Private pay'},{county:'Los Angeles'}),false);
 assert.equal(P.applicable(l,{county:'Kern'}),false);
 assert.equal(P.applicable(l,{county:'Riverside'}),false);
 const old={...l,referenceDocuments:[...l.referenceDocuments],payer:'ALW waiver'};
 P.syncReference(old,{county:'Los Angeles'});assert.equal(old.referenceDocuments[0].active,false);
 assert.equal(P.needsAttention(old,{county:'Los Angeles'}),false);
});
test('Libertana packet is first, existing workflow migration preserves confirmations, and age/contact do not invent patient details',()=>{
 const s=fixture(),l=s.leads[0];assert.equal(engine(s,'u0').countySummary(l).next.key,'libertana_packet');delete l.countyWorkflow.steps.libertana_packet;l.countyWorkflow.steps.authorization.status='done';assert.equal(migrateCountyRoadmaps(s),1);assert.equal(l.countyWorkflow.steps.authorization.status,'done');assert.equal(l.countyWorkflow.steps.libertana_packet.status,'not_started');assert.equal(migrateCountyRoadmaps(s),0);
 const v=P.values({...l,age:76});assert.equal(v.phone,'');assert.equal(v.dob,'');assert.equal(v.recipientEmail,'case@example.invalid');assert.equal(v.currentCounty,undefined);assert.ok(P.missing(l).includes('Date of birth'));assert.equal(P.applicable({...l,cca:'Other Provider'},{county:'Los Angeles'}),true);assert.equal(l.referenceDocuments.length,1);assert.equal(l.referenceDocuments[0].url,P.SOURCE);
});
test('prepared or emailed packets cannot complete the milestone without attached PDF and every verified signature',()=>{
 let s=fixture();const patch={status:'done',owner:'u2',due:null,note:'Reviewed'};assert.throws(()=>command(s,'setCountyStep',['libertana_packet',patch]),/signed PDF/);
 let p={fields:{name:'Fictional Resident'},signatures:{},reviewed:false,preparedAt:new Date().toISOString(),sentAt:new Date().toISOString()};s=command(s,'updateLead',[{libertana:p}]);assert.equal(P.complete(s.leads[0]),false);assert.throws(()=>command(s,'setCountyStep',['libertana_packet',patch]),/signed PDF/);
 assert.throws(()=>command(s,'updateLead',[{libertana:{...p,signedFileId:'not_attached'}}]),/Attach the signed PDF/);
 s.leads[0].files=[{id:'signed',type:'application/pdf'}];p={...p,signedFileId:'signed',reviewed:true,signatures:Object.fromEntries(P.SIGNATURES.map(([k])=>[k,true]))};s=command(s,'updateLead',[{libertana:p}]);s=command(s,'setCountyStep',['libertana_packet',patch]);assert.equal(engine(s,'u0').countySummary(s.leads[0]).next.key,'building_fit');
 s.leads[0].files=[];assert.equal(engine(s,'u0').countySummary(s.leads[0]).next.key,'libertana_packet');assert.equal(engine(s,'u0').countySummary(s.leads[0]).ready,false);
});
test('packet data is validated and the approved email includes specific missing fields without manufacturing consent',()=>{
 const s=fixture();assert.throws(()=>command(s,'updateLead',[{libertana:null}]),/Invalid Libertana/);assert.throws(()=>command(s,'updateLead',[{libertana:{fields:{dob:'2026-02-31'},signatures:{}}}]),/date of birth/);const d=P.email(s.leads[0],{name:'Fictional Staff',email:'staff@example.invalid'});assert.equal(d.subject,'Libertana form — signature requested');assert.deepEqual(Array.from(d.cc),['mwilliams@tharongroup.com','ofielder@tharongroup.com']);assert.match(d.body,/Hi Case Manager,/);assert.match(d.body,/Date of birth/);assert.match(d.body,/Please help arrange for Fictional Resident or their representative/);assert.equal(P.values(s.leads[0]).authority,undefined);
});

test('every new LA County CalAIM lead receives one current packet link; changing provider does not remove it',()=>{let s=fixture();s=command(s,'updateLead',[{cca:'Different provider'}]);assert.equal(s.leads[0].referenceDocuments.filter(d=>d.active).length,1);assert.equal(s.leads[0].referenceDocuments[0].url,P.SOURCE);assert.equal(engine(s,'u0').countySummary(s.leads[0]).next.key,'libertana_packet');migrateCountyRoadmaps(s);assert.equal(s.leads[0].referenceDocuments.length,1);});

test('all four LA County communities expose the same fillable packet and manual email controls',()=>{
 for(const building of ['crenshaw','bellevue','lincoln','plaza']){
  const s=execute(initialState(false),'u0',{op:'createLead',createdId:'L_la_'+building,args:[{first:'Synthetic',last:'Countycheck',building,payer:'CalAIM Community Supports'}]}),tl=engine(s,'u0'),l=tl.S.leads[0];
  assert.equal(tl.B(building).county,'Los Angeles');
  assert.equal(P.applicable(l,tl.B(building)),true);
  assert.equal(l.referenceDocuments.filter(d=>d.active).length,1);
  const ui={window:{TL:tl,TLLibertana:P},document:{addEventListener(){}}};vm.createContext(ui);vm.runInContext(fs.readFileSync(new URL('../site/libertana-ui.js',import.meta.url),'utf8'),ui);
  const html=ui.window.TLLibertanaUI.card(l,true);
  assert.match(html,/Open and fill form/);assert.match(html,/Download fillable PDF/);assert.match(html,/Email signature request/);
  assert.equal(ui.window.TLLibertanaUI.card({...l,payer:'ALW waiver'},true),'');
 }
});

import test from 'node:test';import assert from 'node:assert/strict';import {mkdtempSync,rmSync} from 'node:fs';import {tmpdir} from 'node:os';import {join} from 'node:path';
import {initialState,execute} from '../server/engine.mjs';import {requestedProgram,correctStaffPrograms} from '../server/program-corrections.mjs';
function add(state,id,rep,notes='',cca='',payer='Private pay',building=rep==='u3'?'hallmark':'bellevue'){return execute(state,'u0',{op:'createLead',createdId:id,args:[{first:'Fictional',last:id,rep,notes,cca,payer,building}]});}
test('Olivia uses uploaded ALW notes or the explicit CalAIM default; no CCA guessing overrides her rule',()=>{
 assert.equal(requestedProgram({rep:'u2',notes:'Uploaded ALW referral',cca:'Beta'}).payer,'ALW waiver');
 assert.equal(requestedProgram({rep:'u2',notes:'Pending paperwork',cca:'Beta'}).payer,'CalAIM Community Supports');
 assert.equal(requestedProgram({rep:'u2',notes:'not ALW'}).payer,'CalAIM Community Supports');
});
test('Gaby uses explicit notes first and the approved Kern CCA mapping; unknown and conflicting evidence is flagged',()=>{
 const base={rep:'u3',building:'pointe'};
 assert.equal(requestedProgram({...base,notes:'ALW pending'}).payer,'ALW waiver');assert.equal(requestedProgram({...base,cca:'Master Care'}).payer,'CalAIM Community Supports');assert.equal(requestedProgram({...base,notes:'CCA: Beta'}).payer,'ALW waiver');assert.equal(requestedProgram({...base,notes:'Beta referral'}).payer,'ALW waiver');assert.equal(requestedProgram({...base,cca:'Libertana'}).payer,'ALW waiver');
 assert.ok(requestedProgram({...base,notes:'ALW',cca:'MasterCare'}).review);assert.ok(requestedProgram({...base,cca:'Unknown'}).review);assert.ok(requestedProgram({...base,notes:'Awaiting a callback'}).review);assert.equal(requestedProgram({...base,notes:'Private pay'}).payer,'Private pay');
});
test('existing records are corrected once, retaining documents, notes, building, attribution and previous workflow history',()=>{
 let state=add(initialState(false),'L_olivia_default','u2','Referral from SNF');state=add(state,'L_olivia_alw','u2','ALW pending');state=add(state,'L_gaby_beta','u3','Beta referral');state=add(state,'L_gaby_master','u3','','MasterCare');state=add(state,'L_gaby_unknown','u3');state=add(state,'L_morgan_keep','u1','','','Private pay','hallmark');
 const original=state.leads.find(l=>l.id==='L_olivia_default');original.files=[{id:'original-file'}];const notes=original.notes;const result=correctStaffPrograms(state);
 assert.equal(result.changed,4);assert.equal(result.needsReview,1);assert.equal(result.oliviaCalAIM,1);assert.equal(result.oliviaALW,1);assert.equal(result.gabyCalAIM,1);assert.equal(result.gabyALW,1);
 const l=state.leads.find(l=>l.id===original.id);assert.equal(l.notes,notes);assert.equal(l.files[0].id,'original-file');assert.equal(l.rep,'u2');assert.equal(l.originRep,'u2');assert.equal(l.building,'bellevue');assert.equal(l.countyWorkflow.program,'calaim');assert.equal(state.leads.find(l=>l.id==='L_morgan_keep').payer,'Private pay');assert.ok(state.leads.find(l=>l.id==='L_gaby_unknown').programCorrectionReview);
 const before=JSON.stringify(state);assert.equal(correctStaffPrograms(state),null);assert.equal(JSON.stringify(state),before);
});
test('ALW notes cannot silently convert a Crenshaw referral',()=>{const state=add(initialState(false),'L_crenshaw_alw','u2','ALW','','Other','crenshaw');const result=correctStaffPrograms(state);assert.equal(result.needsReview,1);assert.equal(state.leads[0].payer,'CalAIM Community Supports');});
test('production startup persists corrections and audit in the transaction and does not override later staff edits',async()=>{
 const {openStore}=await import('../server/store.mjs');const {createApplication}=await import('../server/index.mjs');const dir=mkdtempSync(join(tmpdir(),'tharon-staff-programs-')),file=join(dir,'state.sqlite');let state=add(initialState(false),'L_saved_olivia','u2','ALW referral');let store=await openStore(null,file);await store.query('INSERT INTO app_state(id,data) VALUES ($1,$2)',['main',JSON.stringify(state)]);await store.close();
 const env={NODE_ENV:'test',APP_MODE:'setup',SQLITE_PATH:file,DATABASE_URL:''};let app=await createApplication({schedule:false,env});let saved=JSON.parse((await app.store.query('SELECT data FROM app_state WHERE id=$1',['main']))[0].data);assert.equal(saved.leads[0].payer,'ALW waiver');assert.equal(saved.staffProgramCorrections.changed,1);assert.equal((await app.store.query('SELECT * FROM audit_log WHERE action=$1',['staff_programs.corrected'])).length,1);
 saved=execute(saved,'u0',{op:'updateLead',expectedVersion:saved.leads[0].version,args:[saved.leads[0].id,{payer:'CalAIM Community Supports'}]});await app.store.query('UPDATE app_state SET data=$1 WHERE id=$2',[JSON.stringify(saved),'main']);await app.close();app=await createApplication({schedule:false,env});const after=JSON.parse((await app.store.query('SELECT data FROM app_state WHERE id=$1',['main']))[0].data);assert.equal(after.leads[0].payer,'CalAIM Community Supports');await app.close();rmSync(dir,{recursive:true,force:true});
});

test('the original Olivia spreadsheet boilerplate is not an explicit ALW program; v2 repairs the earlier classification',()=>{
 const notes='CCA: Libertana. Age, care, contacts and ALW/CalAIM not provided. Source: handwritten list.';assert.equal(requestedProgram({rep:'u2',notes}).payer,'CalAIM Community Supports');
 let state=add(initialState(false),'L_placeholder_fix','u2',notes,'Libertana','ALW waiver');state.staffProgramCorrections={version:1};state.leads[0].programCorrectionReview='Prior review flag';const result=correctStaffPrograms(state);assert.equal(result.oliviaCalAIM,1);assert.equal(state.leads[0].payer,'CalAIM Community Supports');assert.equal(state.leads[0].programCorrectionReview,undefined);assert.equal(state.staffProgramCorrections.version,2);
});
test('the ALW roadmap identifies Gaby APS-letter referrals without treating missing details as approval',()=>{const decision=requestedProgram({rep:'u3',building:'pointe',notes:'Waiting on APS letter. Review: funding program not stated.'});assert.equal(decision.payer,'ALW waiver');});

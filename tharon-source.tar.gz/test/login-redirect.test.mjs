import test from 'node:test';
import assert from 'node:assert/strict';
import vm from 'node:vm';
import {readFileSync} from 'node:fs';
const source=readFileSync(new URL('../site/login.js',import.meta.url),'utf8');
for(const [query,target] of [['?next=%2Fvoice-test','/voice-test'],['?next=https://example.com','/'],['','/']])test('login returns to the allowed test screen: '+query,async()=>{
 const fields=new Map();const get=s=>{if(!fields.has(s))fields.set(s,{textContent:'',querySelector:()=>({disabled:false})});return fields.get(s);};
 const location={pathname:'/login',hash:'',search:query};
 const ctx={location,document:{querySelector:get},URLSearchParams,FormData:class{*[Symbol.iterator](){yield ['email','fictional@example.com'];yield ['password','fictional'];}},fetch:async()=>({ok:true,json:async()=>({ok:true})})};
 vm.createContext(ctx);await vm.runInContext(source,ctx);
 await get('#loginForm').onsubmit({preventDefault(){},currentTarget:{querySelector:()=>({disabled:false})}});
 assert.equal(location.href,target);
});

test('bare activation URL opens sign-in without asking for a setup code',async()=>{
 let target;const location={pathname:'/activate',hash:'',search:'',replace:p=>{target=p;}};
 const ctx={location,document:{querySelector(){throw Error('No setup form should be needed');}}};
 vm.createContext(ctx);await vm.runInContext(source,ctx);assert.equal(target,'/login');
});
test('expired staff links show sign-in with administrator password recovery',async()=>{
 const fields=new Map();const get=s=>{if(!fields.has(s))fields.set(s,{textContent:'',hidden:false});return fields.get(s);};
 const ctx={location:{pathname:'/activate',hash:'#expired-link',search:''},history:{replaceState(){}},document:{querySelector:get},fetch:async()=>({ok:false,json:async()=>({error:'This setup link is invalid or expired.'})})};
 vm.createContext(ctx);await vm.runInContext(source,ctx);assert.equal(get('#loginForm').hidden,false);assert.equal(get('#activateForm').hidden,true);assert.match(get('#message').textContent,/set your password in Team/);
});

test('authenticator field is hidden and disabled for staff and required only for administrator',async()=>{
 const fields=new Map(),listeners={};const email={value:'mwilliams@tharongroup.com',addEventListener:(name,fn)=>{listeners[name]=fn;}},code={value:'123456'};
 const form={elements:{email,code}},adminField={};fields.set('#loginForm',form);fields.set('#adminCodeField',adminField);
 const get=s=>{if(!fields.has(s))fields.set(s,{});return fields.get(s);};
 const ctx={location:{pathname:'/login',hash:'',search:''},document:{querySelector:get}};vm.createContext(ctx);await vm.runInContext(source,ctx);
 assert.equal(adminField.hidden,true);assert.equal(code.disabled,true);assert.equal(code.required,false);assert.equal(code.value,'');
 email.value=' Steven@TharonGroup.com ';listeners.input();assert.equal(adminField.hidden,false);assert.equal(code.disabled,false);assert.equal(code.required,true);
 email.value='mwilliams@tharongroup.com';listeners.change();assert.equal(adminField.hidden,true);assert.equal(code.required,false);
});

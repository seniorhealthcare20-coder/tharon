import test from 'node:test';
import assert from 'node:assert/strict';
import vm from 'node:vm';
import {readFileSync} from 'node:fs';
const source=readFileSync(new URL('../site/document-viewer.js',import.meta.url),'utf8');
function boot(fetcher=async()=>({ok:true,blob:async()=>new Blob(['fictional PDF'],{type:'application/pdf'})})){
 const events={},scrolls=[],requests=[],rendered=[];let dialog,backCount=0,destroyed=0;
 class Element{
  constructor(tag){this.tag=tag;this.style={};this.attrs={};this.children=[];this.clientWidth=390;this.listeners={};this.isConnected=true;}
  setAttribute(k,v){this.attrs[k]=v;}addEventListener(k,f){this.listeners[k]=f;}
  set innerHTML(v){this.html=v;this.selectors=Object.fromEntries(['h2','.document-close','.document-viewer-content','footer','.document-previous','.document-next','.document-page-count'].map(k=>[k,new Element(k)]));}
  querySelector(k){return this.selectors[k];}appendChild(c){this.children.push(c);}replaceChildren(...c){this.children=c;}
  showModal(){this.open=true;}close(){this.open=false;}remove(){this.removed=true;this.isConnected=false;}focus(opts){this.focusOptions=opts;}
  getContext(){return {};}
 }
 const document={baseURI:'https://app.example/#/lead/fictional',documentElement:{style:{overflow:''}},body:new Element('body'),head:new Element('head'),createElement:tag=>{const e=new Element(tag);if(tag==='dialog')dialog=e;return e;}};
 const location={href:document.baseURI,origin:'https://app.example'};
 const history={state:{kept:'existing state'},pushState(state,title,url){this.state=state;assert.equal(url,location.href);},back(){backCount++;this.state={kept:'existing state'};events.popstate?.();}};
 const pdf={numPages:3,getPage:async n=>({getViewport:({scale})=>({width:600*scale,height:800*scale}),render:opts=>{rendered.push({n,...opts});return {promise:Promise.resolve(),cancel(){}};}})};
 const window={scrollY:742,devicePixelRatio:3,scrollTo:(...p)=>scrolls.push(p),addEventListener:(k,f)=>events[k]=f,pdfjsLib:{GlobalWorkerOptions:{},getDocument:()=>({promise:Promise.resolve(pdf),destroy(){destroyed++;}})}};
 const context={window,document,location,history,URL,Uint8Array,AbortController,Math,Date,fetch:async(...args)=>{requests.push(args);return fetcher(...args);}};
 vm.createContext(context);vm.runInContext(source,context);
 return {api:window.TLDocumentViewer,opener:new Element('a'),dialog:()=>dialog,events,scrolls,requests,rendered,history,destroyed:()=>destroyed,backCount:()=>backCount,document};
}
test('PDF review stays on the lead, navigates pages, and close restores scroll and focus',async()=>{
 const b=boot();await b.api.open({url:'/api/files/fictional',name:'Example.pdf',opener:b.opener});const d=b.dialog();
 assert.equal(b.api.isOpen(),true);assert.equal(d.open,true);assert.equal(b.requests[0][1].credentials,'same-origin');
 assert.equal(b.rendered[0].n,1);assert.equal(d.querySelector('.document-previous').disabled,true);
 await d.querySelector('.document-next').onclick();assert.equal(b.rendered.at(-1).n,2);
 await d.querySelector('.document-next').onclick();assert.equal(d.querySelector('.document-next').disabled,true);
 d.querySelector('.document-close').onclick();assert.equal(b.api.isOpen(),false);assert.equal(d.removed,true);
 assert.deepEqual(b.scrolls,[[0,742]]);assert.equal(b.opener.focusOptions.preventScroll,true);assert.equal(b.document.documentElement.style.overflow,'');assert.equal(b.backCount(),1);assert.equal(b.destroyed(),1);
});
test('Back, Escape and close remain available while a file is loading; late responses do not reopen it',async()=>{
 let respond;const b=boot(()=>new Promise(resolve=>respond=resolve));const pending=b.api.open({url:'/api/files/fictional',name:'Example.pdf',opener:b.opener});
 let prevented=false;b.dialog().listeners.cancel({preventDefault(){prevented=true;}});
 assert.equal(prevented,true);assert.equal(b.requests[0][1].signal.aborted,true);assert.equal(b.api.isOpen(),false);
 respond({ok:true,blob:async()=>new Blob(['fictional'],{type:'application/pdf'})});await pending;assert.equal(b.rendered.length,0);
 const next=b.api.open({url:'/api/files/fictional',name:'Example.pdf',opener:b.opener});
 b.events.popstate();respond({ok:true,blob:async()=>new Blob(['fictional'],{type:'application/pdf'})});await next;assert.equal(b.api.isOpen(),false);
});
test('expired authorization shows an error inside the closable viewer and never renders file contents',async()=>{
 const b=boot(async()=>({ok:false,status:401}));await b.api.open({url:'/api/files/fictional',name:'Example.pdf',opener:b.opener});
 assert.match(b.dialog().querySelector('.document-viewer-content').children[0].textContent,/sign-in expired/);assert.equal(b.rendered.length,0);
 b.events.popstate();assert.equal(b.api.isOpen(),false);assert.deepEqual(b.scrolls,[[0,742]]);
});

import test from 'node:test';import assert from 'node:assert/strict';
import vm from 'node:vm';import {readFileSync} from 'node:fs';
import {initialState,execute,engine,countyRoadmap} from '../server/engine.mjs';
const base=(building='hallmark',payer='ALW waiver')=>execute(initialState(false),'u0',{op:'createLead',createdId:'L_progress_example',args:[{first:'Fictional',last:'Progress',building,payer,rep:['hallmark','carrington','pointe'].includes(building)?'u3':'u2',cca:'Example CCA',notes:'Original source note'}]});
const patch=(extra={})=>({assessment:'pending',approval:'waiting',reason:'',moveStatus:'none',moveDate:'',due:'2026-12-01',note:'',...extra});
test('existing profiles derive compact progress without inventing approvals, APS classification or waiting dates',()=>{const s=base(),l=s.leads[0],tl=engine(s,'u0');l.notes='AARP approval wants to move 12/1/26';let p=tl.referralSummary(tl.Lead(l.id));assert.equal(p.approval,'waiting');assert.equal(p.waitingSince,null);assert.equal(p.assessment,'pending');assert.equal(p.reason,'');assert.equal(l.referralProgress,undefined);});
test('waiting dates survive later updates and reason changes, and dated notes remain in the activity history',()=>{let s=base();const tl=engine(s,'u0'),l=tl.Lead('L_progress_example'),b=tl.B(l.building);const apply=tl.S;const fn=tl.setReferralProgress;fn(l.id,patch({assessment:'accepted',reason:'aps_letter',note:'Waiting for APS letter.'}));const first=l.referralProgress.waitingSince;assert.ok(first);fn(l.id,patch({assessment:'accepted',reason:'waitlist',note:'CCA called; slot still pending.'}));assert.equal(l.referralProgress.waitingSince,first);assert.ok(l.referralProgress.noteUpdatedAt);assert.ok(l.activity.some(a=>a.text.includes('Waiting for APS letter.')));assert.ok(l.activity.some(a=>a.text.includes('slot still pending')));assert.equal(l.notes,'Original source note');assert.ok(tl.referralSummary(l).next.includes('waitlist'));assert.equal(l.countyWorkflow.steps.informing_notice.status,'not_started');});
test('reported approval stays distinct from receipt and does not silently complete county requirements',()=>{let s=base();s=execute(s,'u0',{op:'setReferralProgress',expectedVersion:1,args:['L_progress_example',patch({assessment:'accepted',approval:'missing',note:'CCA reports approved by phone.'})]});let tl=engine(s,'u0'),l=tl.Lead('L_progress_example');assert.equal(tl.referralSummary(l).stage,'paperwork');assert.equal(l.countyWorkflow.steps.informing_notice.status,'pending');assert.equal(l.countyWorkflow.steps.slot_release.status,'not_started');s=execute(s,'u0',{op:'setReferralProgress',expectedVersion:2,args:[l.id,patch({assessment:'accepted',approval:'received',note:'Verified Informing Notice.'})]});tl=engine(s,'u0');l=tl.Lead(l.id);assert.equal(l.countyWorkflow.steps.informing_notice.status,'done');assert.equal(tl.referralSummary(l).stage,'county');assert.throws(()=>execute(s,'u0',{op:'setReferralProgress',expectedVersion:3,args:[l.id,patch({assessment:'accepted',approval:'received',moveStatus:'scheduled',moveDate:'2026-12-01'})]}),/county|Program details/i);});
test('save of details and progress is atomic, permission and version checked, and protects existing notes and attachments',()=>{let s=base();s.leads[0].files=[{id:'file_example',name:'Original.pdf'}];assert.throws(()=>execute(s,'u2',{op:'saveReferral',expectedVersion:1,args:['L_progress_example',{cca:'Changed'},patch()]}),e=>e.status===404);assert.throws(()=>execute(s,'u0',{op:'saveReferral',expectedVersion:0,args:['L_progress_example',{cca:'Changed'},patch()]}),e=>e.status===409);const before=JSON.stringify(s);assert.throws(()=>execute(s,'u0',{op:'saveReferral',expectedVersion:1,args:['L_progress_example',{cca:'Changed'},patch({due:'invalid'})]}));assert.equal(JSON.stringify(s),before);s=execute(s,'u0',{op:'saveReferral',expectedVersion:1,args:['L_progress_example',{cca:'Changed'},patch({note:'Checked today.',due:engine(s,'u0').T})]});assert.equal(s.leads[0].cca,'Changed');assert.equal(s.leads[0].notes,'Original source note');assert.equal(s.leads[0].files[0].id,'file_example');assert.equal(s.leads[0].version,2);assert.ok(engine(s,'u0').allReminders('all').some(t=>t.rule==='referral_progress'));});
test('private pay budget and program tiers remain independent, and reasons are program/county specific',()=>{const privateState=base('hallmark','Private pay'),tl=engine(privateState,'u0'),l=tl.Lead('L_progress_example');assert.equal(tl.referralSummary(l).privatePay,true);assert.throws(()=>tl.setReferralProgress(l.id,patch({reason:'aps_letter'})),/waiting reason/);assert.equal(tl.referralSummary(l).waiting,false);const la=base('bellevue','CalAIM Community Supports');const laTL=engine(la,'u0');assert.throws(()=>laTL.setReferralProgress('L_progress_example',patch({reason:'aps_letter'})),/waiting reason/);assert.ok(countyRoadmap.summary(la.leads[0],la.buildings.find(b=>b.id==='bellevue'),'2026-11-14').steps.some(s=>s.key==='libertana_submission'));});
test('moved-in status and post-move county tasks stay available without erasing prior records',()=>{const s=base();s.leads[0].stage='movein';const tl=engine(s,'u0');assert.equal(tl.referralSummary(tl.Lead('L_progress_example')).moveStatus,'moved');assert.ok(tl.countySummary(tl.Lead('L_progress_example')).steps.some(s=>s.key==='billing_review'));});

test('creating a waiting profile automatically records today and later updates preserve its start',()=>{
 const tl=engine(initialState(false),'u0');
 const l=tl.createLead({first:'Automatic',last:'Wait',building:'hallmark',payer:'ALW waiver',cca:'Example CCA',rep:'u3'},'Created for test',patch());
 assert.equal(l.referralProgress.waitingSince,tl.T);
 assert.equal(tl.referralSummary(l).waitingDays,0);
 tl.setReferralProgress(l.id,patch({reason:'decision',note:'Still waiting.'}));
 assert.equal(l.referralProgress.waitingSince,tl.T);
});
test('approval stops the counter even when paperwork is outstanding; reentering waiting starts separately',()=>{
 const tl=engine(base(),'u0'),id='L_progress_example';
 tl.setReferralProgress(id,patch());
 const l=tl.Lead(id),since=l.referralProgress.waitingSince;
 tl.setReferralProgress(id,patch({approval:'missing'}));
 assert.equal(tl.referralSummary(l).waiting,false);
 assert.equal(tl.referralSummary(l).waitingDays,null);
 assert.equal(l.referralProgress.waitHistory[0].since,since);
 tl.setReferralProgress(id,patch());
 assert.equal(tl.referralSummary(l).waitingSince,tl.T);
});
test('staff cannot supply or change the automatic waiting start through the server',()=>{
 const s=base();
 for(const waitingSince of ['', '2026-02-30', '2026-01-01']){
  const before=JSON.stringify(s);
  assert.throws(()=>execute(s,'u0',{op:'saveReferral',expectedVersion:1,args:['L_progress_example',{cca:'Changed'},patch({waitingSince})]}),/Invalid referral progress fields/);
  assert.equal(JSON.stringify(s),before);
 }
});
test('automatic waiting age advances by calendar days without a staff update',()=>{
 const tl=engine(initialState(false),'u0'),l=tl.createLead({first:'Automatic',last:'Age',building:'hallmark',payer:'ALW waiver',cca:'Example CCA',rep:'u3'},'',patch());
 const ctx={window:{TLRoadmap:countyRoadmap},Date};vm.createContext(ctx);vm.runInContext(readFileSync(new URL('../site/referral-progress.js',import.meta.url),'utf8'),ctx);
 assert.equal(ctx.window.TLReferral.summary(l,tl.B(l.building),tl.addDays(31)).waitingDays,31);
 assert.equal(l.referralProgress.waitingSince,tl.T);
});

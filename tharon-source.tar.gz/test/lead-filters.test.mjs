import test from 'node:test';import assert from 'node:assert/strict';
import {initialState,execute,engine} from '../server/engine.mjs';
function fixture(building='hallmark',payer='CalAIM Community Supports'){const id='L_filter_test';const state=execute(initialState(false),'u0',{op:'createLead',createdId:id,args:[{first:'Fictional',last:'Filter',building,payer,rep:'u2'}]});return {state,id};}
test('program filter excludes private pay, lost referrals and referrals waiting only on assessment or move-in',()=>{
 const {state,id}=fixture();let tl=engine(state,'u0');assert.equal(tl.leadMatchesFilter(tl.Lead(id),'awaiting-program'),true);
 const l=state.leads[0];for(const step of Object.values(l.countyWorkflow.steps))step.status='done';l.countyWorkflow.steps.building_fit.status='pending';tl=engine(state,'u0');assert.equal(tl.leadMatchesFilter(tl.Lead(id),'awaiting-program'),false);assert.equal(tl.leadMatchesFilter(tl.Lead(id),'assessment'),true);
 l.countyWorkflow.steps.authorization.status='pending';l.stage='lost';tl=engine(state,'u0');assert.equal(tl.leadMatchesFilter(tl.Lead(id),'awaiting-program'),false);
 const privateLead=fixture('hallmark','Private pay');tl=engine(privateLead.state,'u0');assert.equal(tl.leadMatchesFilter(tl.Lead(id),'awaiting-program'),false);
});
test('post-move-in Orange authorization remains findable, but an unfinished billing handoff alone is not awaiting approval',()=>{
 const {state,id}=fixture('crescendo');const l=state.leads[0];l.stage='movein';for(const step of Object.values(l.countyWorkflow.steps))step.status='done';l.countyWorkflow.steps.authorization.status='pending';let tl=engine(state,'u0');assert.equal(tl.leadMatchesFilter(tl.Lead(id),'awaiting-program'),true);
 l.countyWorkflow.steps.authorization.status='done';l.countyWorkflow.steps.billing_handoff.status='not_started';tl=engine(state,'u0');assert.equal(tl.leadMatchesFilter(tl.Lead(id),'awaiting-program'),false);
});
test('overdue, blocked and program-review filters use actual roadmap dates/statuses rather than generic lead stages',()=>{
 const {state,id}=fixture();let tl=engine(state,'u0');const l=state.leads[0];l.countyWorkflow.steps.building_fit.due=tl.addDays(-1);l.countyWorkflow.steps.building_fit.status='blocked';tl=engine(state,'u0');assert.equal(tl.leadMatchesFilter(tl.Lead(id),'blocked'),true);assert.equal(tl.leadMatchesFilter(tl.Lead(id),'overdue'),true);
 l.countyWorkflow.steps.building_fit.due=tl.T;tl=engine(state,'u0');assert.equal(tl.leadMatchesFilter(tl.Lead(id),'overdue'),false);
 const unknown=fixture('hallmark','Other');tl=engine(unknown.state,'u0');assert.equal(tl.leadMatchesFilter(tl.Lead(id),'needs-program'),true);assert.equal(tl.leadMatchesFilter(tl.Lead(id),'awaiting-program'),false);
 const excluded=fixture('oxnard');tl=engine(excluded.state,'u0');assert.equal(tl.leadMatchesFilter(tl.Lead(id),'needs-program'),true);
});

test('roadmap filters use the actual next section and distinguish county-specific actions',()=>{
 const {state,id}=fixture('hallmark');let tl=engine(state,'u0');assert.equal(tl.matchesRoadmap(tl.Lead(id),'2'),true);assert.equal(tl.matchesRoadmap(tl.Lead(id),'3'),false);const key=tl.roadmapActionId(tl.Lead(id));assert.match(key,/Kern\|building_fit$/);assert.equal(tl.matchesRoadmap(tl.Lead(id),'all',key),true);assert.equal(tl.matchesRoadmap(tl.Lead(id),'all',key.replace('Kern','Los Angeles')),false);
 state.leads[0].countyWorkflow.steps.building_fit.status='done';tl=engine(state,'u0');assert.equal(tl.matchesRoadmap(tl.Lead(id),'3'),true);assert.equal(tl.matchesRoadmap(tl.Lead(id),'2'),false);
});

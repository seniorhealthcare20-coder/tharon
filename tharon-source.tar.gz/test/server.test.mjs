import test from 'node:test';
import assert from 'node:assert/strict';
import { mkdtempSync,rmSync } from 'node:fs';
import { tmpdir } from 'node:os';
import path from 'node:path';
import { randomUUID } from 'node:crypto';
import { createApplication } from '../server/index.mjs';
import { initialState,execute,scoped,buildings,users } from '../server/engine.mjs';
import { totpCode,seal,unseal,hash } from '../server/security.mjs';

test('production roster is separate, has exactly the requested accounts, and starts empty',()=>{
 const s=initialState(false);assert.equal(s.buildings.length,19);assert.equal(s.leads.length,0);assert.equal(s.tasks.length,0);
 assert.deepEqual(users.map(u=>[u.email,u.role]),[['steven@tharongroup.com','admin'],['mwilliams@tharongroup.com','rep'],['ofielder@tharongroup.com','rep'],['gaby@thepointesummithills.com','rep'],['efrain@tharongroup.com','admin']]);
 assert.equal(new Set(buildings.map(b=>b.id)).size,19);assert.ok(buildings.every(b=>b.licensed===null&&b.occupied===null));
});
test('server enforces ownership, valid assignments, lost reasons, and version conflicts',()=>{
 let s=initialState(false);const id='L_'+randomUUID();s=execute(s,'u1',{op:'createLead',createdId:id,args:[{first:'Fictional',last:'Tester',building:'riverside',rep:'u1'}]});
 assert.throws(()=>execute(s,'u2',{op:'createLead',createdId:id,args:[{first:'Another',last:'Person',rep:'u2',building:'riverside'}]}),e=>e.status===409);
 assert.equal(s.leads[0].version,1);assert.equal(scoped(s,'u2').leads.length,1);assert.equal(scoped(s,'u0').leads.length,1);
 assert.throws(()=>execute(s,'u2',{op:'setTemp',args:[id,'cold'],expectedVersion:1}),e=>e.status===404);
 assert.throws(()=>execute(s,'u1',{op:'assign',args:[id,{rep:'u2'}],expectedVersion:1}),e=>e.status===403);
 assert.throws(()=>execute(s,'u1',{op:'assign',args:[id,{building:'made-up'}],expectedVersion:1}),e=>e.status===422);
 assert.throws(()=>execute(s,'u1',{op:'updateLead',args:[id,{role:'admin'}],expectedVersion:1}),e=>e.status===422);
 assert.throws(()=>execute(s,'u1',{op:'closeLead',args:[id,'lost'],expectedVersion:1}),/reason/i);
 assert.throws(()=>execute(s,'u1',{op:'setTemp',args:[id,'cold'],expectedVersion:0}),e=>e.status===409);
 s=execute(s,'u0',{op:'assign',args:[id,{rep:'u2',building:'hallmark'}],expectedVersion:1});assert.equal(scoped(s,'u1').leads.length,1);assert.equal(scoped(s,'u2').leads.length,1);
});
test('encrypted files detect tampering',()=>{const key=Buffer.alloc(32,9),cipher=seal(Buffer.from('fictional referral'),key);assert.equal(unseal(cipher,key).toString(),'fictional referral');const b=Buffer.from(cipher,'base64');b[15]^=1;assert.throws(()=>unseal(b.toString('base64'),key));});

test('HTTP activation, sign-in, CSRF, idempotency, shared visibility, encrypted files and reporting',async()=>{
 const folder=mkdtempSync(path.join(tmpdir(),'tharon-test-'));const setup='test-only-admin-setup-token-'+randomUUID();
 const app=await createApplication({env:{NODE_ENV:'test',APP_MODE:'live',PHI_APPROVED:'true',SQLITE_PATH:path.join(folder,'app.sqlite'),DATABASE_URL:'',APP_ORIGIN:'',ADMIN_SETUP_TOKEN:setup,REPORTING_TOKEN:'test-reporting-token'}});
 await new Promise(r=>app.server.listen(0,'127.0.0.1',r));const origin='http://127.0.0.1:'+app.server.address().port;
 async function call(p,{method='GET',data,cookie,csrf,headers={},raw}={}){const r=await fetch(origin+p,{method,redirect:'manual',headers:{Origin:origin,...(data?{'Content-Type':'application/json'}:{}),...(cookie?{Cookie:cookie}:{}),...(csrf?{'X-CSRF-Token':csrf}:{}),...headers},body:raw|| (data?JSON.stringify(data):undefined)});const text=await r.text();let body;try{body=JSON.parse(text);}catch{body=text;}return {status:r.status,body,cookie:r.headers.get('set-cookie')?.split(';')[0],headers:r.headers};}
 const password='fictional-test-password-only';
 try{
  assert.equal((await call('/api/state')).status,401);assert.equal((await call('/')).status,302);
  const info=await call('/auth/setup',{method:'POST',data:{token:setup}});assert.equal(info.status,200);assert.ok(info.body.totpSecret);
  assert.equal((await call('/auth/activate',{method:'POST',data:{token:setup,password,code:'000000'}})).status,422);
  assert.equal((await call('/auth/activate',{method:'POST',data:{token:setup,password,code:totpCode(info.body.totpSecret)}})).status,200);
  assert.equal((await call('/auth/setup',{method:'POST',data:{token:setup}})).status,403);
  const adminLogin=await call('/auth/login',{method:'POST',data:{email:users[0].email,password,code:totpCode(info.body.totpSecret)}});assert.equal(adminLogin.status,200);assert.ok(adminLogin.headers.get('set-cookie').includes('HttpOnly'));
  const admin={cookie:adminLogin.cookie,csrf:(await call('/api/state',{cookie:adminLogin.cookie})).body.csrf};
  assert.equal((await call('/api/users',{method:'POST',cookie:admin.cookie,data:{userId:'u1'}})).status,403);
  const invitation=await call('/api/users',{method:'POST',...admin,data:{userId:'u1'}});assert.equal(invitation.status,201);const repToken=invitation.body.url.split('#')[1];
  assert.equal((await call('/auth/activate',{method:'POST',data:{token:repToken,password}})).status,200);
  const repLogin=await call('/auth/login',{method:'POST',data:{email:users[1].email,password}});assert.equal(repLogin.status,200);
  const rep={cookie:repLogin.cookie,csrf:(await call('/api/state',{cookie:repLogin.cookie})).body.csrf};
  assert.equal((await call('/api/users',{...rep})).status,403);
  const expiry=Date.now()+120000;await app.store.query('UPDATE sessions SET expires_at=$1 WHERE user_id=$2',[expiry,'u1']);await call('/api/state',{...rep});assert.equal(Number((await app.store.query('SELECT expires_at FROM sessions WHERE user_id=$1',['u1']))[0].expires_at),expiry,'background polling does not extend inactivity');
  assert.equal((await call('/api/activity',{method:'POST',...rep})).status,200);assert.ok(Number((await app.store.query('SELECT expires_at FROM sessions WHERE user_id=$1',['u1']))[0].expires_at)>expiry);
  const create={id:randomUUID(),op:'createLead',createdId:'L_'+randomUUID(),args:[{first:'Fictional',last:'HTTP Tester',building:'hallmark',rep:'u1',caller:{name:'Fictional Tester',rel:'Self',phone:'5550000001',email:''}}]};
  let r=await call('/api/commands',{method:'POST',...rep,data:create});assert.equal(r.status,200);assert.equal(r.body.state.leads.length,1);assert.equal(r.body.state.leads[0].building,'hallmark');
  r=await call('/api/commands',{method:'POST',...rep,data:create});assert.equal(r.status,200);assert.equal(r.body.state.leads.length,1,'retried creation is idempotent');
  assert.equal((await call('/api/commands',{method:'POST',...rep,data:{id:randomUUID(),op:'updateLead',args:[create.createdId,{notes:'Test'}],expectedVersion:0}})).status,409);
  r=await call('/api/files',{method:'POST',...rep,headers:{'Content-Type':'application/pdf','X-File-Name':'fictional.pdf'},raw:Buffer.from('%PDF-fictional-content')});assert.equal(r.status,201);const file=r.body;
  const stored=(await app.store.query('SELECT ciphertext FROM files WHERE id=$1',[file.id]))[0];assert.ok(!stored.ciphertext.includes('fictional-content'));
  assert.equal((await call('/api/files/'+file.id,{...rep})).status,404,'pending files cannot be fetched by URL');
  r=await call('/api/commands',{method:'POST',...rep,data:{id:randomUUID(),op:'attachFile',args:[create.createdId,{...file,forms:[]}],expectedVersion:1}});assert.equal(r.status,200);
  r=await call('/api/files/'+file.id,{...rep});assert.equal(r.status,200);assert.equal(r.body,'%PDF-fictional-content');
  r=await call('/api/commands',{method:'POST',...admin,data:{id:randomUUID(),op:'assign',args:[create.createdId,{rep:'u2'}],expectedVersion:2}});assert.equal(r.status,200);
  assert.equal((await call('/api/state',{...rep})).body.state.leads.length,1);assert.equal((await call('/api/files/'+file.id,{...rep})).status,200);
  const report=await call('/api/reporting/buildings',{headers:{Authorization:'Bearer test-reporting-token'}});assert.equal(report.status,200);assert.equal(report.body.buildings.length,19);assert.ok(!JSON.stringify(report.body).includes('HTTP Tester'));
  const audits=await app.store.query('SELECT * FROM audit_log');assert.ok(audits.some(x=>x.action==='file.viewed'));assert.ok(!JSON.stringify(audits).includes('HTTP Tester'));
  const batch={id:randomUUID(),records:[{first:'Fictional',last:'Batch One',building:'sierra',rep:'u1'},{first:'Fictional',last:'Batch Two',building:'unknown',rep:'u1'}],skipDuplicates:true};
  assert.equal((await call('/api/import',{method:'POST',...rep,data:batch})).status,422);
  assert.equal((await call('/api/state',{...rep})).body.state.leads.length,1,'invalid batch saves no rows');
  batch.records[1].building='sierra';batch.records[1].rep='u2';
  r=await call('/api/import',{method:'POST',...rep,data:batch});assert.equal(r.status,200);assert.equal(r.body.imported,2);assert.ok(r.body.state.leads.filter(l=>l.id!==create.createdId).every(l=>l.rep==='u1'),'rep cannot import leads into another account');
  r=await call('/api/import',{method:'POST',...rep,data:batch});assert.equal(r.status,200);assert.equal(r.body.state.leads.length,3,'retry saves no duplicate rows');
  batch.records[0].last='Changed Batch';assert.equal((await call('/api/import',{method:'POST',...rep,data:batch})).status,409);
  batch.id=randomUUID();batch.records[0].last='Batch One';r=await call('/api/import',{method:'POST',...rep,data:batch});assert.equal(r.body.imported,0);assert.equal(r.body.skipped,2);
  assert.equal((await call('/api/logout',{method:'POST',...rep})).status,200);assert.equal((await call('/api/state',{...rep})).status,401);
 } finally{await app.close();rmSync(folder,{recursive:true,force:true});}
});


test('every new lead requires a real building and transfers keep the same profile',()=>{
 let s=initialState(false);const id='L_'+randomUUID();
 for(const building of [undefined,null,'','invented-building'])assert.throws(()=>execute(s,'u1',{op:'createLead',createdId:id,args:[{first:'Fictional',last:'Building Requirement',rep:'u1',building}]}),e=>e.status===422);
 s=execute(s,'u1',{op:'createLead',createdId:id,args:[{first:'Fictional',last:'Building Requirement',rep:'u1',building:'riverside'}]});
 assert.throws(()=>execute(s,'u1',{op:'assign',args:[id,{building:null}],expectedVersion:1}),e=>e.status===422);
 assert.throws(()=>execute(s,'u1',{op:'updateLead',args:[id,{building:''}],expectedVersion:1}),e=>e.status===422);
 s=execute(s,'u1',{op:'assign',args:[id,{building:'hallmark'}],expectedVersion:1});assert.equal(s.leads.length,1);assert.equal(s.leads[0].id,id);assert.equal(s.leads[0].building,'hallmark');assert.ok(s.leads[0].activity.some(a=>a.type==='assign'&&a.text.includes('Hallmark')));
});

test('sample entry opens without login while shared records remain private',async()=>{
 const folder=mkdtempSync(path.join(tmpdir(),'tharon-preview-'));
 const app=await createApplication({env:{NODE_ENV:'test',APP_MODE:'sample',SQLITE_PATH:path.join(folder,'app.sqlite'),DATABASE_URL:''}});
 await new Promise(r=>app.server.listen(0,'127.0.0.1',r));const origin='http://127.0.0.1:'+app.server.address().port;
 const get=p=>fetch(origin+p,{redirect:'manual'});
 try{
  for(const p of ['/','/login']){const r=await get(p);assert.equal(r.status,302);assert.equal(r.headers.get('location'),'/preview/');}
  assert.match(await (await get('/preview/')).text(),/sample data only/);
  assert.equal(await (await get('/preview/bootstrap.js')).text(),'');
  assert.match(await (await get('/preview/app.js')).text(),/use strict/);
  assert.match(await (await get('/login?staff=1')).text(),/loginForm/);
  assert.equal((await get('/api/state')).status,401);
  assert.equal((await fetch(origin+'/api/commands',{method:'POST',headers:{'Content-Type':'application/json'},body:'{}'})).status,401);
 }finally{await app.close();rmSync(folder,{recursive:true,force:true});}
});

test('production setup starts empty and permits account activation but blocks lead and audio intake',async()=>{
 const folder=mkdtempSync(path.join(tmpdir(),'tharon-setup-'));
 const app=await createApplication({env:{NODE_ENV:'test',APP_MODE:'setup',SQLITE_PATH:path.join(folder,'app.sqlite'),DATABASE_URL:'',ADMIN_SETUP_TOKEN:'fictional-setup-token-at-least-32-chars'},schedule:false});
 await new Promise(r=>app.server.listen(0,'127.0.0.1',r));const origin='http://127.0.0.1:'+app.server.address().port;
 try{
  assert.equal(JSON.parse((await app.store.query('SELECT data FROM app_state'))[0].data).leads.length,0);
  const health=await (await fetch(origin+'/health')).json();assert.equal(health.mode,'setup');assert.equal(health.launch_ready,false);
  assert.match(await (await fetch(origin+'/login')).text(),/loginForm/);
  const manifest=await (await fetch(origin+'/manifest.webmanifest')).json();assert.equal(manifest.name,'Tharon Leads');assert.equal(manifest.start_url,'/');
  assert.equal((await fetch(origin+'/icons/icon-192.png')).status,200);
  assert.equal((await fetch(origin+'/preview/',{redirect:'manual'})).status,302);
  for(const route of ['/api/commands','/api/import','/api/files','/api/transcribe'])assert.equal((await fetch(origin+route,{method:'POST'})).status,403);
  const setup=await fetch(origin+'/auth/setup',{method:'POST',headers:{Origin:origin,'Content-Type':'application/json'},body:JSON.stringify({token:'fictional-setup-token-at-least-32-chars'})});assert.equal(setup.status,200);const info=await setup.json();assert.ok(info.totpSecret);
  assert.equal((await fetch(origin+'/api/voice-test',{method:'POST'})).status,401);
  const voiceRedirect=await fetch(origin+'/voice-test',{redirect:'manual'});assert.equal(voiceRedirect.status,302);assert.equal(voiceRedirect.headers.get('location'),'/login?next=%2Fvoice-test');
  const post=(route,data,extra={})=>fetch(origin+route,{method:'POST',headers:{Origin:origin,'Content-Type':'application/json',...extra},body:JSON.stringify(data)});
  const password='fictional-voice-test-password';
  assert.equal((await post('/auth/activate',{token:'fictional-setup-token-at-least-32-chars',password,code:totpCode(info.totpSecret)})).status,200);
  const login=await post('/auth/login',{email:users[0].email,password,code:totpCode(info.totpSecret)}),cookie=login.headers.get('set-cookie').split(';')[0];
  const state=await (await fetch(origin+'/api/state',{headers:{Cookie:cookie}})).json();
  assert.equal((await fetch(origin+'/voice-test',{headers:{Cookie:cookie}})).status,200);
  assert.equal((await post('/api/voice-test',{}, {Cookie:cookie})).status,403);
  assert.equal((await post('/api/voice-test',{}, {Cookie:cookie,'X-CSRF-Token':state.csrf})).status,503);
  assert.equal(JSON.parse((await app.store.query('SELECT data FROM app_state'))[0].data).leads.length,0);
 }finally{await app.close();rmSync(folder,{recursive:true,force:true});}
});

test('lead owner and original marketer remain distinct after reassignment, with immutable entry attribution',()=>{
 let state=initialState(false);const id='L_'+randomUUID();
 state=execute(state,'u1',{op:'createLead',createdId:id,args:[{first:'Fictional',last:'Attribution',building:'sierra'}]});
 let lead=state.leads[0];assert.equal(lead.rep,'u1');assert.equal(lead.originRep,'u1');assert.equal(lead.createdBy,'u1');
 state=execute(state,'u0',{op:'assign',args:[id,{rep:'u2'}],expectedVersion:1});lead=state.leads[0];
 assert.equal(lead.rep,'u2');assert.equal(lead.originRep,'u1');assert.equal(lead.createdBy,'u1');
 for(const field of ['originRep','createdBy'])assert.throws(()=>execute(state,'u0',{op:'updateLead',args:[id,{[field]:'u2'}],expectedVersion:2}),e=>e.status===422);
 const other='L_'+randomUUID();state=execute(state,'u0',{op:'createLead',createdId:other,args:[{first:'Fictional',last:'On Behalf',building:'sierra',rep:'u2'}]});lead=state.leads.find(l=>l.id===other);
 assert.equal(lead.originRep,'u2');assert.equal(lead.createdBy,'u0');
});


test('adding Gaby to an existing workspace preserves leads and existing account activation',async()=>{
 const folder=mkdtempSync(path.join(tmpdir(),'tharon-roster-')),env={NODE_ENV:'test',APP_MODE:'setup',SQLITE_PATH:path.join(folder,'app.sqlite'),DATABASE_URL:''};let app;
 try{
  app=await createApplication({env});const row=(await app.store.query('SELECT data FROM app_state WHERE id=$1',['main']))[0];let state=JSON.parse(row.data);state.users=state.users.filter(u=>u.id!=='u3');state.leads=[{id:'L_existing',rep:'u1',notes:'Preserve this fictional record'}];
  await app.store.query('UPDATE app_state SET data=$1 WHERE id=$2',[JSON.stringify(state),'main']);await app.store.query('UPDATE users SET activated_at=$1 WHERE id=$2',['2026-11-01T00:00:00Z','u0']);await app.close();app=null;
  app=await createApplication({env});state=JSON.parse((await app.store.query('SELECT data FROM app_state WHERE id=$1',['main']))[0].data);
  assert.equal(state.users.filter(u=>u.id==='u3').length,1);assert.equal(state.users.find(u=>u.id==='u3').email,'gaby@thepointesummithills.com');assert.equal(state.leads[0].notes,'Preserve this fictional record');assert.ok((await app.store.query('SELECT activated_at FROM users WHERE id=$1',['u0']))[0].activated_at);
 }finally{await app?.close();rmSync(folder,{recursive:true,force:true});}
});

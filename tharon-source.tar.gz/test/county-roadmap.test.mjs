import test from 'node:test';
import assert from 'node:assert/strict';
import {initialState,execute,engine,countyRoadmap,migrateCountyRoadmaps} from '../server/engine.mjs';
const TODAY='2026-11-12';
function lead(building='crenshaw',payer='CalAIM Community Supports'){let state=execute(initialState(false),'u0',{op:'createLead',createdId:'L_county_example',args:[{first:'Fictional',last:'Roadmap',building,payer,rep:'u2'}]});return {state,id:'L_county_example'};}
function update(state,key,patch={}){const l=state.leads[0],now=engine(state,'u0').T;return execute(state,'u0',{op:'setCountyStep',expectedVersion:l.version,args:[l.id,key,{status:'done',owner:'u2',due:now,note:'Operator confirmed against the referral and responsible team.',...patch}]});}
test('all 19 building counties map correctly and exclusions do not borrow another county process',()=>{
 const state=initialState(false);countyRoadmap.syncBuildings(state);assert.equal(state.buildings.length,19);assert.ok(state.buildings.every(b=>b.county));
 for(const id of ['pointe','carrington','hallmark'])assert.equal(state.buildings.find(b=>b.id===id).county,'Kern');
 assert.equal(state.buildings.find(b=>b.id==='orangewood').county,'San Diego');assert.equal(state.buildings.find(b=>b.id==='modesto').county,'Stanislaus');
 for(const county of ['Ventura','Santa Barbara'])for(const program of ['alw','calaim'])assert.equal(countyRoadmap.config(county,program).unavailable,true);
 assert.equal(countyRoadmap.config('').supported,false);
});
test('each CalAIM county follows its specific partner sequence; Stanislaus does not assume Anthem',()=>{
 const keys=c=>countyRoadmap.config(c).steps.map(s=>s.key);
 assert.ok(keys('Los Angeles').includes('libertana_submission'));assert.ok(keys('Riverside').includes('loa_ready'));assert.ok(keys('San Bernardino').includes('loa_ready'));
 assert.ok(keys('Kern').includes('assessment_submission'));assert.ok(keys('San Diego').includes('authorization_request'));
 assert.equal(countyRoadmap.config('Orange').steps.find(s=>s.key==='notify_cca').sameDay,true);
 assert.ok(keys('Orange').indexOf('authorization')>keys('Orange').indexOf('moved_in'));
 assert.doesNotMatch(JSON.stringify(countyRoadmap.config('Stanislaus')),/Anthem.*for approval/);
});
test('migration preserves original leads, documents, ownership, prior approval, and next action without inventing confirmations',()=>{
 const {state}=lead();const l=state.leads[0];delete l.countyWorkflow;l.programStatus='approved';l.assessmentStatus='completed';l.nextAction='Existing action';l.nextFollowUp='2026-11-15';l.files=[{id:'private_original',name:'Fictional.pdf'}];
 const before=JSON.parse(JSON.stringify(l));assert.equal(migrateCountyRoadmaps(state,TODAY),1);
 assert.equal(l.countyWorkflow.legacy.programApproval,'approved');assert.equal(l.countyWorkflow.steps.building_fit.status,'not_started');assert.equal(l.countyWorkflow.steps.authorization.status,'not_started');
 for(const k of ['files','rep','building','originRep','programStatus','assessmentStatus','nextAction','nextFollowUp'])assert.deepEqual(l[k],before[k]);
 const saved=JSON.stringify(state);assert.equal(migrateCountyRoadmaps(state,TODAY),0);assert.equal(JSON.stringify(state),saved);
});
test('confirmed approval can arrive before assessment, but ready remains false until all required steps are explicitly confirmed',()=>{
 let {state}=lead();const l=state.leads[0];l.files=[{id:'signed_packet',type:'application/pdf'}];l.libertana={fields:{},signedFileId:'signed_packet',reviewed:true,signatures:Object.fromEntries(['member1','cca1','member2','agency2','client4','witness4','member5','agency5'].map(k=>[k,true]))};state=update(state,'libertana_packet');state=update(state,'authorization');let tl=engine(state,'u0');assert.equal(tl.countySummary(tl.S.leads[0]).next.key,'building_fit');assert.equal(tl.countySummary(tl.S.leads[0]).ready,false);
 state=update(state,'building_fit');state=update(state,'confirm_pathway',{plan:'L.A. Care'});state=update(state,'libertana_submission');tl=engine(state,'u0');assert.equal(tl.countySummary(tl.S.leads[0]).ready,true);
 assert.throws(()=>update(state,'schedule_movein'),/move-in date/);
});
test('unfinished actions require an owner and date; evidence-required confirmations cannot be silently completed',()=>{
 const {state}=lead();assert.throws(()=>update(state,'building_fit',{note:''}),e=>e.status===422);assert.throws(()=>update(state,'building_fit',{status:'pending',due:''}),e=>e.status===422);assert.throws(()=>update(state,'building_fit',{owner:'unknown'}),e=>e.status===422);
 assert.throws(()=>update(state,'confirm_pathway',{plan:''}),e=>e.status===422);
});
test('responsibility controls reminders and respects building access and concurrent edit protection',()=>{
 let {state,id}=lead();const due=engine(state,'u0').T;
 assert.throws(()=>update(state,'building_fit',{owner:'u3'}),e=>e.status===422);
 state=update(state,'libertana_packet',{status:'pending',owner:'u1',due,waitingOn:'Fictional facility assessor'});
 let tl=engine(state,'u1');const tasks=tl.allReminders('u1').filter(t=>t.leadId===id);assert.equal(tasks.length,1);assert.equal(tasks[0].rule,'county_step');assert.match(tasks[0].text,/Fictional facility assessor/);
 state=execute(state,'u1',{op:'setCountyStep',expectedVersion:state.leads[0].version,args:[id,'libertana_packet',{status:'pending',owner:'u1',due,note:'Assessor will respond.',waitingOn:'Assessor'}]});
 assert.throws(()=>execute(state,'u1',{op:'setCountyStep',expectedVersion:1,args:[id,'libertana_packet',{status:'pending',owner:'u1',due}]}),e=>e.status===409);
 assert.throws(()=>execute(state,'u3',{op:'setCountyStep',expectedVersion:state.leads[0].version,args:[id,'building_fit',{status:'pending',owner:'u3',due}]}),e=>e.status===404);
});
test('county transfer and ALW/CalAIM switches retain previous workflow history without reusing approvals',()=>{
 let {state,id}=lead();state=update(state,'authorization');state=execute(state,'u0',{op:'assign',expectedVersion:state.leads[0].version,args:[id,{building:'sierra'}]});let flow=state.leads[0].countyWorkflow;
 assert.equal(flow.county,'San Bernardino');assert.equal(flow.steps.loa_ready.status,'not_started');assert.equal(flow.previous[0].steps.authorization.status,'done');
 state=execute(state,'u0',{op:'updateLead',expectedVersion:state.leads[0].version,args:[id,{payer:'ALW waiver'}]});flow=state.leads[0].countyWorkflow;assert.equal(flow.program,'alw');assert.equal(flow.steps.informing_notice.status,'not_started');assert.ok(!flow.steps.loa_ready);
});
test('ALW tracks transition, CCA status and actual deadlines, never infers DHCS approval or a notice from the reported status',()=>{
 let {state}=lead('bellevue','ALW waiver');state=update(state,'transition',{transition:'aps',slotStatus:'submitted',waitlistDate:'2026-09-01',placementDeadline:'2026-12-01'});
 const flow=state.leads[0].countyWorkflow;assert.equal(flow.transition,'aps');assert.equal(flow.slotStatus,'submitted');assert.equal(flow.placementDeadline,'2026-12-01');assert.equal(flow.steps.informing_notice.status,'not_started');assert.equal(flow.steps.dhcs_submission.status,'not_started');
 assert.match(countyRoadmap.config('Los Angeles','alw').note,/not verified DHCS approval/);
});
test('Orange post-move-in authorization tasks remain visible after move-in; unknown and excluded programs never appear ready',()=>{
 let {state}=lead('crescendo');state=update(state,'building_fit');state=update(state,'confirm_pathway',{plan:'CalOptima'});state=update(state,'movein_arrangement');state=update(state,'schedule_movein',{moveIn:engine(state,'u0').T});state=update(state,'moved_in',{moveIn:engine(state,'u0').T});
 let tl=engine(state,'u0');assert.equal(tl.S.leads[0].stage,'movein');assert.equal(tl.countySummary(tl.S.leads[0]).next.key,'notify_cca');assert.equal(tl.allReminders('u2')[0].rule,'county_step');
 const excluded=lead('oxnard');tl=engine(excluded.state,'u0');assert.equal(tl.countySummary(tl.S.leads[0]).ready,false);assert.equal(tl.countySummary(tl.S.leads[0]).next.key,'review_program');
});
test('private-pay leads are not given ALW or CalAIM roadmaps',()=>{const {state}=lead('hallmark','Private pay');assert.equal(state.leads[0].countyWorkflow,undefined);assert.equal(engine(state,'u0').countySummary(state.leads[0]),null);});
test('lead reassignment transfers the old marketer’s pending program responsibility and preserves source credit',()=>{
 let {state,id}=lead();state=update(state,'building_fit',{status:'pending',owner:'u2',due:engine(state,'u0').T});
 state=execute(state,'u0',{op:'assign',expectedVersion:state.leads[0].version,args:[id,{rep:'u1'}]});
 assert.equal(state.leads[0].countyWorkflow.steps.building_fit.owner,'u1');assert.equal(state.leads[0].originRep,'u2');
 assert.throws(()=>execute(state,'u2',{op:'setCountyStep',expectedVersion:state.leads[0].version,args:[id,'building_fit',{status:'pending',owner:'u2',due:engine(state,'u0').T}]}),e=>e.status===404);
});
test('an unspecified program is flagged without guessing from CCA; explicit private pay clears that review',()=>{
 let {state,id}=lead('hallmark','Other');assert.equal(state.leads[0].programReviewRequired,true);assert.equal(state.leads[0].countyWorkflow,undefined);
 state=execute(state,'u0',{op:'updateLead',expectedVersion:state.leads[0].version,args:[id,{payer:'Private pay'}]});assert.equal(state.leads[0].programReviewRequired,false);
});
test('startup migration writes existing profiles transactionally and a second startup is idempotent',async()=>{
 const {mkdtempSync,rmSync}=await import('node:fs');const {tmpdir}=await import('node:os');const {join}=await import('node:path');const {openStore}=await import('../server/store.mjs');const {createApplication}=await import('../server/index.mjs');
 const dir=mkdtempSync(join(tmpdir(),'tharon-county-')),file=join(dir,'test.sqlite');
 let {state}=lead('sierra','ALW waiver');delete state.leads[0].countyWorkflow;state.leads[0].programStatus='approved';const saved=JSON.stringify(state.leads[0]);
 let store=await openStore(null,file);await store.query('INSERT INTO app_state(id,data) VALUES ($1,$2)',['main',JSON.stringify(state)]);await store.close();
 let app=await createApplication({schedule:false,env:{NODE_ENV:'test',APP_MODE:'sample',SQLITE_PATH:file,DATABASE_URL:''}});
 const first=JSON.parse((await app.store.query('SELECT data FROM app_state WHERE id=$1',['main']))[0].data);
 assert.equal(first.leads[0].countyWorkflow.program,'alw');assert.equal(first.leads[0].countyWorkflow.steps.informing_notice.status,'not_started');assert.equal(first.leads[0].programStatus,JSON.parse(saved).programStatus);
 assert.equal((await app.store.query('SELECT * FROM audit_log WHERE action=$1',['county_roadmap.migrated'])).length,1);await app.close();
 app=await createApplication({schedule:false,env:{NODE_ENV:'test',APP_MODE:'sample',SQLITE_PATH:file,DATABASE_URL:''}});
 const second=JSON.parse((await app.store.query('SELECT data FROM app_state WHERE id=$1',['main']))[0].data);assert.equal(JSON.stringify(second),JSON.stringify(first));await app.close();rmSync(dir,{recursive:true,force:true});
});
test('building payment policies apply to new and saved leads without assigning a guessed program to Bella View or Lincoln',()=>{
 for(const payer of ['Private pay','ALW waiver','Other']){const {state}=lead('crenshaw',payer);assert.equal(state.leads[0].payer,'CalAIM Community Supports');assert.equal(state.leads[0].countyWorkflow.program,'calaim');assert.equal(state.leads[0].paymentHistory[0].payer,payer);}
 for(const id of ['bellevue','lincoln']){const {state}=lead(id,'Private pay');assert.equal(state.leads[0].payer,'Other');assert.equal(state.leads[0].programReviewRequired,true);assert.deepEqual(Array.from(countyRoadmap.paymentOptions(id),x=>x[0]),['calaim','alw']);}
 for(const id of ['lakes','hallmark','pointe','carrington','shadowridge'])assert.deepEqual(Array.from(countyRoadmap.paymentOptions(id),x=>x[0]),['calaim','alw','private']);
});
test('all production buildings select the right county roadmap, including immediate ALW switches and reopen',()=>{
 for(const b of initialState(false).buildings){let {state,id}=lead(b.id);let tl=engine(state,'u0');const before=tl.countySummary(tl.Lead(id));assert.equal(before.config.county,countyRoadmap.GEO[b.id][0]);assert.ok(before.steps.every(s=>s.phase>=1&&s.phase<=4));
 if(b.id==='crenshaw')continue;
 state=execute(state,'u0',{op:'updateLead',expectedVersion:state.leads[0].version,args:[id,{payer:'ALW waiver'}]});tl=engine(state,'u0');const after=tl.countySummary(tl.Lead(id));assert.equal(tl.Lead(id).countyWorkflow.program,'alw');assert.equal(after.config.county,countyRoadmap.GEO[b.id][0]);if(after.config.supported)assert.ok(after.steps.some(s=>s.key==='informing_notice'));
 state=execute(state,'u0',{op:'updateLead',expectedVersion:state.leads[0].version,args:[id,{payer:'CalAIM Community Supports'}]});tl=engine(state,'u0');assert.deepEqual(Array.from(tl.countySummary(tl.Lead(id)).steps,s=>s.key),Array.from(before.steps,s=>s.key));}
});
test('existing building policy migration is idempotent, preserves source documents and turns temperature reminders off',()=>{
 const {state}=lead('hallmark','ALW waiver');const l=state.leads[0];l.building='crenshaw';l.files=[{id:'source',name:'original.pdf'}];l.programStatus='approved';state.checkin.enabled=true;state.checkin.autoCool=true;
 assert.equal(migrateCountyRoadmaps(state,TODAY),1);assert.equal(l.payer,'CalAIM Community Supports');assert.equal(l.countyWorkflow.steps.authorization.status,'not_started');assert.equal(l.paymentHistory.at(-1).programStatus,'approved');assert.equal(l.files[0].id,'source');assert.equal(state.checkin.enabled,false);assert.equal(state.checkin.autoCool,false);
 const before=JSON.stringify(state);assert.equal(migrateCountyRoadmaps(state,TODAY),0);assert.equal(JSON.stringify(state),before);assert.ok(engine(state,'u0').allReminders('all').every(t=>!['checkin','needs_decision'].includes(t.rule)));
});

import test from 'node:test';import assert from 'node:assert/strict';import {mkdtempSync,rmSync} from 'node:fs';import {tmpdir} from 'node:os';import path from 'node:path';import {randomBytes,randomUUID,createHmac} from 'node:crypto';
import {createApplication} from '../server/index.mjs';import {hash} from '../server/security.mjs';
test('private link opens a distinct admin session with live data, CSRF, attribution, expiry and immediate revocation',async()=>{
 const dir=mkdtempSync(path.join(tmpdir(),'tharon-access-')),access=randomBytes(32).toString('hex'),secret='private-access-test-secret';let expires=new Date(Date.now()+3600000).toISOString();
 const app=await createApplication({env:{NODE_ENV:'test',APP_MODE:'live',PHI_APPROVED:'true',DATABASE_URL:'',SQLITE_PATH:path.join(dir,'state.sqlite'),SESSION_SECRET:secret,APP_ORIGIN:'',DELEGATE_ACCESS_HASH:hash(access),DELEGATE_ACCESS_EXPIRES_AT:expires},schedule:false});await new Promise(r=>app.server.listen(0,'127.0.0.1',r));const origin='http://127.0.0.1:'+app.server.address().port;
 const post=(token,extra={})=>fetch(origin+'/auth/access',{method:'POST',headers:{Origin:origin,'Content-Type':'application/json',...extra},body:JSON.stringify({token})});
 try{
 assert.equal((await fetch(origin+'/access')).status,200);
 assert.equal((await fetch(origin+'/api/state')).status,401);
 assert.equal((await post('bad')).status,403);
 assert.equal((await post(access,{Origin:'https://untrusted.invalid'})).status,403);
 const login=await post(access);assert.equal(login.status,200);const cookie=login.headers.get('set-cookie').split(';')[0];assert.match(login.headers.get('set-cookie'),/HttpOnly/);
 const stateResponse=await fetch(origin+'/api/state',{headers:{Cookie:cookie}}),boot=await stateResponse.json();assert.equal(boot.state.me,'u4');assert.equal(boot.state.users.find(u=>u.id==='u4').role,'admin');assert.ok(boot.state.buildings.length>3);assert.ok(!JSON.stringify(boot).includes(access));
 const command={id:randomUUID(),op:'createLead',createdId:'L_private_test',args:[{first:'Fictional',last:'PrivateAccess',building:'hallmark',rep:'u2',payer:'CalAIM Community Supports'}]};
 const send=csrf=>fetch(origin+'/api/commands',{method:'POST',headers:{Origin:origin,Cookie:cookie,'X-CSRF-Token':csrf,'Content-Type':'application/json'},body:JSON.stringify(command)});
 assert.equal((await send('bad')).status,403);assert.equal((await send(boot.csrf)).status,200);
 const record=(await app.store.query('SELECT user_id FROM audit_log WHERE action=$1 AND record_id=$2',['createLead','L_private_test']))[0];assert.equal(record.user_id,'u4');
 assert.equal((await fetch(origin+'/api/users',{headers:{Cookie:cookie}})).status,200);
 const sessionToken='test-staff-session';await app.store.query('INSERT INTO sessions (token_hash,user_id,expires_at,csrf) VALUES ($1,$2,$3,$4)',[createHmac('sha256',secret).update(sessionToken).digest('hex'),'u1',Date.now()+60000,'csrf']);assert.equal((await fetch(origin+'/api/admin/delegate-access',{method:'DELETE',headers:{Origin:origin,Cookie:'tl_session='+sessionToken,'X-CSRF-Token':'csrf'}})).status,403);
 assert.equal((await fetch(origin+'/api/admin/delegate-access',{method:'DELETE',headers:{Origin:origin,Cookie:cookie,'X-CSRF-Token':boot.csrf}})).status,200);
 assert.equal((await fetch(origin+'/api/state',{headers:{Cookie:cookie}})).status,401);assert.equal((await post(access)).status,403);
 assert.ok(!(await app.store.query('SELECT * FROM audit_log')).some(r=>JSON.stringify(r).includes(access)));
 }finally{await app.close();rmSync(dir,{recursive:true,force:true});}
 const expired=await createApplication({env:{NODE_ENV:'test',APP_MODE:'live',PHI_APPROVED:'true',DATABASE_URL:'',SQLITE_PATH:path.join(dir,'expired.sqlite'),DELEGATE_ACCESS_HASH:hash(access),DELEGATE_ACCESS_EXPIRES_AT:new Date(Date.now()-60000).toISOString()},schedule:false});await new Promise(r=>expired.server.listen(0,'127.0.0.1',r));const expiredOrigin='http://127.0.0.1:'+expired.server.address().port;try{assert.equal((await fetch(expiredOrigin+'/auth/access',{method:'POST',headers:{Origin:expiredOrigin,'Content-Type':'application/json'},body:JSON.stringify({token:access})})).status,403);}finally{await expired.close();rmSync(dir,{recursive:true,force:true});}
});

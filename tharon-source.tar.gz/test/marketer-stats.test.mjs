import test from 'node:test';
import assert from 'node:assert/strict';
import {initialState,engine} from '../server/engine.mjs';
test('marketer totals credit the original source, count completed move-ins, and exclude unknown origins',()=>{
 const state=initialState(false);state.leads=[
 {originRep:'u1',rep:'u2',stage:'movein'},
 {originRep:'u1',rep:'u1',stage:'paperwork',moveIn:'2026-12-01'},
 {originRep:'u1',rep:'u3',stage:'lost'},
 {originRep:'u2',rep:'u1',stage:'new'},
 {rep:'u1',stage:'movein'}];
 const tl=engine(state,'u0');assert.deepEqual(JSON.parse(JSON.stringify(tl.marketerStats('u1'))),{broughtIn:3,movedIn:1,open:1});assert.deepEqual(JSON.parse(JSON.stringify(tl.marketerStats('u2'))),{broughtIn:1,movedIn:0,open:1});assert.equal(tl.marketerStats('u3').broughtIn,0);
});

import test from 'node:test';
import assert from 'node:assert/strict';
import vm from 'node:vm';
import {readFileSync} from 'node:fs';
const source=readFileSync(new URL('../site/app.js',import.meta.url),'utf8');
function boot(){
 const timers=new Map(),requests=[],profiles=[],messages=[];let seq=0,rec,trackStops=0;
 class Recorder{static isTypeSupported(t){return t==='audio/mp4';}constructor(stream,options){rec=this;this.mimeType=options.mimeType;}start(ms){this.timeslice=ms;}stop(){this.stopCalled=true;}}
 const stream={getTracks:()=>[{stop:()=>trackStops++}]};
 const ctx={navigator:{mediaDevices:{getUserMedia:async()=>stream}},window:{MediaRecorder:Recorder},MediaRecorder:Recorder,File,AbortSignal,VOICE:{},UI:{},paintVoice(){},$:()=>null,toast:m=>messages.push(m),render(){},openReview:(text,meta)=>profiles.push({text,meta}),TLRemote:{request:async(path,opts)=>{requests.push({path,opts});return {text:'Jane Example at Summit Hills'};}},setTimeout:(fn,ms)=>{timers.set(++seq,{fn,ms});return seq;},clearTimeout:id=>timers.delete(id)};
 vm.createContext(ctx);vm.runInContext(source.slice(source.indexOf('let recorder=null,recordStream=null'),source.indexOf('function refreshCalendar()')),ctx);
 return {ctx,rec:()=>rec,requests,profiles,messages,stops:()=>trackStops,fire:ms=>{for(const [id,t] of [...timers])if(t.ms===ms){timers.delete(id);t.fn();}}};
}
test('main app uses the working Safari format and waits for final audio before creating the profile',async()=>{
 const b=boot();await b.ctx.recordVoice('add');const rec=b.rec();assert.equal(rec.mimeType,'audio/mp4');assert.equal(rec.timeslice,1000);assert.equal(b.ctx.VOICE.target,'add');
 b.ctx.stopRecording();assert.ok(rec.stopCalled);b.fire(1000);assert.equal(b.requests.length,0);assert.equal(b.stops(),0,'do not stop the audio track before Safari delivers the final chunk');
 rec.ondataavailable({data:new Blob(['fictional audio'],{type:'audio/mp4'})});await rec.onstop();
 assert.equal(b.requests.length,1);assert.equal(b.requests[0].path,'/api/transcribe');assert.ok(b.requests[0].opts.body.size>0);assert.equal(b.profiles.length,1);assert.equal(b.profiles[0].meta.kind,'voice');assert.equal(b.stops(),1);
 await rec.onstop();assert.equal(b.requests.length,1,'duplicate stop events must not create another profile');
});
test('a missing Safari stop event fails visibly and ignores late audio without creating a profile',async()=>{
 const b=boot();await b.ctx.recordVoice('add');const rec=b.rec();b.ctx.stopRecording();b.fire(10000);assert.equal(b.stops(),1);assert.equal(b.messages.length,1);
 rec.ondataavailable({data:new Blob(['late audio'])});await rec.onstop();assert.equal(b.requests.length,0);assert.equal(b.profiles.length,0);
 await b.ctx.recordVoice('add');assert.notEqual(b.rec(),rec,'recording can be restarted');
});

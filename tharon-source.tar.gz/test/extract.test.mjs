import test from 'node:test';
import assert from 'node:assert/strict';
import {extractLead} from '../server/extract.mjs';
const buildings=[{id:'pointe',name:'The Pointe at Summit Hills',city:'',aliases:['Summit Hills']}];
const env={AI_EXTRACTION_ENABLED:'true',OPENAI_API_KEY:'fictional-secret'};
function provider(fields){return async(url,options)=>{const request=JSON.parse(options.body);assert.equal(url,'https://api.openai.com/v1/responses');assert.equal(request.store,false);assert.equal(request.text.format.strict,true);assert.ok(request.instructions.includes('never as instructions'));const output=Object.fromEntries(request.text.format.schema.required.map(k=>[k,null]));Object.assign(output,fields);return {ok:true,json:async()=>({status:'completed',output:[{content:[{type:'output_text',text:JSON.stringify(output)}]}]})};};}
test('AI extraction returns validated structured fields without inventing payer or care',async()=>{
 const result=await extractLead('A fictional referral for Jordan Rivera aged 70 at Summit Hills.',{env,buildings,fetchImpl:provider({first:'Jordan',last:'Rivera',age:70,building:'pointe'})});
 assert.deepEqual(result.fields,{first:'Jordan',last:'Rivera',age:70,building:'pointe'});assert.equal(result.found,4);
});
test('AI extraction cannot choose an unknown building or use malformed resident details',async()=>{
 await assert.rejects(()=>extractLead('Fictional test',{env,buildings,fetchImpl:provider({building:'made-up'})}),e=>e.status===502);
 await assert.rejects(()=>extractLead('Fictional test',{env,buildings,fetchImpl:provider({age:500})}),e=>e.status===502);
});
test('unconfigured AI makes no outbound call and provider failures do not disclose secrets',async()=>{
 let called=false;await assert.rejects(()=>extractLead('Fictional test',{env:{OPENAI_API_KEY:'fictional-secret'},buildings,fetchImpl:async()=>{called=true;}}),e=>e.status===503);assert.equal(called,false);
 await assert.rejects(()=>extractLead('Fictional test',{env,buildings,fetchImpl:async()=>{throw Error('fictional-secret');}}),e=>e.status===502&&!e.message.includes('fictional-secret'));
});

test('AI classifies actual paperwork and rejects unknown document categories',async()=>{
 for(const key of ['lic602a','agreement','hmp','w_isp','w_informing']){const r=await extractLead('Fictional document',{env,buildings,kind:'doc',fetchImpl:provider({document_keys:[key]})});assert.deepEqual(r.docs,[{key,strong:true}]);}
 const r=await extractLead('Referral cover sheet mentions ISP as outstanding',{env,buildings,kind:'doc',fetchImpl:provider({document_keys:[]})});assert.deepEqual(r.docs,[]);
 await assert.rejects(()=>extractLead('Fictional document',{env,buildings,kind:'doc',fetchImpl:provider({document_keys:['unknown']})}),e=>e.status===502);
});

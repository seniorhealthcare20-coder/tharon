import test from 'node:test';import assert from 'node:assert/strict';import {randomUUID,createHash,createHmac} from 'node:crypto';import {mkdtempSync,rmSync} from 'node:fs';import {tmpdir} from 'node:os';import path from 'node:path';
import {initialState,execute,scoped,buildingAccess} from '../server/engine.mjs';import {createApplication} from '../server/index.mjs';import {seal} from '../server/security.mjs';
const id=()=> 'L_'+randomUUID();
function seeded(){let s=initialState(false);for(const [building,last]of [['pointe','Allowed'],['carrington','Shafter'],['hallmark','Bakersfield'],['sierra','Hidden']])s=execute(s,'u0',{op:'createLead',createdId:id(),args:[{first:'Fictional',last,building}]});return s;}
test('Gaby sees only three buildings and their leads; existing unrestricted staff and admin retain access',()=>{
 const s=seeded(),g=scoped(s,'u3');assert.deepEqual(new Set(g.buildings.map(b=>b.id)),new Set(['pointe','carrington','hallmark']));assert.equal(g.leads.length,3);assert.ok(!JSON.stringify(g).includes('Fictional Hidden'));assert.equal(scoped(s,'u1').leads.length,4);assert.equal(scoped(s,'u0').leads.length,4);
 s.users.push({id:'future',role:'rep'});assert.deepEqual(buildingAccess(s,'future'),[]);assert.equal(scoped(s,'future').leads.length,0);
});
test('restricted marketers cannot create or move leads outside their buildings, and only admin changes access',()=>{
 let s=seeded();assert.throws(()=>execute(s,'u3',{op:'createLead',createdId:id(),args:[{first:'Fictional',last:'Forbidden',building:'sierra'}]}),e=>e.status===403);
 assert.throws(()=>execute(s,'u0',{op:'createLead',createdId:id(),args:[{first:'Fictional',last:'Forbidden',building:'sierra',rep:'u3'}]}),e=>e.status===422);
 assert.throws(()=>execute(s,'u3',{op:'setBuildingAccess',args:['u3','all']}),e=>e.status===403);
 s=execute(s,'u0',{op:'setBuildingAccess',args:['u3',['pointe']]});assert.equal(scoped(s,'u3').leads.length,1);assert.deepEqual(buildingAccess(s,'u3'),['pointe']);
 s=execute(s,'u0',{op:'setBuildingAccess',args:['u3',[]]});assert.equal(scoped(s,'u3').leads.length,0);
});
test('restricted HTTP sessions cannot download hidden files, mutate hidden leads, or export hidden profiles',async()=>{
 const folder=mkdtempSync(path.join(tmpdir(),'tharon-access-')),secret='s'.repeat(64),fileKey='f'.repeat(64),csrf='fictional-csrf';
 const app=await createApplication({env:{NODE_ENV:'test',APP_MODE:'live',PHI_APPROVED:'true',DATABASE_URL:'',SQLITE_PATH:path.join(folder,'app.sqlite'),SESSION_SECRET:secret,FILE_ENCRYPTION_KEY:fileKey,APP_ORIGIN:''},schedule:false});
 await new Promise(r=>app.server.listen(0,'127.0.0.1',r));const origin='http://127.0.0.1:'+app.server.address().port;
 try{
  const s=seeded(),hidden=s.leads.find(l=>l.building==='sierra');hidden.files=[{id:'file_hidden',name:'fictional.txt'}];await app.store.query('UPDATE app_state SET data=$1 WHERE id=$2',[JSON.stringify(s),'main']);
  await app.store.query('INSERT INTO files (id,user_id,name,mime,size,sha256,ciphertext,created_at) VALUES ($1,$2,$3,$4,$5,$6,$7,$8)',['file_hidden','u0','fictional.txt','text/plain',9,'fake-hash',seal(Buffer.from('fictional'),createHash('sha256').update(fileKey).digest()),new Date().toISOString()]);
  for(const uid of ['u0','u3'])await app.store.query('INSERT INTO sessions (token_hash,user_id,expires_at,csrf) VALUES ($1,$2,$3,$4)',[createHmac('sha256',secret).update('token-'+uid).digest('hex'),uid,Date.now()+60000,csrf]);
  const headers={Cookie:'tl_session=token-u3',Origin:origin,'X-CSRF-Token':csrf,'Content-Type':'application/json'};
  assert.equal((await fetch(origin+'/api/files/file_hidden',{headers})).status,404);
  const adminFile=await fetch(origin+'/api/files/file_hidden',{headers:{Cookie:'tl_session=token-u0'}});assert.equal(adminFile.status,200);assert.equal(adminFile.headers.get('content-type'),'text/plain');assert.match(adminFile.headers.get('content-disposition'),/^inline;/);assert.equal(await adminFile.text(),'fictional');
  const exported=await (await fetch(origin+'/api/export',{headers})).text();assert.ok(!exported.includes('Hidden'));assert.ok(!exported.includes('file_hidden'));
  const mutate=await fetch(origin+'/api/commands',{method:'POST',headers,body:JSON.stringify({id:randomUUID(),op:'setTemp',args:[hidden.id,'cold'],expectedVersion:1})});assert.equal(mutate.status,404);
  const before=await (await fetch(origin+'/api/state',{headers})).json();assert.equal(before.state.buildings.length,3);
  const revoke=await fetch(origin+'/api/commands',{method:'POST',headers:{...headers,Cookie:'tl_session=token-u0'},body:JSON.stringify({id:randomUUID(),op:'setBuildingAccess',args:['u3',['pointe']]})});assert.equal(revoke.status,200);
  const after=await (await fetch(origin+'/api/state',{headers})).json();assert.equal(after.state.buildings.length,1);assert.notEqual(after.state.accessSignature,before.state.accessSignature);
 }finally{await app.close();rmSync(folder,{recursive:true,force:true});}
});

import test from 'node:test';
import assert from 'node:assert/strict';
import {mkdtempSync,rmSync} from 'node:fs';
import {tmpdir} from 'node:os';
import path from 'node:path';
import {randomUUID,createHash} from 'node:crypto';
import {openStore} from '../server/store.mjs';
import {initialState,execute} from '../server/engine.mjs';
import {seal,unseal} from '../server/security.mjs';
import {createBackup,restoreBackup} from '../server/backup.mjs';

test('encrypted recovery preserves leads and files, drops sessions, rejects wrong keys and occupied targets',async()=>{
 const dir=mkdtempSync(path.join(tmpdir(),'tharon-recovery-')),source=await openStore('',path.join(dir,'source.sqlite')),target=await openStore('',path.join(dir,'restore.sqlite'));
 const keys={backupKey:randomUUID()+randomUUID(),fileKey:randomUUID()+randomUUID()},key=createHash('sha256').update(keys.fileKey).digest();
 try{
  const state=execute(initialState(false),'u1',{op:'createLead',createdId:'L_'+randomUUID(),args:[{first:'Fictional',last:'Recovery',building:'sierra',rep:'u1'}]});
  state.leads[0].files=[{id:'file_fixture',name:'fictional.txt'}];
  await source.query('INSERT INTO app_state (id,data) VALUES ($1,$2)',['main',JSON.stringify(state)]);
  await source.query('INSERT INTO files (id,user_id,name,mime,size,sha256,ciphertext,created_at) VALUES ($1,$2,$3,$4,$5,$6,$7,$8)',['file_fixture','u1','fictional.txt','text/plain',18,createHash('sha256').update('fictional document').digest('hex'),seal(Buffer.from('fictional document'),key),new Date().toISOString()]);
  await source.query('INSERT INTO sessions (token_hash,user_id,expires_at,csrf) VALUES ($1,$2,$3,$4)',['session','u1',Date.now()+10000,'csrf']);
  const archive=await createBackup(source,keys);assert.ok(!archive.includes('Recovery'));assert.ok(!archive.includes('fictional document'));
  await assert.rejects(restoreBackup(target,archive,{...keys,fileKey:randomUUID()}),/match/);
  await assert.rejects(restoreBackup(target,archive,{...keys,backupKey:randomUUID()}));
  const damaged=JSON.parse(archive);damaged.ciphertext=damaged.ciphertext.slice(0,-8)+'AAAAAAAA';await assert.rejects(restoreBackup(target,JSON.stringify(damaged),keys));
  const result=await restoreBackup(target,archive,keys);assert.equal(result.leads,1);assert.equal(result.files,1);assert.equal(result.sessions_restored,0);assert.equal(JSON.parse((await target.query('SELECT data FROM app_state'))[0].data).leads[0].files[0].id,'file_fixture');
  assert.equal(JSON.parse((await target.query('SELECT data FROM app_state'))[0].data).leads[0].last,'Recovery');
  assert.equal(unseal((await target.query('SELECT ciphertext FROM files'))[0].ciphertext,key).toString(),'fictional document');
  assert.equal((await target.query('SELECT * FROM sessions')).length,0);
  await assert.rejects(restoreBackup(target,archive,keys),/separate empty database/);
  assert.equal((await target.query('SELECT * FROM app_state')).length,1);
 }finally{await source.close();await target.close();rmSync(dir,{recursive:true,force:true});}
});

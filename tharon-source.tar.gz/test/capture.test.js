// Tests for the no-typing lead capture parser (site/capture.js) and the sample files.
// The fixtures in test/fixtures/ are the exact text the in-browser readers produced from site/samples/
// (pdf.js for the PDFs, Tesseract OCR for the photo, mammoth for the .docx), captured in Chromium on Nov 12, 2026.
const test=require('node:test');const assert=require('node:assert');const fs=require('node:fs');const path=require('node:path');
const C=require('../site/capture.js');
const site=path.join(__dirname,'..','site');
const fx=n=>fs.readFileSync(path.join(__dirname,'fixtures',n+'.txt'),'utf8');
const B=[{id:'b1',name:'The Gardens of Riverside',short:'Riverside',city:'Riverside, CA'},{id:'b2',name:'Maple Court',short:'Maple Court',city:'Pasadena, CA'},{id:'b3',name:'Sunset Terrace',short:'Sunset',city:'Van Nuys, CA'},{id:'b4',name:'Hallmark of Bakersfield',short:'Bakersfield',city:'Bakersfield, CA'}];
const ctx=kind=>({kind,buildings:B,today:'2026-11-11'});

test('voice: the example from the brief fills every field',()=>{
  const r=C.parseLead('New lead, Margaret Silva, her daughter Ann called, 555-123-4567, coming from Cedars hospital, needs memory care, private pay, wants to move in December 1st, Riverside',ctx('voice'));
  const f=r.fields;
  assert.strictEqual(f.first,'Margaret');assert.strictEqual(f.last,'Silva');
  assert.strictEqual(f.rel,'Daughter');assert.strictEqual(f.callerName,'Ann');
  assert.strictEqual(f.phone,'(555) 123-4567');
  assert.strictEqual(f.source,'Hospital');assert.match(f.sourceDetail,/Cedars Hospital/);
  assert.strictEqual(f.care,'Memory care');assert.strictEqual(f.payer,'Private pay');
  assert.strictEqual(f.moveIn,'2026-12-01');assert.strictEqual(f.building,'b1');
  assert.strictEqual(r.conf.callerName,'low','a first name alone is flagged to check');
  assert.strictEqual(f.notes,undefined,'the transcript must not replace structured fields or fill Notes');
  assert.match(r.text,/Margaret Silva/,'transcript remains available for review');
});
test('voice: spoken digits, spoken email, waiver payer, tier, relative date',()=>{
  const r=C.parseLead('new lead dorothy greene her son Michael called his number is five five five two two two three three three three email michael at example dot com she is 87 coming from Mercy Ridge rehab ALW waiver tier 3 move in next week Bakersfield',ctx('voice'));
  const f=r.fields;
  assert.strictEqual(f.first,'Dorothy');assert.strictEqual(r.conf.first,'low','lowercase name from speech is flagged');
  assert.strictEqual(f.phone,'(555) 222-3333');assert.strictEqual(f.email,'michael@example.com');assert.strictEqual(r.conf.email,'low');
  assert.strictEqual(f.payer,'ALW waiver');assert.strictEqual(f.tier,3);assert.strictEqual(f.source,'SNF');
  assert.strictEqual(f.age,87);assert.strictEqual(f.moveIn,'2026-11-18');assert.strictEqual(r.conf.moveIn,'low');assert.strictEqual(f.building,'b4');
});
test('voice: CalAIM, self-referral, dates roll into next year',()=>{
  const r=C.parseLead('Add a lead for Frank Lowell, calling for himself, 555 444 1212, CalAIM, wants to move in January 15, Maple Court',ctx('voice'));
  assert.strictEqual(r.fields.payer,'CalAIM Community Supports');assert.strictEqual(r.fields.rel,'Self');
  assert.strictEqual(r.fields.callerName,'Frank Lowell');assert.strictEqual(r.fields.moveIn,'2027-01-15');assert.strictEqual(r.fields.building,'b2');
});
test('pdf: hospital referral face sheet (pdf.js text)',()=>{
  const r=C.parseLead(fx('sample-hospital-referral'),ctx('doc'));const f=r.fields;
  assert.deepStrictEqual([f.first,f.last,f.age],['Eleanor','Whitfield',86]);
  assert.deepStrictEqual([f.callerName,f.rel,f.phone,f.email],['Robert Whitfield','Son','(555) 214-8890','robert.whitfield@example.com']);
  assert.strictEqual(f.source,'Hospital');assert.strictEqual(f.care,'Level 2 \u00b7 moderate assist');
  assert.strictEqual(f.payer,'Long-term care insurance');assert.strictEqual(f.moveIn,'2026-12-04');assert.strictEqual(f.building,'b2');
  assert.deepStrictEqual(r.docs,[],'a referral is a new lead, not an admission form');
});
test('photo: intake sheet (Tesseract OCR text)',()=>{
  const r=C.parseLead(fx('sample-intake-sheet-photo'),ctx('doc'));const f=r.fields;
  assert.deepStrictEqual([f.first,f.last,f.age,f.callerName,f.rel],['Henry','Castillo',78,'Rosa Castillo','Daughter']);
  assert.strictEqual(f.phone,'(555) 387-2201');assert.strictEqual(f.source,'Placement agency');assert.strictEqual(f.care,'Memory care');
  assert.strictEqual(f.payer,'ALW waiver');assert.strictEqual(f.moveIn,'2026-12-15');assert.strictEqual(f.building,'b1');
});
test('docx: placement agency referral (mammoth text)',()=>{
  const r=C.parseLead(fx('sample-placement-referral'),ctx('doc'));const f=r.fields;
  assert.deepStrictEqual([f.first,f.last,f.age,f.callerName,f.rel],['Lillian','Park',83,'Daniel Park','Son']);
  assert.strictEqual(f.payer,'CalAIM Community Supports');assert.strictEqual(f.moveIn,'2027-01-05');assert.strictEqual(f.building,'b3');
  assert.strictEqual(f.care,'Level 1 \u00b7 light assist');
});
test('admission and waiver documents are recognised',()=>{
  const a=C.parseLead(fx('sample-lic602a-margaret-silva'),ctx('doc'));
  assert.deepStrictEqual(a.docs.map(d=>d.key).sort(),['lic602a','tb']);assert.deepStrictEqual([a.fields.first,a.fields.last],['Margaret','Silva']);
  const w=C.parseLead(fx('sample-alw-assessment-isp'),ctx('doc'));
  assert.deepStrictEqual(w.docs.map(d=>d.key).sort(),['w_assess','w_isp']);assert.strictEqual(w.fields.tier,3);assert.strictEqual(w.fields.last,'Nguyen');
  assert.deepStrictEqual(C.detectDocs('LIC 603A RESIDENT APPRAISAL').map(d=>d.key),['lic603a']);
  assert.deepStrictEqual(C.detectDocs('Informing Notice\nParticipant: ...').map(d=>d.key),['w_informing']);
  assert.deepStrictEqual(C.detectDocs('Hospital face sheet. Long clinical note follows'.padEnd(600,'.')+' TB test pending'),[],'a passing mention deep in a referral is not a form');
});
test('dates and helpers',()=>{
  assert.strictEqual(C.findDate('move in Dec 3rd',new Date('2026-11-11T00:00:00')).date,'2026-12-03');
  assert.strictEqual(C.findDate('moving in the twenty-first of nothing',new Date('2026-11-11T00:00:00')),null);
  assert.strictEqual(C.findDate('on 3/2',new Date('2026-11-11T00:00:00')).date,'2027-03-02');
  assert.strictEqual(C.splitName('WHITFIELD, Eleanor').last,'Whitfield');
  assert.strictEqual(C.payerFrom('Medi-Cal assisted living waiver'),'ALW waiver');
  assert.strictEqual(C.relFrom('discharge planner'),'Case manager');
});
test('sample files ship and are real files of their type',()=>{
  const sig={pdf:'%PDF',docx:'PK',jpg:'\u00ff\u00d8\u00ff'};
  const files=fs.readdirSync(path.join(site,'samples'));
  assert.ok(files.length>=3);
  for(const f of files){const b=fs.readFileSync(path.join(site,'samples',f)).toString('latin1',0,4); const ext=f.split('.').pop(); assert.ok(b.startsWith(sig[ext]),f+' signature'); assert.match(f,/^sample-/);}
  for(const v of ['vendor/pdfjs/pdf.min.js','vendor/pdfjs/pdf.worker.min.js','vendor/mammoth.browser.min.js','vendor/tesseract/tesseract.min.js','vendor/tesseract/worker.min.js','vendor/tesseract/core/tesseract-core-simd-lstm.wasm.js','vendor/tesseract/core/tesseract-core-lstm.wasm.js','vendor/tesseract/lang/eng.traineddata.gz']) assert.ok(fs.existsSync(path.join(site,v)),v);
  const app=fs.readFileSync(path.join(site,'app.js'),'utf8');
  assert.match(app,/Complete the lead profile/);assert.match(app,/original file is encrypted and saved with the lead/);assert.match(app,/webkitSpeechRecognition/);
  assert.ok(!/https?:\/\/(cdn|unpkg|jsdelivr)/.test(app),'readers load from this site, not a CDN');
});


test('ordinary spoken introductions fill structured lead fields without copying the transcript to Notes',()=>{
 const buildings=require('../config/buildings.json');
 for(const text of ['Her name is Jane Example and she is 82. Her daughter Anna called. Phone is 555 222 3333. She wants The Pointe at Summit Hills and has CalAIM.','I have a new lead named Jane Example for The Pointe at Summit Hills.','Jane Example is 82 years old and needs assisted living at The Pointe at Summit Hills.']){
  const r=C.parseLead(text,{kind:'voice',buildings,today:'2026-11-12'});assert.strictEqual(r.fields.first,'Jane');assert.strictEqual(r.fields.last,'Example');assert.strictEqual(r.fields.building,'pointe');assert.strictEqual(r.fields.notes,undefined);
  if(text.startsWith('Her name')){assert.strictEqual(r.fields.age,82);assert.strictEqual(r.fields.callerName,'Anna');assert.strictEqual(r.fields.phone,'(555) 222-3333');assert.strictEqual(r.fields.payer,'CalAIM Community Supports');}
 }
 const r=C.parseLead('Her name is Jane Example. Note that her daughter prefers afternoon updates.',{kind:'voice',buildings});assert.strictEqual(r.fields.notes,'her daughter prefers afternoon updates.');
});


test('scanned LIC 602A table reads the resident name below numbered headings without capturing facility details',()=>{
 const text=`PHYSICIAN'S REPORT FOR RESIDENTIAL CARE FACILITIES FOR THE ELDERLY
LIC 602A
I. FACILITY INFORMATION
1. NAME OF FACILITY
FICTIONAL PREVIOUS FACILITY
2. TELEPHONE
(555) 010-6001
ll, RESIDENT/PATIENT INFORMATION (To be completed by the resident)
1. NAME (2, BIRTH DATE 13. AGE
RIVERA , JORDAN | 06/15/1944 | 84
ill, AUTHORIZATION FOR RELEASE OF MEDICAL INFORMATION
Patient's diagnosis
Form instructions: memory care, hospice, case manager.`;
 const f=C.parseLead(text,ctx('doc')).fields;assert.strictEqual(f.first,'Jordan');assert.strictEqual(f.last,'Rivera');assert.strictEqual(f.age,82,'age follows birth date rather than an OCR-misread age');assert.strictEqual(f.phone,undefined,'facility phone is not the resident contact');assert.strictEqual(f.callerName,undefined);assert.strictEqual(f.care,undefined,'printed medical form options are not completed care needs');assert.strictEqual(f.payer,undefined,'a 602 alone does not establish ALW enrollment');
 const blank=C.parseLead(text.replace('RIVERA , JORDAN | 06/15/1944 | 84',''),ctx('doc')).fields;assert.strictEqual(blank.first,undefined);assert.strictEqual(blank.last,undefined);
});

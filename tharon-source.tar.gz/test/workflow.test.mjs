import test from 'node:test';import assert from 'node:assert/strict';import {randomUUID} from 'node:crypto';
import {initialState,execute,engine} from '../server/engine.mjs';
const newid=()=> 'L_'+randomUUID();
function create(fields={}){const id=newid(),state=execute(initialState(false),'u1',{op:'createLead',createdId:id,args:[{first:'Fictional',last:'Workflow',building:'sierra',payer:'Private pay',...fields}]});return {id,state};}
test('a missed call requires an outcome and dated next action, stays open and surfaces again on the chosen date',()=>{
 let {id,state}=create();let tl=engine(state,'u1');state.leads[0].created=tl.addDays(-3)+'T10:00';tl=engine(state,'u1');const task=tl.allReminders('u1').find(x=>x.rule==='new_first_call');assert.ok(task);
 assert.throws(()=>execute(state,'u1',{op:'resolveTask',args:[task.id,{outcome:'no_answer',note:'No answer.'}],expectedVersion:1}),e=>e.status===422);
 assert.throws(()=>execute(state,'u2',{op:'resolveTask',args:[task.id,{outcome:'no_answer',note:'No answer.',nextAction:'Call again',nextDate:tl.addDays(3)}],expectedVersion:1}),e=>e.status===404);
 state=execute(state,'u1',{op:'resolveTask',createdId:'task_'+randomUUID(),args:[task.id,{outcome:'no_answer',note:'Left a voicemail.',nextAction:'Call daughter again',nextDate:tl.addDays(3)}],expectedVersion:1});
 tl=engine(state,'u1');const lead=tl.Lead(id);assert.equal(lead.stage,'new');assert.equal(lead.lastContact,null);assert.equal(lead.version,2);assert.equal(tl.upcomingTasks('u1').length,1);assert.ok(!tl.allReminders('u1').some(t=>t.leadId===id));assert.ok(lead.activity.some(a=>a.type==='followup'&&a.by==='u1'));
 state.tasks[0].due=tl.T;tl=engine(state,'u1');assert.equal(tl.allReminders('u1').find(t=>t.leadId===id).text,'Call daughter again');
});
test('program document receipts stay independent from the main referral action and do not create duplicate generic reminders',()=>{
 let {id,state}=create({payer:'CalAIM Community Supports'});let tl=engine(state,'u1');
 const reminder=tl.allReminders('u1').find(x=>x.leadId===id);assert.equal(reminder.rule,'county_step');assert.ok(!tl.allReminders('u1').some(x=>x.rule==='waiver_missing'));
 state=execute(state,'u1',{op:'setDoc',args:[id,'w_assess',{status:'received'}],expectedVersion:1});tl=engine(state,'u1');assert.equal(tl.Lead(id).wdocs.w_assess.status,'received');assert.equal(tl.countySummary(tl.Lead(id)).next.key,'building_fit','a received PDF is not building acceptance');
});

test('pending next actions transfer with the lead and the former owner cannot change them',()=>{
 let {id,state}=create();let tl=engine(state,'u1');state.leads[0].created=tl.addDays(-3)+'T10:00';tl=engine(state,'u1');const reminder=tl.allReminders('u1').find(t=>t.rule==='new_first_call');
 state=execute(state,'u1',{op:'resolveTask',createdId:'task_'+randomUUID(),args:[reminder.id,{outcome:'no_answer',note:'No answer.',nextAction:'Call again',nextDate:tl.addDays(1)}],expectedVersion:1});
 const taskId=state.tasks[0].id;state=execute(state,'u0',{op:'assign',args:[id,{rep:'u2'}],expectedVersion:2});assert.equal(state.tasks[0].rep,'u2');state.tasks[0].due=tl.T;
 assert.throws(()=>execute(state,'u1',{op:'resolveTask',args:[taskId,{outcome:'contacted',note:'Contacted.',nextAction:'Follow up',nextDate:tl.addDays(2)}],expectedVersion:3}),e=>e.status===404);
 assert.equal(engine(state,'u2').allReminders('u2').filter(t=>t.id===taskId).length,1);
});

test('the next-step form drives dated attention without recording a call or changing the lead stage',()=>{
 let {id,state}=create();let tl=engine(state,'u1');state.leads[0].created=tl.addDays(-4)+'T10:00';
 state=execute(state,'u1',{op:'updateLead',args:[id,{nextAction:'Obtain ISP packet',nextFollowUp:tl.addDays(3)}],expectedVersion:1});tl=engine(state,'u1');
 assert.equal(tl.Lead(id).stage,'new');assert.equal(tl.Lead(id).lastContact,null);assert.ok(tl.Lead(id).lastReviewedAt);assert.equal(tl.allReminders('u1').filter(t=>t.leadId===id).length,0);assert.equal(tl.upcomingTasks('u1')[0].text,'Obtain ISP packet');
 state.leads[0].nextFollowUp=tl.T;tl=engine(state,'u1');assert.equal(tl.allReminders('u1').find(t=>t.leadId===id).rule,'next_action');
 assert.throws(()=>execute(state,'u1',{op:'updateLead',args:[id,{nextAction:'',nextFollowUp:tl.T}],expectedVersion:2}),e=>e.status===422);
});

test('pending and approved program paperwork persists, assessment stays in sync, and a program switch does not inherit approval',()=>{
 let {id,state}=create({payer:'ALW waiver'});let lead=state.leads[0];
 state=execute(state,'u1',{op:'setDoc',args:[id,'w_isp',{status:'pending'}],expectedVersion:lead.version});lead=state.leads[0];assert.equal(lead.wdocs.w_isp.status,'pending');assert.ok(lead.wdocs.w_isp.requested);assert.ok(engine(state,'u1').docStats(lead).missing.includes('w_isp'));
 state=execute(state,'u1',{op:'setDoc',args:[id,'w_isp',{status:'approved'}],expectedVersion:lead.version});lead=state.leads[0];assert.ok(lead.wdocs.w_isp.approved);assert.ok(!engine(state,'u1').docStats(lead).missing.includes('w_isp'));
 state=execute(state,'u1',{op:'updateLead',args:[id,{assessmentStatus:'completed',programStatus:'approved'}],expectedVersion:lead.version});lead=state.leads[0];assert.equal(lead.wdocs.w_assess.status,'received');
 state=execute(state,'u1',{op:'updateLead',args:[id,{payer:'CalAIM Community Supports'}],expectedVersion:lead.version});lead=state.leads[0];assert.equal(lead.programStatus,'not_started');assert.equal(lead.wdocs.w_isp.status,'missing');
 state=execute(state,'u1',{op:'updateLead',args:[id,{payer:'ALW waiver'}],expectedVersion:lead.version});lead=state.leads[0];assert.equal(lead.programStatus,'approved');assert.equal(lead.wdocs.w_isp.status,'approved');assert.equal(lead.assessmentStatus,'completed');
 assert.throws(()=>execute(state,'u1',{op:'updateLead',args:[id,{programStatus:'made_up'}],expectedVersion:lead.version}),e=>e.status===422);
});

// Tharon Leads demo tests: read the real site files and exercise the data layer and assistant.
const test=require('node:test');const assert=require('node:assert');const fs=require('node:fs');const path=require('node:path');const vm=require('node:vm');
const site=path.join(__dirname,'..','site');
const read=f=>fs.readFileSync(path.join(site,f),'utf8');
const html=read('index.html'),app=read('app.js'),api=read('api.js'),asst=read('assistant.js'),data=read('data.js'),css=read('styles.css');
function boot(){
  const store={};const ctx={console,URLSearchParams,Date,JSON,Math,
    localStorage:{getItem:k=>store[k]||null,setItem:(k,v)=>{store[k]=String(v);}}};
  ctx.window=ctx; vm.createContext(ctx);
  for(const f of ['data.js','api.js','assistant.js']) vm.runInContext(read(f),ctx,{filename:f});
  return ctx;
}
test('page basics: title, viewport, banner, PWA, local assets',()=>{
  assert.match(html,/<meta name="viewport" content="width=device-width, initial-scale=1/);
  assert.match(html,/<title>[^<]{10,}<\/title>/);
  assert.match(html,/<strong>Demo<\/strong> — sample data only/);
  assert.match(html,/secure hosting/);
  assert.match(html,/rel="manifest" href="manifest.webmanifest"/);
  assert.match(html,/rel="apple-touch-icon"/);
  assert.ok(!/<script>(?!<\/script>)/.test(html),'no inline scripts');
  assert.ok(!/onclick=/.test(html+app),'no inline handlers');
  for(const m of html.matchAll(/(?:src|href)="([^"#:]+)"/g)) assert.ok(fs.existsSync(path.join(site,m[1].split(/[?#]/)[0])),'missing '+m[1]);
  assert.ok(!/(?:src|href)="https?:/.test(html),'no remote scripts or styles');
  const man=JSON.parse(read('manifest.webmanifest'));
  assert.strictEqual(man.display,'standalone');
  for(const i of man.icons) assert.ok(fs.existsSync(path.join(site,i.src)),'icon '+i.src);
  assert.ok(man.icons.some(i=>i.sizes==='512x512')&&man.icons.some(i=>i.sizes==='192x192'));
  assert.match(read('sw.js'),/addEventListener\('fetch'/);
  assert.match(css,/\.tabbar\{display:grid/);
});
test('sample data: 7 users (1 admin), 4 buildings, leads in every stage',()=>{
  const c=boot();const s=c.TL.S;
  assert.strictEqual(s.users.length,7);assert.strictEqual(s.users.filter(u=>u.role==='admin').length,1);
  assert.strictEqual(s.buildings.length,4);
  for(const [k] of c.TL.STAGES) assert.ok(s.leads.some(l=>l.stage===k),'stage '+k);
  for(const f of ['LIC 602A','LIC 603A','LIC 601','LIC 604A','LIC 613C-2','LIC 627C','LIC 605A','TB test']) assert.ok(c.TL.DOCS.some(d=>d.form===f),f);
  assert.ok(!/HIPAA compliant/i.test(html+app+api+asst+data));
  assert.ok(!/lorem ipsum|\bTODO\b|PLACEHOLDER/.test(html+app+api+asst+data),'no unfilled placeholders');
});
test('reminders keep contact follow-ups and omit unrelated admission paperwork',()=>{
  const c=boot();const r=c.TL.allReminders('all').map(x=>x.text);
  assert.ok(r.some(t=>/Call back Linda Hayes .*3 days since the tour/.test(t)),'post-tour call back');
  assert.ok(!r.some(t=>/LIC 602A still missing for Margaret Silva/.test(t)),'private pay has no program checklist');
  assert.ok(!r.some(t=>/admission agreement unsigned/.test(t)),'untracked agreements do not generate tasks');
  const maria=c.TL.allReminders('u1');assert.ok(maria.length>0&&maria.every(x=>x.rep==='u1'));
});
test('editable rules change the Today list',()=>{
  const c=boot();const before=c.TL.allReminders('all').filter(x=>x.rule==='post_tour').length;
  c.TL.S.rules.find(r=>r.id==='post_tour').days=10;
  assert.ok(c.TL.allReminders('all').filter(x=>x.rule==='post_tour').length<before);
});
test('paperwork: marking a document missing emits document.missing and creates a follow-up',()=>{
  const c=boot();const l=c.TL.S.leads.find(x=>x.last==='Price');l.payer='ALW waiver';
  c.TL.setDoc(l.id,'lic602a',{status:'missing',requested:c.TL.addDays(-4),due:c.TL.addDays(-1)});
  assert.ok(c.TL.S.events.some(e=>e.type==='document.missing'&&e.data.lead_id===l.id));
  assert.ok(c.TL.remindersFor(l).some(x=>x.docs&&x.docs.includes('lic602a')));
  c.TL.setDoc(l.id,'lic602a',{status:'received'});
  assert.ok(!c.TL.remindersFor(l).some(x=>x.docs&&x.docs.includes('lic602a')));
});
test('stage change, building assignment and open beds',()=>{
  const c=boot();const l=c.TL.S.leads.find(x=>x.last==='Silva');const b=c.TL.B('b1');const occ=b.occupied;
  c.TL.setStage(l.id,'movein');assert.strictEqual(b.occupied,occ+1);
  assert.ok(c.TL.S.events.some(e=>e.type==='lead.stage_changed'&&e.data.to==='movein'));
  c.TL.assign(l.id,{building:'b4'});assert.strictEqual(b.occupied,occ);
});
test('assistant answers the four example questions from local data',()=>{
  const c=boot();const A=c.TLAssistant.askLocal;
  assert.match(A('which leads are missing paperwork').html,/Albert Nguyen/);
  assert.match(A('which leads are missing paperwork').html,/Margaret Silva/);
  const d=A("what's due today for Maria").html;assert.match(d,/Maria has <b>\d+<\/b>/);
  assert.match(A('how many leads for Riverside this month').html,/<b>\d+<\/b> leads? for The Gardens of Riverside this month/);
  const r=A('assign the Cohen lead to Bakersfield');assert.match(r.html,/Ruth Cohen.*Hallmark of Bakersfield/);
  assert.notStrictEqual(c.TL.S.leads.find(x=>x.last==='Cohen').building,'b4','Ask must not mutate before explicit confirmation');assert.ok(r.proposal);c.TL[r.proposal.op](...r.proposal.args);assert.strictEqual(c.TL.S.leads.find(x=>x.last==='Cohen').building,'b4');
  assert.ok(c.TLAssistant.TOOLS.length>=8);
});
test('mock REST API and JSON round trip',()=>{
  const c=boot();const R=c.TL.request;
  assert.strictEqual(R('GET','/api/v1/buildings').body.data.length,4);
  const created=R('POST','/api/v1/leads',{first_name:'Test',last_name:'Person',contact:{name:'X',relationship:'Son'},building_id:'b2'});
  assert.strictEqual(created.status,201);assert.strictEqual(R('GET','/api/v1/leads/'+created.body.id).body.building_id,'b2');
  assert.strictEqual(R('POST','/api/v1/leads/'+created.body.id+'/stage',{stage:'contacted'}).body.stage,'contacted');
  const ex=c.TL.exportJson();assert.strictEqual(ex.format,'tharon-leads/v1');
  const c2=boot();c2.TL.S.leads.splice(0);assert.strictEqual(c2.TL.importJson(JSON.parse(JSON.stringify(ex)),'merge'),ex.leads.length);
});
test('sample CSV covers the importer columns',()=>{
  const c=boot();const csv=c.TL_CONST.SAMPLE_CSV.split('\n');
  assert.ok(csv.length>=6);assert.match(csv[0],/Resident name.*Referral source.*Payer.*Move-in date.*Building/);
});

test('handoff docs ship with the source',()=>{
  const root=path.join(__dirname,'..');
  for(const f of ['README.md','INTEGRATION.md','CODEX-HANDOFF.md']) assert.ok(fs.existsSync(path.join(root,f)),f);
  const h=fs.readFileSync(path.join(root,'CODEX-HANDOFF.md'),'utf8');
  for(const s of ['Step 0','BAA','audit_log','function calling','Twilio','SendGrid','React Native','TestFlight','GitHub']) assert.ok(h.includes(s),s);
  const i=fs.readFileSync(path.join(root,'INTEGRATION.md'),'utf8');
  for(const s of ['lead.created','lead.stage_changed','document.missing','/leads','/buildings','/documents','/tasks','/users','tharon-leads/v1']) assert.ok(i.includes(s),s);
  assert.ok(!/HIPAA compliant/.test(h.replace(/"HIPAA compliant"/g,'')+i),'never claims compliance');
});

test('ALW / CalAIM waiver checklist: items, sources, reminders, assistant',()=>{
  const c=boot();const TL=c.TL;
  const keys=TL.WDOCS.map(d=>d.key);
  for(const k of ['w_assess','w_hcode','w_informing','w_isp']) assert.ok(keys.includes(k),k);
  assert.strictEqual(TL.WDOCS.find(d=>d.key==='w_hcode').form,'H code','Steven\u2019s own label');
  for(const d of TL.WDOCS) assert.ok(d.verify||/^https:\/\/(www\.)?dhcs\.ca\.gov\//.test(d.src),d.key+' has a DHCS source or is marked verify');
  const alw=TL.S.leads.filter(l=>TL.program(l)==='alw'), cal=TL.S.leads.filter(l=>TL.program(l)==='calaim');
  assert.ok(alw.length>=3&&cal.length>=2);
  const nguyen=TL.S.leads.find(l=>l.last==='Nguyen');
  assert.ok(TL.remindersFor(nguyen).some(r=>r.rule==='waiver_missing'&&/ISP packet/.test(r.text)));
  TL.setDoc(nguyen.id,'w_isp',{status:'received'});TL.setDoc(nguyen.id,'w_assess',{status:'received'});
  assert.ok(!TL.remindersFor(nguyen).some(r=>r.rule==='waiver_missing'));
  assert.strictEqual(TL.wdocStats(nguyen).missing.length,0);
  const a=c.TLAssistant.askLocal('which ALW leads are missing the ISP');
  assert.match(a.html,/ALW leads? (are|is) missing the <b>ISP packet<\/b>/);assert.ok(!/Albert Nguyen/.test(a.html),'ticked lead drops off');
  assert.match(c.TLAssistant.askLocal('which calaim leads are missing the MCP authorization').html,/Rosalind Hughes/);
  const l=TL.createLead({first:'Test',last:'Person',building:'b1',payer:'CalAIM Community Supports',caller:{rel:'Self'}},'test');
  assert.ok(l.wdocs&&l.wdocs.w_mcp&&!l.wdocs.w_waitlist,'CalAIM gets the plan authorization, not the ALW slot');
  const api=TL.request('GET','/api/v1/leads/'+l.id+'/documents');
  assert.ok(api.body.data.some(d=>d.checklist==='waiver_medi_cal'&&d.key==='w_mcp'));
});

test('Hot / Warm / Cold: stale check-ins, escalation, closing, archive, auto-cool, chat',()=>{
  const c=boot();const TL=c.TL;const A=c.TLAssistant.askLocal;
  const L=n=>TL.S.leads.find(l=>l.last===n);
  assert.ok(TL.S.leads.filter(TL.isOpen).every(l=>['hot','warm','cold'].includes(l.temp)));
  const all=TL.allReminders('all');
  const tran=all.find(x=>x.rule==='checkin'&&x.leadId===L('Tran').id);
  assert.ok(tran&&/Any update on Beverly Tran\? Open \d+ days, no activity for \d+/.test(tran.text),'hot lead past 3 days gets a check-in');
  assert.ok(all.some(x=>x.rule==='checkin'&&x.leadId===L('Jensen').id),'warm lead past 7 days');
  const dec=all.find(x=>x.rule==='needs_decision');
  assert.ok(dec&&dec.leadId===L('Watts').id&&dec.rep==='u0','2 unanswered check-ins go to the admin');
  TL.setTemp(L('Tran').id,'warm','Check-in');
  assert.ok(!TL.allReminders('all').some(x=>x.checkin&&x.leadId===L('Tran').id),'answering clears it');
  assert.throws(()=>TL.closeLead(L('Cohen').id,'lost'),/reason/);
  const r=A('close the Cohen lead as lost, chose another facility');
  assert.match(r.html,/Proposed: Close Ruth Cohen as lost/);assert.ok(TL.isOpen(L('Cohen')),'asking alone cannot close a referral');TL[r.proposal.op](...r.proposal.args);
  assert.strictEqual(L('Cohen').stage,'lost');assert.ok(!TL.isOpen(L('Cohen')));assert.ok(TL.closedAt(L('Cohen')));
  assert.ok(TL.S.events.some(e=>e.type==='lead.closed'&&e.data.outcome==='lost'));
  TL.reopenLead(L('Cohen').id);assert.ok(TL.isOpen(L('Cohen')));assert.strictEqual(L('Cohen').temp,'hot');assert.strictEqual(L('Cohen').stage,'contacted');
  assert.match(A('which leads are stale').html,/stale leads?:.*Eugene Watts.*needs a decision/s);
  const ps=TL.pipelineStats(TL.S.leads);assert.ok(ps.open>0&&ps.stale>=2&&ps.avgAge>0);
  TL.S.checkin.autoCool=true; TL.sweep();
  assert.strictEqual(L('Watts').temp,'cold','9 idle days: hot -> warm -> cold, never closed');assert.ok(TL.isOpen(L('Watts')));
  assert.strictEqual(TL.toApi(L('Watts')).temperature,'cold');
});
test('API: stale filter, temperature PATCH, close and reopen',()=>{
  const c=boot();const TL=c.TL;const L=n=>TL.S.leads.find(l=>l.last===n);
  const st=TL.request('GET','/api/v1/leads?stale=true');
  assert.strictEqual(st.status,200);assert.ok(st.body.count>=2&&st.body.data.every(x=>x.stale&&x.status==='open'));
  const id=L('Tran').id;
  const p=TL.request('PATCH','/api/v1/leads/'+id,{temperature:'cold'});
  assert.strictEqual(p.body.temperature,'cold');assert.ok(TL.S.events.some(e=>e.type==='lead.temperature_changed'&&e.data.to==='cold'));
  const cl=TL.request('POST','/api/v1/leads/'+id+'/close',{outcome:'won'});
  assert.strictEqual(cl.body.status,'closed');assert.strictEqual(cl.body.close_outcome,'won');
  assert.ok(TL.request('GET','/api/v1/leads?status=closed').body.data.some(x=>x.id===id));
  const ro=TL.request('POST','/api/v1/leads/'+id+'/reopen');
  assert.strictEqual(ro.body.status,'open');assert.strictEqual(ro.body.temperature,'hot');
});

import test from 'node:test';
import assert from 'node:assert/strict';
import vm from 'node:vm';
import {readFileSync} from 'node:fs';
const source=readFileSync(new URL('../site/app.js',import.meta.url),'utf8');
function boot(){
 let rec;const timers=new Map(),reviews=[],messages=[];let seq=0;
 class Speech {constructor(){rec=this;this.stops=0;this.aborts=0;}start(){}stop(){this.stops++;}abort(){this.aborts++;}}
 const ctx={SRClass:Speech,VOICE:{on:false},UI:{},paintVoice:()=>{},voiceMsg:e=>e,$:()=>null,toast:m=>messages.push(m),openReview:t=>reviews.push(t),ask:()=>{},modal:()=>{},esc:x=>x,setTimeout:(fn,ms)=>{timers.set(++seq,{fn,ms});return seq;},clearTimeout:id=>timers.delete(id)};
 vm.createContext(ctx);vm.runInContext(source.slice(source.indexOf('function startVoice('),source.indexOf('const NEW_LEAD_RE')),ctx);
 const fire=ms=>{for(const [id,t] of [...timers])if(t.ms===ms){timers.delete(id);t.fn();}};
 return {ctx,reviews,messages,fire,rec:()=>rec};
}
test('Safari stop without an end event releases recognition and preserves interim text exactly once',()=>{
 const b=boot();b.ctx.startVoice('add');const rec=b.rec(),result=[{transcript:'Jane Example at Summit Hills'}];result.isFinal=false;rec.onresult({results:[result]});
 b.ctx.stopVoice();assert.equal(b.ctx.VOICE.on,false);assert.equal(rec.stops,1);b.ctx.startVoice('add');assert.equal(b.rec(),rec,'cannot open a second microphone while stopping');
 b.fire(1000);assert.equal(rec.aborts,1);assert.deepEqual(b.reviews,['Jane Example at Summit Hills']);rec.onend();assert.equal(b.reviews.length,1);
 b.ctx.startVoice('add');assert.notEqual(b.rec(),rec,'recording can restart');
});
test('no transcription produces a visible message and clears the recording state',()=>{
 const b=boot();b.ctx.startVoice('add');b.ctx.stopVoice();b.fire(1000);assert.equal(b.ctx.VOICE.on,false);assert.equal(b.ctx.VOICE.stopping,false);assert.deepEqual(b.messages,['no-speech']);assert.equal(b.reviews.length,0);
});
test('speech errors and the recording time limit cannot leave the microphone stuck',()=>{
 const b=boot();b.ctx.startVoice('add');b.rec().onerror({error:'not-allowed'});b.fire(1000);assert.equal(b.ctx.VOICE.on,false);assert.deepEqual(b.messages,['not-allowed']);
 b.ctx.startVoice('add');b.fire(60000);b.fire(1000);assert.equal(b.ctx.VOICE.on,false);assert.equal(b.rec().aborts,1);
});

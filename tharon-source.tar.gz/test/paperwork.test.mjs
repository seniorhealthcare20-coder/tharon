import test from 'node:test';
import assert from 'node:assert/strict';
import {randomUUID} from 'node:crypto';
import {initialState,execute,engine} from '../server/engine.mjs';

test('CalAIM key paperwork tracks document types and program items and keeps checklist, audit and detailed states in sync',()=>{
 const id='L_'+randomUUID();let state=execute(initialState(false),'u1',{op:'createLead',createdId:id,args:[{first:'Fictional',last:'Checklist',building:'sierra',payer:'CalAIM Community Supports'}]});
 let tl=engine(state,'u1'),items=tl.paperworkChecklist(tl.Lead(id));
 assert.deepEqual(Array.from(items,x=>x.key),['agreement','lic602a','hmp','w_assess','w_informing','w_isp']);
 assert.equal(items.find(x=>x.key==='w_isp').optional,true);
 assert.equal(items.find(x=>x.key==='w_informing').optional,true);
 let version=1;
 for(const key of ['agreement','lic602a','hmp','w_assess','w_informing','w_isp']){state=execute(state,'u1',{op:'setDoc',args:[id,key,{status:'received'}],expectedVersion:version++});}
 tl=engine(state,'u1');const lead=tl.Lead(id);assert.ok(tl.paperworkChecklist(lead).every(x=>x.status==='received'&&x.received));assert.equal(lead.docs.lic602a.status,'received');assert.equal(lead.wdocs.w_isp.status,'received');assert.ok(lead.activity.some(x=>x.type==='docs'&&x.by==='u1'&&x.text.includes('ISP')));
 state=execute(state,'u1',{op:'setDoc',args:[id,'w_informing',{status:'na'}],expectedVersion:version++});
 tl=engine(state,'u1');assert.equal(tl.paperworkChecklist(tl.Lead(id)).find(x=>x.key==='w_informing').status,'na');
 assert.throws(()=>execute(state,'u2',{op:'setDoc',args:[id,'w_isp',{status:'missing'}],expectedVersion:version}),e=>e.status===404);
});


test('document checklists work for private pay while program reminders stay scoped',()=>{
 const state=initialState(false),tl=engine(state,'u1');
 const lead={id:'scope',first:'Fictional',last:'Scope',payer:'Private pay',rep:'u1',stage:'paperwork',created:'2026-01-01',activity:[],caller:{},docs:{tb:{status:'missing',due:'2020-01-01'}}};
 assert.equal(tl.paperworkChecklist(lead).length,3);
 assert.equal(tl.docStats(lead).missing.length,3);
 assert.ok(!tl.remindersFor(lead).some(x=>x.docs?.length||x.rule==='movein_agreement'));
 for(const payer of ['ALW waiver','CalAIM Community Supports']){
  lead.payer=payer;lead.docs.lic602a={status:'missing',due:'2020-01-01'};
  assert.deepEqual(Array.from(tl.paperworkChecklist(lead),x=>x.key),['agreement','lic602a','hmp','w_assess','w_informing','w_isp']);
  assert.ok(tl.remindersFor(lead).some(x=>x.rule==='county_step'));
  assert.ok(!tl.remindersFor(lead).some(x=>x.docs?.includes('lic602a')),'the main program action replaces generic missing-document reminders');
  assert.ok(!tl.remindersFor(lead).some(x=>x.docs?.includes('tb')));
 }
});
